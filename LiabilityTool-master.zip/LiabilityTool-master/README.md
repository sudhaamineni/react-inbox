
# LiabilityTool
# LiabilityTool
ReactApp and sass, scss
Backend with Java flyway
