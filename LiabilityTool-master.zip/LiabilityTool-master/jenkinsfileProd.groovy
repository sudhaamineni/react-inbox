def DOCKER_REGISTRY
def MAJOR_BUILD_NUMBER = '1'
def APPLICATION_SERVER = "loon-server"
def APPLICATION_CLIENT = "loon-client"
def FULL_BUILD_VERSION = MAJOR_BUILD_NUMBER + '.0.' + SOURCE_BUILD_NUMBER
def JAR_FILE_NAME = "loon-server-staging-${FULL_BUILD_VERSION}.jar"
def CLIENT_ZIP_FILE_NAME = "loon-client-staging-${FULL_BUILD_VERSION}.zip"
def SERVICE_NOW_GROUP = 'XP_CTS_CHG'
def ORGANIZATION = 'CTS-Loon'
def DOCKER_IMAGE_URI = '/compozed/labs/ci-base-node-eight:1.1'
def ARTIFACTORY_SERVER_URL = "https://artifactory.allstate.com/artifactory/CTS-Compozed/CTS-Loon/loon-server-staging/${FULL_BUILD_VERSION}/${JAR_FILE_NAME}"
def ARTIFACTORY_CLIENT_URL = "https://artifactory.allstate.com/artifactory/CTS-Compozed/CTS-Loon/loon-client-staging/${FULL_BUILD_VERSION}/${CLIENT_ZIP_FILE_NAME}"

withEnv(["PIPELINE=staging",]) {
    node {
        stage('clean') {
            step([$class: 'WsCleanup'])
        }

        checkout scm
        DOCKER_REGISTRY = env.DOCKER_REGISTRY
    }

    node {
        docker.image(DOCKER_REGISTRY + DOCKER_IMAGE_URI).inside('--privileged') {
            withCredentials([
                    [
                            $class          : 'UsernamePasswordMultiBinding',
                            credentialsId   : 'CTS-Loon-System-ID',
                            passwordVariable: 'ARTIFACTORY_PASSWORD',
                            usernameVariable: 'ARTIFACTORY_USERNAME'
                    ],
                    [
                            $class          : 'UsernamePasswordMultiBinding',
                            credentialsId   : 'CTS-Loon-System-ID',
                            passwordVariable: 'CF_PASSWORD',
                            usernameVariable: 'CF_USERNAME'
                    ],
                    [
                            $class          : 'UsernamePasswordMultiBinding',
                            credentialsId   : 'CTS-Loon-PROD-RAVEN-USERID',
                            passwordVariable: 'RAVEN_PASSWORD',
                            usernameVariable: 'RAVEN_USERNAME'
                    ],
                    [
                            $class       : 'StringBinding',
                            credentialsId: 'LOON_CLIENT_API_KEY_PROD',
                            variable     : 'LOON_CLIENT_API_KEY_PROD'
                    ],
                    [
                            $class       : 'StringBinding',
                            credentialsId: 'LOONELIGIBILITY_ENCRYPTION_KEY',
                            variable     : 'LOONELIGIBILITY_ENCRYPTION_KEY'
                    ],
                    [
                            $class          : 'UsernamePasswordMultiBinding',
                            credentialsId   : 'CTS_Loon_PROD_MONGODB_ID',
                            passwordVariable: 'CTS_Loon_PROD_MONGODB_PASSWORD',
                            usernameVariable: 'CTS_Loon_PROD_MONGODB_USERNAME'
                    ],
                    [
                            $class          : 'UsernamePasswordMultiBinding',
                            credentialsId   : 'CTS-Loon-PROD-AuditLog',
                            passwordVariable: 'CTS_Loon_PROD_AuditLog_PASSWORD',
                            usernameVariable: 'CTS_Loon_PROD_AuditLog_USERNAME'
                    ],
                    [
                            $class       : 'StringBinding',
                            credentialsId: 'LEELA_PROD_KEY',
                            variable     : 'LEELA_PROD_KEY'
                    ],
                    [
                            $class       : 'StringBinding',
                            credentialsId: 'DCF_CLIENT_KEY_PROD',
                            variable     : 'DCF_CLIENT_KEY_PROD'
                    ],
                    [
                            $class       : 'StringBinding',
                            credentialsId: 'PARAKEET_API_KEY_PRODUCTION',
                            variable     : 'PARAKEET_API_KEY_PRODUCTION'
                    ],
                    [
                            $class       : 'StringBinding',
                            credentialsId: 'ORGDATA_PROD_CLIENT_KEY',
                            variable     : 'ORGDATA_PROD_CLIENT_KEY'
                    ],
                    [
                            $class       : 'StringBinding',
                            credentialsId: 'SKETCH_CLIENT_KEY_PROD',
                            variable     : 'SKETCH_CLIENT_KEY_PROD'
                    ]
            ]) {
                stage('Deploy Prod') {
                    parallel(
                        Client: {
                            step([$class          : 'ConveyorJenkinsPlugin',
                                  applicationName : "${APPLICATION_CLIENT}",
                                  artifactURL     : ARTIFACTORY_CLIENT_URL,
                                  environment     : 'prod-dmz',
                                  manifest        : """
                                      applications:
                                      - name: ${APPLICATION_CLIENT}
                                        disk_quota: 512M
                                        instances: 2
                                        memory: 128M
                                        space: PROD
                                        buildpacks:
                                        - staticfile_buildpack
                                        routes:
                                        - route: loon.icws.allstate.com
                                        services:
                                        - autoscaler
                                        env:
                                            LOON_BACKEND_URL: https://loon-server.platform.allstate.com
                                            LOONCLIENTAPIKEY: '${LOON_CLIENT_API_KEY_PROD}'
                                            LIABILITYANALYSIS_SYSTEMID: 2974
                                            DCF_CLIENTKEY: '${DCF_CLIENT_KEY_PROD}'
                                            DCF_URL: https://cts-duncan.platform.allstate.com
                                            PARAKEET_URL: https://ingkko.platform.allstate.com
                                            PARAKEET_API_KEY: '${PARAKEET_API_KEY_PRODUCTION}'
                                            SKETCH_URL: https://sketch-frontend-prod.platform.allstate.com
                                            SKETCH_CLIENT_KEY: '${SKETCH_CLIENT_KEY_PROD}'
                                            RADPRO_URL: https://rad-pro-server-prod.platform.allstate.com
                             """,
                                  organization    : ORGANIZATION,
                                  password        : PASSWORD,
                                  serviceNowGroup : SERVICE_NOW_GROUP,
                                  serviceNowUserID: 'CTS-Loon-System-ID',
                                  space           : 'PROD',
                                  username        : USERNAME,
                                  barometerId     : "0418000015FW"
                            ])
                        },
                        Server:
                            {
                                step([$class          : 'ConveyorJenkinsPlugin',
                                      applicationName : APPLICATION_SERVER,
                                      artifactURL     : ARTIFACTORY_SERVER_URL,
                                      environment     : 'prod-mpn',
                                      manifest        : """
                                  applications:
                                  - name: ${APPLICATION_SERVER}
                                    instances: 2
                                    memory: 1024M
                                    disk_quota: 1024M
                                    host: ${APPLICATION_SERVER}
                                    org: ${ORGANIZATION}
                                    space: PROD
                                    buildpacks:
                                    - java_buildpack_offline
                                    services:
                                    - autoscaler
                                    - redisCache
                                    env:
                                        LIABILITYANALYSIS_CLIENTAPIKEY: '${LOON_CLIENT_API_KEY_PROD}'
                                        LOONELIGIBILITY_ENCRYPTION_KEY: '${LOONELIGIBILITY_ENCRYPTION_KEY}'
                                        LOONELIGIBILITY_ENCRYPTION_KEYTAB-FILE: feeder_enc_DEV.keytab
                                        EXTERNALRESOURCES_USESTUBS: false
                                        LEELA_CLAIMURL: 'https://leela-nextgen-service-prod.platform.allstate.com/api/v1/claim/{}?claimParams={}'                                                
                                        LEELA_CLIENTKEY: '${LEELA_PROD_KEY}'
                                        SHADOW_ORGDATA_URL: 'https://cts-org-data-retriever-prod.platform.allstate.com/api/v1/nextgen/org/{}'
                                        SHADOW_ORGDATA_CLIENTKEY: '${ORGDATA_PROD_CLIENT_KEY}'
                                        NEXTGEN_USERID: SYSLOON
                                        NEXTGEN_URL: https://ngcomponents-ws.allstate.com/AllstateCTSNGComponents-WS/api/{}
                                        RAVEN_URL: 'https://ravenapi-ws.allstate.com/RavenAPI-ws/api/Liability'
                                        RAVEN_USERNAME: '${RAVEN_USERNAME}'
                                        RAVEN_PASSWORD: '${RAVEN_PASSWORD}'
                                        DCF_URL: https://cts-duncan.platform.allstate.com/v3/search?claimNumber={}&brandName=ALL&mimeType=image/jpeg
                                        DCF_CONTENTURL: https://cts-duncan.platform.allstate.com/v3/retrieve?alfrescoId={}&versionLabel=1.0
                                        DCF_STOREURL: https://cts-duncan.platform.allstate.com/v3/store
                                        DCF_CLIENTKEY: '${DCF_CLIENT_KEY_PROD}'
                                        PARAKEET_URL: https://ingkko.platform.allstate.com/recordedobjects/{}
                                        PARAKEET_NLP_URL: /recordedobjects/summary/transcripts/
                                        PARAKEET_API_KEY: '${PARAKEET_API_KEY_PRODUCTION}'
                                        GRIFFIN_URL: https://griffin-prod.platform.allstate.com/api/v1/claims/{}/appropriate-damages
                                        SPRING_PROFILES_ACTIVE: PRODUCTION
                                        SPRING_DATA_MONGODB_USERNAME: '${CTS_Loon_PROD_MONGODB_USERNAME}'
                                        SPRING_DATA_MONGODB_PASSWORD: '${CTS_Loon_PROD_MONGODB_PASSWORD}'
                                        SPRING_DATA_MONGODB_DATABASE: "A9PROD"
                                        SPRING_DATA_MONGODB_WRITECONCERN: "2"
                                        SPRING_DATA_MONGODB_TIMEOUT_SOCKET: "5000"
                                        SPRING_DATA_MONGODB_TIMEOUT_SERVERSELECT: "15000"
                                        SPRING_DATA_MONGODB_TIMEOUT_CONNECT: "5000"
                                        SPRING_DATA_MONGODB_SERVER[0]_HOST: "lxv5563.allstate.com"
                                        SPRING_DATA_MONGODB_SERVER[0]_PORT: "27010"
                                        SPRING_DATA_MONGODB_SERVER[1]_HOST: "lxv5564.allstate.com"
                                        SPRING_DATA_MONGODB_SERVER[1]_PORT: "27010"
                                        SPRING_DATA_MONGODB_SERVER[2]_HOST: "lxv5566.allstate.com"
                                        SPRING_DATA_MONGODB_SERVER[2]_PORT: "27010"
                                        SPRING_DATA_MONGODB_SERVER[3]_HOST: "lxv5567.allstate.com"
                                        SPRING_DATA_MONGODB_SERVER[3]_PORT: "27010"
                                        SPRING_DATA_MONGODB_REPLICASET: "MPODS-PROD-001"
                                        SPRING_KAFKA_BOOTSTRAP-SERVERS: 'lxe0961.allstate.com:9092, lxe0962.allstate.com:9092, lxe0963.allstate.com:9092, lxe0964.allstate.com:9092, lxe0965.allstate.com:9092'
                                        SPRING_KAFKA_TEMPLATE_DEFAULT-TOPIC: 'rtalab.allstate.claims.feeder.fnol_context_received'
                                        KAFKA_BOOTSTRAP: 'lxe0961.allstate.com:9092, lxe0962.allstate.com:9092, lxe0963.allstate.com:9092, lxe0964.allstate.com:9092, lxe0965.allstate.com:9092'
                                        KAFKA_GROUP: 'loonDev'
                                        KAFKA_FNOLTOPIC: 'rtalab.allstate.claims.feeder.fnol_context_received'
                                        KAFKA_AUTOMATEDLIABILITYTOPIC: 'rtalab.allstate.claims.feeder.sgl_response_received'
                                        FEATURE-SWITCHES_SAVESUMMARYDOCONSUBMIT: 'FALSE'
                                        FEATURE-SWITCHES_OPENSUMMARYDOCONSUCCESS: 'TRUE'
                                        FEATURE-SWITCHES_RENDERSKETCHTAB: 'TRUE'
                                        FEATURE-SWITCHES_SENDLIABILITYSCOREONSUBMIT: 'FALSE'
                                        FEATURE-SWITCHES_ENABLEADMIN: 'FALSE'
                                        FEATURE-SWITCHES_ENABLESETTLETAB: 'TRUE'
                                        FEATURE-SWITCHES_SUBMITSETTLEMENTFILENOTE: 'FALSE'
                                        FEATURE-SWITCHES_VALIDATECONTRIBUTINGFACTOREVIDENCE: 'FALSE'
                                        JBP_CONFIG_CONTAINER_CERTIFICATE_TRUST_STORE: '{enabled: true}'
                                        AUDITLOG_USERNAME: '${CTS_Loon_PROD_AuditLog_USERNAME}'
                                        AUDITLOG_PASSWORD: '${CTS_Loon_PROD_AuditLog_PASSWORD}'
                                        AUDITLOG_URL: 'https://cts-auditlog-v2-prod.platform.allstate.com/api/'
                                        AUDITLOG_BIRDWATCH-URL: 'https://cts-auditlog-v2-prod.platform.allstate.com'
                                        AUDITLOG_LOGINSERTSENABLED: 'true'
                                        LOGGING_APPLICATION_NAME: LiabilityTool
                                        HYSTRIX_COMMAND_CALLAUDITLOGSERVICE_ENABLEHYSTRIX: false
                                        HYSTRIX_COMMAND_CALLAUDITLOGSERVICE_EXECUTION_ISOLATION_THREAD_TIMEOUTINMILLISECONDS: 1000
                                        HYSTRIX_COMMAND_CALLAUDITLOGSERVICE_CIRCUITBREAKER_REQUESTVOLUMETHRESHOLD: 100
                                        HYSTRIX_COMMAND_CALLAUDITLOGSERVICE_CIRCUITBREAKER_ERRORTHRESHOLDPERCENTAGE: 20
                                        HYSTRIX_COMMAND_CALLAUDITLOGSERVICE_CIRCUITBREAKER_SLEEPWINDOWINMILLISECONDS: 300000
                                        HYSTRIX_COMMAND_THREADPOOL_DEFAULT_METRICS_ROLLINGSTATS_TIMEINMILLISECONDS: 300000
                                        KERBEROS_CONFIG: kafka-kerberos/krb5.conf
                                        KERBEROS_AUTH: kafka-kerberos/rtalab_feeder_nonprod.jaas
                                        MESSAGING_PARAKEET_NLP_QUEUE_NAME: DOES_NOT_EXIST
                                        MESSAGING_RECEIVE_TIMEOUT: 100000
                                        MESSAGING_CONNECTION_CACHE_SIZE: 10
                                        MESSAGING_CONSUMERS_MAX_CONCURRENT: 20
                                        MESSAGING_CONSUMERS_IDLE_CONCURRENT: 1
                                        MESSAGING_TIBCO_JNDI_INITIAL_CONTEXT_FACTORY: com.tibco.tibjms.naming.TibjmsInitialContextFactory
                                        MESSAGING_TIBCO_JNDI_URL: tibjmsnaming://tibjndi-qa.allstate.com:22320
                                        MESSAGING_TIBCO_JNDI_PRINCIPAL: claimsappsavc-ext
                                        MESSAGING_TIBCO_JNDI_CREDENTIALS: claims38408
                                        MESSAGING_TIBCO_JNDI_QUEUE_CONNECTION_FACTORY_NAME: DOES_NOT_EXIST
                                        MESSAGING_TIBCO_EMS_USERNAME: claimsappsavc-ext
                                        MESSAGING_TIBCO_EMS_PASSWORD: claims38408
                                        MESSAGING_TIBCO_EMS_CONNECTION_TIMEOUT: 30000
                                        MESSAGING_TIBCO_EMS_CONNECTION_ATTEMPTS: 6
                                        MESSAGING_TIBCO_EMS_RECONNECTION_TIMEOUT: 90000
                                        MESSAGING_TIBCO_EMS_RECONNECTION_ATTEMPTS: 6
                                        EMAIL_SMTPHOST: mail.allstate.com
                                        EMAIL_SMTPPORT: 25
                                        EMAIL_TO: parakeet@allstate.com
                                        EMAIL_FROM: loon@allstate.com
                         """,
                                      organization    : ORGANIZATION,
                                      password        : PASSWORD,
                                      serviceNowGroup : SERVICE_NOW_GROUP,
                                      serviceNowUserID: 'CTS-Loon-System-ID',
                                      space           : 'PROD',
                                      username        : USERNAME,
                                      barometerId     : "0418000015FW"
                                ])
                            }
                    )

                }
            }
        }
    }
}