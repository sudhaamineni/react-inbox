#!/bin/bash

rm -rf ./output/*
selenium-standalone start &
SPRING_PROFILES_ACTIVE=local
sleep 10
