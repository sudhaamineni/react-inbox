/**
 * @providesModule EmptyModule
 */
module.exports = '';