#!/bin/bash

kill $(ps -A | grep selenium-standalone | awk '{ print $1}')