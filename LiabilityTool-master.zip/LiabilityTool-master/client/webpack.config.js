const path = require('path');
const webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');
const WebpackUglifyJsPlugin = require('webpack-uglify-js-plugin');

const config = {
    target: 'web',
    output: {
        path: __dirname + '/dist', // Note: Physical files are only output by the production build task `npm run build`.
        publicPath: '/',
        filename: 'app-[hash].js'
    },
    devServer: {
        contentBase: path.resolve(__dirname, 'src')
    },
    plugins: [
        new webpack.HotModuleReplacementPlugin(),
        new webpack.NoEmitOnErrorsPlugin(),
        new HtmlWebpackPlugin({
            template: 'src/index.html',
            filename: 'index.html',
            favicon: 'src/main/assets/images/favicon.ico'
        }),
        new webpack.DefinePlugin({'process.env.NODE_ENV': `\"${process.env.NODE_ENV}\"`}),
        new WebpackUglifyJsPlugin({
            cacheFolder: path.resolve(__dirname, './node_modules/webpack_cached/'),
            minimize: true,
            sourceMap: process.env.NODE_ENV === 'local',
            output: {comments: false},
            compress: {warnings: false}
        }),
        new CopyWebpackPlugin([
            {
                from: 'Staticfile'
            },
            {
                from: 'node_modules/sketchy-bird/build/images',
                to: 'images',
            },
            {
                from: 'node_modules/sketchy-bird/build/fonts',
                to: 'fonts',
            },
            {
                from: 'src/ie-error.html',
                to: 'ie-error.html',
            }
        ])
    ],
    module: {
        loaders: [
            {
                test: /\.scss$/,
                loaders: ['style-loader', 'css-loader', 'resolve-url-loader', 'sass-loader?sourceMap']
            },
            {
                test: /\.css$/,
                loader: 'style-loader!css-loader!resolve-url-loader'
            },
            {
                test: /\.(woff|woff2|eot|ttf)$/,
                exclude: /node_modules/,
                loader: 'file-loader?limit=1024&name=fonts/[name].[ext]'
            },
            {
                test: /\.js?$/,
                exclude: /node_modules/,
                loader: 'babel-loader'
            },
            {
                test: /\.(gif|png|ico|svg)$/,
                loader: 'file-loader?&name=images/[name].[ext]'
            },
            {
                test: /\.(mp3|wav)$/,
                loader: 'file-loader?&name=sounds/[name].[ext]'
            },
            {
                test: /\.json$/,
                loader: 'json-loader'
            }
        ]
    },
};

const userId = process.env.NODE_ENV === 'localci' ? 'tst-loon2' :
    'tst-loon1';
    // 'tst-loon-ro';
const port = process.env.NODE_ENV === 'localci' ? '3010' : '3000';

if (process.env.NODE_ENV === 'dev' || process.env.NODE_ENV === 'production') {
    config.devtool = 'source-map';
    config.entry = ['./src/main/index.js'];
    config.plugins.push(new CopyWebpackPlugin([{from: 'nginx.conf'}]));
    config.plugins.push(new webpack.optimize.UglifyJsPlugin()); //minify everything
    config.plugins.push(new webpack.optimize.AggressiveMergingPlugin());//Merge chunks
    if (process.env.NODE_ENV === 'production') {
        config.mode = 'production';
    }
} else {
    config.devtool = 'eval-source-map';
    config.entry = [`webpack-dev-server/client?http://localhost:${port}`, 'webpack/hot/only-dev-server', './src/main/index.js'];
    config.devServer = {
        contentBase: './dist',
        proxy: {
            '/api': {
                target: 'http://localhost:8080',
                secure: false,
                headers: {
                    'iv-user': userId,
                    'iv-groups': 'loon-nonprod',
                    'api-key': '0e0fd21a-b1a4-4975-868d-3db9b3073ce4'
                }
            },
            '/v3/retrieve': {
                target: 'https://cts-duncan-staging-pt.platform-test.allstate.com',
                secure: false,
                changeOrigin: true,
                headers: {
                    'CLIENT_KEY': '46e7afc6-6151-4fe0-81c2-673cf6ea484b',
                    'SYSTEM_ID': '2974'
                }
            },
            '/recordedobjects': {
                target: 'https://ingkko-staging.apps.nonprod-mpn.ro11.allstate.com',
                secure: false,
                changeOrigin: true,
                headers: {
                    'api-key': '123456-654321'
                }
            },
            '/sketch': {
                target: 'https://sketch-frontend-uat.platform-test.allstate.com',
                secure: false,
                changeOrigin: true,
                headers: {
                    'iv-user': userId,
                    'client-key': '0632870e-e367-4c31-abaa-412314174db0'
                }
            },
            '/radpro': {
                target: 'https://rad-pro-server-uat.platform-test.allstate.com',
                secure: false,
                changeOrigin: true,
                pathRewrite: {'^/radpro' : ''},
            },
        }
    };
}

module.exports = config;
