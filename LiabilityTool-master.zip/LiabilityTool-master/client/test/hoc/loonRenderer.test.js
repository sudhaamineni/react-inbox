import React from 'react';
import {shallow} from 'enzyme';

import {LoonRenderer, mapDispatchToProps, mapStateToProps} from '../../src/main/hoc/loonRenderer';
import {Investigation as mockComponent} from '../../src/main/components/investigation/Investigation';
import {getClaimDataAction} from '../../src/main/actions/claimDataActions';

jest.unmock('../../src/main/hoc/loonRenderer');

describe('Given LoonRenderer component', () => {
    let wrapper;
    const mockHistory = {push: jest.fn()},
        mockGetClaimDataAction = jest.fn();

    beforeEach(() => {
        const ConditionalComponent = LoonRenderer(mockComponent);
        wrapper = shallow(
            <ConditionalComponent.WrappedComponent
                userRoles={['role1', 'role2']}
                locked={false}
                claimNumber={'123'}
                errorHeader={''}
                match={{path: '/investigate'}}
                history={mockHistory}
                getClaimDataAction={mockGetClaimDataAction}
            />
        );
        mockHistory.push.mockClear();
    });

    describe('When rendering root div', () => {
        it('should render without l-shell--status-bar style without error', () => {
            expect(wrapper.find('div').props().className).toBe('l-shell l-shell--masthead l-shell--1024 ');
        });

        it('should render with overflow style for initial fault tab', () => {
            wrapper.setProps({match: {path: '/initial-fault'}});
            expect(wrapper.find('div').props().className).toBe('l-shell l-shell--masthead l-shell--1024-overflow ');
        });

        it('should render with l-shell--status-bar style with error', () => {
            wrapper.setProps({errorHeader: 'error'});
            expect(wrapper.find('div').props().className).toBe('l-shell l-shell--masthead l-shell--1024 l-shell--status-bar');
        });
    });

    describe('When rendering NavigationHeader', () => {
        it('should render with showTabs prop as true when not rendering home page without error', () => {
            expect(wrapper.find('withRouter(Connect(NavigationHeader))').props().showTabs).toBe(true);
        });

        it('should render with showTabs prop as false with error', () => {
            wrapper.setProps({errorHeader: 'error'});
            expect(wrapper.find('withRouter(Connect(NavigationHeader))').props().showTabs).toBe(false);
        });

        it('should render with showTabs prop as false when rendering home page', () => {
            wrapper.setProps({match: {path: '/'}});
            expect(wrapper.find('withRouter(Connect(NavigationHeader))').props().showTabs).toBe(false);
        });

        it('should render with showTabs prop as false when rendering reports page', () => {
            wrapper.setProps({match: {path: '/rpt'}});
            expect(wrapper.find('withRouter(Connect(NavigationHeader))').props().showTabs).toBe(false);
        });
    });

    describe('When rendering LossDetailsHeader', () => {
        it('should render when not rendering home page without error', () => {
            expect(wrapper.find('Connect(LossDetailsHeader)').length).toBe(1);
        });

        it('should not render when error', () => {
            wrapper.setProps({errorHeader: 'error'});
            expect(wrapper.find('Connect(LossDetailsHeader)').length).toBe(0);
        });

        it('should not render when rendering home page', () => {
            wrapper.setProps({match: {path: '/'}});
            expect(wrapper.find('Connect(LossDetailsHeader)').length).toBe(0);
        });

        it('should not render when rendering report page', () => {
            wrapper.setProps({match: {path: '/rpt'}});
            expect(wrapper.find('Connect(LossDetailsHeader)').length).toBe(0);
        });

        it('should not render when claimNumber is empty', () => {
            wrapper.setProps({claimNumber: ''});
            expect(wrapper.find('Connect(LossDetailsHeader)').length).toBe(0);
        });
    });

    describe('When rendering passed component', () => {
        it('should render ErrorPage when unauthorized user value is undefined with error', () => {
            wrapper.setProps({userRoles: undefined, errorHeader: 'error'});
            expect(wrapper.find('Connect(ErrorPage)').exists()).toBe(true);
        });

        it('should render blank page when unauthorized user value is undefined with no error', () => {
            wrapper.setProps({userRoles: undefined});
            expect(wrapper.find(mockComponent).exists()).toBe(false);
        });

        it('should render ErrorPage when user is unauthorized', () => {
            wrapper.setProps({userRoles: []});
            expect(wrapper.find('Connect(ErrorPage)').exists()).toBe(true);
        });

        it('should render the report page if the current page is rpt, even when there is an error or claim number is missing', () => {
            wrapper.setProps(({
                claimNumber: '',
                match: {path: '/rpt'},
                errorHeader: 'error'
            }));
            expect(wrapper.find(mockComponent).exists()).toBe(true);
        });

        describe('When claim number is missing in store and not on home page', () => {
            it('should call getClaimDataAction when the claim number is available in session storage', () => {
                window.sessionStorage.setItem("loonWipClaimNumber", "000000001234");
                wrapper.setProps(({claimNumber: '', match: {path: '/notHome'}}));
                expect(mockGetClaimDataAction).toBeCalledWith('000000001234');
            });

            it('should navigate the user to the home page when the claim number is missing session storage', () => {
                window.sessionStorage.clear();
                wrapper.setProps(({claimNumber: '', match: {path: '/notHome'}}));
                expect(mockHistory.push).toBeCalledWith('/');
            });
        });

        it('should NOT navigate the user to the home page when the claim number is missing but already on the home page', () => {
            wrapper.setProps(({claimNumber: '', match: {path: '/'}}));
            expect(mockHistory.push).not.toBeCalled();
        });

        it('should NOT navigate the user to the home page when the claim number is available and not on the home page', () => {
            wrapper.setProps(({claimNumber: '123', match: {path: '/notHome'}}));
            expect(mockHistory.push).not.toBeCalled();
        });

        it('should render ErrorPage with error and not rendering home page', () => {
            wrapper.setProps({errorHeader: 'error'});
            expect(wrapper.find('Connect(ErrorPage)').exists()).toBe(true);
        });

        it('should render the passed component when all conditions are valid', () => {
            expect(wrapper.find(mockComponent).exists()).toBe(true);
        });
    });

    describe('Connect', () => {
        it('should connect state values as props', () => {
            const store = {
                user: {userId: 'user_id', userRoles: ['role1', 'role2']},
                claimData: {claimNumber: '123', initialFaultSubmitTime: "09/12/2018", locked: true},
                status: {errorHeader: 'An error occurred.'},
            };
            const router = {
                match: {path: '/investigate'},
                history: {push: jest.fn()}
            };
            const result = mapStateToProps(store, router);

            expect(result.userRoles).toEqual(['role1', 'role2']);
            expect(result.claimNumber).toEqual('123');
            expect(result.locked).toEqual(true);
            expect(result.initialFaultSubmitTime).toEqual('09/12/2018');
            expect(result.errorHeader).toEqual('An error occurred.');
            expect(result.match).toEqual({path: '/investigate'});
            expect(result.history).toEqual(router.history);
        });

        it('should connect dispatch actions as props', () => {
            const expected = {
                getClaimDataAction,
            };
            expect(mapDispatchToProps).toEqual(expected);
        });
    });
});
