import {getData, openBlob, postData} from '../src/main/httpClient';

import axios from 'axios';
import MockAdapter from 'axios-mock-adapter';

jest.unmock('../src/main/httpClient');
jest.unmock('lodash');

describe('httpClient', () => {
    describe('when making HTTP GET request', () => {
        let mockAdapter;

        beforeEach(() => {
            window.location.reload = jest.fn();
            mockAdapter = new MockAdapter(axios);
        });

        it('calls the backend for getData', () => {
            mockAdapter.onGet('url').reply(200, 'stuff');
            return getData('url').then((response) => {
                expect(response.status).toBe(200);
                expect(response.data).toEqual('stuff');
            });
        });

        it('returns error on call to the backend for getData that returns an error', () => {
            mockAdapter.onGet('url').reply(400, 'error stuff');
            return getData('url').catch((response) => {
                expect(response.status).toBe(400);
                expect(response.data).toEqual('error stuff');
            });
        });

        it('returns undefined when backend is unavailable to return a status', () => {
            mockAdapter.onGet('url').reply(null);
            return getData('url').catch((response) => {
                expect(response.data).toBe(undefined);
            });
        });

        describe('When ISAM expires', () => {
            it('reloads the page on 200 status', () => {
                mockAdapter.onGet('url').reply(200, 'html action: pkmslogin', {'content-type': 'text/html'});
                return getData('url').then(() => {
                    expect(window.location.reload).toBeCalledWith(true);
                });
            });

            it('reloads the page on error', () => {
                mockAdapter.onGet('url').reply(400, 'html action: pkmslogin', {'content-type': 'text/html'});
                return getData('url').catch(() => {
                    expect(window.location.reload).toBeCalledWith(true);
                });
            });
        });
    });

    describe('onBlob', () => {

        let mockAdapter;

        beforeEach(() => {
            URL.createObjectURL = jest.fn().mockReturnValue("myCreateObjectUrl");
            window.open= jest.fn();
            mockAdapter = new MockAdapter(axios);
        });

        it('should call get with the required params', () => {
            const spy = jest.spyOn(axios, 'get');
            openBlob("url", "data");

            expect(spy).toHaveBeenCalledWith('url', {"responseType": "blob"});
        });

        it('calls the window.open when get returns data', () => {
            mockAdapter.onGet('url', {responseType: 'blob'})
                .reply(200, 'data stuff');

            openBlob('url', 'pdf')
                .then(() => {
                    expect(window.open).toBeCalledWith("myCreateObjectUrl");
                    expect(window.open).not.toBeCalled();
                })
        });

        it('does not call window.open when  getData returns an error', () => {
            mockAdapter.onGet('url', {responseType: 'blob'})
                .reply(400, 'error stuff');

            openBlob('url', 'pdf')
                .catch(() => {
                expect(window.open).not.toBeCalled();
            });
        });

        it('returns error on call to the backend for getData that returns an error', () => {
            mockAdapter.onGet('url', {responseType: 'blob'})
                .reply(400, 'error stuff');

            openBlob('url','pdf').catch((error) => {
                expect(error.status).toBe(400);
                expect(error.data).toEqual('error stuff');
                expect(window.open).toBeCalled();
            });
        });


    });

    describe('when making HTTP POST request', () => {
        let mockAdapter;

        beforeEach(() => {
            window.location.reload = jest.fn();
            mockAdapter = new MockAdapter(axios);
        });

        it('calls the backend for postData', () => {
            mockAdapter.onPost('url').reply(200, 'stuff',);
            return postData('url', 'data').then((response) => {
                expect(response.status).toBe(200);
                expect(response.data).toEqual('stuff');
            });
        });

        it('calls the backend for postData', () => {
            mockAdapter.onPost('url').reply(400, 'error stuff',);
            return postData('url', 'data').catch((response) => {
                expect(response.status).toBe(400);
                expect(response.data).toEqual('error stuff');
            });
        });

        describe('When ISAM expires', () => {
            it('reloads the page on postData when status is ok', () => {
                mockAdapter.onPost('url').reply(200, 'stuff pkmslogin', {'content-type': 'text/html'});
                return postData('url', 'data').then(() => {
                    expect(window.location.reload).toBeCalledWith(true);
                });
            });

            it('reloads the page on postData error', () => {
                mockAdapter.onPost('url').reply(400, 'stuff pkmslogin', {'content-type': 'text/html'});
                return postData('url', 'data').catch(() => {
                    expect(window.location.reload).toBeCalledWith(true);
                });
            });
        });

        describe('passes timeout config', () => {
            it('should pass 30000 when called with no timeout', () => {
                const spy = jest.spyOn(axios, 'post');
                postData("url", "data");

                expect(spy).toHaveBeenCalledWith('url', 'data', {timeout: 30000});
            });

            it('should pass timeout', () => {
                const spy = jest.spyOn(axios, 'post');
                postData("url", "data", 0);

                expect(spy).toHaveBeenCalledWith('url', 'data', {timeout: 0});
            });
        });
    });
});