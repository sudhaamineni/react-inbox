jest.unmock('../src/main/LoonRouter');
jest.unmock('../src/main/actions/keepAliveActions');

import {shallow} from 'enzyme';
import React from 'react';

import LoonRouter from '../src/main/LoonRouter';

describe('Given LoonRouter', () => {
    let wrapper, theRoute;
    const mockStore = {
        dispatch: jest.fn(),
    };

    beforeEach(() => {
        wrapper = shallow(<LoonRouter store={mockStore}/>);
        theRoute = wrapper.props().children.props.children.props.children;
    });

    describe('When Routing', () => {
        let index = -1;
        beforeEach(() => {
            index++;
        });

        it('Then the router should have a /search route to LoonRenderer', () => {
            expect(theRoute[index].props.exact).toBe(true);
            expect(theRoute[index].props.path).toBe('/search');
        });

        it('Then the router should have a /investigate route', () => {
            expect(theRoute[index].props.exact).toBe(true);
            expect(theRoute[index].props.path).toBe('/investigate');
        });

        it('Then the router should have a /sketch route', () => {
            expect(theRoute[index].props.exact).toBe(true);
            expect(theRoute[index].props.path).toBe('/sketch');
        });

        it('Then the router should have a /liability route', () => {
            expect(theRoute[index].props.exact).toBe(true);
            expect(theRoute[index].props.path).toBe('/initial-fault');
        });

        it('Then the router should have a /settlement route', () => {
            expect(theRoute[index].props.exact).toBe(true);
            expect(theRoute[index].props.path).toBe('/settlement');
        });

        it('Then the router should have a /admin route', () => {
            expect(theRoute[index].props.exact).toBe(true);
            expect(theRoute[index].props.path).toBe('/admin');
        });

        it('Then the router should have a /next/review route', () => {
            expect(theRoute[index].props.exact).toBe(true);
            expect(theRoute[index].props.path).toBe('/next/review');
        });

        it('Then the router should have a /next route', () => {
            expect(theRoute[index].props.exact).toBe(true);
            expect(theRoute[index].props.path).toBe('/next');
        });

        it('Then the router should have /rpt route', () => {
            expect(theRoute[index].props.exact).toBe(true);
            expect(theRoute[index].props.path).toBe('/rpt');
        });

        it('Then the router should have a / route', () => {
            expect(theRoute[index].props.exact).toBe(true);
            expect(theRoute[index].props.path).toBe('/');
        });
    });

    describe('when mounting', () => {
        it('Then the router should call the setInterval to keep session alive', () => {
            wrapper.instance().componentDidMount();
            expect(setInterval).toBeCalledWith(wrapper.instance().keepAlive, 60 * 60 * 1000);
        });
    });

    describe('KeepAlive', () => {
        it('publishes sessionKeepAliveAction', () => {
            wrapper.instance().keepAlive();
            expect(mockStore.dispatch).toBeCalledWith({type: 'SESSION_KEEPALIVE'});
        });
    });
});