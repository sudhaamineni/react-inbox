jest.unmock("../../src/main/httpClient");
jest.unmock("../../src/main/sagas/keepAliveSagas");
jest.unmock("../../src/main/actions/keepAliveActions");

import {takeEvery} from "redux-saga";
import * as sagas from '../../src/main/sagas/keepAliveSagas';
import {testSaga} from "redux-saga-test-plan";
import {getData} from '../../src/main/httpClient';

describe('Keep Alive Session Sagas', () => {
    describe("checks session alive", () => {

        it('When SESSION_KEEPALIVE action IS DISPATCHED', () => {

            const watchSessionKeepaliveIterator = sagas.watchSessionKeepAlive();
            const expectedSessionKeepaliveActionIterator = takeEvery("SESSION_KEEPALIVE", sagas.sessionKeepalive());

            expect(watchSessionKeepaliveIterator.next().value).toEqual(expectedSessionKeepaliveActionIterator.next().value)
        });

        it('creates a keep alive session', () => {
            const url = '/api/v1/sessions';

            const mockAction = {type: 'SESSION_KEEPALIVE'};

            const mockResponse = {data: {}, status: 200};

            testSaga(sagas.sessionKeepalive, mockAction)
                .next()
                .call(getData, url)
                .next(mockResponse)
                .next()
                .isDone()
        });

        it('Does not rethrow exceptions returned from api call', () => {
            const url = '/api/v1/sessions';

            const mockAction = {type: 'SESSION_KEEPALIVE'};
            const mockError = {error: 'some error info'};

            testSaga(sagas.sessionKeepalive, mockAction)
                .next()
                .call(getData, url)
                .throw(mockError)
                .next()
                .isDone()

        })

    });
});