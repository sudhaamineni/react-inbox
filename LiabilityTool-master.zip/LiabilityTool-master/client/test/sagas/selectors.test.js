jest.unmock('../../src/main/sagas/selectors');

import {
    getClaimData,
    getFeatureSwitches,
    getUser,
    selectParticipants,
    selectVoiceAttachments
} from '../../src/main/sagas/selectors';

describe('Saga Selectors', () => {
    it('getUser returns user state object', () => {
        const mockState = {
            user: {
                userId: 'abc'
            },
        };
        expect(getUser(mockState)).toEqual({userId: 'abc'});
    });

    it('getClaimData returns claimData state object', () => {
        const mockState = {
            claimData: {
                claimNumber: '123'
            },
        };
        expect(getClaimData(mockState)).toEqual({claimNumber: '123'});
    });

    it('getFeatureSwitches returns featureSwitches state object', () => {
        const mockState = {
            featureSwitches: {
                enableAdmin: true
            },
        };
        expect(getFeatureSwitches(mockState)).toEqual({enableAdmin: true});
    });

    it('selectVoiceAttachments returns voiceAttachments from claimData state object', () => {
        const mockState = {
            claimData: {
                voiceAttachments: [{sourceVoiceId: '1'}]
            },
        };
        expect(selectVoiceAttachments(mockState)).toEqual([{sourceVoiceId: '1'}]);
    });

    it('selectParticipants returns participants from claimData state object', () => {
        const mockState = {
            claimData: {
                participants: [{participantPartyId: '1'}]
            },
        };
        expect(selectParticipants(mockState)).toEqual([{participantPartyId: '1'}]);
    });
});