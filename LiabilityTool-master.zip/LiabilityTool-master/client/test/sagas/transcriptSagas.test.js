import { getTranscriptData } from '../../src/main/sagas/transcriptSagas';
import { testSaga } from 'redux-saga-test-plan'
import { getTranscriptDataFailureAction, getTranscriptSuccessAction } from '../../src/main/actions/transcriptActions';
import { getData } from '../../src/main/httpClient';
import { getFeatureSwitches } from '../../src/main/sagas/selectors';

jest.unmock('../../src/main/sagas/transcriptSagas');
jest.unmock('../../test/helpers/sagaTestHelper');
jest.unmock('../../src/main/actions/transcriptActions');
jest.unmock('../../src/main/actions/claimDataActions');
jest.unmock('../../src/main/actions/errorActions');

describe('Transcript sagas', () => {
    describe('Get Transcripts Saga', () => {
        it('When the parakeet call is successful', () => {
            const mockHighlightEntities = [{
                highlightTexts: [{ beginIndex: 5, endIndex: 10 }]
            }];
            const mockAction = {
                type: 'GET_TRANSCRIPT',
                voiceId: 'voiceId',
                transcriptUrl: '/transcript_url',
                nlpUrl: '/nlp_url',
                highlightEntities: mockHighlightEntities
            };
            const mockTranscriptResponse = {
                data: {
                    recordingId: 'voiceId',
                    contents: [{ beginTime: 5.5 }]
                }
            };
            const mockNlpResponse = {
                data: {
                    recordingId: 'voiceId',
                    categories: [
                        { categoryName: 'abc' },
                        { categoryName: 'def' },
                    ]
                }
            };

            testSaga(getTranscriptData, mockAction)
                .next()
                .call(getData, '/transcript_url')
                .next(mockTranscriptResponse)
                .call(getData, '/nlp_url')
                .next(mockNlpResponse)
                .put(getTranscriptSuccessAction({
                    voiceId: 'voiceId',
                    transcriptData: mockTranscriptResponse.data.contents,
                    nlpData: mockNlpResponse.data.categories,
                    highlightEntities: mockHighlightEntities
                }))
                .next()
                .isDone()
        });

        it('When the backend call fails', () => {
            const mockAction = {
                type: 'GET_TRANSCRIPT',
                voiceId: 'voiceId',
                transcriptUrl: 'url'
            };

            testSaga(getTranscriptData, mockAction)
                .next()
                .throw()
                .put(getTranscriptDataFailureAction('voiceId'))
                .next()
                .isDone()
        });
    });
});
