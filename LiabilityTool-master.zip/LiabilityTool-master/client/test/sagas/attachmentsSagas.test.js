import { takeEvery } from "redux-saga";
import {
    getPhotoAttachments,
    getVoiceAttachments,
    saveEvidence,
    watchSaveEvidence
} from '../../src/main/sagas/attachmentsSagas';
import { getTranscriptData } from '../../src/main/sagas/transcriptSagas';
import { testSaga } from 'redux-saga-test-plan'
import {
    getPhotoAttachmentsFailureAction,
    getPhotoAttachmentsSuccessAction,
    getVoiceAttachmentsFailureAction,
    getVoiceAttachmentsSuccessAction
} from '../../src/main/actions/attachmentsActions';
import { getData, postData } from '../../src/main/httpClient';
import { setErrorMessagesAction, } from '../../src/main/actions/errorActions';

jest.unmock('../../src/main/sagas/attachmentsSagas');
jest.unmock('../../test/helpers/sagaTestHelper');
jest.unmock('../../src/main/actions/attachmentsActions');
jest.unmock('../../src/main/actions/errorActions');
jest.unmock('../../src/main/sagas/transcriptSagas');
jest.unmock('../../src/main/helpers/claimDataHelper');
jest.unmock('../../src/main/actions/errorActions');

describe('Get Attachments sagas', () => {
    describe('getPhotoAttachments', () => {
        it('When the backend call is successful', () => {
            const url = '/api/v1/liabilityanalysis/photoattachments/000000001234';
            const mockAction = {
                type: 'GET_PHOTO_ATTACHMENTS',
                claimNumber: '1234',
            };
            const mockResponse = {
                data: [{
                    photoAttachments: [{
                        dcfId: '1',
                        url: '1url'
                    }, {
                        dcfId: '2',
                        url: '2url'
                    }
                    ]
                }]
            };

            testSaga(getPhotoAttachments, mockAction)
                .next()
                .call(getData, url)
                .next(mockResponse)
                .put(getPhotoAttachmentsSuccessAction(mockResponse.data))
                .next(mockResponse)
                .isDone();
        });

        it('When the backend call is not successful', () => {
            const mockAction = {
                type: 'GET_PHOTO_ATTACHMENTS',
                claimNumber: '1234',
            };

            testSaga(getPhotoAttachments, mockAction)
                .next()
                .throw()
                .put(getPhotoAttachmentsFailureAction())
                .next()
                .isDone();
        });
    });

    describe('getVoiceAttachments', () => {
        it('When the backend call is successful', () => {
            const url = '/api/v1/liabilityanalysis/voiceattachments/000000001234';
            const mockAction = {
                type: 'GET_VOICE_ATTACHMENTS',
                claimNumber: '1234',
            };
            const mockResponse = {
                data: [{
                    sourceVoiceId: 'id1',
                    sourceTranscriptUrl: '/dcf/url?id=id1',
                    sourceNlpUrl: 'nlp_url_1',
                    highlightEntities: [{
                        highlightTexts: [{ beginIndex: 5, endIndex: 10 }, { beginIndex: 0, endIndex: 30 }]
                    }]
                }, {
                    sourceVoiceId: 'id2',
                    sourceTranscriptUrl: '/ghi/url=id=id2',
                    sourceNlpUrl: 'nlp_url_2',
                    highlightEntities: []
                }]
            };

            testSaga(getVoiceAttachments, mockAction)
                .next()
                .call(getData, url)
                .next(mockResponse)
                .put(getVoiceAttachmentsSuccessAction(mockResponse.data))
                .next(mockResponse)
                .fork(getTranscriptData, {
                    type: 'GET_TRANSCRIPT',
                    voiceId: 'id1',
                    transcriptUrl: '/dcf/url?id=id1',
                    nlpUrl: 'nlp_url_1',
                    highlightEntities: [{
                        highlightTexts: [{ beginIndex: 5, endIndex: 10 }, { beginIndex: 0, endIndex: 30 }]
                    }]
                })
                .next()
                .fork(getTranscriptData, {
                    type: 'GET_TRANSCRIPT',
                    voiceId: 'id2',
                    transcriptUrl: '/ghi/url=id=id2',
                    nlpUrl: 'nlp_url_2',
                    highlightEntities: []
                })
                .next()
                .isDone();
        });

        it('When the backend call is not successful', () => {
            const mockAction = {
                type: 'GET_VOICE_ATTACHMENTS',
                claimNumber: '1234',
            };

            testSaga(getVoiceAttachments, mockAction)
                .next()
                .throw()
                .put(getVoiceAttachmentsFailureAction())
                .next()
                .isDone();
        });
    });

    describe('Given the saveEvidence saga', () => {
        it('should take every action of type SAVE_EVIDENCE and call saveEvidence saga', () => {
            const watchIterator = watchSaveEvidence();
            const expectedIterator = takeEvery('SAVE_EVIDENCE', saveEvidence);

            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
        });

        describe('Given SAVE_EVIDENCE action is received', () => {
            const mockAction = {
                type: 'SAVE_EVIDENCE',
                claimNumber: '123',
                evidence: { id: 'evidenceId' }
            };

            it('should perform a post to the server', () => {
                testSaga(saveEvidence, mockAction)
                    .next()
                    .call(postData, '/api/v1/liabilityanalysis/000000000123/evidence', mockAction.evidence)
                    .next()
                    .isDone();
            });

            describe('When post to server errors out', () => {
                it('when error does not contain message header and description', () => {
                    const mockError = {
                        data: {
                            notMessageHeader: 'something else'
                        }
                    };

                    testSaga(saveEvidence, mockAction)
                        .next()
                        .call(postData, '/api/v1/liabilityanalysis/000000000123/evidence', mockAction.evidence)
                        .throw(mockError)
                        .put(setErrorMessagesAction('Our systems are currently unavailable',
                            'Our systems are currently unable to process your search. Please try again later.'))
                        .next()
                        .isDone();
                });

                it('when error contains message header and description', () => {
                    const mockError = {
                        data: {
                            messageHeader: 'Some header',
                            messageDescription: 'Some description'
                        }
                    };

                    testSaga(saveEvidence, mockAction)
                        .next()
                        .call(postData, '/api/v1/liabilityanalysis/000000000123/evidence', mockAction.evidence)
                        .throw(mockError)
                        .put(setErrorMessagesAction('Some header', 'Some description'))
                        .next()
                        .isDone();
                });
            });
        });
    });
});
