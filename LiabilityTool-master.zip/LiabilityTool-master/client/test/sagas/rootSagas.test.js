jest.unmock('../../src/main/sagas/rootSagas');
jest.unmock('../../src/main/sagas/claimDataSagas');
jest.unmock('../../src/main/sagas/submitSagas');
jest.unmock('../../src/main/sagas/initSagas');
jest.unmock('../../src/main/sagas/keepAliveSagas');
jest.unmock('../../src/main/sagas/signOutSagas');
jest.unmock('../../src/main/sagas/transcriptSagas');
jest.unmock('../../src/main/sagas/assignmentSagas');
jest.unmock('../../src/main/sagas/adminSagas');
jest.unmock('../../src/main/sagas/reportingSagas');
jest.unmock('../../src/main/sagas/eventSagas');
jest.unmock('../../src/main/sagas/attachmentsSagas');

import { fork } from 'redux-saga/effects';
import {
    watchGetClaimData,
    watchPhotoRotation,
    watchPhotoToggleBookmark,
    watchSaveClaimUnlock,
    watchSaveHighlight,
    watchSaveNoFaultAllocationIndicator,
    watchSaveReportedPci,
    watchSaveSketch,
    watchSaveUpdatedLossLocation,
    watchSaveVoiceParticipant
} from '../../src/main/sagas/claimDataSagas';
import {
    watchSubmitLiabilty,
    watchSubmitSettlement,
    watchUpdateDamageApportionment
} from '../../src/main/sagas/submitSagas';
import { init } from '../../src/main/sagas/initSagas';
import rootSagas from '../../src/main/sagas/rootSagas';
import { watchSessionKeepAlive } from '../../src/main/sagas/keepAliveSagas';
import { watchSignOut } from '../../src/main/sagas/signOutSagas';
import { watchInsertAssignmentClaimList } from '../../src/main/sagas/adminSagas';
import { watchGetNextAssignment, watchOnStartReviewTimeout } from '../../src/main/sagas/assignmentSagas';
import {
    watchGetClaimsByCreatedTime,
    watchGetInitialFaultPendingClaims,
    watchGetClaimsByInitialFaultSubmitted,
    watchGetReSubmittedClaims,
} from '../../src/main/sagas/reportingSagas';
import { watchRetrieveDiagram, watchSaveDiagram, watchSaveFalseDrag, watchSendFeedback } from 'sketchy-bird';
import {
    watchCreateEvent,
    watchRemoveEvent,
    watchUpdateDamages,
    watchUpdateEvent
} from '../../src/main/sagas/eventSagas';
import { watchSaveEvidence } from '../../src/main/sagas/attachmentsSagas';

describe('rootSaga', () => {
    it('initializes all sagas', () => {
        const rootSagaIterator = rootSagas();
        expect(rootSagaIterator.next().value).toEqual([
            fork(init),
            fork(watchGetClaimData),
            fork(watchSaveNoFaultAllocationIndicator),
            fork(watchSubmitLiabilty),
            fork(watchSessionKeepAlive),
            fork(watchSignOut),
            fork(watchSaveUpdatedLossLocation),
            fork(watchSaveHighlight),
            fork(watchGetNextAssignment),
            fork(watchInsertAssignmentClaimList),
            fork(watchPhotoToggleBookmark),
            fork(watchPhotoRotation),
            fork(watchOnStartReviewTimeout),
            fork(watchGetReSubmittedClaims),
            fork(watchSaveDiagram),
            fork(watchRetrieveDiagram),
            fork(watchSaveFalseDrag),
            fork(watchSendFeedback),
            fork(watchSaveSketch),
            fork(watchCreateEvent),
            fork(watchUpdateEvent),
            fork(watchRemoveEvent),
            fork(watchSaveVoiceParticipant),
            fork(watchUpdateDamageApportionment),
            fork(watchUpdateDamages),
            fork(watchSaveClaimUnlock),
            fork(watchSubmitSettlement),
            fork(watchSaveReportedPci),
            fork(watchSaveEvidence),
            fork(watchGetClaimsByCreatedTime),
            fork(watchGetInitialFaultPendingClaims),
            fork(watchGetClaimsByInitialFaultSubmitted)
        ]);
    });
});
