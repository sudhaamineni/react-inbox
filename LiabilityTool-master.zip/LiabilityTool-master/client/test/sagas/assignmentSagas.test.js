import {
    getNextAssignment,
    onStartReviewTimeout,
    watchGetNextAssignment,
    watchOnStartReviewTimeout
} from "../../src/main/sagas/assignmentSagas";
import {push} from "react-router-redux";
import {takeEvery} from "redux-saga";
import {getNextAssignmentSuccessAction,} from '../../src/main/actions/assignmentActions';
import {setErrorMessagesAction} from '../../src/main/actions/errorActions';
import {testSaga} from "redux-saga-test-plan";
import {getData, postData} from '../../src/main/httpClient'
import {clearClaimDataAction} from '../../src/main/actions/claimDataActions';

jest.unmock('../../src/main/sagas/assignmentSagas');
jest.unmock("../../src/main/actions/assignmentActions");
jest.unmock('../../test/helpers/sagaTestHelper');
jest.unmock('../../src/main/sagas/claimDataSagas');
jest.unmock('../../src/main/actions/errorActions');
jest.unmock("../../src/main/actions/claimDataActions");

describe('AssignmentSagas', () => {
    it('watchGetNextAssignment', () => {
        const watchIterator = watchGetNextAssignment();
        const expectedIterator = takeEvery('GET_NEXT_ASSIGNMENT', getNextAssignment);

        expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
        expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
    });

    describe('getNextAssignment', () => {
        it('When the backend call is successful and not already on target uri', () => {
            window.location.hash = '#/NotTargetPage';

            const url = `/api/v1/assignment/next`;
            const mockAction = {
                type: 'GET_NEXT_ASSIGNMENT'
            };
            const mockResponse = {
                data: {
                    claimNumber: '1234'
                }
            };
            const mockStore = {
                user: {
                    userId: "userId"
                }
            };

            testSaga(getNextAssignment, mockAction)
                .next()
                .call(getData, url)
                .next(mockResponse)
                .put(getNextAssignmentSuccessAction(mockResponse.data))
                .next(mockStore)
                .put(push('/next/review'))
                .next()
                .isDone()
        });

        it('When the backend call returns an error', () => {
            const mockAction = {
                type: 'GET_NEXT_ASSIGNMENT'
            };

            testSaga(getNextAssignment, mockAction)
                .next()
                .throw()
                .put(setErrorMessagesAction('Our systems are currently unavailable',
                    'Our systems are currently unable to process your search. Please try again later.'))
                .next()
                .isDone()
        });
    });

    it('watchOnStartReviewTimeout', () => {
        const watchIterator = watchOnStartReviewTimeout();
        const expectedIterator = takeEvery('ON_START_REVIEW_TIMEOUT', onStartReviewTimeout);

        expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
        expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
    });

    describe('onStartReviewTimeout', () => {
        it('When the backend call is successful', () => {
            testSaga(onStartReviewTimeout, {type: 'GET_NEXT_ASSIGNMENT'})
                .next()
                .put(clearClaimDataAction())
                .next()
                .put(push('/next'))
                .next()
                .call(postData, '/api/v1/assignment/status/a-rfa')
                .next()
                .isDone()
        });

        it('When the backend call is not successful', () => {
            testSaga(onStartReviewTimeout, {type: 'GET_NEXT_ASSIGNMENT'})
                .next()
                .put(clearClaimDataAction())
                .next()
                .put(push('/next'))
                .next()
                .throw()
                .put(setErrorMessagesAction('Our systems are currently unavailable',
                    'Our systems are currently unable to process your search. Please try again later.'))
                .next()
                .isDone()
        });
    });
});