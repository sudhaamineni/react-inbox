import {takeEvery} from 'redux-saga';
import {take} from 'redux-saga/effects';
import {push} from 'react-router-redux';
import {testSaga} from 'redux-saga-test-plan';
import {getClaimDataFailureAction, getClaimDataSuccessAction} from '../../src/main/actions/claimDataActions';
import {
    clearErrorMessagesAction,
    setErrorMessagesAction,
    setErrorWithClaimNumberAction
} from '../../src/main/actions/errorActions';
import {getData, postData} from '../../src/main/httpClient';
import * as selectors from '../../src/main/sagas/selectors';
import {
    getClaimData,
    getUrlToGoTo,
    saveClaimUnlock,
    saveHighlight,
    saveNoFaultAllocationIndicator,
    saveParticipantData,
    savePhotoAttachments,
    saveReportedPci,
    saveSketch,
    saveUpdatedLossLocation,
    saveVoiceAttachments,
    saveVoiceParticipant,
    watchGetClaimData,
    watchPhotoRotation,
    watchPhotoToggleBookmark,
    watchSaveAddFollowupRequestAction,
    watchSaveClaimDataLiabilityRangeUpdate,
    watchSaveClaimUnlock,
    watchSaveContributingFactor,
    watchSaveHighlight,
    watchSaveNoFaultAllocationIndicator,
    watchSaveReportedPci,
    watchSaveSketch,
    watchSaveUpdatedLossLocation,
    watchSaveVoiceParticipant
} from '../../src/main/sagas/claimDataSagas';
import {getPhotoAttachments, getVoiceAttachments} from '../../src/main/sagas/attachmentsSagas';

jest.unmock('../../src/main/sagas/claimDataSagas');
jest.unmock('../../src/main/sagas/attachmentsSagas');
jest.unmock('../../test/helpers/sagaTestHelper');
jest.unmock('../../src/main/actions/claimDataActions');
jest.unmock('../../src/main/actions/transcriptActions');
jest.unmock('../../src/main/actions/errorActions');
jest.unmock('../../src/main/helpers/claimDataHelper');

describe('Claim Data sagas', () => {
    describe('getClaimData', () => {
        it('When GET_CLAIMDATA action is dispatched', () => {
            const watchGetClaimDataActionIterator = watchGetClaimData();
            const expectedGetClaimDataActionIterator = takeEvery('GET_CLAIMDATA', getClaimData);

            expect(watchGetClaimDataActionIterator.next().value).toEqual(expectedGetClaimDataActionIterator.next().value);
            expect(watchGetClaimDataActionIterator.next().value).toEqual(expectedGetClaimDataActionIterator.next().value);
        });

        describe('When the backend call is successful', () => {
            let url, mockAction, mockPhotoAttachmentAction, mockVoiceAttachmentAction, mockResponse;

            beforeEach(() => {
                url = '/api/v1/liabilityanalysis/000000001234';

                mockAction = {
                    type: 'GET_CLAIMDATA',
                    claimNumber: '1234',
                };


                mockPhotoAttachmentAction = {
                    type: 'GET_PHOTO_ATTACHMENTS',
                    claimNumber: '000000001234',
                };

                mockVoiceAttachmentAction = {
                    type: 'GET_VOICE_ATTACHMENTS',
                    claimNumber: '000000001234',
                };

                mockResponse = {
                    data: {
                        claimNumber: '000000001234'
                    }
                };

            });

            it('when called from the home page', () => {
                window.sessionStorage.setItem = jest.fn();
                window.location.hash = '#/';

                testSaga(getClaimData, mockAction)
                    .next()
                    .call(getData, url)
                    .next(mockResponse)
                    .put(clearErrorMessagesAction())
                    .next(mockResponse)
                    .put(getClaimDataSuccessAction(mockResponse.data))
                    .next(mockResponse)
                    .put(push('/investigate'))
                    .next()
                    .fork(getPhotoAttachments, mockPhotoAttachmentAction)
                    .next()
                    .fork(getVoiceAttachments, mockVoiceAttachmentAction)
                    .next()
                    .isDone();

                expect(window.sessionStorage.setItem).toBeCalledWith('loonWipClaimNumber', '000000001234');
            });

            it('when called from not the home page (refresh action)', () => {
                window.sessionStorage.setItem = jest.fn();
                window.location.hash = '#/review';

                testSaga(getClaimData, mockAction)
                    .next()
                    .call(getData, url)
                    .next(mockResponse)
                    .put(clearErrorMessagesAction())
                    .next(mockResponse)
                    .put(getClaimDataSuccessAction(mockResponse.data))
                    .next(mockResponse)
                    .fork(getPhotoAttachments, mockPhotoAttachmentAction)
                    .next()
                    .fork(getVoiceAttachments, mockVoiceAttachmentAction)
                    .next()
                    .isDone();

                expect(window.sessionStorage.setItem).toBeCalledWith('loonWipClaimNumber', '000000001234');
            });
        });

        describe('When the backend call is not successful', () => {
            it('When the backend call fails with a Network Error', () => {
                const mockAction = {
                    type: 'GET_CLAIMDATA',
                    claimNumber: '1234',
                };
                const mockError = {
                    data: {
                        notMessageHeader: 'something else'
                    }
                };

                testSaga(getClaimData, mockAction)
                    .next()
                    .throw(mockError)
                    .put(getClaimDataFailureAction())
                    .next()
                    .put(setErrorWithClaimNumberAction('Our systems are currently unavailable',
                        'Our systems are currently unable to process your search. Please try again later.', undefined))
                    .next()
                    .put(push('/investigate'))
                    .next()
                    .isDone();
            });

            it('When the backend call fails with unavailable error', () => {
                const mockError = {
                    data: {
                        messageHeader: 'Our systems are currently unavailable',
                        messageDescription: 'Some error description',
                        newClaimNumber: undefined
                    }
                };

                const mockAction = {
                    type: 'GET_CLAIMDATA',
                    claimNumber: '1234',
                };

                testSaga(getClaimData, mockAction)
                    .next()
                    .throw(mockError)
                    .put(getClaimDataFailureAction())
                    .next()
                    .put(setErrorWithClaimNumberAction('Our systems are currently unavailable', 'Some error description', undefined))
                    .next()
                    .put(push('/investigate'))
                    .next()
                    .isDone();
            });

            it('When the backend call fails with a custom error', () => {
                const mockError = {
                    data: {
                        messageHeader: 'Some custom error',
                        messageDescription: 'Some error description',
                        newClaimNumber: undefined
                    }
                };

                const mockAction = {
                    type: 'GET_CLAIMDATA',
                    claimNumber: '1234',
                };

                testSaga(getClaimData, mockAction)
                    .next()
                    .throw(mockError)
                    .put(getClaimDataFailureAction())
                    .next()
                    .put(setErrorWithClaimNumberAction('Some custom error', 'Some error description', undefined))
                    .next()
                    .put(push('/'))
                    .next()
                    .isDone();
            });

            it('When the backend call fails with a custom error', () => {
                const mockError = {
                    data: {
                        messageHeader: 'Some custom error',
                        messageDescription: 'Some error description',
                        newClaimNumber: 'someNewClaimNumber'
                    }
                };

                const mockAction = {
                    type: 'GET_CLAIMDATA',
                    claimNumber: '1234',
                };

                testSaga(getClaimData, mockAction)
                    .next()
                    .throw(mockError)
                    .put(getClaimDataFailureAction())
                    .next()
                    .put(setErrorWithClaimNumberAction('Some custom error', 'Some error description', 'someNewClaimNumber'))
                    .next()
                    .put(push('/'))
                    .next()
                    .isDone();
            });
        });
    });

    describe('saveNoFaultAllocationIndicator', () => {
        it('When SAVE_NO_FAULT_IND action IS DISPATCHED', () => {
            const watchIterator = watchSaveNoFaultAllocationIndicator();
            const expectedIterator = takeEvery('SAVE_NO_FAULT_IND', saveNoFaultAllocationIndicator);

            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
        });

        describe('saveNoFaultAllocationIndicator saga', () => {
            it('performs a post to the backend', () => {
                const url = '/api/v1/liabilityanalysis/save-no-fault-ind/123';
                const mockAction = {
                    type: 'SAVE_NO_FAULT_IND',
                    claimNumber: '123',
                    noFaultAllocationAgreement: true,
                    noFaultAllocationResponse: true
                };
                const payload = {noFaultAllocationAgreement: true, noFaultAllocationResponse: true};

                testSaga(saveNoFaultAllocationIndicator, mockAction)
                    .next()
                    .call(postData, url, payload)
                    .next()
                    .isDone();
            });

            it('when an error occurred while performing a post to backend and error message is available', () => {
                const mockAction = {
                    type: 'SAVE_NO_FAULT_IND',
                };
                const mockError = {
                    data: {
                        messageHeader: 'error header',
                        messageDescription: 'error desc'
                    }
                };

                testSaga(saveNoFaultAllocationIndicator, mockAction)
                    .next()
                    .throw(mockError)
                    .put(setErrorMessagesAction('error header', 'error desc'))
                    .next()
                    .isDone();
            });

            it('when an error occurred while performing a post to backend and error message is available', () => {
                const mockAction = {
                    type: 'SAVE_NO_FAULT_IND',
                };
                const mockError = {
                    data: {
                        notMessageHeader: 'something else'
                    }
                };

                testSaga(saveNoFaultAllocationIndicator, mockAction)
                    .next()
                    .throw(mockError)
                    .put(setErrorMessagesAction('Our systems are currently unavailable',
                        'Our systems are currently unable to process your search. Please try again later.'))
                    .next()
                    .isDone();
            });
        });
    });

    describe('Given getUrlToGoTo function', () => {
        it('should return /investigate when window location is #/', () => {
            window.location.hash = '#/';
            expect(getUrlToGoTo()).toBe('/investigate');
        });

        it('should return /investigate when window location starts with #/investigate', () => {
            window.location.hash = '#/investigate';
            expect(getUrlToGoTo()).toBe('/investigate');
        });

        it('should return window locaton when window location is not #/ and does not start with #/investigate', () => {
            window.location.hash = '#/somethingElse';
            expect(getUrlToGoTo()).toBe('/somethingElse');
        });
    });

    describe('saveSketch', () => {
        it('When SAVE_SKETCH action IS DISPATCHED', () => {
            const watchIterator = watchSaveSketch();
            const expectedIterator = takeEvery('SAVE_SKETCH', saveSketch);

            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
        });

        it('should perform post and no error occurs', () => {
            const mockAction = {
                type: 'SAVE_SKETCH',
                sketch: {
                    imageSource: 'imageSource',
                    garageSource: 'garageSource',
                    notRequiredReason: 'no reason'
                }
            };
            const mockClaimData = {
                claimNumber: '123'
            };

            testSaga(saveSketch, mockAction)
                .next()
                .select(selectors.getClaimData)
                .next(mockClaimData)
                .call(postData, '/api/v1/liabilityanalysis/123/sketch', mockAction.sketch)
                .next()
                .isDone();
        });

        it('when an error occurred while performing a post to backend and error message is available', () => {
            const mockError = {
                data: {
                    messageHeader: 'error header',
                    messageDescription: 'error desc'
                }
            };
            const updatedBoolean = {
                claimNumber: '123'
            };
            const mockAction = {
                type: 'SAVE_SKETCH',
                updatedBoolean
            };

            testSaga(saveSketch, mockAction)
                .next()
                .throw(mockError)
                .put(setErrorMessagesAction('error header', 'error desc'))
                .next()
                .isDone();
        });

        it('when an error occurred while performing a post to backend and error message is available', () => {
            const mockError = {
                data: {
                    notMessageHeader: 'something else'
                }
            };
            const updatedBoolean = {
                claimNumber: '123'
            };
            const mockAction = {
                type: 'SAVE_SKETCH',
                updatedBoolean
            };

            testSaga(saveSketch, mockAction)
                .next()
                .throw(mockError)
                .put(setErrorMessagesAction('Our systems are currently unavailable',
                    'Our systems are currently unable to process your search. Please try again later.'))
                .next()
                .isDone();
        });
    });

    describe('Given saveHighlight saga', () => {
        it('When SAVE_HIGHLIGHT action IS DISPATCHED', () => {
            const watchIterator = watchSaveHighlight();
            const expectedIterator = takeEvery('SAVE_HIGHLIGHT', saveHighlight);

            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
        });

        describe('Given SAVE_HIGHLIGHT action is received', () => {
            let involvedParty = {
                participantId: '1',
                participantSourceId: '11',
                assetId: 'asset1',
                damageSections: [
                    'front',
                    'rear'
                ],
                contributingFactors: [
                    {
                        category: null,
                        reason: 'proper-lookout',
                        details: 'saw-other-party',
                        evidenceIds: ['evidenceId1', 'evidenceId3','evidence5']
                    }
                ],
                affectedParties: [
                    {
                        participantId: '2',
                        participantSourceId: '22',
                        assetId: 'B9763FCB7D843B1F',
                        passengerPartyIds: [],
                        affectedPercent: 12,
                        beginNegotiatingRange: 7,
                        endNegotiatingRange: 17,
                        submittedAffectedPercent: 12,
                        faultAllocationPercent: 1
                    }
                ]
            };
            const event =
                {id: '0', title: 'my first event title', severity: 1, involvedParties: [involvedParty]};
            const events = [event];
            const mockAction = {
                type: 'SAVE_HIGHLIGHT',
                claimNumber: '1',
                voiceId: '12',
                highlightEntities: [{id: 'highlight123'}],
                evidences: [{id: 'evidence123', sourceId: 'highlight123', type: 'highlight'}],
                events:events
            };
            const url = '/api/v1/liabilityanalysis/000000000001/12/highlight';
            const payload = {
                highlightEntities: mockAction.highlightEntities,
                evidences: mockAction.evidences,
                events:events
            };

            it('performs a post to the backend and no error occurs', () => {
                testSaga(saveHighlight, mockAction)
                    .next()
                    .call(postData, url, payload)
                    .next()
                    .isDone();
            });

            describe('performs a post to the backend and an error occurs', () => {
                it('when error does not contain message header and description', () => {
                    const mockError = {
                        data: {
                            notMessageHeader: 'something else'
                        }
                    };

                    testSaga(saveHighlight, mockAction)
                        .next()
                        .call(postData, url, payload)
                        .throw(mockError)
                        .put(setErrorMessagesAction('Our systems are currently unavailable',
                            'Our systems are currently unable to process your search. Please try again later.'))
                        .next()
                        .isDone();
                });

                it('when error contains message header and description', () => {
                    const mockError = {
                        data: {
                            messageHeader: 'Some header',
                            messageDescription: 'Some description'
                        }
                    };

                    testSaga(saveHighlight, mockAction)
                        .next()
                        .call(postData, url, payload)
                        .throw(mockError)
                        .put(setErrorMessagesAction('Some header', 'Some description'))
                        .next()
                        .isDone();
                });
            });
        });
    });

    describe('saveUpdatedLossLocation', () => {
        it('When SAVE_UPDATED_LOSS_LOCATION action IS DISPATCHED', () => {
            const watchSaveUpdatedLossLocationIterator = watchSaveUpdatedLossLocation();
            const expectedSaveUpdatedLossLocationIterator = takeEvery('SAVE_UPDATED_LOSS_LOCATION', saveUpdatedLossLocation);

            expect(watchSaveUpdatedLossLocationIterator.next().value).toEqual(expectedSaveUpdatedLossLocationIterator.next().value);
            expect(watchSaveUpdatedLossLocationIterator.next().value).toEqual(expectedSaveUpdatedLossLocationIterator.next().value);
        });

        it('should save updated loss location', () => {
            const mockAction = {
                type: 'SAVE_UPDATED_LOSS_LOCATION',
                claimNumber: '123',
                latitude: 1,
                longitude: 2,
                updatedLossLocation: 'new location'
            };

            testSaga(saveUpdatedLossLocation, mockAction)
                .next()
                .call(postData, '/api/v1/liabilityanalysis/losslocation/123', {
                    latitude: 1,
                    longitude: 2,
                    updatedLossLocation: 'new location'
                })
                .next()
                .isDone();
        });
    });

    describe('saveVoiceParticipant', () => {
        it('should watch SAVE_VOICE_PARTICIPANT actions', () => {
            const saveVoiceParticipantIterator = watchSaveVoiceParticipant();
            expect(saveVoiceParticipantIterator.next().value).toEqual(take('SAVE_VOICE_PARTICIPANT', saveVoiceParticipant));
            expect(saveVoiceParticipantIterator.next().done).toBe(false);
        });

        it('should get participant name and evidences and save it to backend when participant is selected', () => {
            const mockAction = {
                type: 'SAVE_VOICE_PARTICIPANT',
                claimNumber: '123',
                index: '1',
                participantSourceId: 'abc',
                callType: 'fnol'
            };

            const mockVoiceAttachments = [{
                participantSourceId: '',
                participantDisplayName: 'OTHER',
                sourceVoiceId: '50',
                sourceVoiceTitle: 'inquiry'
            }, {
                participantSourceId: 'xyz',
                participantDisplayName: 'my name',
                sourceVoiceId: '51',
                sourceVoiceTitle: 'inquiry',
            }, {
                participantSourceId: '',
                participantDisplayName: '',
                sourceVoiceId: '52',
            }];

            const mockParticipants = [{
                participantSourceId: 'xyz',
                firstName: 'my',
                lastName: 'name',
                name: 'my name'
            }, {
                participantSourceId: 'abc',
                firstName: '',
                lastName: '',
                organizationName: 'org name',
                name: 'org name'
            }
            ];

            const mockEvidences = [
                {type: 'highlight', callType: 'inquiry', sourceVoiceId: '50', participantDisplayName: 'OTHER'},
                {type: 'photo', photoUrl: '/myUrl'},
                {
                    type: 'highlight',
                    callType: 'inquiry',
                    sourceVoiceId: '51',
                    participantDisplayName: 'my name',
                    participantSourceId: 'xyz'
                }];

            const expectedSavedVoiceAttachments = [{
                participantSourceId: '',
                participantDisplayName: 'OTHER',
                sourceVoiceId: '50',
                sourceVoiceTitle: 'inquiry'
            }, {
                participantSourceId: 'abc',
                participantDisplayName: 'org name',
                sourceVoiceId: '51',
                sourceVoiceTitle: 'fnol',
            }, {
                participantSourceId: '',
                participantDisplayName: '',
                sourceVoiceId: '52',
            }];

            const expectedSavedEvidences = [
                {type: 'highlight', callType: 'inquiry', sourceVoiceId: '50', participantDisplayName: 'OTHER'},
                {type: 'photo', photoUrl: '/myUrl'},
                {
                    type: 'highlight',
                    callType: 'fnol',
                    sourceVoiceId: '51',
                    participantDisplayName: 'org name',
                    participantSourceId: 'abc'
                }];

            testSaga(saveVoiceParticipant, mockAction)
                .next()
                .select(selectors.selectVoiceAttachments)
                .next(mockVoiceAttachments)
                .select(selectors.selectParticipants)
                .next(mockParticipants)
                .select(selectors.selectEvidences)
                .next(mockEvidences)
                .call(saveVoiceAttachments, {
                    claimNumber: '123',
                    voiceAttachments: expectedSavedVoiceAttachments,
                    evidences: expectedSavedEvidences,
                })
                .next()
                .put({
                    type: 'SAVE_VOICE_PARTICIPANT_SUCCESS',
                    voiceAttachments: expectedSavedVoiceAttachments,
                    evidences: expectedSavedEvidences
                })
                .next()
                .isDone();
        });

        it('should save participant and evidences when display name of Other is selected', () => {
            const mockAction = {
                type: 'SAVE_VOICE_PARTICIPANT',
                claimNumber: '123',
                index: '1',
                participantSourceId: 'OTHER',
                callType: 'fnol',
            };

            const mockVoiceAttachments = [{
                participantSourceId: 'xyz',
                participantDisplayName: 'my name',
                sourceVoiceId: '50',
                sourceVoiceTitle: 'inquiry',
            }, {
                participantSourceId: 'xyz',
                participantDisplayName: 'my name',
                sourceVoiceId: '51',
                sourceVoiceTitle: 'loss-investigation',
            }, {
                participantSourceId: '',
                participantDisplayName: '',
                sourceVoiceId: '52',
                sourceVoiceTitle: 'my-cat-just-did-this-cute-thing',
            }];

            const mockEvidences = [
                {type: 'highlight', callType: 'inquiry', sourceVoiceId: '50', participantDisplayName: 'OTHER'},
                {type: 'photo', photoUrl: '/myUrl'},
                {
                    type: 'highlight',
                    callType: 'inquiry',
                    sourceVoiceId: '51',
                    participantDisplayName: 'my name',
                    participantSourceId: 'xyz'
                }];

            const mockParticipants = [{
                participantSourceId: 'xyz',
                firstName: 'my',
                lastName: 'name',
            }, {
                participantSourceId: 'abc',
                firstName: '',
                lastName: '',
                organizationName: 'org name',
            }
            ];

            const expectedSavedVoiceAttachments = [{
                participantSourceId: 'xyz',
                participantDisplayName: 'my name',
                sourceVoiceId: '50',
                sourceVoiceTitle: 'inquiry',
            }, {
                participantSourceId: '',
                participantDisplayName: 'Other',
                sourceVoiceId: '51',
                sourceVoiceTitle: 'fnol',
            }, {
                participantSourceId: '',
                participantDisplayName: '',
                sourceVoiceId: '52',
                sourceVoiceTitle: 'my-cat-just-did-this-cute-thing',
            }];

            const expectedSavedEvidences = [
                {type: 'highlight', callType: 'inquiry', sourceVoiceId: '50', participantDisplayName: 'OTHER'},
                {type: 'photo', photoUrl: '/myUrl'},
                {
                    type: 'highlight',
                    callType: 'fnol',
                    sourceVoiceId: '51',
                    participantDisplayName: 'Other',
                    participantSourceId: ''
                }];

            testSaga(saveVoiceParticipant, mockAction)
                .next()
                .select(selectors.selectVoiceAttachments)
                .next(mockVoiceAttachments)
                .select(selectors.selectParticipants)
                .next(mockParticipants)
                .select(selectors.selectEvidences)
                .next(mockEvidences)
                .call(saveVoiceAttachments, {
                    claimNumber: '123',
                    voiceAttachments: expectedSavedVoiceAttachments,
                    evidences: expectedSavedEvidences
                })
                .next()
                .put({
                    type: 'SAVE_VOICE_PARTICIPANT_SUCCESS',
                    voiceAttachments: expectedSavedVoiceAttachments,
                    evidences: expectedSavedEvidences
                })
                .next()
                .isDone();
        });
    });

    describe('saveClaimUnlock', () => {
        it('When SAVE_CLAIM_UNLOCK action IS DISPATCHED', () => {
            const watchIterator = watchSaveClaimUnlock();
            const expectedIterator = takeEvery('SAVE_CLAIM_UNLOCK', saveClaimUnlock);

            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
        });

        it('performs a post to the backend', () => {
            const url = '/api/v1/liabilityanalysis/claim-unlock/000000000123';
            const mockAction = {
                type: 'SAVE_CLAIM_UNLOCK',
                claimNumber: '123',
                reason: 'Other',
                description: 'description'
            };
            const payload = {
                unlockReason: 'Other',
                unlockDescription: 'description'
            };

            testSaga(saveClaimUnlock, mockAction)
                .next()
                .call(postData, url, payload)
                .next()
                .isDone();
        });

        it('when an error occurred while performing a post to backend and error message is available', () => {
            const mockAction = {
                type: 'SAVE_CLAIM_UNLOCK',
                claimNumber: '123',
                reason: 'Other',
                description: 'description'
            };
            const mockError = {
                data: {
                    messageHeader: 'error header',
                    messageDescription: 'error desc'
                }
            };

            testSaga(saveClaimUnlock, mockAction)
                .next()
                .throw(mockError)
                .put(setErrorMessagesAction('error header', 'error desc'))
                .next()
                .isDone();
        });

        it('when an error occurred while performing a post to backend and error message is available', () => {
            const mockAction = {
                type: 'SAVE_CLAIM_UNLOCK',
                claimNumber: '123',
                reason: 'Other',
                description: 'description'
            };
            const mockError = {
                data: {
                    notMessageHeader: 'something else'
                }
            };

            testSaga(saveClaimUnlock, mockAction)
                .next()
                .throw(mockError)
                .put(setErrorMessagesAction('Our systems are currently unavailable',
                    'Our systems are currently unable to process your search. Please try again later.'))
                .next()
                .isDone();
        });
    });

    describe('Given savePhotoAttachments', () => {
        let involvedParty = {
            participantId: '1',
            participantSourceId: '11',
            assetId: 'asset1',
            damageSections: [
                'front',
                'rear'
            ],
            contributingFactors: [
                {
                    category: null,
                    reason: 'proper-lookout',
                    details: 'saw-other-party',
                    evidenceIds: ['evidenceId3','evidence5']
                }
            ],
            affectedParties: [
                {
                    participantId: '2',
                    participantSourceId: '22',
                    assetId: 'B9763FCB7D843B1F',
                    passengerPartyIds: [],
                    affectedPercent: 12,
                    beginNegotiatingRange: 7,
                    endNegotiatingRange: 17,
                    submittedAffectedPercent: 12,
                    faultAllocationPercent: 1
                }
            ]
        };
        const event =
            {id: '0', title: 'my first event title', severity: 1, involvedParties: [involvedParty]};
        it('should watch for PHOTO_TOGGLE_BOOKMARK action and call savePhotoAttachments saga', () => {
            const watchIterator = watchPhotoToggleBookmark();
            const expectedIterator = takeEvery('PHOTO_TOGGLE_BOOKMARK', savePhotoAttachments);

            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
        });

        it('should watch for PHOTO_ROTATION action and call savePhotoAttachments saga', () => {
            const watchIterator = watchPhotoRotation();
            const expectedIterator = takeEvery('PHOTO_ROTATION', savePhotoAttachments);

            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
        });

        describe('Given savePhotoAttachments saga', () => {
            const mockAction = {
                type: 'PHOTO_TOGGLE_BOOKMARK',
                claimNumber: '1',
                participantSourceId: '12',
                photoAttachments: [{dcfId: 'photo123'}],
                evidences: [{id: 'evidence123', sourceId: 'photo123', type: 'photo'}],
                events:[event]
            };
            const url = '/api/v1/liabilityanalysis/000000000001/12/photo';
            const payload = {
                photoAttachments: mockAction.photoAttachments,
                evidences: mockAction.evidences,
                events:[event]
            };

            it('performs a post to the backend and no error occurs', () => {
                testSaga(savePhotoAttachments, mockAction)
                    .next()
                    .call(postData, url, payload)
                    .next()
                    .isDone();
            });

            describe('performs a post to the backend and an error occurs', () => {
                it('when error does not contain message header and description', () => {
                    const mockError = {
                        data: {
                            notMessageHeader: 'something else'
                        }
                    };

                    testSaga(savePhotoAttachments, mockAction)
                        .next()
                        .call(postData, url, payload)
                        .throw(mockError)
                        .put(setErrorMessagesAction('Our systems are currently unavailable',
                            'Our systems are currently unable to process your search. Please try again later.'))
                        .next()
                        .isDone();
                });

                it('when error contains message header and description', () => {
                    const mockError = {
                        data: {
                            messageHeader: 'Some header',
                            messageDescription: 'Some description'
                        }
                    };

                    testSaga(savePhotoAttachments, mockAction)
                        .next()
                        .call(postData, url, payload)
                        .throw(mockError)
                        .put(setErrorMessagesAction('Some header', 'Some description'))
                        .next()
                        .isDone();
                });
            });
        });
    });

    describe('saveReportedPci', () => {
        it('When SAVE_REPORTED_PCI action IS DISPATCHED', () => {
            const watchIterator = watchSaveReportedPci();
            const expectedIterator = takeEvery('SAVE_REPORTED_PCI', saveReportedPci);

            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
        });

        it('performs a post to the backend', () => {
            const url = '/api/v1/liabilityanalysis/000000000123/saveReportedPci';
            const mockAction = {
                type: 'SAVE_REPORTED_PCI',
                claimNumber: '123',
                reportedPciDate: new Date(),
                sourceVoiceId: "voiceid",
                transcriptId: "transcriptId",
                pciCategories: ['selection1', 'selection2']
            };
            const data = {
                reportedPciDate: mockAction.reportedPciDate,
                sourceVoiceId: "voiceid",
                transcriptId: "transcriptId",
                pciCategories: ['selection1', 'selection2']
            };

            testSaga(saveReportedPci, mockAction)
                .next()
                .call(postData, url, data)
                .next()
                .isDone();
        });

        it('when an error occurred while performing a post to backend and error message is available', () => {
            const mockAction = {
                type: 'SAVE_REPORTED_PCI',
                claimNumber: '123',
                sourceVoiceId: "voiceid",
                transcriptId: "transcriptId"
            };
            const mockError = {
                data: {
                    messageHeader: 'error header',
                    messageDescription: 'error desc'
                }
            };

            testSaga(saveReportedPci, mockAction)
                .next()
                .throw(mockError)
                .put(setErrorMessagesAction('error header', 'error desc'))
                .next()
                .isDone();
        });

        it('when an error occurred while performing a post to backend and error message is available', () => {
            const mockAction = {
                type: 'SAVE_REPORTED_PCI',
                claimNumber: '123'
            };
            const mockError = {
                data: {
                    notMessageHeader: 'something else'
                }
            };

            testSaga(saveReportedPci, mockAction)
                .next()
                .throw(mockError)
                .put(setErrorMessagesAction('Our systems are currently unavailable',
                    'Our systems are currently unable to process your search. Please try again later.'))
                .next()
                .isDone();
        });
    });
});
