import * as selectors from "../../src/main/sagas/selectors";

jest.unmock('../../test/helpers/sagaTestHelper');
jest.unmock('../../src/main/sagas/submitSagas');
jest.unmock('../../src/main/actions/submitActions');
jest.unmock('../../src/main/actions/claimDataActions');
jest.unmock('../../src/main/actions/errorActions');

import {takeEvery} from 'redux-saga';
import {
    submitLiability,
    submitSettlement,
    updateDamageApportionment,
    watchSubmitLiabilty,
    watchSubmitSettlement,
    watchUpdateDamageApportionment
} from '../../src/main/sagas/submitSagas';
import {testSaga} from 'redux-saga-test-plan'
import {
    submitLiabilityErrorAction,
    submitLiabilitySuccessAction,
    submitSettlementErrorAction,
    submitSettlementSuccessAction
} from '../../src/main/actions/submitActions';
import {getClaimDataSuccessAction} from '../../src/main/actions/claimDataActions';
import {openBlob, postData} from '../../src/main/httpClient';
import {setErrorMessagesAction} from '../../src/main/actions/errorActions';
import {getCurrentTime} from '../../src/main/helpers/dateTimeHelper';

describe('Submit sagas', () => {
    beforeEach(() => {
        getCurrentTime.mockReturnValue('cur time');
    });

    describe('Submit liability Saga', () => {
        it('When SEND_SUBMITTED action IS DISPATCHED', () => {
            const watchSubmittedActionIterator = watchSubmitLiabilty();
            const expectedSubmittedActionIterator = takeEvery('SUBMIT_LIABILITY', submitLiability);

            expect(watchSubmittedActionIterator.next().value).toEqual(expectedSubmittedActionIterator.next().value);
            expect(watchSubmittedActionIterator.next().value).toEqual(expectedSubmittedActionIterator.next().value);
        });

        it('submitLiability calls postData with claimData and mapImage and also calls summary pdf url if openSummaryDocOnSuccess is true', () => {
            const url = '/api/v1/liabilitydecision';
            const liabilityAnalysisEntity = {
                claimNumber: '012345678',
                claimId: '123',
                locked: true
            };
            const claimData = {
                claimNumber: '012345678',
                claimId: '123'
            };
            const mockAction = {
                type: 'SUBMIT_LIABILITY',
                claimData,
                mapImage: 'the map image content'
            };
            const payload = {
                liabilityAnalysisEntity,
                mapImage: 'the map image content',
            };
            const mockResponse = {data: {}};
            const mockFeatureSwitch ={openSummaryDocOnSuccess: true}

            testSaga(submitLiability, mockAction)
                .next()
                .call(postData, url, payload, 0)
                .next(mockResponse)
                .put(submitLiabilitySuccessAction(mockResponse.data))
                .next()
                .select(selectors.getFeatureSwitches)
                .next(mockFeatureSwitch)
                .call(openBlob, '/api/v1/liabilitydecision/012345678/summary-pdf', 'application/pdf')
                .next()
                .isDone();
        });

        it('submitLiability calls postData with claimData and mapImageand also does not call summary pdf url if openSummaryDocOnSuccess is false', () => {
            const url = '/api/v1/liabilitydecision';
            const liabilityAnalysisEntity = {
                claimNumber: '012345678',
                claimId: '123',
                locked: true
            };
            const claimData = {
                claimNumber: '012345678',
                claimId: '123'
            };
            const mockAction = {
                type: 'SUBMIT_LIABILITY',
                claimData,
                mapImage: 'the map image content'
            };
            const payload = {
                liabilityAnalysisEntity,
                mapImage: 'the map image content',
            };
            const mockResponse = {data: {}};
            const mockFeatureSwitch ={openSummaryDocOnSuccess: false}

            testSaga(submitLiability, mockAction)
                .next()
                .call(postData, url, payload, 0)
                .next(mockResponse)
                .put(submitLiabilitySuccessAction(mockResponse.data))
                .next()
                .select(selectors.getFeatureSwitches)
                .next(mockFeatureSwitch)
                .isDone()
        });

        it('submitliability calls postData with liabilityAnalysisEntity but receives error', () => {
            const claimData = {
                claimNumber: '012345678',
                claimId: '123'
            };
            const mockAction = {type: 'SUBMIT_LIABILITY', claimData};

            testSaga(submitLiability, mockAction)
                .next()
                .throw()
                .put(submitLiabilityErrorAction())
                .next()
                .isDone();
        });
    });

    describe('Update damage apportionment Saga', () => {
        it('When UPDATE_DAMAGE_APPORTIONMENT action IS received', () => {
            const watchIterator = watchUpdateDamageApportionment();
            const expectedIterator = takeEvery('UPDATE_DAMAGE_APPORTIONMENT', updateDamageApportionment);

            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
        });

        it('posts data to backend and no error occurs', () => {
            const claimDataResponse = {claimNumber: '123'};
            const mockAction = {
                type: 'UPDATE_DAMAGE_APPORTIONMENT',
                claimNumber: '123'
            };
            testSaga(updateDamageApportionment, mockAction)
                .next()
                .call(postData, '/api/v1/liabilitydecision/123/damage-apportionment', {apportionedAllocatedFaultSaveTime: 'cur time'}, 0)
                .next({data: claimDataResponse})
                .put(getClaimDataSuccessAction(claimDataResponse))
                .next()
                .isDone();
        });

        describe('posts to backend and an error occurs', () => {
            it('when error does not contain message header and description', () => {
                const mockAction = {
                    type: 'UPDATE_DAMAGE_APPORTIONMENT',
                    claimNumber: '123'
                };
                const mockError = {
                    data: {
                        notMessageHeader: 'something else'
                    }
                };

                testSaga(updateDamageApportionment, mockAction)
                    .next()
                    .call(postData, '/api/v1/liabilitydecision/123/damage-apportionment', {apportionedAllocatedFaultSaveTime: 'cur time'}, 0)
                    .throw(mockError)
                    .put(setErrorMessagesAction('Our systems are currently unavailable',
                        'Our systems are currently unable to process your search. Please try again later.'))
                    .next()
                    .isDone();
            });

            it('when error contains message header and description', () => {
                const mockAction = {
                    type: 'UPDATE_DAMAGE_APPORTIONMENT',
                    claimNumber: '123'
                };
                const mockError = {
                    data: {
                        messageHeader: 'Some header',
                        messageDescription: 'Some description'
                    }
                };

                testSaga(updateDamageApportionment, mockAction)
                    .next()
                    .call(postData, '/api/v1/liabilitydecision/123/damage-apportionment', {apportionedAllocatedFaultSaveTime: 'cur time'}, 0)
                    .throw(mockError)
                    .put(setErrorMessagesAction('Some header', 'Some description'))
                    .next()
                    .isDone();
            });
        });
    });

    describe('Submit settlement saga', () => {
        it('should watch for the SUBMIT_SETTLEMENT action and call submitSettlement saga', () => {
            const watchIterator = watchSubmitSettlement();
            const expectedIterator = takeEvery('SUBMIT_SETTLEMENT', submitSettlement);

            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
        });

        it('posts data to backend and no error occurs', () => {
            const mockAction = {
                type: 'SUBMIT_SETTLEMENT',
                claimNumber: '123'
            };
            testSaga(submitSettlement, mockAction)
                .next()
                .call(postData, '/api/v1/liabilitydecision/123/submit-settlement', {}, 0)
                .next()
                .put(submitSettlementSuccessAction())
                .next()
                .isDone();
        });

        describe('posts to backend and an error occurs', () => {
            it('when error does not contain message header and description', () => {
                const mockAction = {
                    type: 'SUBMIT_SETTLEMENT',
                    claimNumber: '123'
                };
                const mockError = {
                    data: {
                        notMessageHeader: 'something else'
                    }
                };

                testSaga(submitSettlement, mockAction)
                    .next()
                    .call(postData, '/api/v1/liabilitydecision/123/submit-settlement', {}, 0)
                    .throw(mockError)
                    .put(submitSettlementErrorAction())
                    .next()
                    .isDone();
            });

            it('when error contains message header and description', () => {
                const mockAction = {
                    type: 'SUBMIT_SETTLEMENT',
                    claimNumber: '123'
                };
                const mockError = {
                    data: {
                        messageHeader: 'Some header',
                        messageDescription: 'Some description'
                    }
                };

                testSaga(submitSettlement, mockAction)
                    .next()
                    .call(postData, '/api/v1/liabilitydecision/123/submit-settlement', {}, 0)
                    .throw(mockError)
                    .put(submitSettlementErrorAction())
                    .next()
                    .isDone();
            });
        });
    });
});
