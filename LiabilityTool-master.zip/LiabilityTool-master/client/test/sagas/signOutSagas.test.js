jest.unmock('../../src/main/sagas/signOutSagas');

import {takeEvery} from 'redux-saga';
import {signOut, watchSignOut} from '../../src/main/sagas/signOutSagas';
import {getClaimData} from '../../src/main/sagas/selectors';
import {testSaga} from 'redux-saga-test-plan';
import {getData, postData} from '../../src/main/httpClient';
import {replace} from 'connected-react-router';

describe('SignOut Sagas', () => {
    beforeEach(() => {
        window.location.reload = jest.fn();
        window.sessionStorage.clear = jest.fn();
    });

    it('watches signOutAction', () => {
        const watchSignOutIterator = watchSignOut();
        const expectedSignOutIterator = takeEvery('SIGNOUT', signOut());

        expect(watchSignOutIterator.next().value).toEqual(expectedSignOutIterator.next().value);
    });

    describe('signOut', () => {
        describe('When claim data status is ASSIGNED', () => {
            it('clears sessionStorage, gets claim data from state, posts assignment status, logs out the user, and directs the user to the home page', () => {
                testSaga(signOut, {type: 'SIGNOUT'})
                    .next()
                    .select(getClaimData)
                    .next({status: 'ASSIGNED'})
                    .call(postData, '/api/v1/assignment/status/a-rfa')
                    .next()
                    .call(getData, '/pkmslogout')
                    .next()
                    .put(replace('/'))
                    .next()
                    .isDone();

                expect(window.location.reload).toBeCalledWith(true);
                expect(window.sessionStorage.clear).toHaveBeenCalled();
            });

            describe('When the backend call to update assignment status errors out', () => {
                it('clears sessionStorage, gets claim data from state, logs out the user, and directs the user to the home page', () => {
                    testSaga(signOut, {type: 'SIGNOUT'})
                        .next()
                        .select(getClaimData)
                        .next({status: 'ASSIGNED'})
                        .throw()
                        .call(getData, '/pkmslogout')
                        .next()
                        .put(replace('/'))
                        .next()
                        .isDone();

                    expect(window.location.reload).toBeCalledWith(true);
                    expect(window.sessionStorage.clear).toHaveBeenCalled();
                });
            });

            describe('When the logout call errors out', () => {
                it('clears sessionStorage, gets claim data from state, posts assignment status, and directs the user to the home page', () => {
                    testSaga(signOut, {type: 'SIGNOUT'})
                        .next()
                        .select(getClaimData)
                        .next({status: 'ASSIGNED'})
                        .call(postData, '/api/v1/assignment/status/a-rfa')
                        .next()
                        .throw()
                        .put(replace('/'))
                        .next()
                        .isDone();

                    expect(window.location.reload).toBeCalledWith(true);
                    expect(window.sessionStorage.clear).toHaveBeenCalled();
                });
            });
        });

        describe('When claim data status is not ASSIGNED', () => {
            it('clears sessionStorage, gets claim data from state, logs out the user, and directs the user to the home page', () => {
                testSaga(signOut, {type: 'SIGNOUT'})
                    .next()
                    .select(getClaimData)
                    .next({status: 'SOMETHING'})
                    .call(getData, '/pkmslogout')
                    .next()
                    .put(replace('/'))
                    .next()
                    .isDone();

                expect(window.location.reload).toBeCalledWith(true);
                expect(window.sessionStorage.clear).toHaveBeenCalled();
            });

            describe('When the logout call errors out', () => {
                it('clears sessionStorage, gets claim data from state, and directs the user to the home page', () => {
                    testSaga(signOut, {type: 'SIGNOUT'})
                        .next()
                        .select(getClaimData)
                        .next({status: 'SOMETHING'})
                        .throw()
                        .put(replace('/'))
                        .next()
                        .isDone();

                    expect(window.location.reload).toBeCalledWith(true);
                    expect(window.sessionStorage.clear).toHaveBeenCalled();
                });
            });
        });
    });
});