jest.unmock('../../src/main/sagas/adminSagas');
jest.unmock('../../test/helpers/sagaTestHelper');
jest.unmock("../../src/main/actions/adminActions");

import {takeEvery} from "redux-saga";
import {postData} from '../../src/main/httpClient';
import * as sagas from '../../src/main/sagas/adminSagas';
import {testSaga} from 'redux-saga-test-plan';
import {INSERT_ASSIGNMENT_CLAIM_LIST} from '../../src/main/actions/actionTypes';
import {insertAssignmentAdminSuccessAction, insertAssignmentAdminErrorAction} from '../../src/main/actions/adminActions';

describe('Admin sagas', () => {
    describe("Send com.allstate.cts.loon.admin Sagas", () => {
        it('When INSERT_ASSIGNMENT_CLAIM_LIST action IS DISPATCHED', () => {
            const watchInsertAssignmentClaimListActionIterator = sagas.watchInsertAssignmentClaimList();
            const expectedInsertAssignmentClaimListActionIterator = takeEvery(INSERT_ASSIGNMENT_CLAIM_LIST, sagas.insertAssignmentClaimList);

            expect(watchInsertAssignmentClaimListActionIterator.next().value).toEqual(expectedInsertAssignmentClaimListActionIterator.next().value);
            expect(watchInsertAssignmentClaimListActionIterator.next().value).toEqual(expectedInsertAssignmentClaimListActionIterator.next().value);
        });

        it('insertAssignmentClaimList calls postData with list of claimNumbers ,clearQueue value and useKafka value', () => {
            const url = '/api/v1/admin?clearQueue=true&useKafka=true';
            const claimNumberList = '0123   4, 333  33';
            const expectedClaimNumberList = ['01234', '33333']
            const mockAction = {type: 'INSERT_ASSIGNMENT_CLAIM_LIST', claimNumberList, clearQueue: true , useKafka: true};
            const mockResponse = {date: {}};

            testSaga(sagas.insertAssignmentClaimList, mockAction)
                .next()
                .call(postData, url, expectedClaimNumberList)
                .next(mockResponse)
                .put(insertAssignmentAdminSuccessAction())
                .next()
                .isDone()
        })

        it('insertAssignmentClaimList calls postData but receives an error ', () => {

            const claimNumberList = '01234, 33333';
            const mockAction = {type: INSERT_ASSIGNMENT_CLAIM_LIST, claimNumberList};
           testSaga(sagas.insertAssignmentClaimList,mockAction)
               .next()
               .throw()
               .put(insertAssignmentAdminErrorAction())
               .next()
               .isDone()
        });
    });
});