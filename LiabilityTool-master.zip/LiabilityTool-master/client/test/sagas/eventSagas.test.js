import {takeEvery} from 'redux-saga';
import {testSaga} from 'redux-saga-test-plan';
import {setErrorMessagesAction} from '../../src/main/actions/errorActions';
import {postData} from '../../src/main/httpClient';
import {padClaimNumber} from '../../src/main/helpers/claimDataHelper'
import {
    createEvent,
    removeEvent,
    updateDamages,
    updateEvent,
    watchCreateEvent,
    watchRemoveEvent,
    watchUpdateDamages,
    watchUpdateEvent,
} from '../../src/main/sagas/eventSagas';
import {getClaimData} from "../../src/main/sagas/selectors";

jest.unmock('../../src/main/sagas/eventSagas');
jest.unmock('../../src/main/actions/errorActions');

describe('Event sagas', () => {
    describe('createEvent', () => {
        it('When CREATE_EVENT action is dispatched', () => {
            const watchIterator = watchCreateEvent();
            const expectedIterator = takeEvery('CREATE_EVENT', createEvent);

            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
        });

        it('When the backend call is successful', () => {
            padClaimNumber.mockReturnValue('000000000123');
            const mockAction = {
                type: 'CREATE_EVENT',
                claimNumber: '123',
                event: {id: '1'}
            };
            testSaga(createEvent, mockAction)
                .next()
                .call(postData, '/api/v1/liabilityanalysis/event/create/000000000123', mockAction.event)
                .next()
                .isDone();
        });

        it('When the backend call is not successful and messageHeader is not available', () => {
            const mockAction = {
                type: 'CREATE_EVENT',
                claimNumber: '123',
                event: {id: '1'}
            };
            const mockError = {
                data: {
                    notMessageHeader: 'something else'
                }
            };

            testSaga(createEvent, mockAction)
                .next()
                .throw(mockError)
                .put(setErrorMessagesAction('Our systems are currently unavailable',
                    'Our systems are currently unable to process your search. Please try again later.'))
                .next()
                .isDone();
        });

        it('When the backend call is not successful and messageHeader is available', () => {
            const mockAction = {
                type: 'CREATE_EVENT',
                claimNumber: '123',
                event: {id: '1'}
            };
            const mockError = {
                data: {
                    messageHeader: 'blah',
                    messageDescription: 'blah desc'
                }
            };

            testSaga(createEvent, mockAction)
                .next()
                .throw(mockError)
                .put(setErrorMessagesAction('blah', 'blah desc'))
                .next()
                .isDone();
        });
    });

    describe('updateEvent', () => {
        it('When UPDATE_EVENT action is dispatched', () => {
            const watchIterator = watchUpdateEvent();
            const expectedIterator = takeEvery('UPDATE_EVENT', updateEvent);

            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
        });

        it('When the backend call is successful', () => {
            padClaimNumber.mockReturnValue('000000000123');
            const mockAction = {
                type: 'UPDATE_EVENT',
                claimNumber: '123',
                event: {id: '1'}
            };
            testSaga(updateEvent, mockAction)
                .next()
                .call(postData, '/api/v1/liabilityanalysis/event/update/000000000123', mockAction.event)
                .next()
                .isDone();
        });

        it('When the backend call is not successful and messageHeader is not available', () => {
            const mockAction = {
                type: 'UPDATE_EVENT',
                claimNumber: '123',
                event: {id: '1'}
            };
            const mockError = {
                data: {
                    notMessageHeader: 'something else'
                }
            };

            testSaga(updateEvent, mockAction)
                .next()
                .throw(mockError)
                .put(setErrorMessagesAction('Our systems are currently unavailable',
                    'Our systems are currently unable to process your search. Please try again later.'))
                .next()
                .isDone();
        });

        it('When the backend call is not successful and messageHeader is available', () => {
            const mockAction = {
                type: 'UPDATE_EVENT',
                claimNumber: '123',
                event: {id: '1'}
            };
            const mockError = {
                data: {
                    messageHeader: 'blah',
                    messageDescription: 'blah desc'
                }
            };

            testSaga(updateEvent, mockAction)
                .next()
                .throw(mockError)
                .put(setErrorMessagesAction('blah', 'blah desc'))
                .next()
                .isDone();
        });
    });

    describe('removeEvent', () => {
        it('When REMOVE_EVENT action is dispatched', () => {
            const watchIterator = watchRemoveEvent();
            const expectedIterator = takeEvery('REMOVE_EVENT', removeEvent);

            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
        });

        it('When the backend call is successful', () => {
            padClaimNumber.mockReturnValue('000000000123');
            const mockAction = {
                type: 'REMOVE_EVENT',
                claimNumber: '123',
                event: {id: '1'}
            };
            testSaga(removeEvent, mockAction)
                .next()
                .call(postData, '/api/v1/liabilityanalysis/event/remove/000000000123', mockAction.event)
                .next()
                .isDone();
        });

        it('When the backend call is not successful and messageHeader is not available', () => {
            const mockAction = {
                type: 'REMOVE_EVENT',
                claimNumber: '123',
                event: {id: '1'}
            };
            const mockError = {
                data: {
                    notMessageHeader: 'something else'
                }
            };

            testSaga(removeEvent, mockAction)
                .next()
                .throw(mockError)
                .put(setErrorMessagesAction('Our systems are currently unavailable',
                    'Our systems are currently unable to process your search. Please try again later.'))
                .next()
                .isDone();
        });

        it('When the backend call is not successful and messageHeader is available', () => {
            const mockAction = {
                type: 'REMOVE_EVENT',
                claimNumber: '123',
                event: {id: '1'}
            };
            const mockError = {
                data: {
                    messageHeader: 'blah',
                    messageDescription: 'blah desc'
                }
            };

            testSaga(removeEvent, mockAction)
                .next()
                .throw(mockError)
                .put(setErrorMessagesAction('blah', 'blah desc'))
                .next()
                .isDone();
        });
    });

    describe('updateDamages', () => {
        describe('When UPDATE_EVENT action is dispatched', () => {
            it('should take every UPDATE_EVENT', () => {
                const watchUpdateDamagesIterator = watchUpdateDamages();
                const expectedIterator = takeEvery('UPDATE_DAMAGES', updateDamages);

                expect(watchUpdateDamagesIterator.next().value).toEqual(expectedIterator.next().value);
                expect(watchUpdateDamagesIterator.next().value).toEqual(expectedIterator.next().value);
            });
        });
        describe('updateDamages', () => {

            it('when call is successful', () => {
                padClaimNumber.mockReturnValue('000000000789');
                const mockClaimData = {
                    claimNumber: '789',
                    events: [
                        {
                            involvedParties: [
                                {
                                    participantPartyId: '01', damageSections: ['back']
                                },
                                {
                                    participantPartyId: '02', damageSections: ['front']
                                }

                            ]
                        }
                    ]
                };
                const mockAction = {
                    type: 'UPDATE_DAMAGES',
                    eventIndex: 0,
                    involvedPartyIndex: 1,
                    damageSections: ['front', 'back']
                };

                const expectedUpdatedEvent = {
                    involvedParties: [
                        {
                            participantPartyId: '01', damageSections: ['back']
                        },
                        {
                            participantPartyId: '02', damageSections: ['front', 'back']
                        }

                    ]
                };

                testSaga(updateDamages, mockAction)
                    .next()
                    .select(getClaimData)
                    .next(mockClaimData)
                    .call(updateEvent, {claimNumber: '789', event: expectedUpdatedEvent})
                    .next()
                    .isDone();
            });

            it('when updateDamages fails messageHeader is not available', () => {
                    const mockAction = {
                        eventIndex: 0,
                        involvedPartyIndex: 1,
                        damageSections: ['front', 'back']
                    };
                    const mockError = {
                        data: {
                            notMessageHeader: 'something else'
                        }
                    };

                    testSaga(updateEvent, mockAction)
                        .next()
                        .throw(mockError)
                        .put(setErrorMessagesAction('Our systems are currently unavailable',
                            'Our systems are currently unable to process your search. Please try again later.'))
                        .next()
                        .isDone();
            });
        });
    });
});