jest.unmock('../../src/main/sagas/initSagas');
jest.unmock('../../test/helpers/sagaTestHelper');
jest.unmock('../../src/main/actions/initActions');
jest.unmock('../../src/main/actions/errorActions');

import {init} from '../../src/main/sagas/initSagas';
import {testSaga} from 'redux-saga-test-plan';
import {initFailureAction, initSuccessAction} from '../../src/main/actions/initActions';
import {getData} from '../../src/main/httpClient';

describe('Init sagas', () => {
    describe('init', () => {
        it('When backend call is successful', () => {
            const url = '/api/v1/init';
            const mockResponse = {
                data: {
                    userId: 'something',
                    userRoles: ['role1', 'role2'],
                    assignedClaimData: {claimNumber: '123'},
                    featureSwitches: {enableAdmin: true}
                },
                status: 200
            };

            testSaga(init)
                .next()
                .call(getData, url)
                .next(mockResponse)
                .put(initSuccessAction(mockResponse.data))
                .next()
                .isDone();
        });

        it('When backend call is not successful', () => {
            const url = '/api/v1/init';

            testSaga(init)
                .next()
                .call(getData, url)
                .throw({status: 500})
                .put(initFailureAction(500))
                .next()
                .isDone();
        });
    });
});
