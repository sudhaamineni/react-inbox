jest.unmock('../../src/main/sagas/reportingSagas');
jest.unmock('../../test/helpers/sagaTestHelper');
jest.unmock("../../src/main/actions/reportingActions");
jest.unmock("../../src/main/actions/errorActions");

import { takeEvery } from "redux-saga";
import { getData } from '../../src/main/httpClient';
import {
    getClaimsByCreatedTime,
    getInitialFaultPendingClaims,
    getClaimsByInitialFaultSubmitted,
    getReSubmittedClaims,
    watchGetClaimsByCreatedTime,
    watchGetInitialFaultPendingClaims,
    watchGetClaimsByInitialFaultSubmitted,
    watchGetReSubmittedClaims,
} from '../../src/main/sagas/reportingSagas';
import { testSaga } from 'redux-saga-test-plan';
import {
    getClaimsByCreatedTimeSuccessAction,
    getInitialFaultPendingClaimsSuccessAction,
    getReSubmittedClaimsSuccessAction,
    getClaimsByInitialFaultSubmittedSuccessAction,
} from '../../src/main/actions/reportingActions';
import { setErrorMessagesAction } from '../../src/main/actions/errorActions';

describe('Reporting sagas', () => {
    describe("getReSubmittedClaims saga", () => {
        it('when GET_RESUBMITTED_CLAIMS action is dispatched', () => {
            const watchIterator = watchGetReSubmittedClaims();
            const expectedIterator = takeEvery('GET_RESUBMITTED_CLAIMS', getReSubmittedClaims);

            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
        });

        it('when backend call is successful', () => {
            const mockAction = { type: 'GET_RESUBMITTED_CLAIMS', beginDate: 20180101, endDate: 20190101 };
            const mockResponse = { data: [{ claimNumber: '123' }] };

            testSaga(getReSubmittedClaims, mockAction)
                .next()
                .call(getData, '/api/v1/rpt/resubmitted/20180101/20190101')
                .next(mockResponse)
                .put(getReSubmittedClaimsSuccessAction(mockResponse.data))
                .next()
                .isDone();
        });

        it('when backend call fails', () => {
            const mockAction = { type: 'GET_RESUBMITTED_CLAIMS' };
            testSaga(getReSubmittedClaims, mockAction)
                .next()
                .throw()
                .put(setErrorMessagesAction('Error occurred', 'Error occurred while running report. Please retry.'))
                .next()
                .isDone();
        });
    });

    describe("getClaimsByCreatedTime saga", () => {

        it('when GET_CLAIMS_BY_CREATED_TIME action is dispatched', () => {
            const watchIterator = watchGetClaimsByCreatedTime();
            const expectedIterator = takeEvery('GET_CLAIMS_BY_CREATED_TIME', getClaimsByCreatedTime);

            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
        });

        it('when backend call is successful', () => {
            const mockAction = { type: 'GET_CLAIMS_BY_CREATED_TIME', beginDate: 20180101, endDate: 20190101 };
            const mockResponse = { data: [{ claimNumber: '123' }] };

            testSaga(getClaimsByCreatedTime, mockAction)
                .next()
                .call(getData, '/api/v1/rpt/claims-by-created-time/20180101/20190101')
                .next(mockResponse)
                .put(getClaimsByCreatedTimeSuccessAction(mockResponse.data))
                .next()
                .isDone();
        });

        it('when backend call fails', () => {
            const mockAction = { type: 'GET_CLAIMS_BY_CREATED_TIME' };
            testSaga(getClaimsByCreatedTime, mockAction)
                .next()
                .throw()
                .put(setErrorMessagesAction('Error occurred', 'Error occurred while running report. Please retry.'))
                .next()
                .isDone();
        });
    });

    describe('getInitialFaultPendingClaims saga', () => {
        it('should watch for GET_INITIAL_FAULT_PENDING_CLAIMS actions', () => {
            const watchIterator = watchGetInitialFaultPendingClaims();
            const expectedIterator = takeEvery('GET_INITIAL_FAULT_PENDING_CLAIMS', getInitialFaultPendingClaims);

            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
        });

        it('should put getInitialFaultPendingClaimsSuccessAction when call is successful', () => {
            const mockAction = {
                type: 'GET_INITIAL_FAULT_PENDING_CLAIMS',
            };

            const mockResponse = { data: [{ claimNumber: '123' }] };

            testSaga(getInitialFaultPendingClaims, mockAction)
                .next()
                .call(getData, '/api/v1/rpt/initial-fault-pending-claims')
                .next(mockResponse)
                .put(getInitialFaultPendingClaimsSuccessAction(mockResponse.data))
                .next()
                .isDone();
        });

        it('should put setErrorMessagesAction when call fails', () => {
            const mockAction = {
                type: 'GET_INITIAL_FAULT_PENDING_CLAIMS',
            };

            testSaga(getInitialFaultPendingClaims, mockAction)
                .next()
                .throw()
                .put(setErrorMessagesAction('Error occurred', 'Error occurred while running report. Please retry.'))
                .next()
                .isDone();
        });
    });

    describe("getClaimsByInitialFaultSubmitted saga", () => {

        it('when GET_CLAIMS_BY_INITIAL_FAULT_SUBMITTED_TIME action is dispatched', () => {
            const watchIterator = watchGetClaimsByInitialFaultSubmitted();
            const expectedIterator = takeEvery('GET_CLAIMS_BY_INITIAL_FAULT_SUBMITTED_TIME', getClaimsByInitialFaultSubmitted);

            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
            expect(watchIterator.next().value).toEqual(expectedIterator.next().value);
        });

        it('when backend call is successful', () => {
            const mockAction = {type: 'GET_CLAIMS_BY_INITIAL_FAULT_SUBMITTED_TIME', beginDate: 20180101, endDate: 20190101};
            const mockResponse = {data: [{claimNumber: '123'}]};

            testSaga(getClaimsByInitialFaultSubmitted, mockAction)
                .next()
                .call(getData, '/api/v1/rpt/claims-by-initial-fault-submitted-time/20180101/20190101')
                .next(mockResponse)
                .put(getClaimsByInitialFaultSubmittedSuccessAction(mockResponse.data))
                .next()
                .isDone();
        });

        it('when backend call fails', () => {
            const mockAction = {type: 'GET_CLAIMS_BY_INITIAL_FAULT_SUBMITTED_TIME'};
            testSaga(getClaimsByInitialFaultSubmitted, mockAction)
                .next()
                .throw()
                .put(setErrorMessagesAction('Error occurred', 'Error occurred while running report. Please retry.'))
                .next()
                .isDone();
        });
    });
});
