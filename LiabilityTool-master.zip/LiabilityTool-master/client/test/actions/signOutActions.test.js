jest.unmock("../../src/main/actions/signOutActions");

import {
    signOutAction
} from "../../src/main/actions/signOutActions";


describe("signOutActions", () => {

    it("creates signOutAction", () => {
        expect(signOutAction()).toEqual({
            type: 'SIGNOUT'
        });
    });
});