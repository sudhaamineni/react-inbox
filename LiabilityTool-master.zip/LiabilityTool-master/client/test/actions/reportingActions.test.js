import {
    clearReportDataAction,
    getClaimsByCreatedTimeAction,
    getClaimsByCreatedTimeSuccessAction,
    getInitialFaultPendingClaimsAction,
    getInitialFaultPendingClaimsSuccessAction,
    getReSubmittedClaimsAction,
    getReSubmittedClaimsSuccessAction,
    getClaimsByInitialFaultSubmittedAction,
    getClaimsByInitialFaultSubmittedSuccessAction,
} from "../../src/main/actions/reportingActions";

jest.unmock("../../src/main/actions/reportingActions");

describe("Given reportingActions", () => {
    it("creates getReSubmittedClaimsAction", () => {
        expect(getReSubmittedClaimsAction('20180101', '20190101')).toEqual({
            type: 'GET_RESUBMITTED_CLAIMS',
            beginDate: '20180101',
            endDate: '20190101'
        });
    });

    it("creates getReSubmittedClaimsSuccessAction", () => {
        const claims = [{
            claimNumber: '123'
        }];

        expect(getReSubmittedClaimsSuccessAction(claims)).toEqual({
            type: 'GET_RESUBMITTED_CLAIMS_SUCCESS',
            claims
        });
    });

    it("creates clearReportDataAction", () => {
        expect(clearReportDataAction()).toEqual({
            type: 'CLEAR_REPORT_DATA'
        });
    });

    it("creates getClaimsByCreatedTimeAction", () => {
        expect(getClaimsByCreatedTimeAction('20180101', '20190101')).toEqual({
            type: 'GET_CLAIMS_BY_CREATED_TIME',
            beginDate: '20180101',
            endDate: '20190101'
        });
    });

    it("creates getClaimsByCreatedTimeSuccessAction", () => {
        const claims = [{
            claimNumber: '123'
        }];

        expect(getClaimsByCreatedTimeSuccessAction(claims)).toEqual({
            type: 'GET_CLAIMS_BY_CREATED_TIME_SUCCESS',
            claims
        });
    });

    it('creates getInitialFaultPendingClaimsAction', () => {
        const expectedAction = {
            type: 'GET_INITIAL_FAULT_PENDING_CLAIMS'
        };

        const actualAction = getInitialFaultPendingClaimsAction();
        expect(actualAction).toEqual(expectedAction);
    });

    it('creates getInitialFaultPendingClaimsSuccessAction', () => {
        const expectedAction = {
            type: 'GET_INITIAL_FAULT_PENDING_CLAIMS_SUCCESS',
            claims: 'data'
        };

        const actualAction = getInitialFaultPendingClaimsSuccessAction('data');
        expect(actualAction).toEqual(expectedAction);
    });

    it("creates getClaimsByInitialFaultSubmittedAction", () => {

        expect(getClaimsByInitialFaultSubmittedAction('20180101', '20190101')).toEqual({
            type: 'GET_CLAIMS_BY_INITIAL_FAULT_SUBMITTED_TIME',
            beginDate: '20180101',
            endDate: '20190101'
        });
    });

    it("creates getClaimsByInitialFaultSubmittedSuccessAction", () => {
        const claims = [{
            claimNumber: '123'
        }];

        expect(getClaimsByInitialFaultSubmittedSuccessAction(claims)).toEqual({
            type: 'GET_CLAIMS_BY_INITIAL_FAULT_SUBMITTED_TIME_SUCCESS',
            claims
        });
    });
});
