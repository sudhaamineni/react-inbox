jest.unmock("../../src/main/actions/evidenceActions");
import { showEvidenceModalAction, evidenceModalErrorAction } from "../../src/main/actions/evidenceActions";

describe("evidenceActions", () => {
    it("creates showEvidenceModalAction", () => {
        expect(showEvidenceModalAction(true)).toEqual({
            type: 'SHOW_EVIDENCE_MODAL',
            showEvidenceModal: true
        });
    });

    it("creates evidenceModalErrorAction", () => {
        expect(evidenceModalErrorAction(true)).toEqual({
            type: 'EVIDENCE_MODAL_ERROR',
            evidenceModalError: true
        });
    });
});