jest.unmock('../../src/main/actions/errorActions');

import {clearErrorMessagesAction, setErrorWithClaimNumberAction, setErrorMessagesAction, clearNewClaimNumberAction} from '../../src/main/actions/errorActions';

describe('errorActions', () => {
    it('should setErrorMessageAction on error', () => {
        const errorHeader = 'System Error';
        const errorDescription = 'There is a system error';
        expect(setErrorMessagesAction(errorHeader, errorDescription)).toEqual({
            type: 'SET_ERROR_MESSAGES',
            errorHeader,
            errorDescription,
        });
    });

    it('creates setErrorMessagesWithClaimNumberAction on error', () => {
        const errorHeader = 'System Error';
        const errorDescription = 'There is a system error';
        const newClaimNumber = '12345';
        expect(setErrorWithClaimNumberAction(errorHeader, errorDescription, newClaimNumber)).toEqual({
            type: 'SET_ERROR_MESSAGES_WITH_CLAIM_NUMBER',
            errorHeader,
            errorDescription,
            newClaimNumber
        });
    });


    it('creates clearErrorMessagesAction on error', () => {
        expect(clearErrorMessagesAction()).toEqual({
            type: 'CLEAR_ERROR_MESSAGES'
        });
    });

    it('creates clearNewClaimNumberAction on error', () => {
        expect(clearNewClaimNumberAction()).toEqual({
            type: 'CLEAR_NEW_CLAIM_NUMBER'
        });
    });
});