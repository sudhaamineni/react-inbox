jest.unmock('../../src/main/actions/attachmentsActions.js');

import {
    getPhotoAttachmentsFailureAction,
    getPhotoAttachmentsSuccessAction,
    getVoiceAttachmentsFailureAction,
    getVoiceAttachmentsSuccessAction,
    saveEvidenceAction
} from '../../src/main/actions/attachmentsActions';

describe('attachmentsActions', () => {
    it('should create a getPhotoAttachmentsSuccessAction action', () => {
        expect(getPhotoAttachmentsSuccessAction([{ firstName: 'name' }])).toEqual({
            type: 'GET_PHOTO_ATTACHMENTS_SUCCESS',
            liabilitySubjects: [{ firstName: 'name' }]
        });
    });

    it('should create a getPhotoAttachmentsFailureAction action', () => {
        expect(getPhotoAttachmentsFailureAction()).toEqual({
            type: 'GET_PHOTO_ATTACHMENTS_FAILURE'
        });
    });

    it('should create a getVoiceAttachmentsSuccessAction action', () => {
        expect(getVoiceAttachmentsSuccessAction([{ sourceVoiceId: '1' }])).toEqual({
            type: 'GET_VOICE_ATTACHMENTS_SUCCESS',
            voiceAttachments: [{ sourceVoiceId: '1' }]
        });
    });

    it('should create a getVoiceAttachmentsFailureAction action', () => {
        expect(getVoiceAttachmentsFailureAction()).toEqual({
            type: 'GET_VOICE_ATTACHMENTS_FAILURE'
        });
    });

    it('should create a saveEvidence action', () => {
        const evidence = { id: 'evidenceId' };
        expect(saveEvidenceAction('123', evidence)).toEqual({
            type: 'SAVE_EVIDENCE',
            claimNumber: '123',
            evidence
        });
    });
});
