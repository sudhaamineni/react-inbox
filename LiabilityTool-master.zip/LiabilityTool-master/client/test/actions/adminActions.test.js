jest.unmock("../../src/main/actions/adminActions");

import {
    insertAssignmentClaimListAction,
    insertAssignmentAdminErrorAction,
    insertAssignmentAdminSuccessAction
} from "../../src/main/actions/adminActions";

describe("insertAssignmentClaimListAction", () => {
    it("creates the insertAssignmentClaimListAction with clearQueue as true and useKafka as true", () => {
        expect(insertAssignmentClaimListAction('01234, 12345, 67890', true,true)).toEqual({
            type:'INSERT_ASSIGNMENT_CLAIM_LIST',
            claimNumberList: '01234, 12345, 67890',
            clearQueue: true,
            useKafka:true
        });
    });

    it("creates the insertAssignmentClaimListAction with clearQueue as false and useKafka as false", () => {
        expect(insertAssignmentClaimListAction('01234, 12345, 67890', false,false)).toEqual({
            type:'INSERT_ASSIGNMENT_CLAIM_LIST',
            claimNumberList: '01234, 12345, 67890',
            clearQueue: false,
            useKafka:false
        });
    });


    it("creates the insertAssignmentAdminSuccessAction", () => {
        expect(insertAssignmentAdminSuccessAction()).toEqual({
            type:'INSERT_ASSIGNMENT_ADMIN_SUCCESS',
        });
    });

    it("creates the insertAssignmentAdminErrorAction", () => {
        expect(insertAssignmentAdminErrorAction()).toEqual({
            type:'INSERT_ASSIGNMENT_ADMIN_ERROR',
        });
    });
});