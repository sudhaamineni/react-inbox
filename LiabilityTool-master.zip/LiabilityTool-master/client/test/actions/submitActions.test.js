jest.unmock("../../src/main/actions/submitActions");

import {
    liabilitySubmittedAction, settlementSubmittedAction,
    submitLiabilityAction,
    submitLiabilityCancelAction,
    submitLiabilityErrorAction,
    submitLiabilitySuccessAction,
    submitSettlementAction, submitSettlementCancelAction, submitSettlementErrorAction, submitSettlementSuccessAction,
    updateDamageApportionmentAction
} from "../../src/main/actions/submitActions";

describe("submitActions", () => {
    const claimData = {
        claimNumber: "012345678",
        claimId: "123"
    };

    it("creates submitLiabilityAction", () => {
        expect(submitLiabilityAction(claimData, 'google map image data')).toEqual({
            type: 'SUBMIT_LIABILITY',
            claimData,
            mapImage: 'google map image data'
        });
    });

    it("creates submitLiabilitySuccessAction", () => {
        expect(submitLiabilitySuccessAction(claimData)).toEqual({
            type: 'SUBMIT_LIABILITY_SUCCESS',
            claimData
        });
    });

    it('creates submitLiabilityErrorAction', () => {
        expect(submitLiabilityErrorAction()).toEqual({
            type: 'SUBMIT_LIABILITY_ERROR'
        });
    });

    it('creates sendFileNoteSubmittedAction', () => {
        expect(liabilitySubmittedAction()).toEqual({
            type: 'LIABILITY_SUBMITTED'
        });
    });

    it('creates sendFileNoteCancelAction', () => {
        expect(submitLiabilityCancelAction()).toEqual({
            type: 'CANCEL_SUBMIT_LIABILITY'
        });
    });

    it('should create updateDamageApportionmentAction on receiving UPDATE_DAMAGE_APPORTIONMENT', () => {
        expect(updateDamageApportionmentAction('123')).toEqual({
            type: 'UPDATE_DAMAGE_APPORTIONMENT',
            claimNumber: '123'
        });
    });

    it('should create submitSettlementAction on receiving SUBMIT_SETTLEMENT', () => {
        expect(submitSettlementAction('123')).toEqual({
            type: 'SUBMIT_SETTLEMENT',
            claimNumber: '123'
        });
    });

    it("creates submitSettlementSuccessAction", () => {
        expect(submitSettlementSuccessAction()).toEqual({
            type: 'SUBMIT_SETTLEMENT_SUCCESS',
        });
    });

    it('creates submitSettlementErrorAction', () => {
        expect(submitSettlementErrorAction()).toEqual({
            type: 'SUBMIT_SETTLEMENT_ERROR'
        });
    });

    it('creates settlementSubmittedAction', () => {
        expect(settlementSubmittedAction()).toEqual({
            type: 'SETTLEMENT_SUBMITTED'
        });
    });

    it('creates submitSettlementCancelAction', () => {
        expect(submitSettlementCancelAction()).toEqual({
            type: 'SUBMIT_SETTLEMENT_CANCEL'
        });
    });
});