jest.unmock("../../src/main/actions/transcriptActions");

import {
    getTranscriptDataFailureAction,
    getTranscriptSuccessAction,
    saveHighlightAction,
    saveVoiceParticipantAction,
    saveVoiceParticipantSuccessAction
} from '../../src/main/actions/transcriptActions';

describe('getTranscriptAction', () => {
    const transcript = {
        voiceId: 'id',
        transcriptData: [
            { text: 'abc' },
            { text: 'def' }
        ]
    };

    it('creates getTranscriptSuccessAction', () => {
        expect(getTranscriptSuccessAction(transcript)).toEqual({
            type: 'GET_TRANSCRIPT_SUCCESS',
            transcript
        });
    });
});

describe('saveHighlightAction', () => {
    it('creates saveHighlightAction', () => {
        const claimNumber = '1';
        const voiceId = '12';
        const highlightEntities = [{ id: 'highlight1', highlightTexts: [{ chunkIndex: 1, beginIndex: 8, endIndex: 15 }] }];
        const evidences = [{ id: 'evidence1', sourceId: 'highlight1', type: 'highlight' }];

        let involvedParty = {
            participantId: '1',
            participantSourceId: '11',
            assetId: 'asset1',
            damageSections: [
                'front',
                'rear'
            ],
            contributingFactors: [
                {
                    category: null,
                    reason: 'proper-lookout',
                    details: 'saw-other-party',
                    evidenceIds: ['evidenceId1', 'evidenceId3','evidence5']
                }
            ],
            affectedParties: [
                {
                    participantId: '2',
                    participantSourceId: '22',
                    assetId: 'B9763FCB7D843B1F',
                    passengerPartyIds: [],
                    affectedPercent: 12,
                    beginNegotiatingRange: 7,
                    endNegotiatingRange: 17,
                    submittedAffectedPercent: 12,
                    faultAllocationPercent: 1
                }
            ]
        };
        const event =
            {id: '0', title: 'my first event title', severity: 1, involvedParties: [involvedParty]};
        const events = [event];
        expect(saveHighlightAction(claimNumber, voiceId, highlightEntities, evidences, events)).toEqual({
            type: 'SAVE_HIGHLIGHT',
            claimNumber,
            voiceId,
            highlightEntities,
            evidences,
            events
        });
    });
});

describe('saveVoiceParticipantAction', () => {
    it('creates saveVoiceParticipantAction', () => {
        const claimNumber = '123';
        const index = '1';
        const participantSourceId = 'participantId';
        const callType = 'FNOL';
        expect(saveVoiceParticipantAction(claimNumber, index, participantSourceId, callType)).toEqual({
            type: 'SAVE_VOICE_PARTICIPANT',
            claimNumber,
            index,
            participantSourceId,
            callType,
        });
    });
});

describe('saveVoiceParticipantSuccessAction', () => {
    it('creates saveVoiceParticipantSuccessAction', () => {
        const voiceAttachments = [{ id: 'newVoiceAttachments' }];
        const evidences = [{id: 1, type: 'highlight'}];
        expect(saveVoiceParticipantSuccessAction(voiceAttachments, evidences)).toEqual({
            type: 'SAVE_VOICE_PARTICIPANT_SUCCESS',
            voiceAttachments,
            evidences
        });
    });
});

describe('getTranscriptDataFailureAction', () => {
    const voiceId = 'id';

    it('creates getTranscriptDataFailureAction', () => {
        expect(getTranscriptDataFailureAction(voiceId)).toEqual({
            type: 'GET_TRANSCRIPT_FAILURE',
            voiceId
        });
    });
});
