jest.unmock('../../src/main/actions/claimDataActions');

import {
    clearClaimDataAction,
    getClaimDataAction,
    getClaimDataFailureAction,
    getClaimDataSuccessAction,
    saveClaimUnlockAction,
    saveNoFaultAllocationIndicatorAction,
    saveReportedPciAction,
    saveSketchAction
} from '../../src/main/actions/claimDataActions';

describe('getClaimDataAction', () => {
    let claimData = {claimNumber: '12345'};

    it('creates getClaimDataAction', () => {
        expect(getClaimDataAction('12345')).toEqual({
            type: 'GET_CLAIMDATA',
            claimNumber: '12345'
        });
    });

    it('creates clearClaimDataAction', () => {
        expect(clearClaimDataAction()).toEqual({
            type: 'CLEAR_CLAIMDATA'
        });
    });

    it('creates getClaimDataSuccessAction', () => {
        expect(getClaimDataSuccessAction(claimData)).toEqual({
            type: 'GET_CLAIMDATA_SUCCESS',
            claimData
        });
    });

    it('creates getClaimDataFailureAction', () => {
        expect(getClaimDataFailureAction(claimData)).toEqual({
            type: 'GET_CLAIMDATA_FAILURE',
            claimData
        });
    });

    it('creates saveNoFaultAllocationIndicatorAction', () => {
        expect(saveNoFaultAllocationIndicatorAction('123', true, true)).toEqual({
            type: 'SAVE_NO_FAULT_IND',
            claimNumber: '123',
            noFaultAllocationAgreement: true,
            noFaultAllocationResponse: true
        });
    });

    it('should create saveSketchAction', () => {
        const sketch = {imageSource: 'imageSource', garageSource: 'garageSource', notRequiredReason: 'no reason'};
        expect(saveSketchAction(sketch)).toEqual({
            type: 'SAVE_SKETCH',
            sketch
        });
    });

    it('should create saveClaimUnlockAction', () => {
        expect(saveClaimUnlockAction('123', 'reason', 'description')).toEqual({
            type: 'SAVE_CLAIM_UNLOCK',
            claimNumber: '123',
            reason: 'reason',
            description: 'description',
        });
    });

    it('should create saveReportedPciAction', () => {
        expect(saveReportedPciAction('123', 'voiceId', 'transcriptId', ['Credit Card']).type).toBe('SAVE_REPORTED_PCI');
        expect(saveReportedPciAction('123', 'voiceId', 'transcriptId', ['Credit Card']).claimNumber).toBe('123');
        expect(saveReportedPciAction('123', 'voiceId', 'transcriptId', ['Credit Card']).sourceVoiceId).toBe('voiceId');
        expect(saveReportedPciAction('123', 'voiceId', 'transcriptId', ['Credit Card']).transcriptId).toBe('transcriptId');
        expect(saveReportedPciAction('123', 'voiceId', 'transcriptId', ['Credit Card']).pciCategories).toEqual(['Credit Card']);
        expect(saveReportedPciAction('123', 'voiceId', 'transcriptId', ['Credit Card']).reportedPciDate).not.toBe(null);
    });
});
