jest.unmock("../../src/main/actions/keepAliveActions");
import * as actions from '../../src/main/actions/keepAliveActions';
import expect from 'expect';

describe('sessionKeepaliveActions', () => {
    it('creates a session keepalive action', () => {
        expect(actions.sessionKeepAliveAction()).toEqual({
            type: 'SESSION_KEEPALIVE'
        });
    });
});