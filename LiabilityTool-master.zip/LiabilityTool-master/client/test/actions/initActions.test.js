jest.unmock('../../src/main/actions/initActions');

import {initFailureAction, initSuccessAction} from '../../src/main/actions/initActions';

describe('Init actions', () => {
    it('creates initSuccessAction', () => {
        const response = {
            userId: 'something',
            userRoles: ['role1', 'role2'],
            assignedClaimData: {claimNumber: '123'},
            featureSwitches: {
                enableAdmin: true,
            }
        };

        expect(initSuccessAction(response)).toEqual({
            type: 'INIT_SUCCESS',
            response
        });
    });

    it('creates initFailureAction', () => {
        expect(initFailureAction(500)).toEqual({
            type: 'INIT_FAILURE',
            status: 500
        });
    });
});
