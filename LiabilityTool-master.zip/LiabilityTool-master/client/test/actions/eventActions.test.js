jest.unmock("../../src/main/actions/eventActions");

import {
    createEventAction,
    removeEventAction,
    updateDamagesAction,
    updateEventAction,
    setEventsValidationAction
} from "../../src/main/actions/eventActions";

describe("Given eventActions", () => {
    it("creates createEventAction", () => {
        const mockEvent = {id: '1'};
        expect(createEventAction('123', mockEvent)).toEqual({
            type: 'CREATE_EVENT',
            claimNumber: '123',
            event: mockEvent
        });
        expect(mockEvent.id).not.toBe('1');
    });

    it("creates updateEventAction", () => {
        const mockEvent = {id: '1'};
        expect(updateEventAction('123', mockEvent)).toEqual({
            type: 'UPDATE_EVENT',
            claimNumber: '123',
            event: mockEvent
        });
    });

    it("creates removeEventAction", () => {
        const mockEvent = {id: '1'};
        expect(removeEventAction('123', mockEvent)).toEqual({
            type: 'REMOVE_EVENT',
            claimNumber: '123',
            event: mockEvent
        });
    });

    it("creates updateDamagesAction", () => {
        const expectedAction = {
            type: 'UPDATE_DAMAGES',
            eventIndex: 1,
            involvedPartyIndex: 2,
            damageSections: ['my', 'damages']
        };
        expect(updateDamagesAction(1, 2, ['my', 'damages'])).toEqual(expectedAction);
    });

    it('should create setEventsValidationAction', () => {
        const eventsValidation = [{id: 'id'}];
        const expected = {
            type: 'SET_EVENTS_VALIDATION',
            eventsValidation
        };
        expect(setEventsValidationAction(eventsValidation)).toEqual(expected);
    });
});