jest.unmock('../../src/main/actions/lossLocationActions');

import {lossLocationSaveAction} from '../../src/main/actions/lossLocationActions';

describe('lossLocationActions', () => {
    it('creates lossLocationSaveAction', () => {
        const claimNumber = '12345';
        const updatedLossLocation = '2670 Sanders Rd, Northbrook, Illinois, 60062, Cook County';
        const latitude = 42.09989510881545;
        const longitude = 87.87490108310107;

        expect(lossLocationSaveAction(claimNumber, latitude, longitude, updatedLossLocation)).toEqual({
            type: 'SAVE_UPDATED_LOSS_LOCATION',
            claimNumber,
            latitude,
            longitude,
            updatedLossLocation
        });
    });
});