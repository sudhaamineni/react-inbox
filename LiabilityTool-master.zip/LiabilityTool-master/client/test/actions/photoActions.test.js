jest.unmock("../../src/main/actions/photoActions");

import {photoRotationAction, photoToggleBookmarkAction} from "../../src/main/actions/photoActions";

describe("photoActions", () => {
    const claimNumber = '123',
        participantSourceId = 'p1',
        photoAttachments = [
            {dcfId: '1', url: 'link1'},
            {dcfId: '2', url: 'link2'}
        ],
        evidences = [
            {id: 'e1', sourceId: '1'},
            {id: 'e2', sourceId: '2'}
        ];
    let involvedParty = {
        participantId: '1',
        participantSourceId: '11',
        assetId: 'asset1',
        damageSections: [
            'front',
            'rear'
        ],
        contributingFactors: [
            {
                category: null,
                reason: 'proper-lookout',
                details: 'saw-other-party',
                evidenceIds: ['somephotoid', 'evidence2','evidence5']
            }
        ],
        affectedParties: [
            {
                participantId: '2',
                participantSourceId: '22',
                assetId: 'B9763FCB7D843B1F',
                passengerPartyIds: [],
                affectedPercent: 12,
                beginNegotiatingRange: 7,
                endNegotiatingRange: 17,
                submittedAffectedPercent: 12,
                faultAllocationPercent: 1
            }
        ]
    };
    const event =
        {id: '0', title: 'my first event title', severity: 1, involvedParties: [involvedParty]};
    const events=[event];

    it("dispatches photoToggleBookmarkAction", () => {
        expect(photoToggleBookmarkAction(claimNumber, participantSourceId, photoAttachments, evidences, events))
            .toEqual({type: 'PHOTO_TOGGLE_BOOKMARK', claimNumber, participantSourceId, photoAttachments, evidences, events});
    });

    it("dispatches photoRotationAction", () => {
        expect(photoRotationAction(claimNumber, participantSourceId, photoAttachments, evidences))
            .toEqual({type: 'PHOTO_ROTATION', claimNumber, participantSourceId, photoAttachments, evidences});
    });
});
