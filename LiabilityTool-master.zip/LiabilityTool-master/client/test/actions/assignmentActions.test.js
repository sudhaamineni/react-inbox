jest.unmock("../../src/main/actions/assignmentActions");

import {
    getActiveAssignmentAction,
    getActiveAssignmentSuccessAction,
    getNextAssignmentAction,
    getNextAssignmentSuccessAction,
    onStartReviewTimeoutAction,
    setActiveAssignmentRetrievedAction,
    updateAssignmentStatusAction
} from "../../src/main/actions/assignmentActions";

describe('assignmentActions', () => {
    let claimData = {claimNumber: '12345'};

    it('creates getNextAssignmentAction', () => {
        expect(getNextAssignmentAction()).toEqual({
            type: 'GET_NEXT_ASSIGNMENT'
        });
    });

    it('creates getNextAssignmentSuccessAction', () => {
        expect(getNextAssignmentSuccessAction(claimData)).toEqual({
            type: 'GET_NEXT_ASSIGNMENT_SUCCESS',
            claimData
        });
    });

    it('creates updateAssignmentStatusAction', () => {
        expect(updateAssignmentStatusAction('newStatus', claimData)).toEqual({
            type: 'SAVE_UPDATED_ASSIGNMENT_STATUS',
            updatedClaimData: {
                claimNumber: '12345',
                status: 'newStatus'
            }
        })
    });

    it('creates onStartReviewTimeoutAction', () => {
        expect(onStartReviewTimeoutAction('123')).toEqual({
            type: 'ON_START_REVIEW_TIMEOUT',
            claimNumber: '123'
        });
    });
});