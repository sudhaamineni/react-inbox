jest.unmock('../../../src/main/components/sketch/Sketch');
jest.mock('sketchy-bird');

import React from 'react';
import {shallow} from 'enzyme';
import {Diagram, getDiagramImage, getDiagramObjects} from 'sketchy-bird';
import {mapDispatchToProps, mapStateToProps, Sketch} from '../../../src/main/components/sketch/Sketch';
import analyticsHelper from '../../../src/main/helpers/analyticsHelper';
import {getParticipantName, getSketchTemplateType, isReadOnly} from '../../../src/main/helpers/claimDataHelper';
import {saveSketchAction} from '../../../src/main/actions/claimDataActions';
import {evidenceModalErrorAction, showEvidenceModalAction} from '../../../src/main/actions/evidenceActions';

describe('Given the Sketch component', () => {
    let wrapper;
    const mockLiabilitySubjectsList = [
            {
                firstName: 'Randi',
                lastName: 'Dewall',
                role: 'insured',
                asset: {
                    vehicleYear: '2019',
                    vehicleMake: 'Tesla',
                    vehicleModel: 'S3',
                    assetTypeDescription: 'Auto',
                    vehicleItemId: 'GUID0',
                }
            },
            {
                organizationName: 'Patel Bruh',
                role: 'claimant',
                asset: {
                    vehicleYear: '1971',
                    vehicleMake: 'Ford',
                    vehicleModel: 'Pinto',
                    assetTypeDescription: 'Auto',
                    vehicleItemId: 'GUID1',
                }
            },
            {
                firstName: 'Trina',
                lastName: 'Lee',
                role: 'claimant',
                asset: {
                    vehicleYear: null,
                    vehicleMake: null,
                    vehicleModel: null,
                    assetTypeDescription: 'Property',
                    vehicleItemId: 'GUID2',
                },
            },
            {
                firstName: 'Ima',
                lastName: 'Pedestrian',
                role: 'PEDESTRIAN/BICYCLIST',
                participantSourceId: 'participantSourceId3'
            }
        ],
        mockSaveSketchAction = jest.fn(),
        mockShowEvidenceModalAction = jest.fn(),
        mockEvidenceModalErrorAction = jest.fn(),
        evidences = [{id: 1, category: "my category"}],
        mockHistory = {block: jest.fn().mockReturnValue(true)},
        sketch = {
            imageSource: 'imageSource',
            garageSource: 'garageSource',
            completed: true,
            notRequiredReason: 'no reason'
        };
    window.scrollTo = jest.fn();

    beforeEach(() => {
        getParticipantName.mockReturnValueOnce('Randi Dewall');
        getParticipantName.mockReturnValueOnce('Patel Bruh');
        getParticipantName.mockReturnValueOnce('Ima Pedestrian');
        getSketchTemplateType.mockReturnValue('sketchTemplateType');

        wrapper = shallow(
            <Sketch
                claimNumber={'123'}
                liabilitySubjects={mockLiabilitySubjectsList}
                lossDetailTypeCode={'SomeCode'}
                sketch={sketch}
                garageImage={'garageSource'}
                isReadOnly={false}
                evidences={evidences}
                saveSketchAction={mockSaveSketchAction}
                history={mockHistory}
                showEvidenceModalAction={mockShowEvidenceModalAction}
                evidenceModalErrorAction={mockEvidenceModalErrorAction}
            />
        );
    });

    it('tracks page using SiteCatalyst', () => {
        wrapper.instance().componentDidMount();
        expect(analyticsHelper.trackPage).toHaveBeenCalledWith('claims/loon/sketchPage');
    });

    describe('lifecycle methods', () => {
        describe('componentDidMount', () => {
            it('sets the window to the top of the page when componentDidMount', () => {
                wrapper.instance().componentDidMount();
                expect(window.scrollTo).toHaveBeenCalledWith(0, 0);

            });

            it('should set unblock to the return value of history block method', () => {
                wrapper.instance().unblock = undefined;
                wrapper.instance().componentDidMount();
                expect(wrapper.instance().unblock).toBe(true);
            });

            it('should set unblock to the return value of history block method', () => {
                wrapper.setProps({history: {block: jest.fn().mockReturnValue(false)}});

                wrapper.instance().unblock = undefined;
                wrapper.instance().componentDidMount();
                expect(wrapper.instance().unblock).toBe(false);
            });

            it('should call history block method with historyBlockCallback as parameter', () => {
                jest.clearAllMocks();

                wrapper.instance().componentDidMount();
                expect(mockHistory.block).toBeCalledWith(wrapper.instance().historyBlockCallback);
            });

            describe('historyBlockCallback', () => {
                it('should return true when target route is not initial fault', () => {
                    expect(wrapper.instance().historyBlockCallback({pathname: '/not-initial-fault'})).toBe(true);
                    expect(mockShowEvidenceModalAction).not.toBeCalled();
                    expect(mockEvidenceModalErrorAction).not.toBeCalled();
                });

                it('should return true when target route is initial-fault and evidence list is empty', () => {
                    wrapper.setProps({evidences: []});
                    expect(wrapper.instance().historyBlockCallback({pathname: '/initial-fault'})).toBe(true);
                    expect(mockShowEvidenceModalAction).not.toBeCalled();
                    expect(mockEvidenceModalErrorAction).not.toBeCalled();
                });

                it('should return true when target route is initial-fault and all evidences has category', () => {
                    wrapper.setProps({evidences: [{id: 1, category: "my category"}]});
                    expect(wrapper.instance().historyBlockCallback({pathname: '/initial-fault'})).toBe(true);
                    expect(mockShowEvidenceModalAction).not.toBeCalled();
                    expect(mockEvidenceModalErrorAction).not.toBeCalled();
                });

                it('should return false and invoke showEvidenceModalAction with true' +
                    ' when target route is initial-fault and evidence category is not valid', () => {
                    const invalidCategories = ['', undefined, null];

                    invalidCategories.forEach(invalidCategory => {
                        wrapper.setProps({evidences: [{id: 1, category: invalidCategory}]});
                        expect(wrapper.instance().historyBlockCallback({pathname: '/initial-fault'})).toBe(false);
                        expect(mockShowEvidenceModalAction).toBeCalledWith(true);
                        expect(mockEvidenceModalErrorAction).toBeCalledWith(true);
                    });
                });
            });
        });

        describe('componentWillUnmount', () => {
            beforeEach(() => {
                wrapper.instance().unblock = jest.fn();
                mockSaveSketchAction.mockReset();
                getDiagramObjects.mockReturnValue([{type: 'asset'}]);
            });

            it('should call unblock function', () => {
                wrapper.instance().componentWillUnmount();
                expect(wrapper.instance().unblock).toBeCalled();
            });

            it('should not call saveSketchAction in read only mode', () => {
                wrapper.setProps({isReadOnly: true});

                wrapper.instance().componentWillUnmount();
                expect(mockSaveSketchAction).not.toHaveBeenCalled();
            });

            it('should call saveSketchAction and pass image source from getDiagramImage when available', () => {
                const sketchExpected = {...sketch, imageSource: 'sketch'};
                getDiagramImage.mockReturnValue('sketch');

                wrapper.instance().componentWillUnmount();
                expect(mockSaveSketchAction).toHaveBeenCalledWith(sketchExpected);
            });

            it('should call saveSketchAction and pass image source from store when getDiagramImage is not available', () => {
                getDiagramImage.mockReturnValue(null);

                wrapper.instance().componentWillUnmount();
                expect(mockSaveSketchAction).toHaveBeenCalledWith(sketch);
            });

            it('should call saveSketchAction and pass garage source from sketch reducer when available', () => {
                wrapper.setProps({garageImage: 'asset'});

                const sketchExpected = {...sketch, garageSource: 'asset'};
                wrapper.instance().componentWillUnmount();
                expect(mockSaveSketchAction).toHaveBeenCalledWith(sketchExpected);
            });

            it('should call saveSketchAction and pass garage source from store when sketch reducer does not have garage image', () => {
                wrapper.setProps({garageImage: ''});

                const sketchExpected = {...sketch, garageSource: 'garageSource'};
                wrapper.instance().componentWillUnmount();
                expect(mockSaveSketchAction).toHaveBeenCalledWith(sketchExpected);
            });

            it('should call saveSketchAction with completed as false when getDiagramObjects returns null', () => {
                const sketchExpected = {...sketch, completed: false};
                getDiagramObjects.mockReturnValue(null);

                wrapper.instance().componentWillUnmount();
                expect(mockSaveSketchAction).toHaveBeenCalledWith(sketchExpected);
            });

            it('should call saveSketchAction with completed as false when getDiagramObjects returns empty', () => {
                const sketchExpected = {...sketch, completed: false};
                getDiagramObjects.mockReturnValue([]);

                wrapper.instance().componentWillUnmount();
                expect(mockSaveSketchAction).toHaveBeenCalledWith(sketchExpected);
            });

            it('should call saveSketchAction with completed as false when getDiagramObjects does not return any type of asset', () => {
                const sketchExpected = {...sketch, completed: false};
                getDiagramObjects.mockReturnValue([{type: 'notAsset'}]);

                wrapper.instance().componentWillUnmount();
                expect(mockSaveSketchAction).toHaveBeenCalledWith(sketchExpected);
            });
        });
    });

    it('should have the title as Loon - {claimNumber} when claim number is available', () => {
        wrapper.setProps({claimNumber: '000123456789'});
        wrapper.instance().componentDidMount();
        expect(document.title).toEqual('Loon - 123456789');
    });

    it('should have the title as Loon - {claimNumber} when claim number is not available', () => {
        wrapper.setProps({claimNumber: ''});
        wrapper.instance().componentDidMount();
        expect(document.title).toEqual('Loon -');
    });

    it('should render GoogleMapContainer', () => {
        expect(wrapper.find('Connect(GoogleMapContainer)').exists()).toBe(true);
    });

    it('should render sketch header text', () => {
        expect(wrapper.find('#sketch-header-text').text()).toBe('Sketch the scene to better explain initial fault:')
    });

    it('should render the Diagram with participants that are associated to non-property assets', () => {
        const expectedVehicleList = [
            {
                id: 'GUID0',
                name: 'Randi Dewall',
                role: 'insured',
                year: '2019',
                make: 'Tesla',
                model: 'S3',
                type: 'auto',
            },
            {
                id: 'GUID1',
                name: 'Patel Bruh',
                role: 'claimant',
                year: '1971',
                make: 'Ford',
                model: 'Pinto',
                type: 'auto',
            },
            {
                id: 'participantSourceId3',
                name: 'Ima Pedestrian',
                role: 'PEDESTRIAN/BICYCLIST',
                year: '',
                make: '',
                model: '',
                type: 'auto',
            },
        ];
        expect(wrapper.find(Diagram).props().claimNumber).toBe('123');
        expect(wrapper.find(Diagram).props().assets).toEqual(expectedVehicleList);
        expect(wrapper.find(Diagram).props().readOnly).toBe(false);
        expect(wrapper.find(Diagram).props().templateType).toEqual('sketchTemplateType');

        expect(getSketchTemplateType).toHaveBeenCalledWith('SomeCode');

        // Note: even though we pass 'key' as a prop, it is a special react prop that you cannot access.
        // So, the following will fail
        //expect(wrapper.find(Diagram).props().key).toBe('123');
    });

    describe('Connect', () => {
        it('mapStateToProps', () => {
            const givenParticipants = [
                {role: 'insured', firstName: 'Ima', lastName: 'Insured'}
            ];
            const expectedParticipants = [
                {role: 'insured', firstName: 'Ima', lastName: 'Insured'}
            ];
            const claimData = {
                claimNumber: '123',
                sketch: {imageSource: 'imageSource'},
                liabilitySubjects: givenParticipants,
                lossDetailTypeCode: '20',
                locked: true,
                evidences: [{id: 1, category: 'myCategory'}],
            };
            const diagram = {
                assetsImage: 'my assets image'
            };
            const user = {userRoles: ['LOON User']};
            const state = {claimData, user, diagram};

            isReadOnly.mockReturnValue(true);

            const result = mapStateToProps(state);
            expect(result.claimNumber).toEqual('123');
            expect(result.liabilitySubjects).toEqual(expectedParticipants);
            expect(result.lossDetailTypeCode).toEqual('20');
            expect(result.sketch).toEqual({imageSource: 'imageSource'});
            expect(result.garageImage).toEqual('my assets image');
            expect(result.isReadOnly).toEqual(true);
            expect(result.evidences).toEqual([{id: 1, category: 'myCategory'}]);
            expect(isReadOnly).toBeCalledWith(user.userRoles, claimData.locked);
        });

        it('mapDispatchToProps', () => {
            expect(mapDispatchToProps.saveSketchAction).toEqual(saveSketchAction);
            expect(mapDispatchToProps.showEvidenceModalAction).toEqual(showEvidenceModalAction);
            expect(mapDispatchToProps.evidenceModalErrorAction).toEqual(evidenceModalErrorAction);
        });
    });
});
