jest.unmock('../../src/main/components/SearchPage');
jest.unmock('../../src/main/helpers/claimDataHelper');

import {mapDispatchToProps, mapStateToProps, SearchPage} from '../../src/main/components/SearchPage';
import React from 'react';
import {shallow} from 'enzyme';
import {clearClaimDataAction, getClaimDataAction} from '../../src/main/actions/claimDataActions';
import {clearNewClaimNumberAction} from '../../src/main/actions/errorActions';
import analyticsHelper from '../../src/main/helpers/analyticsHelper';

describe('SearchPage', () => {
    let wrapper;
    const mockGetClaimDataAction = jest.fn(), mockClearClaimDataAction = jest.fn(),
        mockClearNewClaimNumberAction = jest.fn();

    beforeEach(() => {
        window.sessionStorage.setItem('loonWipClaimNumber', '123');

        wrapper = shallow(
            <SearchPage
                errorHeader={'header'}
                errorDescription={'desc'}
                newClaimNumber={''}
                retrievingClaimData={true}
                getClaimDataAction={mockGetClaimDataAction}
                clearClaimDataAction={mockClearClaimDataAction}
                clearNewClaimNumberAction={mockClearNewClaimNumberAction}
            />
        );
    });

    it('tracks using SiteCatalyst', () => {
        expect(analyticsHelper.trackPage).toHaveBeenCalledWith('claims/loon/searchPage');
    });

    it('should have the title as Loon - Search', () => {
        wrapper.instance().componentDidMount();
        expect(document.title).toEqual('Loon - Search');
    });

    it('renders loon logo', () => {
        expect(wrapper.find('.loon-logo').props().src).toBe('../images/ic-welcomelogo.svg');
    });

    it('renders welcome label', () => {
        expect(wrapper.find('.u-text-insured').text()).toBe('Welcome to Loon');
    });

    it('renders search instruction label', () => {
        expect(wrapper.find('#search-instructions').text()).toBe('Search for a claim number to begin a liability analysis');
    });

    it('should set in progress claim number on construct', () => {
        expect(wrapper.instance().state.claimNumber).toBe('123');
    });

    it('passes props to SearchField', () => {
        const searchField = wrapper.find('SearchField');
        const errorTextIcon = searchField.props().errorText.props.children[0];
        const errorTextSpan = searchField.props().errorText.props.children[1].props.children.props.children;
        expect(searchField.props().type).toBe('text');
        expect(searchField.props().placeholder).toBe('Enter a claim number');
        expect(searchField.props().maxLength).toBe(50);
        expect(searchField.props().loading).toBe(true);
        expect(searchField.props().hasError).toBe(true);
        expect(searchField.props().defaultValue).toBe('123');
        expect(searchField.props().autoComplete).toBe(false);
        expect(errorTextIcon.props.icon).toBe('alert-octagon');
        expect(errorTextSpan[0]).toBe(false);
        expect(errorTextSpan[1]).toBe('desc');
    });

    it('should render Unauthorized error text when error header is Unauthorized', () => {
        wrapper.setProps({errorHeader: 'Unauthorized', errorDescription: 'error'});
        const errorTextSpan = wrapper.find('SearchField').props().errorText.props.children[1].props.children.props.children;
        expect(errorTextSpan[0].props.children).toEqual(['Unauthorized', ' ']);
        expect(errorTextSpan[1]).toBe('error');
    });

    describe('when claim has been reset', () => {
        it('should render modal dialog error when receiving claim reset exception', () => {
            wrapper.setState({claimNumber: '000414376467'});
            wrapper.setProps({newClaimNumber: '000428157135', errorDescription: 'This claim has been reset.'});
            const modalDialogProps = wrapper.find('ModalDialog').props();
            expect(modalDialogProps.isActive).toBe(true);
            expect(modalDialogProps.title).toBe('This claim has been reset');
            expect(modalDialogProps.promptType).toBe('error');
            expect(modalDialogProps.isPrompt).toBe(false);
            expect(modalDialogProps.hideTrigger).toBe(true);
            expect(modalDialogProps.isLoading).toBe(true);

            expect(modalDialogProps.footer.props.children.props.children.props.children).toBe('Continue');
            const modalDialogText1 = modalDialogProps.children[0].props.children;
            expect(modalDialogText1[0]).toBe('Please note claim ');
            expect(modalDialogText1[1].props.children[0]).toBe('#');
            expect(modalDialogText1[1].props.children[1]).toBe('000414376467');
            expect(modalDialogText1[2]).toBe(' has been reset to ');
            expect(modalDialogText1[3].props.children[0]).toBe('#');
            expect(modalDialogText1[3].props.children[1]).toBe('000428157135');
            expect(modalDialogText1[3].props.children[2]).toBe('.');
            expect(modalDialogProps.children[1].props.children).toBe('You will be redirected to this new claim.');
        });

        it('should call getClaimDataAction with new claimNumber when continue is clicked', () => {
            wrapper.setProps({newClaimNumber: '000428157135', errorDescription: 'This claim has been reset.'});
            wrapper.find('ModalDialog').props().footer.props.children.props.children.props.onClick();
            expect(mockGetClaimDataAction).toBeCalledWith('000428157135');
        });

        it('should not display the loader when the claim is loaded', () => {
            wrapper.setProps({
                retrievingClaimData: false,
                newClaimNumber: '000428157135',
                errorDescription: 'This claim has been reset.'
            });
            const modalDialogProps = wrapper.find('ModalDialog').props();
            expect(modalDialogProps.isLoading).toBe(false);
        });

        it('should not display error modal if newClaimNumber is empty', () => {
            wrapper.setProps({newClaimNumber: '', errorDescription: 'This claim has been reset.',});
            expect(wrapper.find('ModalDialog').exists()).toBe(false)
        });

        it('should not display error modal if newClaimNumber is  null', () => {
            wrapper.setProps({newClaimNumber: null, errorDescription: 'This claim has been reset.',});
            expect(wrapper.find('ModalDialog').exists()).toBe(false)
        });

        it('should not display error modal if errorDescription is wrong', () => {
            wrapper.setProps({newClaimNumber: '123', errorDescription: 'NOT THE RIGHT TEXT: ',});
            expect(wrapper.find('ModalDialog').exists()).toBe(false)
        });

        it('calls clearNewClaimNumberAction when modal is closed', () => {
            wrapper.setState({claimNumber: '000414376467'});
            wrapper.setProps({newClaimNumber: '000428157135', errorDescription: 'This claim has been reset.'});
            wrapper.find('ModalDialog').props().onClose();
            expect(mockClearNewClaimNumberAction).toHaveBeenCalled();
        });
    });

    it('updates state onChange of SearchField', () => {
        wrapper.find('SearchField').simulate('change', '123');
        expect(wrapper.instance().state.claimNumber).toBe('123');
    });

    it('calls getClaimDataAction onSubmit of SearchField with a claimNumber', () => {
        wrapper.find('SearchField').simulate('change', '123');
        wrapper.find('SearchField').simulate('submit');
        expect(mockGetClaimDataAction).toBeCalledWith('123');
    });

    it("calls trackevent onSubmit of SearchField with a claim number", () => {
        const expectedEvent = {
            message: 'success',
            eventAction: 'SearchPage_FindClaims_ButtonClicked',
            eventSource: 'button',
            errorCode: '',
        };
        wrapper.find('SearchField').simulate('change', '123');
        wrapper.find('SearchField').simulate('submit');
        expect(analyticsHelper.trackEvent).toHaveBeenCalledWith(expectedEvent)
        expect(analyticsHelper.trackTransaction).toHaveBeenCalledWith({claimNumber: '000000000123'});
    });

    it('calls clearClaimDataAction onSubmit of SearchField without a claimNumber', () => {
        wrapper.find('SearchField').simulate('change', '');
        wrapper.find('SearchField').simulate('submit');
        expect(mockClearClaimDataAction).toBeCalled();
    });

    it('calls clearClaimDataAction onSubmit of SearchField without a claimNumber (spaces)', () => {
        wrapper.find('SearchField').simulate('change', ' ');
        wrapper.find('SearchField').simulate('submit');
        expect(mockClearClaimDataAction).toBeCalled();
    });

    describe('Connect', () => {
        describe('mapStateToProps', () => {
            const status = {
                errorHeader: 'header',
                errorDescription: 'desc',
                newClaimNumber: 'newclaimnumber',
                retrievingClaimData: true
            };
            const state = {status};
            it('maps required store items to props', () => {
                const result = mapStateToProps(state);
                expect(result.errorHeader).toBe('header');
                expect(result.errorDescription).toBe('desc');
                expect(result.newClaimNumber).toBe('newclaimnumber');
                expect(result.retrievingClaimData).toBe(true);
            });

            it('maps dispatch to props', () => {
                expect(mapDispatchToProps.getClaimDataAction).toBe(getClaimDataAction);
                expect(mapDispatchToProps.clearClaimDataAction).toBe(clearClaimDataAction);
                expect(mapDispatchToProps.clearNewClaimNumberAction).toBe(clearNewClaimNumberAction);
            });
        });
    });
});
