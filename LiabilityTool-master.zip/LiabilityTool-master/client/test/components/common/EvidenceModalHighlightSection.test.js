import React from 'react';
import {shallow} from 'enzyme';
import {
    EvidenceModalHighlightSection,
    mapDispatchToProps,
    mapStateToProps
} from '../../../src/main/components/common/EvidenceModalHighlightSection';
import {saveEvidenceAction} from '../../../src/main/actions/attachmentsActions';
import {saveHighlightAction} from '../../../src/main/actions/transcriptActions';
import {evidenceModalErrorAction} from "../../../src/main/actions/evidenceActions";
import deepFreeze from 'deep-freeze';

jest.unmock('../../../src/main/components/common/EvidenceModalHighlightSection');
jest.unmock('../../../src/main/constants/loonConstants');

describe('EvidenceModalHighlightSection', () => {
    let wrapper;
    const claimNumber = '123456789000',
        category = 'damages',
        highlights = [
            {
                id: 'e1',
                sourceId: 'he1',
                type: 'highlight',
                category: 'damages',
                transcriptCreatedDate: '2019-03-08T14:26:41.509+0000',
                participantSourceId: 'p1',
                sourceVoiceId: 'v1',
                callType: 'Inquiry',
                highlightTexts: [{chunkIndex: 0}, {chunkIndex: 1}]
            },
            {
                id: 'e2',
                sourceId: 'he2',
                type: 'highlight',
                category: 'damages',
                transcriptCreatedDate: '2019-03-06T14:26:41.509+0000',
                participantSourceId: 'p2',
                participantDisplayName: 'Participant2',
                sourceVoiceId: 'v1',
                callType: 'Inquiry',
                highlightTexts: [
                    {chunkIndex: 1, speaker: 'caller', text: 'hey'},
                    {chunkIndex: 2, speaker: 'rep', text: 'hi'},
                    {chunkIndex: 2, speaker: 'rep', text: 'how are you'},
                    {chunkIndex: 3, speaker: 'caller', text: 'fine'},
                ]
            },
            {
                id: 'e3',
                sourceId: 'he3',
                type: 'highlight',
                category: 'damages',
                transcriptCreatedDate: '2019-03-07T14:26:41.509+0000',
                participantSourceId: 'p3',
                participantDisplayName: 'Participant3',
                sourceVoiceId: 'v1',
                callType: 'Inquiry',
                highlightTexts: [{chunkIndex: 2}, {chunkIndex: 3}]
            },
        ],
        voiceAttachments = [{
            sourceVoiceId: 'v1',
            highlightEntities: [
                {id: 'he1'},
                {id: 'he2'}
            ]
        }],
        mockSaveEvidenceAction = jest.fn(),
        mockSaveHighlightAction = jest.fn(),
        mockEvidenceModalErrorAction = jest.fn();

    deepFreeze(highlights);
    deepFreeze(claimNumber);
    deepFreeze(voiceAttachments);

    beforeEach(() => {
        wrapper = shallow(
            <EvidenceModalHighlightSection
                highlights={highlights}
                category={category}
                claimNumber={claimNumber}
                voiceAttachments={voiceAttachments}
                evidences={highlights}
                saveEvidenceAction={mockSaveEvidenceAction}
                saveHighlightAction={mockSaveHighlightAction}
                evidenceModalErrorAction={mockEvidenceModalErrorAction}
                readOnly={false}
            />
        );
    });

    it('should render highlight sections based on number of highlight evidences prop', () => {
        expect(wrapper.find('.c-btn.c-btn--tag--pill').length).toBe(3);
    });

    describe('Header pill', () => {
        it('should render the name of the participant inside a pill', () => {
            expect(wrapper.find('.c-btn.c-btn--tag--pill').at(0).text()).toBe('<Icon />Inquiry from Participant2');
        });

        it('should display the pill with correct text for Unknown participant', () => {
            expect(wrapper.find('.c-btn.c-btn--tag--pill').at(2).text()).toBe('<Icon />Inquiry from Unknown');
        });

        it('should render a tag icon in the pill', () => {
            expect(wrapper.find('Icon').at(0).props().icon).toBe('tag');
        });
    });

    it('should render highlight texts based on number of highlight texts in the evidence', () => {
        expect(wrapper.find('.highlight-review').length).toBe(3);
        expect(wrapper.find('.highlight-review').at(0).find('.evidence-transcript-chunk').length).toBe(4);
    });

    it('should render the highlighted transcript', () => {
        expect(wrapper.find('.highlight-review').at(0).text()).toBe('callerheyrephi how are youcallerfine');
    });

    describe('Evidence Menu', () => {
        it('should render with default props', () => {
            const options = [
                {label: 'Loss Address', value: 'loss-address'},
                {label: 'Road Attributes', value: 'road-attributes'},
                {label: 'Condition of Roadway', value: 'condition-of-roadway'},
                {label: 'Weather', value: 'weather'},
                {label: 'Traffic Control Measures', value: 'traffic-control-measures'},
                {label: 'Amount of Traffic', value: 'amount-of-traffic'},
                {label: 'Time of Day', value: 'time-of-day'},
                {label: 'Direction of Travel', value: 'direction-of-travel'},
                {label: 'Participant Speed', value: 'participant-speed'},
                {label: 'Point of Impact', value: 'point-of-impact'},
                {label: 'Damages', value: 'damages'},
                {label: 'Driver Actions', value: 'driver-actions'},
                {label: 'Injuries', value: 'injuries'},
                {label: 'Other', value: 'other'},
            ];

            expect(wrapper.find('EvidenceMenu').props().align).toBe('left');
            expect(wrapper.find('EvidenceMenu').props().columns).toBe(2);
            expect(wrapper.find('EvidenceMenu').props().options).toEqual(options);
            expect(wrapper.find('EvidenceMenu').props().position).toEqual('top');
            expect(wrapper.find('EvidenceMenu').props().isActive).toBe(false);
            expect(wrapper.find('EvidenceMenu').props().readOnly).toBe(false);
            expect(wrapper.find('EvidenceMenu').props().forwardRef).toEqual(null);
            expect(wrapper.find('EvidenceMenu').props().selected).toBe('damages');
        });

        it('should render the EvidenceMenu as readOnly if it is read only', () => {
            wrapper.setProps({readOnly: true});
            expect(wrapper.find('EvidenceMenu').props().readOnly).toBe(true);
        });

        it('should render with active prop has true when tag icon is clicked', () => {
            document.getElementById = jest.fn().mockReturnValue({
                getBoundingClientRect: jest.fn().mockReturnValue({}),
                children: [
                    {},
                    {getBoundingClientRect: jest.fn().mockReturnValue({})}
                ],
            });

            wrapper.find('button').at(0).simulate('click');

            expect(wrapper.find('EvidenceMenu').props().isActive).toBe(true);
            expect(wrapper.find('EvidenceMenu').props().forwardRef).not.toBe(null);
            expect(wrapper.find('EvidenceMenu').props().position).toEqual('top');

            expect(document.getElementById).toBeCalledWith('e2');
            expect(document.getElementById).toBeCalledWith('evidence-modal_content');
        });

        it('should render with bottom position when there is less space at the top', () => {
            document.getElementById = jest.fn().mockReturnValue({
                getBoundingClientRect: jest.fn().mockReturnValue({y: 1200}),
                children: [
                    {},
                    {getBoundingClientRect: jest.fn().mockReturnValue({y: 1000})}
                ],
            });

            wrapper.find('button').at(0).simulate('click');

            expect(wrapper.find('EvidenceMenu').props().isActive).toBe(true);
            expect(wrapper.find('EvidenceMenu').props().forwardRef).not.toBe(null);
            expect(wrapper.find('EvidenceMenu').props().position).toEqual('bottom');

            expect(document.getElementById).toBeCalledWith('e2');
            expect(document.getElementById).toBeCalledWith('evidence-modal_content');
        });

        it('should close evidence menu', () => {
            wrapper.instance().setState({evidenceMenuRefId: 'e2'});
            wrapper.find('EvidenceMenu').simulate('close');

            expect(wrapper.find('EvidenceMenu').props().isActive).toBe(false);
        });

        it('should not update category if same category is selected', () => {
            wrapper.find('EvidenceMenu').simulate('select', 'damages');

            expect(mockSaveEvidenceAction).not.toBeCalled();
        });

        it('should remove error banner is the category selected from untagged and is the last one', () => {
            wrapper.setProps({
                category: 'untagged',
                highlights: [{id: 1, highlightTexts: []}]
            });
            wrapper.instance().setState({evidenceMenuRefId: 1});
            wrapper.find('EvidenceMenu').simulate('select', 'not untagged');

            expect(mockEvidenceModalErrorAction).toBeCalledWith(false);
        });

        it('should update category if different category is selected', () => {
            mockEvidenceModalErrorAction.mockReset();
            wrapper.instance().setState({evidenceMenuRefId: 'e2'});
            wrapper.find('EvidenceMenu').simulate('select', 'another category');

            const expected = {
                id: 'e2',
                sourceId: 'he2',
                type: 'highlight',
                category: 'another category',
                transcriptCreatedDate: '2019-03-06T14:26:41.509+0000',
                participantSourceId: 'p2',
                participantDisplayName: 'Participant2',
                sourceVoiceId: 'v1',
                callType: 'Inquiry',
                highlightTexts: [
                    {chunkIndex: 1, speaker: 'caller', text: 'hey'},
                    {chunkIndex: 2, speaker: 'rep', text: 'hi'},
                    {chunkIndex: 2, speaker: 'rep', text: 'how are you'},
                    {chunkIndex: 3, speaker: 'caller', text: 'fine'},
                ]
            };
            expect(mockSaveEvidenceAction).toBeCalledWith('123456789000', expected);
            expect(wrapper.find('EvidenceMenu').props().isActive).toBe(false);
            expect(mockEvidenceModalErrorAction).not.toBeCalled();
        });

        it('should remove highlight and evidence when trash icon is clicked', () => {
            wrapper.instance().setState({evidenceMenuRefId: 'e2'});
            wrapper.find('EvidenceMenu').simulate('removeClick');

            const expectedEvidences = [
                {
                    id: 'e1',
                    sourceId: 'he1',
                    type: 'highlight',
                    category: 'damages',
                    transcriptCreatedDate: '2019-03-08T14:26:41.509+0000',
                    participantSourceId: 'p1',
                    sourceVoiceId: 'v1',
                    callType: 'Inquiry',
                    highlightTexts: [{chunkIndex: 0}, {chunkIndex: 1}]
                },
                {
                    id: 'e3',
                    sourceId: 'he3',
                    type: 'highlight',
                    category: 'damages',
                    transcriptCreatedDate: '2019-03-07T14:26:41.509+0000',
                    participantSourceId: 'p3',
                    participantDisplayName: 'Participant3',
                    sourceVoiceId: 'v1',
                    callType: 'Inquiry',
                    highlightTexts: [{chunkIndex: 2}, {chunkIndex: 3}]
                },
            ];

            expect(mockSaveHighlightAction).toBeCalledWith('123456789000', 'v1', [{id: 'he1'}], expectedEvidences);
            expect(wrapper.find('EvidenceMenu').props().isActive).toBe(false);
        });
    });

    describe('Connect', () => {
        it('should mapStateToProps', () => {
            const state = {
                claimData: {
                    claimNumber: '123',
                    voiceAttachments: [{id: 'v1'}],
                    evidences: [{id: 'e1'}],
                }
            };

            const actualProps = mapStateToProps(state);
            expect(actualProps.claimNumber).toEqual('123');
            expect(actualProps.voiceAttachments).toEqual([{id: 'v1'}]);
            expect(actualProps.evidences).toEqual([{id: 'e1'}]);
        });

        it('should mapDispatchToProps', () => {
            expect(mapDispatchToProps.saveEvidenceAction).toEqual(saveEvidenceAction);
            expect(mapDispatchToProps.saveHighlightAction).toEqual(saveHighlightAction);
            expect(mapDispatchToProps.evidenceModalErrorAction).toEqual(evidenceModalErrorAction);
        });
    });
});
