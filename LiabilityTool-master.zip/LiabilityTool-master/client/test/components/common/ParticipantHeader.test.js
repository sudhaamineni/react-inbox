jest.unmock('../../../src/main/components/common/ParticipantHeader');
import {shallow} from 'enzyme';
import React from 'react';

import ParticipantHeader from '../../../src/main/components/common/ParticipantHeader';
import {
    getParticipantName,
    getVehicleInfo,
    isInsured,
    getAssetTypeShortName,
    getIconLabel
} from '../../../src/main/helpers/claimDataHelper';

describe('Participant Header', () => {
    let wrapper;
    jest.mock('../../../src/main/helpers/claimDataHelper', () => ({
        getParticipantName: jest.fn(),
        getVehicleInfo: jest.fn(),
        isInsured: jest.fn(),
        getAssetTypeShortName: jest.fn()
    }));
    getParticipantName.mockReturnValue("HOWARD ELLIOTT");
    getVehicleInfo.mockReturnValue('2002 TOYOTA COROLLA');
    isInsured.mockReturnValueOnce(true).mockReturnValue(false);
    getAssetTypeShortName.mockReturnValue('motorcycle');
    getIconLabel.mockReturnValue('Insured Owner');
    let liabilitySubjects = [
        {
            firstName: 'HOWARD',
            lastName: 'ELLIOTT',
            organizationName: null,
            asset: {
                vehicleYear: '2002',
                vehicleMake: 'TOYOTA',
                vehicleModel: 'COROLLA',
                assetTypeDescription: 'Motorcycle',
            },
            participantSourceId: 'insuredId',
            liabilityRangeBeginPercent: 10,
            liabilityRangeEndPercent: 20,
            liabilityRangeError: false,
            role: 'INSURED',
            contributingFactors: [],
            isDriver: true,
            photoAttachments: [],
            voiceAttachments: []
        },
        {
            firstName: 'JAMES',
            lastName: 'BLACK II',
            organizationName: null,
            asset: {
                vehicleYear: '2000',
                vehicleMake: 'PORSCHE',
                vehicleModel: 'BOXSTER',
            },
            participantSourceId: 'participantId',
            liabilityRangeBeginPercent: 80,
            liabilityRangeEndPercent: 90,
            liabilityRangeError: false,
            role: 'CLAIMANT',
            contributingFactors: [],
        },
        {
            firstName: '',
            lastName: '',
            organizationName: 'Org Name',
            asset: {
                vehicleYear: '2000',
                vehicleMake: 'PORSCHE',
                vehicleModel: 'BOXSTER',
            },
            participantSourceId: 'participantId',
            liabilityRangeBeginPercent: 80,
            liabilityRangeEndPercent: 90,
            liabilityRangeError: false,
            role: 'CLAIMANT',
            contributingFactors: [],
        },
        {
            firstName: '',
            lastName: '',
            organizationName: '',
            asset: {
                vehicleYear: '2000',
                vehicleMake: 'PORSCHE',
                vehicleModel: 'BOXSTER',
            },
            participantSourceId: 'participantId3',
            liabilityRangeBeginPercent: 80,
            liabilityRangeEndPercent: 90,
            liabilityRangeError: false,
            role: 'CLAIMANT',
            contributingFactors: [],
        }
    ];

    let participant5 = {
        firstName: 'Fifth Participant',
        lastName: 'Last Name',
        organizationName: '',
        asset: {
            vehicleYear: '2013',
            vehicleMake: 'TOYOTA',
            vehicleModel: 'PRIUS',
        },
        participantSourceId: 'participantId5',
        liabilityRangeBeginPercent: 80,
        liabilityRangeEndPercent: 90,
        liabilityRangeError: false,
        role: 'CLAIMANT',
        contributingFactors: [],
    };

    describe('Given Participants prop not available', () => {

        beforeEach(() => {
            wrapper = shallow(
                <ParticipantHeader
                    liabilitySubjects={[]}
                />
            );
        });

        it('renders not available message', () => {
            expect(wrapper.find("#noParticipants").text()).toBe("Participants are not available.");
        });
    });

    describe('Given liabilitySubjects prop is available', () => {
        let wrapper;
        beforeEach(() => {
            wrapper = shallow(
                <ParticipantHeader
                    liabilitySubjects={liabilitySubjects}
                />
            );
        });

        it('should render the ParticipantPills', () => {
            expect(wrapper.find('ParticipantPill').length).toBe(4);
            expect(wrapper.find('ParticipantPill').get(0).props.liabilitySubject).toBe(liabilitySubjects[0]);
            expect(wrapper.find('ParticipantPill').get(1).props.liabilitySubject).toBe(liabilitySubjects[1]);
            expect(wrapper.find('ParticipantPill').get(2).props.liabilitySubject).toBe(liabilitySubjects[2]);
            expect(wrapper.find('ParticipantPill').get(3).props.liabilitySubject).toBe(liabilitySubjects[3]);
        });


        it('renders participant name', () => {
            expect(wrapper.find('#participant-name0').props().children).toEqual('HOWARD ELLIOTT');
            expect(getParticipantName).toHaveBeenCalledWith(liabilitySubjects[0]);
            expect(getParticipantName).toHaveBeenCalledWith(liabilitySubjects[1]);
            expect(getParticipantName).toHaveBeenCalledWith(liabilitySubjects[2]);
            expect(getParticipantName).toHaveBeenCalledWith(liabilitySubjects[3]);
        });
        it('renders vehicle information', () => {
            expect(wrapper.find('#participant-vehicle0').props().children).toBe('2002 TOYOTA COROLLA');
            expect(getVehicleInfo).toHaveBeenCalledWith(liabilitySubjects[0]);
            expect(getVehicleInfo).toHaveBeenCalledWith(liabilitySubjects[1]);
            expect(getVehicleInfo).toHaveBeenCalledWith(liabilitySubjects[2]);
            expect(getVehicleInfo).toHaveBeenCalledWith(liabilitySubjects[3]);
        });

    });

    describe('there are 4 or less liabilitySubjects ', () => {
        it('should not render show more button', () => {
            expect(wrapper.find('#show-more-btn').exists()).toBe(false);
        });
    });

    describe('there are 5 or more liabilitySubjects ', () => {
        let moreParticipants = [...liabilitySubjects, participant5];
        beforeEach(() => {
            wrapper = shallow(
                <ParticipantHeader
                    liabilitySubjects={moreParticipants}
                />
            );
        });

        it('should display 4 liabilitySubjects initially', () => {
            expect(getParticipantName).toHaveBeenCalledWith(moreParticipants[0]);
            expect(getParticipantName).toHaveBeenCalledWith(moreParticipants[1]);
            expect(getParticipantName).toHaveBeenCalledWith(moreParticipants[2]);
            expect(getParticipantName).toHaveBeenCalledWith(moreParticipants[3]);
            expect(getParticipantName).not.toHaveBeenCalledWith(moreParticipants[4]);
        });

        it('should display 5 liabilitySubjects when show more button is clicked', () => {
            wrapper = shallow(
                <ParticipantHeader
                    liabilitySubjects={moreParticipants}
                    expanded={true}
                />
            );
            expect(getParticipantName).toHaveBeenCalledWith(moreParticipants[0]);
            expect(getParticipantName).toHaveBeenCalledWith(moreParticipants[1]);
            expect(getParticipantName).toHaveBeenCalledWith(moreParticipants[2]);
            expect(getParticipantName).toHaveBeenCalledWith(moreParticipants[3]);
            expect(getParticipantName).toHaveBeenCalledWith(moreParticipants[4]);
        });
    });
});
