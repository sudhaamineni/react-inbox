import React from 'react';
import {shallow} from 'enzyme';
import EvidenceModalSection from '../../../src/main/components/common/EvidenceModalSection';

jest.unmock('../../../src/main/components/common/EvidenceModalSection');
jest.unmock('../../../src/main/constants/loonConstants');

describe('Evidence Modal Section', () => {
    let wrapper;
    describe('common', () => {
        let evidences = [{id: 1, type: 'photo', category: 'damages'},
            {id: 2, type: 'photo', category: 'damages'},
            {id: 3, type: 'highlight', category: 'damages'}];

        beforeEach(() => {
            wrapper = shallow(<EvidenceModalSection category="damages"
                                                    evidences={evidences}
                                                    readOnly={false}/>);
        });

        it('should render the photos of the evidence if there are photos', () => {
            let expectedPhotoEvidences = [{id: 1, type: 'photo', category: 'damages'},
                {id: 2, type: 'photo', category: 'damages'}];

            expect(wrapper.find('Connect(EvidenceModalPhotoSection)').props().photoEvidences).toEqual(expectedPhotoEvidences);
            expect(wrapper.find('Connect(EvidenceModalPhotoSection)').props().category).toEqual('damages');
            expect(wrapper.find('Connect(EvidenceModalPhotoSection)').props().readOnly).toBe(false);
        });

        it('should render the evidence photo section with read only as true if it is read only', () => {
            wrapper.setProps({readOnly: true});
            expect(wrapper.find('Connect(EvidenceModalPhotoSection)').props().readOnly).toBe(true);
        });

        it('should not render the Photo section is there are no photos', () => {
            let evidences = [{id: 3, type: 'highlight', category: 'damages'}];

            wrapper = shallow(<EvidenceModalSection category="damages"
                                                    evidences={evidences}
                                                    enableTagging={true}
                                                    showBottomHorizontalRule={true}
                                                    readOnly={false}/>);

            expect(wrapper.find('Connect(EvidenceModalPhotoSection)').exists()).toBe(false);

        });

        it('should render the highlights of the evidence if there are highlights', () => {
            let expectedHighlightEvidences = [{id: 3, type: 'highlight', category: 'damages'}];

            expect(wrapper.find('Connect(EvidenceModalHighlightSection)').props().highlights).toEqual(expectedHighlightEvidences);
            expect(wrapper.find('Connect(EvidenceModalHighlightSection)').props().category).toEqual('damages');
            expect(wrapper.find('Connect(EvidenceModalHighlightSection)').props().readOnly).toBe(false);
        });

        it('should render the evidence photo section with read only as true if it is read only', () => {
            wrapper.setProps({readOnly: true});
            expect(wrapper.find('Connect(EvidenceModalHighlightSection)').props().readOnly).toBe(true);
        });

        it('should not render the Highlight section if there are no highlights', () => {
            let evidences = [{id: 1, type: 'photo', category: 'damages'},
                {id: 2, type: 'photo', category: 'damages'}];

            wrapper = shallow(<EvidenceModalSection category="damages"
                                                    evidences={evidences}
                                                    enableTagging={true}
                                                    showBottomHorizontalRule={true}
                                                    readOnly={false}/>);

            expect(wrapper.find('EvidenceModalHighlightSection').exists()).toBe(false);
        });
    });

    describe('Untagged Section', () => {
        let evidences = [{id: 1, type: 'photo', category: 'untagged'},
            {id: 2, type: 'photo', category: 'untagged'},
            {id: 3, type: 'highlight', category: 'untagged'}];

        beforeEach(() => {
            wrapper = shallow(<EvidenceModalSection category="untagged"
                                                    evidences={evidences}
                                                    readOnly={false}/>);
        });

        it('should have a gray background', () => {
            expect(wrapper.find('.background-very-light-gray').exists()).toBe(true);
        });

        it('should have a subheader', () => {
            expect(wrapper.find('#untagged-section__subheader').text()).toBe('Tag the following evidence type before assigning fault.');
        });

        it('should render the category icon with magenta icon', () => {
            expect(wrapper.find('Icon').props().icon).toBe('tag');
            expect(wrapper.find('Icon').props().color).toBe('magenta');
            expect(wrapper.find('Icon').props().size).toBe(1.0);
        });

        it('should render category header', () => {
            expect(wrapper.find('#category-section__header__text').text()).toBe('Untagged (3)');
        });
    });

    describe('Tagged Section', () => {
        let evidences = [{id: 1, type: 'photo', category: 'damages'},
            {id: 2, type: 'photo', category: 'damages'},
            {id: 3, type: 'highlight', category: 'damages'}];

        beforeEach(() => {
            wrapper = shallow(<EvidenceModalSection category="damages"
                                                    evidences={evidences}
                                                    readOnly={false}/>);
        });

        it('should not have a gray background', () => {
            expect(wrapper.find('.background-very-light-gray').exists()).toBe(false);
        });

        it('should not have a subheader', () => {
            expect(wrapper.find('#untagged-section__subheader').exists()).toBe(false);
        });

        it('should render the category icon with gray icon', () => {
            expect(wrapper.find('Icon').props().icon).toBe('tag');
            expect(wrapper.find('Icon').props().color).toBe('loon-gray-light');
            expect(wrapper.find('Icon').props().size).toBe(1.0);
        });

        it('should render category header', () => {
            expect(wrapper.find('#category-section__header__text').text()).toBe('Damages (3)');
        });
    });
});
