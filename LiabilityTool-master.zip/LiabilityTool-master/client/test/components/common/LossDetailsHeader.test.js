jest.unmock('../../../src/main/components/common/LossDetailsHeader');
jest.unmock('../../../src/main/constants/detailLossTypeIconConstants');

import React from 'react';
import {shallow} from 'enzyme';
import {LossDetailsHeader, mapStateToProps} from '../../../src/main/components/common/LossDetailsHeader';
import {convertZuluTimeToLocalTime, formatLossDateString} from '../../../src/main/helpers/dateTimeHelper';
import {isReadOnlyUser} from '../../../src/main/helpers/claimDataHelper';

describe('Given LossDetailsHeader', () => {
    let wrapper;
    let claimData = {
        mapAddress: '123 SwrappertName, City, State ZipCode',
        updatedLossLocation: undefined,
        claimNumber: '123',
        initialFaultSubmitTime: '2017-08-06 12:12:12',
        lossDetailType: 'Intersection Accident',
        lossDetailTypeCode: '-1',
        lossDate: '2017-08-06',
        lossTime: '9:32 am',
        lossState: 'California',
        liabilitySubjects: ['1', '2', '3'],
    };

    beforeEach(() => {
        convertZuluTimeToLocalTime.mockReturnValue('Wed. Aug 06, 2017 12:12PM CDT');
        formatLossDateString.mockReturnValue('Wed. Aug 06, 2017');
        wrapper = shallow(
            <LossDetailsHeader
                claimData={claimData}
                readOnly={false}
            />
        );
    });

    describe('Margin top', () => {
        it('should render with 4.5rem when not a read only user', () => {
            expect(wrapper.find('#liability-analysis--scene').props().className).toBe('u-vr-9-top');
        });

        it('should render with 8rem when a read only user', () => {
            wrapper.setProps({readOnly: true});
            expect(wrapper.find('#liability-analysis--scene').props().className).toBe('margin-top-6rem');
        });
    });

    describe('renders correct incident icon', () => {
        it('renders grey circle when lossDetailTypeCode is not in dictionary', () => {
            expect(wrapper.find('#loss-detail-type-icon').props().icon).toBe('default-car-circle');
        });

        it('renders the backing accident icon when lossDetailTypeCode is 06', () => {
            wrapper.setProps({claimData: {...claimData, lossDetailTypeCode: '06'}});
            expect(wrapper.find('#loss-detail-type-icon').props().icon).toEqual('backing-accident-circle');
        });

        it('renders the intersection icon when lossDetailTypeCode is 07', () => {
            wrapper.setProps({claimData: {...claimData, lossDetailTypeCode: '07'}});
            expect(wrapper.find('#loss-detail-type-icon').props().icon).toEqual('intersection-circle');
        });

        it('renders the standing water icon when lossDetailTypeCode is 08', () => {
            wrapper.setProps({claimData: {...claimData, lossDetailTypeCode: '08'}});
            expect(wrapper.find('#loss-detail-type-icon').props().icon).toEqual('standing-water-circle');
        });

        it('renders the changing lanes icon when lossDetailTypeCode is 09', () => {
            wrapper.setProps({claimData: {...claimData, lossDetailTypeCode: '09'}});
            expect(wrapper.find('#loss-detail-type-icon').props().icon).toEqual('changing-lanes-circle');
        });

        it('renders the head on icon when lossDetailTypeCode is 11', () => {
            wrapper.setProps({claimData: {...claimData, lossDetailTypeCode: '11'}});
            expect(wrapper.find('#loss-detail-type-icon').props().icon).toEqual('head-on-collision-circle');
        });

        it('renders the hit fixed object icon when lossDetailTypeCode is 07', () => {
            wrapper.setProps({claimData: {...claimData, lossDetailTypeCode: '14'}});
            expect(wrapper.find('#loss-detail-type-icon').props().icon).toEqual('hit-fixed-object-circle');
        });

        it('renders the hit bike icon when lossDetailTypeCode is 15', () => {
            wrapper.setProps({claimData: {...claimData, lossDetailTypeCode: '15'}});
            expect(wrapper.find('#loss-detail-type-icon').props().icon).toEqual('hit-bike-circle');
        });

        it('renders the making a turn icon when lossDetailTypeCode is 17', () => {
            wrapper.setProps({claimData: {...claimData, lossDetailTypeCode: '17'}});
            expect(wrapper.find('#loss-detail-type-icon').props().icon).toEqual('right-of-way-circle');
        });

        it('renders the parked vehicle icon when lossDetailTypeCode is 19', () => {
            wrapper.setProps({claimData: {...claimData, lossDetailTypeCode: '19'}});
            expect(wrapper.find('#loss-detail-type-icon').props().icon).toEqual('parked-vehicle-circle');
        });

        it('renders the parked vehicle icon when lossDetailTypeCode is 20', () => {
            wrapper.setProps({claimData: {...claimData, lossDetailTypeCode: '20'}});
            expect(wrapper.find('#loss-detail-type-icon').props().icon).toEqual('parked-vehicle-circle');
        });

        it('renders the rear-end accident icon when lossDetailTypeCode is 21', () => {
            wrapper.setProps({claimData: {...claimData, lossDetailTypeCode: '21'}});
            expect(wrapper.find('#loss-detail-type-icon').props().icon).toEqual('rear-end-accident-circle');
        });

        it('renders the rear-end accident icon when lossDetailTypeCode is 22', () => {
            wrapper.setProps({claimData: {...claimData, lossDetailTypeCode: '22'}});
            expect(wrapper.find('#loss-detail-type-icon').props().icon).toEqual('rear-end-accident-circle');
        });

        it('renders the rear-end accident icon when lossDetailTypeCode is 23', () => {
            wrapper.setProps({claimData: {...claimData, lossDetailTypeCode: '23'}});
            expect(wrapper.find('#loss-detail-type-icon').props().icon).toEqual('rear-end-accident-circle');
        });

        it('renders the sideswipe icon when lossDetailTypeCode is 24', () => {
            wrapper.setProps({claimData: {...claimData, lossDetailTypeCode: '24'}});
            expect(wrapper.find('#loss-detail-type-icon').props().icon).toEqual('sideswipe-circle');
        });
    });

    describe('renders the correct text based on props', () => {
        it('calls formatDateTime with initialFaultSubmitTime', () => {
            expect(convertZuluTimeToLocalTime).toHaveBeenCalledWith('2017-08-06 12:12:12');
        });

        it('Renders claim submit status submitted when claim is submitted', () => {
            expect(wrapper.find('#claim-submit-status').text()).toBe('Claim #123 initial fault last submitted:');
        });

        it('Renders claim submit time when claim is submitted', () => {
            expect(wrapper.find('#claim-submit-time').text()).toBe('Wed. Aug 06, 2017 12:12PM CDT');
        });

        it('Renders claim submit status not submitted when claim is not submitted', () => {
            wrapper.setProps({claimData: {...claimData, initialFaultSubmitTime: undefined}});
            expect(wrapper.find('#claim-submit-status').text()).toBe('Claim #123 initial fault not submitted');
        });

        it('Renders unsubmitted icon when claim is not submitted', () => {
            wrapper.setProps({claimData: {...claimData, initialFaultSubmitTime: undefined}});
            expect(wrapper.find('#submit-status-icon').props().icon).toBe('update');
            expect(wrapper.find('#submit-status-icon').props().color).toBe('hot-pink');
        });

        it('Renders submitted icon when claim is submitted', () => {
            expect(wrapper.find('#submit-status-icon').props().color).toBe('button');
        });

        it('Renders loss details', () => {
            expect(wrapper.find('#loss-details-label').text()).toBe('Loss Details');
        });

        it('Renders loss detail type header and label', () => {
            expect(wrapper.find('#loss-detail-type-value').text()).toBe('Intersection Accident');
        });

        it('calls formatDateTime with initialFaultSubmitTime', () => {
            expect(formatLossDateString).toHaveBeenCalledWith('2017-08-06');
        });

        it('Renders the lossDate, time and state', () => {
            expect(wrapper.find('#loss-date-state-value').text()).toBe('Wed. Aug 06, 2017 at 9:32 AM in California');
        });
    });

    describe('there are 4 or less liabilitySubjects ', () => {
        it('should not render show more button', () => {
            expect(wrapper.find('#show-more-btn').exists()).toBe(false);
        });
    });

    describe('there are 4 or more liabilitySubjects ', () => {
        it('should not render show more button', () => {
            claimData = {
                mapAddress: '123 SwrappertName, City, State ZipCode',
                updatedLossLocation: undefined,
                claimNumber: '123',
                initialFaultSubmitTime: '2017-08-06 12:12:12',
                lossDetailType: 'Intersection Accident',
                lossDetailTypeCode: '-1',
                lossDate: '2017-08-06',
                lossTime: '9:32 am',
                lossState: 'California',
                liabilitySubjects: ['1', '2', '3', '4', '5'],
            };
            wrapper = shallow(
                <LossDetailsHeader
                    claimData={claimData}
                    readOnly={false}
                />
            );
            expect(wrapper.find('#show-more-btn').exists()).toBe(true);
        });
    });

    describe('renders the liabilitySubjects section', () => {

        it('should render liabilitySubjects label', () => {
            expect(wrapper.find('#participants-label').props().children).toEqual('Participants (5)');
        });

        it('should render the participant header', () => {
            expect(wrapper.find('ParticipantHeader').exists()).toBe(true);
        });
    });

    describe('connect', () => {
        it('should map store items as props', () => {
            const claimData = {claimNumber: '123'};
            const user = {userRoles: ['Read Only']};
            const store = {claimData, user};

            isReadOnlyUser.mockReturnValue(true);

            const result = mapStateToProps(store);
            expect(result.claimData).toBe(claimData);
            expect(result.readOnly).toBe(true);

            expect(isReadOnlyUser).toBeCalledWith(user.userRoles);
        });
    });
});
