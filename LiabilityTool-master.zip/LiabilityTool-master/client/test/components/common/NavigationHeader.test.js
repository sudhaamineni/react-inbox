import analyticsHelper from "../../../src/main/helpers/analyticsHelper";
import React from 'react';
import {shallow} from 'enzyme';
import {
    mapDispatchToProps,
    mapStateToProps,
    NavigationHeader
} from '../../../src/main/components/common/NavigationHeader';
import {signOutAction} from '../../../src/main/actions/signOutActions';
import {clearErrorMessagesAction} from '../../../src/main/actions/errorActions';
import {evidenceModalErrorAction, showEvidenceModalAction} from '../../../src/main/actions/evidenceActions';
import {isReadOnlyUser} from '../../../src/main/helpers/claimDataHelper';

jest.unmock('../../../src/main/components/common/NavigationHeader');

describe('Navigation Header', () => {
    let wrapper;
    const mockSignOutAction = jest.fn(),
        mockClearErrorMessagesAction = jest.fn();
    window.addEventListener = jest.fn();
    window.removeEventListener = jest.fn();
    document.getElementsByTagName = jest.fn().mockReturnValue([{scrollLeft: 32}]);
    let mockEvidences;
    let mockHistory = {push: jest.fn(), location: {pathname: '/some-route'}};
    let mockShowEvidenceModalAction, mockEvidenceModalErrorAction;

    beforeEach(() => {
        mockEvidences = [{id: 'evidence1', type: 'highlight', sourceId: 'highlight1'},
            {id: 'evidence2', type: 'highlight', sourceId: 'highlight2'}];
        mockShowEvidenceModalAction = jest.fn();
        mockEvidenceModalErrorAction = jest.fn();
        wrapper = shallow(
            <NavigationHeader
                userId={'smude'}
                history={mockHistory}
                isClaimSubmitted={false}
                renderSketchTab={false}
                enableSettleTab={false}
                showTabs={true}
                readOnlyUser={false}
                locked={false}
                signOutAction={mockSignOutAction}
                clearErrorMessagesAction={mockClearErrorMessagesAction}
                evidences={mockEvidences}
                claimNumber="12345"
                showEvidenceModalAction={mockShowEvidenceModalAction}
                evidenceModalErrorAction={mockEvidenceModalErrorAction}
                showEvidenceModal={false}
            />
        );
    });

    describe('Header component', () => {
        it('passes user prop', () => {
            expect(wrapper.find('Header').props().user).toEqual('smude');
        });

        it('passes showTabs prop', () => {
            expect(wrapper.find('Header').props().showTabs).toEqual(true);
        });

        describe('passes tabs prop', () => {
            it('should render default tabs', () => {
                expect(wrapper.find('Header').props().tabs).toEqual(['investigate', 'initial fault']);
            });

            it('should render sketch tab when renderSketchTab is true', () => {
                wrapper.setProps({renderSketchTab: true});
                expect(wrapper.find('Header').props().tabs).toEqual(['investigate', 'sketch', 'initial fault']);
            });

            it('should not render settle tab if claim has not been submitted, even if enableSettleTab is true', () => {
                wrapper.setProps({enableSettleTab: true});
                expect(wrapper.find('Header').props().tabs).toEqual(['investigate', 'initial fault']);
            });

            it('should not render settle tab if claim has been submitted but enableSettleTab featureSwitch is false', () => {
                wrapper.setProps({isClaimSubmitted: true});
                expect(wrapper.find('Header').props().tabs).toEqual(['investigate', 'initial fault']);
            });

            it('renders settle tab when enableSettleTab, and locked are true', () => {
                wrapper.setProps({enableSettleTab: true, locked: true});
                expect(wrapper.find('Header').props().tabs).toEqual(['investigate', 'initial fault', 'settlement']);
            });

            it('should not render settlement tab if claim was unlocked', () => {
                wrapper.setProps({enableSettleTab: true, locked: false});
                expect(wrapper.find('Header').props().tabs).toEqual(['investigate', 'initial fault']);
            });

            it('renders sketch and settlement tabs when renderSketchTab, enableSettleTab, and locked are true', () => {
                wrapper.setProps({renderSketchTab: true, enableSettleTab: true, locked: true});
                expect(wrapper.find('Header').props().tabs).toEqual(['investigate', 'sketch', 'initial fault', 'settlement']);
            });
        });

        describe('passes activeTab prop', () => {
            it('passes investigate when window.location.hash is #/', () => {
                window.location.hash = '#/';
                expect(wrapper.find('Header').props().activeTab).toEqual('investigate');
            });

            it('replaces hyphen with space if window.location.hash has it', () => {
                window.location.hash = '#/something-else';
                wrapper.setProps({rerender: true});
                expect(wrapper.find('Header').props().activeTab).toEqual('something else');
            });

            it('passes the tab name from window.location.hash', () => {
                window.location.hash = '#/theTab';
                wrapper.setProps({claimNumber: '12345'});
                expect(wrapper.find('Header').props().activeTab).toEqual('theTab');
            });
        });

        describe('passes showEvidence prop', () => {
            it('passes showTabs as the showEvidence prop', () => {
                wrapper.setProps({showTabs: true});
                expect(wrapper.find('Header').props().showEvidence).toBe(true);
                wrapper.setProps({showTabs: false});
                expect(wrapper.find('Header').props().showEvidence).toBe(false);
            });
        });

        describe('passes badgeContent prop', () => {
            it('should pass the number of evidences', () => {
                expect(wrapper.find('Header').props().badgeContent).toEqual(2);
            });

            it('should default to zero if there are no evidences', () => {
                wrapper.setProps({evidences: []});
                expect(wrapper.find('Header').props().badgeContent).toEqual(0);
            });
        });

        describe('passes triggerEvidence prop', () => {
            it('should pass as true for two seconds when evidence is added', () => {
                expect(wrapper.find('Header').props().triggerEvidence).toBe(false);
                wrapper.setProps({evidences: []});
                wrapper.setProps({evidences: [{id: 'e1'}]});
                expect(wrapper.find('Header').props().triggerEvidence).toBe(true);
                setTimeout(() => {
                    it('should pass as clear after two seconds when evidence is added', () => {
                        expect(wrapper.find('Header').props().triggerEvidence).toBe(false);
                    });
                }, 2000);
            });

            it('should pass as true for two seconds when evidence is removed', () => {
                wrapper.setProps({evidences: []});
                expect(wrapper.find('Header').props().triggerEvidence).toBe(true);
            });
        });

        describe('onLogoClick callback prop', () => {
            it('should return to / when the logo is clicked ', () => {
                window.sessionStorage.clear = jest.fn();
                wrapper.find('Header').simulate('logoClick');
                expect(mockClearErrorMessagesAction).toBeCalled();
                expect(mockHistory.push).toHaveBeenCalledWith('/');
                expect(window.sessionStorage.clear).toBeCalled();
            });
        });

        describe('onEvidenceClick callback prop', () => {
            it('should invoke showEvidenceModalAction with true when Header evidence button is clicked', () => {
                wrapper.find('Header').simulate('evidenceClick');
                expect(mockShowEvidenceModalAction).toBeCalledWith(true);
            });

            it('should track event when evidence button is clicked', () => {
                wrapper.find('Header').simulate('evidenceClick');
                expect(analyticsHelper.trackEvent).toBeCalledWith({
                    message: 'Evidence count = 2',
                    eventAction: 'NavigationHeader_Evidence_ButtonClicked',
                    eventSource: 'button',
                    errorCode: '',
                });
            });
        });

        describe('onTabChange callback prop', () => {
            it('when tab name does not contain space', () => {
                wrapper.find('Header').simulate('tabChange', 'something');
                expect(mockHistory.push).toHaveBeenCalledWith('/something');
            });

            it('when tab name contains space', () => {
                wrapper.find('Header').simulate('tabChange', 'something else');
                expect(mockHistory.push).toHaveBeenCalledWith('/something-else');
            });
        });

        describe('onMenuItemClick callback prop', () => {
            it('should sign the user out', () => {
                wrapper.find('Header').simulate('menuItemClick');
                expect(mockSignOutAction).toBeCalled();
            });
        });
    });

    describe('Evidence Modal', () => {
        it('should render the EvidenceModal with isActive true when showEvidenceModal prop is true', () => {
            wrapper.setProps({showEvidenceModal: true});
            expect(wrapper.find('Connect(EvidenceModal)').props().isActive).toBe(true);
        });

        it('should render the EvidenceModal with isActive false when showEvidenceModal prop is false', () => {
            wrapper.setProps({showEvidenceModal: false});
            expect(wrapper.find('Connect(EvidenceModal)').props().isActive).toBe(false);
        });

        it('should invoke showEvidenceModalAction and evidenceModalErrorAction with false on close', () => {
            wrapper.find('Header').simulate('evidenceClick');
            expect(mockShowEvidenceModalAction).toBeCalledWith(true);

            wrapper.find('Connect(EvidenceModal)').simulate('close');
            expect(mockShowEvidenceModalAction).toBeCalledWith(false);
            expect(mockEvidenceModalErrorAction).toBeCalledWith(false);
        });

        describe('when the EvidenceModal onContinueToFault event is invoked', () => {
            it('should invoke showEvidenceModalAction and evidenceModalErrorAction with false', () => {
                wrapper.find('Connect(EvidenceModal)').simulate('continueToFault');
                expect(mockShowEvidenceModalAction).toBeCalledWith(false);
                expect(mockEvidenceModalErrorAction).toBeCalledWith(false);
            });

            it('should set a timer to allow for the modal dismissal animation to play', () => {
                wrapper.find('Connect(EvidenceModal)').simulate('continueToFault');
                expect(wrapper.instance().transitionTimer).not.toBe(null);
            });

            it('should route to the initial-fault page when after a delay if we are not on the /inital-fault page', () => {
                jest.useFakeTimers();
                wrapper.find('Connect(EvidenceModal)').simulate('continueToFault');
                jest.runAllTimers();

                expect(mockHistory.push).toHaveBeenCalledWith('/initial-fault');
            });

            it('should not route to the initial-fault page if we are already on the page', () => {
                mockHistory = {push: jest.fn(), location: {pathname: '/initial-fault'}};
                wrapper.setProps({history: mockHistory});
                jest.useFakeTimers();
                wrapper.find('Connect(EvidenceModal)').simulate('continueToFault');
                jest.runAllTimers();

                expect(mockHistory.push).not.toHaveBeenCalled();
            });
        });
    });

    describe('Error Header', () => {
        it('should not render the ErrorBanner when the user is not Read Only and not showing the tabs', () => {
            wrapper.setProps({showTabs: false, readOnlyUser: false});
            expect(wrapper.find('ErrorBanner').length).toEqual(0);
        });

        it('should not render the ErrorBanner when the user is not Read Only even when showing the tabs', () => {
            wrapper.setProps({showTabs: true, readOnlyUser: false});
            expect(wrapper.find('ErrorBanner').length).toEqual(0);
        });

        it('should not render the Error Header when the user is Read Only but not showing the tabs', () => {
            wrapper.setProps({showTabs: false, readOnlyUser: true});
            expect(wrapper.find('ErrorBanner').length).toEqual(0);
        });

        it('should render the ErrorBanner when the user is Read Only and showing the tabs', () => {
            wrapper.setProps({readOnlyUser: true, showTabs: true});
            expect(wrapper.find('ErrorBanner').children().at(0).text()).toBe('Read Only Mode');
            expect(wrapper.find('ErrorBanner').children().at(1).text()).toBe('You are unable to edit this claim.');
            expect(wrapper.find('ErrorBanner').props().error).toBe(false);
        });

        it('should render the ErrorBanner when the user is not Read Only, claim is submitted', () => {
            wrapper.setProps({locked: true, readOnlyUser: false, showTabs: true});
            expect(wrapper.find('ErrorBanner').children().at(0).text()).toContain('Read Only Mode');
            expect(wrapper.find('ErrorBanner').children().at(1).text()).toContain('Initial Fault for this claim has been submitted.');
            expect(wrapper.find('#unlock-claim-link').text()).toBe('Unlock to make changes');
            expect(wrapper.find('ErrorBanner').props().error).toBe(false);
        });

        it('should not render the ErrorBanner when the user is not Read Only, claim is submitted and currentTab is settlement', () => {
            window.location.hash = '#/settlement';
            wrapper.setProps({locked: true, readOnlyUser: false, showTabs: true});
            expect(wrapper.find('ErrorBanner').length).toBe(0);
        });

        it('should not render the ErrorBanner when the user is not Read Only, claim is not submitted', () => {
            wrapper.setProps({locked: false, readOnlyUser: false, showTabs: true});
            expect(wrapper.find('ErrorBanner').length).toBe(0);
        });

        it('should show the UnlockClaimModal upon click of the unlock button', () => {
            window.location.hash = '#/notSettlement';
            wrapper.setProps({locked: true, readOnlyUser: false, showTabs: true});
            wrapper.find('ErrorBanner').find('a').simulate('click');
            expect(wrapper.find('Connect(UnlockClaimModal)').length).toBe(1);
        });
    });

    describe('Unlock Claim Modal', () => {
        it('should be active when showUnlockClaimModal is true', () => {
            wrapper.instance().setState({showUnlockClaimModal: true});
            expect(wrapper.find('Connect(UnlockClaimModal)').props().isActive).toBe(true);
        });

        it('should be inactive when showUnlockClaimModal is false', () => {
            wrapper.instance().setState({showUnlockClaimModal: false});
            expect(wrapper.find('Connect(UnlockClaimModal)').props().isActive).toBe(false);
        });

        it('should dismiss the Unlock Claim Modal when the toggleShowUnlockClaimModal callback is invoked', () => {
            wrapper.instance().setState({showUnlockClaimModal: true});
            wrapper.find('Connect(UnlockClaimModal)').props().toggleShowUnlockClaimModal();
            expect(wrapper.find('Connect(UnlockClaimModal)').props().isActive).toBe(false);
        });

    });

    describe('Lifecycle Events', () => {
        describe('initial state', () => {
            it('should start with showUnlockClaimModal and evidenceTriggered state as false', () => {
                expect(wrapper.instance().state.showUnlockClaimModal).toBe(false);
                expect(wrapper.instance().state.evidenceTriggered).toBe(false);
            });

            it('should start with no transitionTimer', () => {
                expect(wrapper.instance().transitionTimer).toBe(null);
            });
        });

        describe('componentWillUnmount', () => {
            it(' should clear out the transition timer if a timer exists', () => {
                wrapper.instance().transitionTimer = 'I am a timer';
                wrapper.instance().componentWillUnmount();
                expect(clearTimeout).toBeCalledWith('I am a timer');
            });

            it(' should NOT clear out the transition timer if a timer does not exists', () => {
                wrapper.instance().componentWillUnmount();
                expect(clearTimeout).not.toBeCalled();
            });
        });
    });

    describe('Connect', () => {
        const evidences = [{id: 'evidence1', sourceId: 'highlight1', type: 'highlight'}];
        const claimData = {claimNumber: '1234', initialFaultSubmitTime: 'right now', locked: true, evidences};
        const user = {userId: 'smude', userRoles: ['Read Only']};
        const featureSwitches = {renderSketchTab: false, enableSettleTab: true};
        const status = {showEvidenceModal: true};
        const state = {user, claimData, featureSwitches, evidences, status};
        const routerProps = {
            history: {}
        };

        it('maps required store items to props', () => {
            isReadOnlyUser.mockReturnValue(true);

            const result = mapStateToProps(state, routerProps);
            expect(result.userId).toEqual('smude');
            expect(result.history).toEqual({});
            expect(result.isClaimSubmitted).toBe(true);
            expect(result.renderSketchTab).toBe(false);
            expect(result.enableSettleTab).toBe(true);
            expect(result.readOnlyUser).toBe(true);
            expect(result.evidences).toEqual(evidences);
            expect(result.showEvidenceModal).toEqual(true);

            expect(isReadOnlyUser).toBeCalledWith(user.userRoles);
        });

        it('maps dispatch to props', () => {
            expect(mapDispatchToProps.signOutAction).toEqual(signOutAction);
            expect(mapDispatchToProps.showEvidenceModalAction).toEqual(showEvidenceModalAction);
            expect(mapDispatchToProps.evidenceModalErrorAction).toEqual(evidenceModalErrorAction);
            expect(mapDispatchToProps.clearErrorMessagesAction).toEqual(clearErrorMessagesAction);
        });
    });
});
