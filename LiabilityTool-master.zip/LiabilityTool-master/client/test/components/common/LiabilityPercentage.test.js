jest.unmock('../../../src/main/components/common/LiabilityPercentage');

import React from 'react';
import {shallow} from 'enzyme';
import LiabilityPercentage from '../../../src/main/components/common/LiabilityPercentage';
import {allowThreeDigitNumbers} from '../../../src/main/helpers/decisionErrorHelper';

describe('Given LiabilityPercentage component', () => {
    let wrapper;
    let mockOnBlurCallback;

    beforeEach(() => {
        mockOnBlurCallback = jest.fn();
        wrapper = shallow(
            <LiabilityPercentage
                value={20}
                readOnly={true}
                onBlurCallback={mockOnBlurCallback}
                hasError={true}
            />
        );
    });

    it('should set hasValidationError to false by default', () => {
        expect(wrapper.instance().state.hasValidationError).toBe(false);
    });

    it('should set percentValue to undefined by default', () => {
        expect(wrapper.instance().state.percentValue).toBe(undefined);
    });

    it('should render FormField with passed value prop', () => {
        expect(wrapper.find('FormField').props().value).toBe(20);
    });

    it('should pass the value of \'0\' as prop when value is 0', () => {
        wrapper.setProps({value: 0});
        expect(wrapper.find('FormField').props().value).toBe('0');
    });

    it('should pass a disabled prop as true when readOnly is true', () => {
        expect(wrapper.find('FormField').props().disabled).toBe(true);
    });

    it('should render percent sign', () => {
        expect(wrapper.find('#percentage').text()).toBe(' % ');
    });

    it('should set autoComplete to false', () => {
        expect(wrapper.find('FormField').props().autoComplete).toBe(false);
    });

    it('should call allowThreeDigitNumbers on key down', () => {
        wrapper.find('FormField').simulate('keydown');
        expect(allowThreeDigitNumbers).toBeCalled();
    });

    describe('onBlur', () => {
        it('should call onBlur prop on blur and update state hasValidationError to false', () => {
            wrapper.setState({hasValidationError: true});
            wrapper.find('FormField').simulate('blur', {target: {value: '99'}});
            expect(mockOnBlurCallback).toBeCalledWith(99);
            expect(wrapper.instance().state.hasValidationError).toBe(false);
        });

        it('should call onBlur with null event value when event value is an empty string', () => {
            wrapper.find('FormField').simulate('blur', {target: {value: ''}});
            expect(mockOnBlurCallback).toBeCalledWith(null);
        });

        it('should call onBlur with null event value when event value is spaces', () => {
            wrapper.find('FormField').simulate('blur', {target: {value: ' '}});
            expect(mockOnBlurCallback).toBeCalledWith(null);
        });

        describe('should not call onBlur prop when prev value is same as current', () => {
            it('prev value is null and current value is empty', () => {
                wrapper.setProps({value: null});
                wrapper.find('FormField').simulate('blur', {target: {value: ''}});

                expect(mockOnBlurCallback).not.toBeCalled();
            });

            it('prev value is null and current value is spaces', () => {
                wrapper.setProps({value: null});
                wrapper.find('FormField').simulate('blur', {target: {value: ' '}});

                expect(mockOnBlurCallback).not.toBeCalled();
            });

            it('prev value is null and current value is spaces', () => {
                wrapper.setProps({value: 11});
                wrapper.find('FormField').simulate('blur', {target: {value: '11'}});

                expect(mockOnBlurCallback).not.toBeCalled();
            });
        });
    });

    describe('Error states', () => {
        it('should render in error state when hasError', () => {
            expect(wrapper.find('.liability-range').props().className.includes('liability-range-error')).toBe(true);
        });

        it('should show validation error when entered with more than 100 and onBlurCallback should not be called', () => {
            wrapper.setState({hasValidationError: false});
            wrapper.find('FormField').simulate('blur', {target: {value: '123'}});
            expect(mockOnBlurCallback).not.toBeCalled();
            expect(wrapper.instance().state.hasValidationError).toBe(true);
            expect(wrapper.instance().state.percentValue).toBe(123);
        });

        it('should show validation error when entered with less than 0 and onBlurCallback should not be called', () => {
            wrapper.setState({hasValidationError: false});
            wrapper.find('FormField').simulate('blur', {target: {value: '-13'}});
            expect(mockOnBlurCallback).not.toBeCalled();
            expect(wrapper.instance().state.hasValidationError).toBe(true);
            expect(wrapper.instance().state.percentValue).toBe(-13);
        });

        it('should not show validation error when percent value is set to the last valid value from an error state', () => {
            wrapper.setProps({value: 99});
            wrapper.setState({hasValidationError: true, percentValue: undefined});

            wrapper.find('FormField').simulate('blur', {target: {value: '99'}});
            expect(wrapper.instance().state.hasValidationError).toBe(false);
        });

        it('should clear validation error', () => {
            wrapper.setState({hasValidationError: false, percentValue: undefined});
            wrapper.find('FormField').simulate('blur', {target: {value: '123'}});
            expect(wrapper.instance().state.hasValidationError).toBe(true);
            expect(wrapper.instance().state.percentValue).toBe(123);
            wrapper.find('FormField').simulate('blur', {target: {value: '100'}});
            expect(wrapper.instance().state.hasValidationError).toBe(false);
            expect(wrapper.instance().state.percentValue).toBe(undefined);
        });

        it('should set hasValidationError to false when entered an empty string', () => {
            wrapper.setState({hasValidationError: true, percentValue: 123});
            wrapper.find('FormField').simulate('blur', {target: {value: ''}});
            expect(wrapper.instance().state.hasValidationError).toBe(false);
            expect(wrapper.instance().state.percentValue).toBe(undefined);
        });

        describe('Validation error message', () => {
            describe('hasValidationError is true', () => {
                beforeEach(() => {
                    wrapper.setProps({hasError: false});
                    wrapper.setState({hasValidationError: true, percentValue: 123});
                });

                it('should get the value of FormField from percentValue state when hasValidationError is true', () => {
                    expect(wrapper.find('FormField').props().value).toBe(123);
                });

                it('should render with liability-range-error classname', () => {
                    expect(wrapper.find('.liability-range').props().className.includes('liability-range-error')).toBe(true);
                });

                it('should render % with u-text-error when hasValidationError is true', () => {
                    expect(wrapper.find('#percentage').props().className.includes('u-text-error')).toBe(true);
                });

                it('should render error text when the error is because the percentage is too large', () => {
                    expect(wrapper.find('#validation-error').text()).toBe('Must be 0-100%');
                });

                it('should render error text when the error is because the percentage is too large', () => {
                    wrapper.setState({percentValue: -123});
                    expect(wrapper.find('#validation-error').text()).toBe('Must be 0-100%');
                });

                it('should not render error text when the error is caused by any other reason ', () => {
                    wrapper.setState({percentValue: 45});
                    expect(wrapper.find('#validation-error').text()).toBe('');
                });
            });

            it('when hasValidationError is false, should render without any errors', () => {
                wrapper.setProps({hasError: false});
                wrapper.setState({hasValidationError: false});
                expect(wrapper.find('FormField').props().value).toBe(20);
                expect(wrapper.find('.liability-range').props().className.includes('liability-range-error')).toBe(false);
                expect(wrapper.find('#percentage').props().className.includes('color-bright-blue')).toBe(true);
                expect(wrapper.find('#validation-error').text()).toBe('');
            });
        });
    });
});
