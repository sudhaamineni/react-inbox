jest.unmock('../../../src/main/components/common/ErrorPage');

import {ErrorPage, mapDispatchToProps, mapStateToProps} from '../../../src/main/components/common/ErrorPage';
import {signOutAction} from '../../../src/main/actions/signOutActions';

import React from 'react';
import {shallow} from 'enzyme';

describe('Given an Error Page component', () => {
    let wrapper;
    const mockSignOutAction = jest.fn();

    beforeEach(() => {
        wrapper = shallow(
            <ErrorPage
                errorHeader={'Error Header'}
                errorDescription={'Error Description'}
                errorButton={''}
                signOutAction={mockSignOutAction}
            />
        );
    });

    it('passes icon to ErrorMessage', () => {
        expect(wrapper.find('ErrorMessage').props().icon.props.icon).toBe('alert-octagon');
    });

    it('passes errorText to ErrorMessage', () => {
        expect(wrapper.find('ErrorMessage').props().errorText.props.children).toBe('Error Header');
    });

    it('passes helpText to ErrorMessage', () => {
        expect(wrapper.find('ErrorMessage').props().helpText.props.children).toBe('Error Description');
    });

    it('passes buttonText to ErrorMessage', () => {
        expect(wrapper.find('ErrorMessage').props().buttonText.props.children).toBe('');
    });

    it('passes hideBtn to ErrorMessage', () => {
        expect(wrapper.find('ErrorMessage').props().hideBtn).toBe(true);
    });

    it('passes onButtonClick to ErrorMessage', () => {
        wrapper.find('ErrorMessage').props().onButtonClick();
        expect(mockSignOutAction).not.toBeCalled();
    });

    describe('When error button is back to login', () => {
        beforeEach(() => {
            wrapper.setProps({errorButton: 'Back to Login'});
        });

        it('passes buttonText to ErrorMessage', () => {
            expect(wrapper.find('ErrorMessage').props().buttonText.props.children).toBe('Back to Login');
        });

        it('passes hideBtn to ErrorMessage', () => {
            expect(wrapper.find('ErrorMessage').props().hideBtn).toBe(false);
        });

        it('passes onButtonClick to ErrorMessage', () => {
            wrapper.find('ErrorMessage').props().onButtonClick();
            expect(mockSignOutAction).toBeCalled();
        });
    });

    describe('Connect', () => {
        describe('mapStateToProps', () => {
            const status = {
                errorHeader: 'Error Header',
                errorDescription: 'Error Description',
                errorButton: 'Error Button'
            };
            const state = {status};

            it('maps required store items to props', () => {
                const result = mapStateToProps(state);
                expect(result.errorHeader).toBe('Error Header');
                expect(result.errorDescription).toBe('Error Description');
                expect(result.errorButton).toBe('Error Button');
            });
        });

        it('mapDispatchToProps', () => {
            expect(mapDispatchToProps.signOutAction).toBe(signOutAction);
        });
    });
});
