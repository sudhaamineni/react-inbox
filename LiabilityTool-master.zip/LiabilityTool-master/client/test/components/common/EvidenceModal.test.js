import React from 'react';
import {shallow} from 'enzyme';
import {showEvidenceModalAction} from '../../../src/main/actions/evidenceActions';
import {EvidenceModal, mapDispatchToProps, mapStateToProps} from '../../../src/main/components/common/EvidenceModal';
import {isReadOnly} from '../../../src/main/helpers/claimDataHelper';

jest.unmock('../../../src/main/components/common/EvidenceModal');
jest.unmock('../../../src/main/constants/loonConstants');

describe('EvidenceModal', () => {
    let wrapper;
    let mockEvidences;
    let mockOnClose;
    let mockOnContinueToFault;
    let mockShowEvidenceModalAction;
    beforeEach(() => {
        mockEvidences = [
            {id: 'evidence1', sourceId: 'highlight1', type: 'highlight', category: 'damages'},
            {id: 'evidence2', sourceId: 'highlight2', type: 'highlight', category: null},
            {id: 'evidence3', sourceId: 'photo1', type: 'photo', category: null, photoUrl: 'my/photo1'},
            {id: 'evidence4', sourceId: 'photo2', type: 'photo', category: null, photoUrl: 'my/photo2'},
            {
                id: 'evidence5',
                sourceId: 'photo3',
                type: 'photo',
                category: 'condition-of-roadway',
                photoUrl: 'my/photo3'
            },
            {id: 'evidence6', sourceId: 'highlight3', type: 'highlight', category: 'condition-of-roadway'}
        ];
        mockOnClose = jest.fn();
        mockOnContinueToFault = jest.fn();
        mockShowEvidenceModalAction = jest.fn();
        wrapper = shallow(
            <EvidenceModal
                isActive
                evidences={mockEvidences}
                onClose={mockOnClose}
                onContinueToFault={mockOnContinueToFault}
                showEvidenceModalAction={mockShowEvidenceModalAction}
                readOnly={false}
                evidenceModalError={false}
            />);
    });

    it('should render a ModalDialog', () => {
        expect(wrapper.find('ModalDialog').exists()).toBe(true);
    });

    it('should pass the isActive prop to the ModalDialog', () => {
        wrapper.setProps({isActive: true});
        expect(wrapper.find('ModalDialog').props().isActive).toBe(true);
        wrapper.setProps({isActive: false});
        expect(wrapper.find('ModalDialog').props().isActive).toBe(false);
    });

    it('should hide the trigger', () => {
        expect(wrapper.find('ModalDialog').props().hideTrigger).toBe(true);
    });

    it('should invoke onClose prop when ModalDialog is closed', () => {
        wrapper.find('ModalDialog').simulate('close');
        expect(mockOnClose).toBeCalled();
    });

    describe('header', () => {
        let modalHeader;

        beforeEach(() => {
            modalHeader = shallow(wrapper.find('ModalDialog').props().header);
        });

        it('should contain the word Evidence and evidence count', () => {
            expect(modalHeader.text()).toEqual(expect.stringContaining('Evidence (6)'));
        });

        it('should have a yellow star', () => {
            expect(modalHeader.find('Icon').props().icon).toBe('star');
            expect(modalHeader.find('Icon').props().color).toBe('bookmark');
            expect(modalHeader.find('Icon').props().size).toBe(1.5);
        });
    });

    describe('error banner', () => {

        describe('when evidenceModalError is true ', () => {
            beforeEach(() => {
                wrapper.setProps({evidenceModalError: true});
            });

            it('should display an error banner with error prop when evidenceModalError is true', () => {
                expect(wrapper.find('ErrorBanner').props().error).toBe('error');
            });

            it('should display the error message inside the error banner when evidence', () => {
                expect(wrapper.find('ErrorBanner').children().at(0).text()).toBe('Missing Information.');
                expect(wrapper.find('ErrorBanner').children().at(1).text()).toBe(' Complete evidence tagging to continue to Assign Fault.');
            });
        });

        describe('when evidenceModalError is false', () => {
            it('should not display an error banner  when evidenceModalError is true', () => {
                wrapper.setProps({evidenceModalError: false});
                expect(wrapper.find('ErrorBanner').exists()).toBe(false);
            });
        });
    });

    describe('Body', () => {
        describe('untagged and category sections', () => {
            it('renders the EvidenceModalSection for each evidence category', () => {
                expect(wrapper.find('EvidenceModalSection').length).toBe(3);
                expect(wrapper.find('EvidenceModalSection').at(0).exists()).toBe(true);
                expect(wrapper.find('EvidenceModalSection').at(1).exists()).toBe(true);
                expect(wrapper.find('EvidenceModalSection').at(2).exists()).toBe(true);
            });

            it('renders the EvidenceModalSection with correct props for each evidence category and sorted', () => {
                const expectedUntaggedEvidences = [{
                    id: 'evidence2',
                    sourceId: 'highlight2',
                    type: 'highlight',
                    category: null
                }, {
                    id: 'evidence3',
                    sourceId: 'photo1',
                    type: 'photo',
                    category: null,
                    photoUrl: 'my/photo1'
                },
                    {id: 'evidence4', sourceId: 'photo2', type: 'photo', category: null, photoUrl: 'my/photo2'}];
                const expectedDamagesEvidences = [{
                    id: 'evidence1',
                    sourceId: 'highlight1',
                    type: 'highlight',
                    category: 'damages'
                }];
                const expectedWeatherConditionEvidences = [{
                    id: 'evidence5',
                    sourceId: 'photo3',
                    type: 'photo',
                    category: 'condition-of-roadway',
                    photoUrl: 'my/photo3'
                },
                    {id: 'evidence6', sourceId: 'highlight3', type: 'highlight', category: 'condition-of-roadway'}];

                expect(wrapper.find('EvidenceModalSection').at(0).props().category).toBe('untagged');
                expect(wrapper.find('EvidenceModalSection').at(0).props().evidences).toEqual(expectedUntaggedEvidences);
                expect(wrapper.find('EvidenceModalSection').at(0).props().readOnly).toBe(false);
                expect(wrapper.find('EvidenceModalSection').at(1).props().category).toBe('condition-of-roadway');
                expect(wrapper.find('EvidenceModalSection').at(1).props().evidences).toEqual(expectedWeatherConditionEvidences);
                expect(wrapper.find('EvidenceModalSection').at(1).props().readOnly).toBe(false);
                expect(wrapper.find('EvidenceModalSection').at(2).props().category).toBe('damages');
                expect(wrapper.find('EvidenceModalSection').at(2).props().evidences).toEqual(expectedDamagesEvidences);
                expect(wrapper.find('EvidenceModalSection').at(2).props().readOnly).toBe(false);
            });

            it('renders the EvidenceModalSection with correct props for each evidence category and sorted (2)', () => {
                let mockEvidences = [
                    {id: 'evidence6', sourceId: 'highlight3', type: 'highlight', category: 'condition-of-roadway'},
                    {id: 'evidence1', sourceId: 'highlight1', type: 'highlight', category: 'damages'},
                    {id: 'evidence2', sourceId: 'highlight2', type: 'highlight', category: null},
                    {id: 'evidence3', sourceId: 'photo1', type: 'photo', category: null, photoUrl: 'my/photo1'},
                    {id: 'evidence4', sourceId: 'photo2', type: 'photo', category: null, photoUrl: 'my/photo2'},
                    {
                        id: 'evidence5',
                        sourceId: 'photo3',
                        type: 'photo',
                        category: 'condition-of-roadway',
                        photoUrl: 'my/photo3'
                    },
                ];

                wrapper = shallow(
                    <EvidenceModal
                        isActive
                        evidences={mockEvidences}
                        onClose={mockOnClose}
                        onContinueToFault={mockOnContinueToFault}
                        showEvidenceModalAction={mockShowEvidenceModalAction}
                        readOnly={false}
                        evidenceModalError={false}
                    />);

                const expectedUntaggedEvidences = [{
                    id: 'evidence2',
                    sourceId: 'highlight2',
                    type: 'highlight',
                    category: null
                }, {
                    id: 'evidence3',
                    sourceId: 'photo1',
                    type: 'photo',
                    category: null,
                    photoUrl: 'my/photo1'
                },
                    {id: 'evidence4', sourceId: 'photo2', type: 'photo', category: null, photoUrl: 'my/photo2'}];
                const expectedDamagesEvidences = [{
                    id: 'evidence1',
                    sourceId: 'highlight1',
                    type: 'highlight',
                    category: 'damages'
                }];
                const expectedWeatherConditionEvidences = [
                    {id: 'evidence6', sourceId: 'highlight3', type: 'highlight', category: 'condition-of-roadway'}, {
                        id: 'evidence5',
                        sourceId: 'photo3',
                        type: 'photo',
                        category: 'condition-of-roadway',
                        photoUrl: 'my/photo3'
                    }];

                expect(wrapper.find('EvidenceModalSection').at(0).props().category).toBe('untagged');
                expect(wrapper.find('EvidenceModalSection').at(0).props().evidences).toEqual(expectedUntaggedEvidences);
                expect(wrapper.find('EvidenceModalSection').at(1).props().category).toBe('condition-of-roadway');
                expect(wrapper.find('EvidenceModalSection').at(1).props().evidences).toEqual(expectedWeatherConditionEvidences);
                expect(wrapper.find('EvidenceModalSection').at(2).props().category).toBe('damages');
                expect(wrapper.find('EvidenceModalSection').at(2).props().evidences).toEqual(expectedDamagesEvidences);
            });
        });
    });

    describe('footer', () => {
        let modalFooter;

        beforeEach(() => {
            modalFooter = shallow(wrapper.find('ModalDialog').props().footer);
        });

        it('should render the "Continue to Fault" button', () => {
            expect(modalFooter.find('button').exists()).toBe(true);
            expect(modalFooter.find('button').text()).toBe('Continue to Fault');
            expect(modalFooter.find('button').props().onClick).toBe(mockOnContinueToFault);
        });

        it('should render the "Continue to Fault" button disabled if there are untagged evidence', () => {
            expect(modalFooter.find('button').props().disabled).toBe(true);
        });

        it('should render the "Continue to Fault" button enabled if there are no untagged evidence', () => {
            let mockEvidences = [
                {id: 'evidence1', sourceId: 'highlight1', type: 'highlight', category: 'damages'},
                {id: 'evidence2', sourceId: 'highlight2', type: 'highlight', category: 'road conditions'}
            ];

            wrapper = shallow(
                <EvidenceModal
                    isActive
                    evidences={mockEvidences}
                    onClose={mockOnClose}
                    onContinueToFault={mockOnContinueToFault}
                    showEvidenceModalAction={mockShowEvidenceModalAction}
                    readOnly={false}
                    evidenceModalError={false}
                />
            );
            modalFooter = shallow(wrapper.find('ModalDialog').props().footer);
            expect(modalFooter.find('button').props().disabled).toBe(false);
        });

        it('should invoke continueToFault callback when footer button is clicked', () => {
            modalFooter.find('button').simulate('click');
            expect(mockOnContinueToFault).toBeCalled();
        });
    });

    describe('empty state', () => {
        beforeEach(() => {
            wrapper.setProps({evidences: []});
        });

        it('should render a gray star', () => {
            const modalHeader = shallow(wrapper.find('ModalDialog').props().header);
            expect(modalHeader.find('Icon').props().color).toBe('gray-lighter');
        });

        it('should render the empty state message', () => {
            expect(wrapper.find('.evidence-modal__empty').text()).toEqual(expect.stringContaining('You haven\'t added any evidence'));
            expect(wrapper.find('.evidence-modal__empty').text()).toEqual(expect.stringContaining('Photos and transcript highlights can be added as evidence on <Link />.'));
            expect(wrapper.find('Link').props().children).toEqual('Investigate');
        });

        it('should not render any EvidenceModalSection components', () => {
            expect(wrapper.find('EvidenceModalSection').exists()).toBe(false);
        });

        it('should navigate to the investigate page and close the modal when the investigate link is clicked', () => {
            const link = wrapper.find('Link');
            expect(link.props().children).toBe('Investigate');
            expect(link.props().to).toEqual('/investigate');
            link.simulate('click');
            expect(mockShowEvidenceModalAction).toBeCalledWith(false);
        });
    });

    describe('Horizontal rule', () => {
        it('should render for evidences except the last one', () => {
            expect(wrapper.find('hr').length).toBe(2);

            expect(wrapper.find('#evidence-modal-section').at(0).find('hr').exists()).toBe(true);
            expect(wrapper.find('#evidence-modal-section').at(1).find('hr').exists()).toBe(true);
            expect(wrapper.find('#evidence-modal-section').at(2).find('hr').exists()).toBe(false);
        });
    });

    describe('connect', () => {
        it('should mapStateToProps', () => {
            const claimData = {
                evidences: [{
                    blah: 'blah',
                }, {
                    blah: 'blah2',
                }],
                locked: true
            };

            const status = {evidenceModalError: false};
            const user = {userRoles: ['LOON Read Only User']};

            const expectedEvidences = [{
                blah: 'blah',
            }, {
                blah: 'blah2',
            }];

            isReadOnly.mockReset();
            isReadOnly.mockReturnValue(true);

            const state = {claimData, status, user};
            const result = mapStateToProps(state);
            expect(result.evidences).toEqual(expectedEvidences);
            expect(result.evidenceModalError).toEqual(false);
            expect(result.readOnly).toBe(true);
            expect(isReadOnly).toBeCalledWith(['LOON Read Only User'], true);
        });

        it('should mapDispatchToProps', () => {
            const expected = {
                showEvidenceModalAction,
            };

            expect(mapDispatchToProps).toEqual(expected);
        });
    });
});
