jest.unmock('../../../src/main/components/common/GoogleMapContainer');

import React from 'react';
import {shallow} from 'enzyme';
import {
    GoogleMapContainer,
    mapDispatchToProps,
    mapStateToProps
} from '../../../src/main/components/common/GoogleMapContainer';
import {lossLocationSaveAction} from '../../../src/main/actions/lossLocationActions';
import {isReadOnly} from '../../../src/main/helpers/claimDataHelper';

describe('Given GoogleMapContainer', () => {
    let wrapper;

    const mockClaimData = {
            mapAddress: '123 SwrappertName, City, State ZipCode',
            updatedLossLocation: 'test',
            claimNumber: '123',
            initialFaultSubmitTime: '2017-08-06 12:12:12',
            lossDetailType: 'Intersection Accident',
            lossDetailTypeCode: '01',
            lossDate: '06/08/2017',
            lossTime: '9:32 am',
            lossState: 'California',
            longitude: undefined,
            latitude: undefined
        },
        mockLossLocationSaveAction = jest.fn();

    beforeEach(() => {
        wrapper = shallow(
            <GoogleMapContainer
                claimData={mockClaimData}
                lossLocationSaveAction={mockLossLocationSaveAction}
                readOnly={false}
            />
        );
    });

    describe('renders google map', () => {
        it('should pass isClickToActivate prop as true', () => {
            expect(wrapper.find('GoogleMap').props().isClickToActivate).toBe(true);
        });

        it('should pass minHeight prop as 366px', () => {
            expect(wrapper.find('GoogleMap').props().minHeight).toBe('366px');
        });

        it('should pass address prop as the updatedLossLocation from claimData when updatedLossLocation is available', () => {
            expect(wrapper.find('GoogleMap').props().address).toBe('test');
        });

        it('should pass address prop as the mapAddress from claimData when updatedLossLocation is not available', () => {
            wrapper.setProps({claimData: {...mockClaimData, updatedLossLocation: undefined}});
            expect(wrapper.find('GoogleMap').props().address).toBe('123 SwrappertName, City, State ZipCode');
        });

        it('should pass address prop as empty when updatedLossLocation and mapAddress is not available', () => {
            wrapper.setProps({claimData: {...mockClaimData, updatedLossLocation: undefined, mapAddress: undefined}});
            expect(wrapper.find('GoogleMap').props().address).toBe('');
        });

        it('should pass readOnly prop as false when user does not have read only role', () => {
            expect(wrapper.find('GoogleMap').props().readOnly).toBe(false);
        });

        it('should pass readOnly prop as true when user has read only role', () => {
            wrapper.setProps({readOnly: true});
            expect(wrapper.find('GoogleMap').props().readOnly).toBe(true);
        });

        it('should pass latLng prop as undefined when no latitude is available', () => {
            wrapper.setProps({claimData: {...mockClaimData, latitude: undefined}});
            expect(wrapper.find('GoogleMap').props().latLng).toEqual(undefined);
        });

        it('should pass latLng prop as undefined when no longitude is available', () => {
            wrapper.setProps({claimData: {...mockClaimData, longitude: undefined}});
            expect(wrapper.find('GoogleMap').props().latLng).toEqual(undefined);
        });

        it('should pass latLng prop when both latitude and longitude are available', () => {
            wrapper.setProps({claimData: {...mockClaimData, latitude: 11.11, longitude: 22.22}});
            expect(wrapper.find('GoogleMap').props().latLng).toEqual({lat: 11.11, lng: 22.22});
        });

        it('Passes 18 for mapOptions.zoom prop', () => {
            expect(wrapper.find('GoogleMap').props().mapOptions.zoom).toBe(18);
        });

        it('Passes true for mapOptions.ScrollWheel', () => {
            expect(wrapper.find('GoogleMap').props().mapOptions.scrollwheel).toBe(true);
        });

        it('Passes true for mapOptions.draggable', () => {
            expect(wrapper.find('GoogleMap').props().mapOptions.draggable).toBe(true);
        });

        it('Passes Satellite for mapOptions.mapTypeId', () => {
            expect(wrapper.find('GoogleMap').props().mapOptions.mapTypeId).toBe('hybrid');
        });

        it('should pass styles prop', () => {
            expect(wrapper.find('GoogleMap').props().mapOptions.styles).toEqual([
                {
                    featureType: 'road',
                    stylers: [
                        {visibility: 'on'}
                    ]
                }
            ]);
        });

        it('Passes true for mapOptions.SwrappertViewControl', () => {
            expect(wrapper.find('GoogleMap').props().mapOptions.streetViewControl).toBe(true);
        });

        it('Passes true for mapOptions.mapTypeControl', () => {
            expect(wrapper.find('GoogleMap').props().mapOptions.mapTypeControl).toBe(false);
        });

        it('Passes RightCenter for mapOptions.zoomControlOptions.position', () => {
            expect(wrapper.find('GoogleMap').props().mapOptions.zoomControlOptions.position).toBe('Right Center');
        });

        it('Passes RightCenter for mapOptions.swrappertViewControlOptions.position', () => {
            expect(wrapper.find('GoogleMap').props().mapOptions.streetViewControlOptions.position).toBe('Right Center');
        });
    });

    describe('error states', () => {
        const missingLocationClaimData = {
            mapAddress: '123 SwrappertName, City, State ZipCode',
            updatedLossLocation: null,
            claimNumber: '123',
            initialFaultSubmitTime: '2017-08-06 12:12:12',
            lossDetailType: 'Intersection Accident',
            lossDetailTypeCode: '01',
            lossDate: '06/08/2017',
            lossTime: '9:32 am',
            lossState: 'California',
            lossCountyDescription: 'SomeLossCounty',
            lossCity: null,
            lossStreet: null,
            lossAddress: null,
            lossZip: null,
            longitude: undefined,
            latitude: undefined
        };

        beforeEach(() => {
            wrapper = shallow(
                <GoogleMapContainer
                    claimData={missingLocationClaimData}
                    lossLocationSaveAction={mockLossLocationSaveAction}
                    readOnly={false}
                />
            );
        });

        it('should render a error header when user has not updated loss location and only state and county are available', () => {
            wrapper.setProps({claimData: missingLocationClaimData});
            expect(wrapper.find('ErrorBanner').props().error).toBe(true);
            expect(wrapper.find('ErrorBanner').props().children[0].props.children).toBe('Missing Information: ');
            expect(wrapper.find('ErrorBanner').props().children[1]).toBe('Please provide the most precise loss location available');
        });

        it('should not render an error header when the loss location has been updated', () => {
            const updatedLossLocationClaimData = {
                mapAddress: '123 SwrappertName, City, State ZipCode',
                updatedLossLocation: 'Some updated loss location',
                claimNumber: '123',
                initialFaultSubmitTime: '2017-08-06 12:12:12',
                lossDetailType: 'Intersection Accident',
                lossDetailTypeCode: '01',
                lossDate: '06/08/2017',
                lossTime: '9:32 am',
                lossState: 'California',
                lossCountyDescription: 'SomeLossCounty',
                lossCity: null,
                lossStreet: null,
                lossAddress: null,
                lossZip: null,
                longitude: undefined,
                latitude: undefined
            };

            expect(wrapper.find('ErrorBanner').exists()).toBe(true);
            wrapper.setProps({claimData: updatedLossLocationClaimData});
            expect(wrapper.find('ErrorBanner').exists()).toBe(false);
        });

        it('should not render an error header when claimData contains more than just loss state and county', () => {
            const preciseLocationClaimData = {
                mapAddress: '123 SwrappertName, City, State ZipCode',
                updatedLossLocation: null,
                claimNumber: '123',
                initialFaultSubmitTime: '2017-08-06 12:12:12',
                lossDetailType: 'Intersection Accident',
                lossDetailTypeCode: '01',
                lossDate: '06/08/2017',
                lossTime: '9:32 am',
                lossState: 'California',
                lossCountyDescription: 'SomeLossCounty',
                lossCity: 'Chitown',
                lossStreet: 'The streets',
                lossAddress: 'Some numbers',
                lossZip: '600666',
                longitude: undefined,
                latitude: undefined
            };

            expect(wrapper.find('ErrorBanner').exists()).toBe(true);
            wrapper.setProps({claimData: preciseLocationClaimData});
            expect(wrapper.find('ErrorBanner').exists()).toBe(false);
        });
    });

    describe('onConfirmAddress', () => {
        beforeEach(() => {
            mockLossLocationSaveAction.mockReset();
        });

        it('onConfirmAddress calls the lossLocationSaveAction when a address is passed in', () => {
            wrapper.find('GoogleMap').simulate('confirmAddress', 'test1', {lng: 22, lat: -34});
            expect(mockLossLocationSaveAction).toBeCalledWith('123', -34, 22, 'test1');
        });

        it('onConfirmAddress does not call the lossLocationSaveAction when a address is not passed in', () => {
            wrapper.find('GoogleMap').simulate('confirmAddress', undefined, {lng: 22, lat: -34});
            expect(mockLossLocationSaveAction).not.toHaveBeenCalled();
        });

        it('onConfirmAddress does not call the lossLocationSaveAction when the address is not changed', () => {
            wrapper.find('GoogleMap').simulate('confirmAddress', 'test', {lng: 22, lat: -34});
            expect(mockLossLocationSaveAction).not.toHaveBeenCalled();
        });
    });

    describe('onMapChange read write access', () => {
        beforeEach(() => {
            mockLossLocationSaveAction.mockReset();
        });

        it('onMapChange calls the lossLocationSaveAction when mapOptions are passed in', () => {
            wrapper.find('GoogleMap').simulate('mapChange', {center: {lng: 22, lat: -34}});
            expect(mockLossLocationSaveAction).toBeCalledWith('123', -34, 22, 'test');
        });

        it('onMapChange does not call the lossLocationSaveAction when mapOptions are not passed in', () => {
            wrapper.find('GoogleMap').simulate('mapChange', undefined);
            expect(mockLossLocationSaveAction).not.toHaveBeenCalled();
        });

        it('onMap does not call the lossLocationSaveAction when the longitude or latitude is not changed', () => {
            wrapper.find('GoogleMap').simulate('mapChange', {center: {lng: undefined, lat: undefined}});
            expect(mockLossLocationSaveAction).not.toHaveBeenCalled();
        });

        it('should not call the lossLocationSaveAction when mapOptions are passed in and the user is ReadOnly', () => {
            wrapper.setProps({readOnly: true});
            wrapper.find('GoogleMap').simulate('mapChange', {center: {lng: 123, lat: 123}});
            expect(mockLossLocationSaveAction).not.toHaveBeenCalled();
        });

        it('should not call  the lossLocationSaveAction when claimData has not changed longitude/latitude', () => {
            wrapper.setProps({
                claimData: {
                    longitude: undefined,
                    latitude: undefined
                }
            });
            wrapper.find('GoogleMap').simulate('mapChange', {center: {lng: undefined, lat: undefined}});
            expect(mockLossLocationSaveAction).not.toHaveBeenCalled();
        });
    });

    describe('connect', () => {
        it('should map store items as props', () => {
            const claimData = {claimNumber: '123'},
                user = {userId: 'user1', userRoles: ['LOON User']};
            const store = {claimData, user};

            isReadOnly.mockReturnValue(true);

            const result = mapStateToProps(store);
            expect(result.claimData).toBe(claimData);
            expect(result.readOnly).toBe(true);
            expect(isReadOnly).toBeCalledWith(user.userRoles, claimData.locked);
        });

        it('should map action as props', () => {
            const expected = {
                lossLocationSaveAction
            };
            expect(mapDispatchToProps).toEqual(expected);
        });
    });
});
