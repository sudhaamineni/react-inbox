import React from 'react';
import {shallow} from 'enzyme';
import {
    mapDispatchToProps,
    mapStateToProps,
    UnlockClaimModal
} from '../../../src/main/components/common/UnlockClaimModal';
import {saveClaimUnlockAction} from '../../../src/main/actions/claimDataActions';

jest.unmock('../../../src/main/components/common/UnlockClaimModal');

describe('When UnlockClaimModal component', () => {
    let wrapper;
    let mockToggleShowUnlockClaimModal,
        mockSaveClaimUnlockAction;

    beforeEach(() => {
        mockToggleShowUnlockClaimModal = jest.fn();
        mockSaveClaimUnlockAction = jest.fn();
        wrapper = shallow(
            <UnlockClaimModal
                claimNumber="ClaimNumber"
                isActive={true}
                toggleShowUnlockClaimModal={mockToggleShowUnlockClaimModal}
                saveClaimUnlockAction={mockSaveClaimUnlockAction}
            />
        );
    });

    describe('renders ModalDialog component', () => {
        it('should pass props to ModalDialog component on render', () => {
            expect(wrapper.find('ModalDialog').props().title.props.children).toEqual('Unlock Claim');
            expect(wrapper.find('ModalDialog').props().showCloseBtn).toBe(true);
            expect(wrapper.find('ModalDialog').props().hideTrigger).toBe(true);
            expect(wrapper.find('ModalDialog').props().isActive).toBe(true);
            expect(wrapper.find('ModalDialog').props().footer.props.children.props.children.props.children).toBe('Unlock');
        });

        it('should display the dropdown label', () => {
            expect(wrapper.find('.u-vr-2.u-text-md.loon-color-gray-404040.u-text-normal').text()).toBe('Please provide your reason for unlocking this claim.');
        });

        it('should render CustomDropdown', () => {
            const optionsToUnlock = [
                {label: 'Received additional loss information', value: 'info'},
                {label: 'Correction/Error', value: 'error',},
                {label: 'Other', value: 'other',},
            ];
            const dropdown = wrapper.find('ModalDialog').find('CustomDropdown');
            expect(dropdown.props().items).toEqual(optionsToUnlock);
            expect(dropdown.props().placeHolder).toEqual('Select Reason...');
            expect(dropdown.props().hasError).toBe(false);
            expect(dropdown.props().initialSelectedItem).toEqual({value: 'select'});
            expect(dropdown.props().errorText).toBe('Please choose a reason');
        });

        it('should not render text area by default', () => {
            expect(wrapper.find('ModalDialog').find('FormField').length).toBe(0);
        });

        describe('Save button click', () => {
            it('should not call saveClaimUnlockAction and show error for dropdown when Save is clicked with select option in the dropdown', () => {
                let footer = shallow(wrapper.find('ModalDialog').props().footer);

                footer.find('.c-btn--primary').simulate('click');
                expect(mockSaveClaimUnlockAction).not.toBeCalled();
                expect(wrapper.find('CustomDropdown').props().hasError).toBe(true);
            });

            it('should call the save claim unlock action if other is not chosen', () => {
                let footer = shallow(wrapper.find('ModalDialog').props().footer);

                const item = {label: 'Correction/Error', value: 'error'};
                wrapper.find('CustomDropdown').simulate('select', item);

                footer.find('.c-btn--primary').simulate('click');
                expect(mockSaveClaimUnlockAction).toBeCalledWith('ClaimNumber', 'error', '');
                expect(mockToggleShowUnlockClaimModal).toBeCalled();
            });

            it('should call the save claim unlock action with correct parameters if other is chosen', () => {
                let footer = shallow(wrapper.find('ModalDialog').props().footer);

                const item = {label: 'Other', value: 'other'};
                wrapper.find('CustomDropdown').simulate('select', item);

                wrapper.find('FormField').simulate('blur', {target: {value: 'my reason to unlock'}});
                footer.find('.c-btn--primary').simulate('click');
                expect(mockSaveClaimUnlockAction).toBeCalledWith('ClaimNumber', 'other', 'my reason to unlock');
                expect(mockToggleShowUnlockClaimModal).toBeCalled();
            });
        });

        it('should not render textArea on dropdown selecting info (something not Other)', () => {
            const item = {label: 'Correction/Error', value: 'error'};
            wrapper.find('CustomDropdown').simulate('select', item);

            expect(wrapper.find('ModalDialog').find('FormField').length).toBe(0);
            expect(wrapper.find('CustomDropdown').props().initialSelectedItem).toEqual({value: 'error'});
            expect(wrapper.find('CustomDropdown').props().hasError).toBe(false);
        });

        it('should render textArea after selecting other in dropdown', () => {
            const item = {label: 'Other', value: 'other'};
            wrapper.find('CustomDropdown').simulate('select', item);

            expect(wrapper.find('ModalDialog').find('FormField').props().type).toBe('textarea');
            expect(wrapper.find('ModalDialog').find('FormField').props().placeholder).toBe('Please provide an explanation');
            expect(wrapper.find('ModalDialog').find('FormField').props().rows).toBe(4);
            expect(wrapper.find('ModalDialog').find('FormField').props().maxLength).toBe(160);
            expect(wrapper.find('ModalDialog').find('FormField').props().value).toBe('');
            expect(wrapper.find('ModalDialog').find('FormField').props().hasError).toBe(false);
            expect(wrapper.find('ModalDialog').find('FormField').props().errorText).toBe('Please provide an explanation');
            expect(wrapper.find('ModalDialog').find('FormField').props().autoComplete).toBe(false);

            expect(wrapper.find('CustomDropdown').props().initialSelectedItem).toEqual({value: 'other'});
            expect(wrapper.find('CustomDropdown').props().hasError).toBe(false);
        });

        it('should render textArea label after selecting other in dropdown', () => {
            const item = {label: 'Other', value: 'other'};
            wrapper.find('CustomDropdown').simulate('select', item);
            expect(wrapper.find('.u-vr-3-top.u-vr-2.u-text-md.loon-color-gray-404040.u-text-normal').text()).toBe('If other, please provide an explanation.');
        });
    });

    describe('mapDispatchToProps', () => {
        expect(mapDispatchToProps).toEqual({saveClaimUnlockAction});
    });

    describe('mapStateToProps', () => {
        const claimData = {claimNumber: '123'};
        const store = {claimData};
        const result = mapStateToProps(store);
        expect(result.claimNumber).toEqual('123');
    });
});
