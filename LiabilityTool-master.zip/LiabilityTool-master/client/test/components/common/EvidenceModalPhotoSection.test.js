jest.unmock('../../../src/main/constants/loonConstants');
jest.unmock('../../../src/main/components/common/EvidenceModalPhotoSection');

import React from 'react';
import {shallow} from 'enzyme';
import {
    EvidenceModalPhotoSection,
    mapDispatchToProps,
    mapStateToProps
} from '../../../src/main/components/common/EvidenceModalPhotoSection';
import {saveEvidenceAction} from '../../../src/main/actions/attachmentsActions';
import {photoToggleBookmarkAction} from '../../../src/main/actions/photoActions';
import {evidenceModalErrorAction} from '../../../src/main/actions/evidenceActions';
import deepFreeze from 'deep-freeze';

describe('EvidenceModalPhotoSection', () => {
    let wrapper;
    const mockSaveEvidenceAction = jest.fn(),
        mockPhotoToggleBookmarkAction = jest.fn(),
        mockEvidenceModalErrorAction = jest.fn(),
        photoEvidences = [
            {
                id: 1,
                type: 'photo',
                photoUrl: 'photo/1',
                rotation: 0,
                role: 'CLAIMANT',
                participantPartyId: '02',
                participantSourceId: 'p2',
                category: 'the category'
            },
            {
                id: 2,
                type: 'photo',
                photoUrl: 'photo/2',
                rotation: 90,
                role: 'CLAIMANT',
                participantPartyId: '02',
                participantSourceId: 'p2',
                category: 'the category'
            },
            {
                id: 3,
                type: 'photo',
                photoUrl: 'photo/3',
                rotation: 270,
                role: 'INSURED',
                participantPartyId: '01',
                participantSourceId: 'p1',
                category: 'the category',
                sourceId: 'dcf1'
            },
        ],
        liabilitySubjects = [
            {participantSourceId: 'p1', photoAttachments: [{dcfId: 'dcf1', bookmarked: true}]},
            {participantSourceId: 'p2'}
        ];

    deepFreeze(photoEvidences);
    deepFreeze(liabilitySubjects);

    beforeEach(() => {
        wrapper = shallow(
            <EvidenceModalPhotoSection
                category={'the category'}
                photoEvidences={photoEvidences}
                claimNumber={'123'}
                liabilitySubjects={liabilitySubjects}
                evidences={photoEvidences}
                saveEvidenceAction={mockSaveEvidenceAction}
                photoToggleBookmarkAction={mockPhotoToggleBookmarkAction}
                readOnly={false}
                evidenceModalErrorAction={mockEvidenceModalErrorAction}
            />
        );
    });

    it('should render photos from evidences in sorted order', () => {
        expect(wrapper.find('img').at(0).props().src).toBe('photo/3');
        expect(wrapper.find('img').at(1).props().src).toBe('photo/1');
        expect(wrapper.find('img').at(2).props().src).toBe('photo/2');
    });

    it('should have a transform rotation style based on rotation value from props', () => {
        const rotate0 = {transform: 'rotate(0deg)'};
        const rotate90 = {transform: 'rotate(90deg)'};
        const rotate270 = {transform: 'rotate(270deg)'};

        expect(wrapper.find('img').at(0).props().style).toEqual(rotate270);
        expect(wrapper.find('img').at(1).props().style).toEqual(rotate0);
        expect(wrapper.find('img').at(2).props().style).toEqual(rotate90);
    });

    it('should render photos with a tag icon', () => {
        expect(wrapper.find('button').at(0).props().disabled).toBe(false);
        expect(wrapper.find('Icon').at(0).props().icon).toBe('tag');
    });

    it('should render photos with a tag icon in disabled state in read only mode', () => {
        wrapper.setProps({readOnly: true});
        expect(wrapper.find('button').at(0).props().disabled).toBe(true);
    });

    describe('Evidence Menu', () => {
        it('should render with default props', () => {
            const options = [
                {label: 'Road Attributes', value: 'road-attributes'},
                {label: 'Condition of Roadway', value: 'condition-of-roadway'},
                {label: 'Traffic Control Measures', value: 'traffic-control-measures'},
                {label: 'Point of Impact', value: 'point-of-impact'},
                {label: 'Damages', value: 'damages'},
                {label: 'Other', value: 'other'},
            ];

            expect(wrapper.find('EvidenceMenu').props().align).toBe('right');
            expect(wrapper.find('EvidenceMenu').props().columns).toBe(1);
            expect(wrapper.find('EvidenceMenu').props().options).toEqual(options);
            expect(wrapper.find('EvidenceMenu').props().position).toEqual('bottom');
            expect(wrapper.find('EvidenceMenu').props().isActive).toBe(false);
            expect(wrapper.find('EvidenceMenu').props().readOnly).toBe(false);
            expect(wrapper.find('EvidenceMenu').props().forwardRef).toBe(null);
            expect(wrapper.find('EvidenceMenu').props().selected).toBe('the category');
        });

        it('should render the EvidenceMenu as readOnly if it is read only', () => {
            wrapper.setProps({readOnly: true});
            expect(wrapper.find('EvidenceMenu').props().readOnly).toBe(true);
        });

        it('should render with active prop has true when tag icon is clicked', () => {
            document.getElementById = jest.fn().mockReturnValue({
                getBoundingClientRect: jest.fn().mockReturnValue({y: 1000}),
                children: [
                    {},
                    {},
                    {getBoundingClientRect: jest.fn().mockReturnValue({y: 1200})}
                ],
            });

            wrapper.find('button').at(0).simulate('click');

            expect(wrapper.find('EvidenceMenu').props().isActive).toBe(true);
            expect(wrapper.find('EvidenceMenu').props().forwardRef).not.toBe(null);
            expect(wrapper.find('EvidenceMenu').props().position).toEqual('top');
            expect(document.getElementById).toBeCalledWith(3);
            expect(document.getElementById).toBeCalledWith('evidence-modal_content');
        });

        it('should close evidence menu', () => {
            wrapper.instance().setState({evidenceMenuRefId: 3});
            wrapper.find('EvidenceMenu').simulate('close');

            expect(wrapper.find('EvidenceMenu').props().isActive).toBe(false);
        });

        it('should not update category if same category is selected', () => {
            wrapper.find('EvidenceMenu').simulate('select', 'the category');

            expect(mockSaveEvidenceAction).not.toBeCalled();
        });

        it('should update category if different category is selected', () => {
            wrapper.instance().setState({evidenceMenuRefId: 3});
            wrapper.find('EvidenceMenu').simulate('select', 'another category');

            const expected = {
                id: 3,
                sourceId: 'dcf1',
                type: 'photo',
                photoUrl: 'photo/3',
                rotation: 270,
                role: 'INSURED',
                participantPartyId: '01',
                participantSourceId: 'p1',
                category: 'another category'
            };
            expect(mockSaveEvidenceAction).toBeCalledWith('123', expected);
            expect(wrapper.find('EvidenceMenu').props().isActive).toBe(false);

            expect(mockEvidenceModalErrorAction).not.toBeCalled();
        });

        it('should remove error banner is the category selected from untagged and is the last one', () => {
            wrapper.setProps({
                category: 'untagged',
                photoEvidences: [{id: 1}]
            });
            wrapper.instance().setState({evidenceMenuRefId: 1});
            wrapper.find('EvidenceMenu').simulate('select', 'not untagged');

            expect(mockEvidenceModalErrorAction).toBeCalledWith(false);
        });

        it('should remove bookmark and evidence when trash icon is clicked', () => {
            wrapper.instance().setState({evidenceMenuRefId: 3});
            wrapper.find('EvidenceMenu').simulate('removeClick');

            const expectedPhotoEvidences = [
                    {
                        id: 1,
                        type: 'photo',
                        photoUrl: 'photo/1',
                        rotation: 0,
                        role: 'CLAIMANT',
                        participantPartyId: '02',
                        participantSourceId: 'p2',
                        category: 'the category'
                    },
                    {
                        id: 2,
                        type: 'photo',
                        photoUrl: 'photo/2',
                        rotation: 90,
                        role: 'CLAIMANT',
                        participantPartyId: '02',
                        participantSourceId: 'p2',
                        category: 'the category'
                    },
                ],
                expectedPhotoAttachments = [{dcfId: 'dcf1', bookmarked: false}];

            expect(mockPhotoToggleBookmarkAction).toBeCalledWith('123', 'p1', expectedPhotoAttachments, expectedPhotoEvidences);
            expect(wrapper.find('EvidenceMenu').props().isActive).toBe(false);
        });
    });

    describe('Connect', () => {
        it('mapStateToProps', () => {
            const state = {
                claimData: {
                    claimNumber: '123',
                    liabilitySubjects: [{id: 's1'}],
                    evidences: [{id: 'e1'}]
                }
            };
            const result = mapStateToProps(state);
            expect(result.claimNumber).toEqual('123');
            expect(result.liabilitySubjects).toEqual([{id: 's1'}]);
            expect(result.evidences).toEqual([{id: 'e1'}]);
        });

        it('mapDispatchToProps', () => {
            expect(mapDispatchToProps.saveEvidenceAction).toEqual(saveEvidenceAction);
            expect(mapDispatchToProps.photoToggleBookmarkAction).toEqual(photoToggleBookmarkAction);
            expect(mapDispatchToProps.evidenceModalErrorAction).toEqual(evidenceModalErrorAction);
        });
    });
});
