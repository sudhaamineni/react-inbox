jest.unmock('../../../src/main/components/common/ParticipantPill');

import React from 'react';
import {shallow} from 'enzyme';
import {getAssetTypeShortName, getIconLabel} from '../../../src/main/helpers/claimDataHelper';
import ParticipantPill from '../../../src/main/components/common/ParticipantPill';

describe('Given Participant Pill component', () => {
    let wrapper;
    getAssetTypeShortName.mockReturnValue('auto');
    getIconLabel.mockReturnValue('Insured Owner')
    const liabilitySubject = {
        role: 'INSURED',
        firstName: 'first',
        lastName: 'last',
        participantPartyId: '1',
        participantSourceId: '11',
        asset: {assetTypeDescription: 'Auto'},
        vehicleMake: 'Honda',
        vehicleModel: 'Accord',
        vehicleYear: 2000
    };

    beforeEach(() => {
        wrapper = shallow(
            <ParticipantPill
                liabilitySubject={liabilitySubject}
            />
        );
    });

    it('should display participant role pill for insured', () => {
        expect(wrapper.find('#participant-pill').props().className.includes('c-badge--pill--insured')).toBe(true);
        expect(wrapper.find('#participant-pill').props().children[1]).toBe("Insured Owner");
        expect(wrapper.find('.c-badge--pill__icon__container').props().className.includes('c-badge--pill__icon__container--vertical')).toBe(false);

        expect(getAssetTypeShortName).toBeCalledWith('Auto');
        expect(getIconLabel).toBeCalledWith(liabilitySubject)
    });

    it('should display participant role pill for uninsured', () => {
        wrapper.setProps({liabilitySubject: {...liabilitySubject, role: 'UNINSURED'}});
        expect(wrapper.find('#participant-pill').props().className.includes('c-badge--pill--insured')).toBe(false);
        expect(wrapper.find('.c-badge--pill__icon__container').props().className.includes('c-badge--pill__icon__container--vertical')).toBe(false);
    });

    it('should render participant role pill with left padding for pedestrian', () => {
        wrapper.setProps({liabilitySubject: {...liabilitySubject, role: 'PEDESTRIAN/BICYCLIST'}});
        expect(wrapper.find('.c-badge--pill__icon__container').props().className.includes('c-badge--pill__icon__container--vertical')).toBe(true);
    });

    describe('Icon component', () => {
        it('should display for insured', () => {
            expect(wrapper.find('Icon').props().icon).toBe("auto");
            expect(wrapper.find('Icon').props().color).toBe("insured");
        });

        it('should pass color prop as claimant if no role available', () => {
            wrapper.setProps({liabilitySubject: {...liabilitySubject, role: undefined}});
            expect(wrapper.find('Icon').props().color).toBe("claimant");
        });

        it('should pass icon prop as undefined if no asset available', () => {
            wrapper.setProps({liabilitySubject: {...liabilitySubject, asset: undefined}});
            expect(wrapper.find('Icon').props().icon).toBe(undefined);
        });

        it('should pass icon prop as pedestrian when role is PEDESTRIAN/BICYCLIST', () => {
            wrapper.setProps({liabilitySubject: {...liabilitySubject, role: 'PEDESTRIAN/BICYCLIST'}});
            expect(wrapper.find('Icon').props().icon).toBe('pedestrian');
        });

        it('should pass size prop as 1.625 when participant role is not PEDESTRIAN/BICYCLIST', () => {
            wrapper.setProps({liabilitySubject: {...liabilitySubject, role: 'NOT PEDESTRIAN/BICYCLIST'}});
            expect(wrapper.find('Icon').props().size).toBe(1.625);
        });

        it('should pass size prop as 1 when participant role is PEDESTRIAN/BICYCLIST', () => {
            wrapper.setProps({liabilitySubject: {...liabilitySubject, role: 'PEDESTRIAN/BICYCLIST'}});
            expect(wrapper.find('Icon').props().size).toBe(0.875);
        });
    });
});