jest.unmock('../../../src/main/components/common/ErrorBanner');

import ErrorBanner from '../../../src/main/components/common/ErrorBanner';

import React from 'react';
import {shallow} from 'enzyme';

describe('Given an Error Header component', () => {
    let wrapper;

    beforeEach(() => {
        wrapper = shallow(
            <ErrorBanner error={true}>
                <span>Error message</span>
                <span>Error description</span>
            </ErrorBanner>
        );
    });

    it('should render Alert component with error message and description', () => {
        expect(wrapper.find('Alert').props().type).toBe('error');
        expect(wrapper.find('Alert').props().className.includes('error-border')).toBe(true);
        expect(wrapper.find('Alert').props().children[0].props.children).toBe('Error message');
        expect(wrapper.find('Alert').props().children[1].props.children).toBe('Error description');
    });

    it('should render Alert component without border if error is false', () => {
        wrapper.setProps({error: false});
        expect(wrapper.find('Alert').props().className.includes('error-border')).toBe(false);
        expect(wrapper.find('Alert').props().type).toBe('info');
    });
});