import analyticsHelper from '../../../src/main/helpers/analyticsHelper';
import React from 'react';
import {shallow} from 'enzyme';
import {
    ContributingFactor,
    mapDispatchToProps,
    mapStateToProps
} from '../../../src/main/components/common/ContributingFactor';
import {
    createId,
    getAssetTypeShortName,
    getDamageOptions,
    getParticipantName,
    getVehicleInfo,
    isInsured
} from '../../../src/main/helpers/claimDataHelper';
import {revalidateEvent} from '../../../src/main/helpers/eventValidationHelper';
import {MEGA_MENU_ITEMS} from '../../../src/main/constants/contributingFactorConstants';
import {setEventsValidationAction, updateEventAction} from '../../../src/main/actions/eventActions';
import deepFreeze from 'deep-freeze';
import _ from 'lodash';

jest.unmock('../../../src/main/constants/contributingFactorConstants');
jest.unmock('../../../src/main/constants/loonConstants');
jest.unmock('../../../src/main/helpers/contributingFactorHelper');
jest.unmock('../../../src/main/components/common/ContributingFactor');
jest.unmock('lodash');

describe('ContributingFactor', () => {
    let wrapper;
    let event,
        mockUpdateEventAction,
        mockSetEventsValidationAction,
        mockEventsValidation;

    beforeEach(() => {
        mockUpdateEventAction = jest.fn();
        mockSetEventsValidationAction = jest.fn();
        event = {
            id: '0',
            title: 'Event 1',
            involvedParties: [
                {
                    contributingFactors: [{reason: 'driver-compromised', details: 'tired-distracted', evidenceIds: []}],
                    participantId: '1',
                    participantSourceId: '11',
                    assetId: 'asset1',
                    affectedParties: [{
                        participantId: '2',
                        participantSourceId: '22',
                        initialFaultPercent: 22,
                        assetId: 'asset2',
                    }]
                },
                {
                    contributingFactors: [],
                    participantId: '2',
                    participantSourceId: '22',
                    assetId: 'asset2',
                    affectedParties: [{
                        participantId: '1',
                        participantSourceId: '11',
                        initialFaultPercent: 88,
                        assetId: 'asset1',
                    }]
                }
            ]
        };
        mockEventsValidation = [
            {
                error: false,
                involvedParties: [
                    {
                        contributingFactors: [
                            {
                                hasMissingCfDetailError: false,
                                hasMissingCfReasonError: false,
                            },
                            {
                                hasMissingCfDetailError: false,
                                hasMissingCfReasonError: false,
                            }
                        ]
                    }
                ]

            }
        ];

        mockUpdateEventAction.mockClear();
        getAssetTypeShortName.mockReturnValue('auto');
        isInsured.mockReturnValue(true);
        getParticipantName.mockImplementation((param) => {
            return param.participantSourceId === '11' ? 'first1 last1' : 'first2 last2';
        });
        getVehicleInfo.mockReturnValue('2000 Honda Accord');
        getDamageOptions.mockReturnValue([{value: 'Front', label: 'Front', checked: true}]);
        createId.mockReturnValue('cfSomeId');
        deepFreeze(event);

        wrapper = shallow(
            <ContributingFactor
                readOnly={false}
                hasMissingDetailsError={false}
                cfIndex={0}
                contributingFactor={{reason: 'driver-compromised', details: 'tired-distracted'}}
                event={event}
                eventIndex={0}
                involvedParty={event.involvedParties[0]}
                involvedPartyIndex={0}
                claimNumber={'123'}
                updateEventAction={mockUpdateEventAction}
                eventsValidation={mockEventsValidation}
                setEventsValidationAction={mockSetEventsValidationAction}
                evidences={[]}
                validateContributingFactorEvidence={true}
            />
        );
    });

    describe('Contributing factor', () => {
        describe('Mega Menu', () => {
            it('should render close a MegaMenu component in the first column', () => {
                const megaMenu = wrapper.find('#cf-column1-0').find('MegaMenu');

                expect(megaMenu.length).toBe(1);
                expect(megaMenu.at(0).props().items).toEqual(MEGA_MENU_ITEMS);
                expect(megaMenu.at(0).props().readonly).toEqual(false);
                expect(megaMenu.at(0).props().initialSelectedItem).toEqual({
                    value: 'driver-compromised',
                    label: 'Driver Compromised'
                });
                expect(megaMenu.at(0).props().initialSelectedIcon).toEqual('additional-factors');
            });

            it('should render a MegaMenu open for an empty contributing factor ', () => {
                const contributingFactor = {};
                wrapper.setProps({contributingFactor});

                const megaMenu = wrapper.find('MegaMenu');
                expect(megaMenu.props().isDefaultOpen).toBe(true);
            });

            it('should set the right option for contributing factors and dispatch update event when MegaMenu is selected', () => {
                const newInvolvedParty = {...event.involvedParties[0]};
                newInvolvedParty.contributingFactors = [{}];
                wrapper.setProps({involvedParty: newInvolvedParty});

                const expectedInvolvedParty = {
                    ...newInvolvedParty,
                    contributingFactors: [{
                        id: 'cfSomeId',
                        reason: 'participant-has-right-of-way',
                        category: 'Right of Way',
                        details: null,
                        evidenceIds: []
                    }]
                };
                const expectedUpdatedEvent = _.cloneDeep(event);
                expectedUpdatedEvent.involvedParties[0] = expectedInvolvedParty;

                wrapper.find('MegaMenu').simulate('select', {
                    value: 'participant-has-right-of-way',
                    label: 'Has Right of Way'
                });

                expect(mockUpdateEventAction).toBeCalledWith('123', expectedUpdatedEvent);
            });

            it('should validate events onSelect of MegaMenu when there is already an error', () => {
                const eventsValidation = [{
                    error: true,
                    involvedParties: [
                        {minOneCfError: true},
                    ]
                }];

                wrapper.setProps({eventsValidation});

                const newInvolvedParty = {...event.involvedParties[0]};
                const expectedInvolvedParty = {
                    ...newInvolvedParty,
                    contributingFactors: [{
                        id: 'cfSomeId',
                        reason: 'late-recognition',
                        category: 'Danger Recognition',
                        details: null,
                        evidenceIds: []
                    }]
                };
                const expectedUpdatedEvent = _.cloneDeep(event);
                expectedUpdatedEvent.involvedParties[0] = expectedInvolvedParty;

                wrapper.find('MegaMenu').simulate('select', {value: 'late-recognition', label: 'Late recognition'});
                expect(revalidateEvent).toBeCalledWith(expectedUpdatedEvent, mockSetEventsValidationAction, 0, eventsValidation, [], true);
            });

            it('should not validate events onSelect of MegaMenu when there is no error', () => {
                const eventsValidation = [{
                    error: false,
                    involvedParties: [
                        {minOneCfError: false},
                    ]
                }];

                wrapper.setProps({eventsValidation});

                wrapper.find('MegaMenu').simulate('select', {value: 'late-recognition', label: 'Late recognition'});

                expect(mockSetEventsValidationAction).not.toBeCalled();
            });

            it('should pass the value of validateContributingFactorEvidence to revalidateEvent helper', () => {
                const eventsValidation = [{
                    error: true,
                    involvedParties: [
                        {minOneCfError: true},
                    ]
                }];

                wrapper.setProps({eventsValidation, validateContributingFactorEvidence: false});

                const newInvolvedParty = {...event.involvedParties[0]};
                const expectedInvolvedParty = {
                    ...newInvolvedParty,
                    contributingFactors: [{
                        id: 'cfSomeId',
                        reason: 'late-recognition',
                        category: 'Danger Recognition',
                        details: null,
                        evidenceIds: []
                    }]
                };
                const expectedUpdatedEvent = _.cloneDeep(event);
                expectedUpdatedEvent.involvedParties[0] = expectedInvolvedParty;

                wrapper.find('MegaMenu').simulate('select', {value: 'late-recognition', label: 'Late recognition'});
                expect(revalidateEvent).toBeCalledWith(expectedUpdatedEvent, mockSetEventsValidationAction, 0, eventsValidation, [], false);

            });

            it('should set hasError to true on the MegaMenu when missingCfReasonError is true', () => {
                const eventsValidation = [{
                    error: true,
                    involvedParties: [
                        {
                            contributingFactors: [
                                {missingCfReasonError: true},
                            ]
                        },
                    ]
                }];
                wrapper.setProps({eventsValidation});

                expect(wrapper.find('MegaMenu').props().hasError).toBe(true);
            });

            it('should set hasError to false on the MegaMenu when missingCfReasonError is false', () => {
                const eventsValidation = [{
                    error: true,
                    involvedParties: [
                        {
                            contributingFactors: [
                                {missingCfReasonError: false},
                            ]
                        },
                    ]
                }];
                wrapper.setProps({eventsValidation});

                expect(wrapper.find('MegaMenu').props().hasError).toBe(false);
            });
        });

        describe('Remove Contributing Factors', () => {
            it('should render an X icon next to the contributing factor', () => {
                const xIcon = wrapper.find('#contributing-factor-icon-x-0');

                expect(xIcon.props().color).toBe('button');
                expect(xIcon.props().icon).toBe('cross');
                expect(xIcon.props().className.includes('pointer')).toBe(true);
                expect(xIcon.props().size).toBe(0.6);
                expect(xIcon.props().disabled).toBe(false);

            });

            it('should invoke updateEventAction with removed contributing factor when the x icon is clicked', () => {
                const newEvent = _.cloneDeep(event);
                const newInvolvedParty = {...newEvent.involvedParties[0]};
                newInvolvedParty.contributingFactors = [
                    {reason: 'driver-compromised'},
                    {reason: 'right-of-way', details: null}
                ];
                wrapper.setProps({involvedParty: newInvolvedParty, readOnly: false});

                const expectedInvolvedParties = newEvent.involvedParties.slice(0);
                expectedInvolvedParties[0].contributingFactors = [
                    {reason: 'right-of-way', details: null}
                ];

                const expectedEvent = {
                    ...newEvent,
                    involvedParties: expectedInvolvedParties,
                };

                wrapper.find('#contributing-factor-icon-x-0').simulate('click');
                expect(mockUpdateEventAction).toBeCalledWith('123', expectedEvent);
            });

            it('should invoke setEventsValidationAction when the x icon is clicked and error exists', () => {
                const eventsValidation = [{error: true}];

                const newEvent = _.cloneDeep(event);
                const newInvolvedParty = {...newEvent.involvedParties[0]};
                newInvolvedParty.contributingFactors = [
                    {reason: 'driver-compromised'},
                    {reason: 'right-of-way', details: null}
                ];
                wrapper.setProps({involvedParty: newInvolvedParty, readOnly: false, eventsValidation});

                const expectedInvolvedParties = newEvent.involvedParties.slice(0);
                expectedInvolvedParties[0].contributingFactors = [
                    {reason: 'right-of-way', details: null}
                ];

                const expectedEvent = {
                    ...newEvent,
                    involvedParties: expectedInvolvedParties,
                };

                wrapper.find('#contributing-factor-icon-x-0').simulate('click');

                expect(revalidateEvent).toBeCalledWith(expectedEvent, mockSetEventsValidationAction, 0, eventsValidation, [], true);
            });

            it('should disable the X icon when user is readOnly', () => {
                const newInvolvedParty = {...event.involvedParties[0]};
                newInvolvedParty.contributingFactors = [{reason: 'driver-compromised'}, {}];
                wrapper.setProps({involvedParty: newInvolvedParty, readOnly: true});

                const crossIcons = wrapper.find('#affected-parties-section').find('Icon').filter('[icon="cross"]');
                crossIcons.forEach(i => {
                    mockUpdateEventAction.mockClear();
                    expect(i.props().disabled).toBe(true);
                    expect(i.props().className.includes('cursor-not-allowed')).toBe(true);
                    i.simulate('click');
                    expect(mockUpdateEventAction).not.toBeCalled();
                });
            });
        });

        describe('Details', () => {
            describe('drop downs', () => {
                it('should render details dropdown when a contributing factor with details is selected', () => {
                    const expectedOptions = [
                        {
                            value: 'tired-distracted',
                            label: 'Tired / Distracted'
                        },
                        {
                            value: 'under-influence',
                            label: 'Under influence'
                        },
                        {
                            value: 'medical-emergency',
                            label: 'Medical Emergency'
                        },
                        {
                            value: 'road-rage',
                            label: 'Road Rage'
                        }
                    ];

                    expect(wrapper.find('#contributing-factor-qualifier-0').length).toBe(1);
                    expect(wrapper.find('#contributing-factor-qualifier-0').props().placeHolder).toEqual('Select');
                    expect(wrapper.find('#contributing-factor-qualifier-0').props().items).toEqual(expectedOptions);
                });

                it('should clear out details when contributing factors is changed', () => {
                    const updatedEvent = _.cloneDeep(event);
                    const newInvolvedParty = {...updatedEvent.involvedParties[0]};
                    newInvolvedParty.contributingFactors = [{
                        id: 'cfSomeId',
                        reason: 'proper-lookout',
                        details: 'saw-other-party'
                    }];
                    wrapper.setProps({involvedParty: newInvolvedParty});

                    const expectedInvolvedParty = {
                        ...newInvolvedParty,
                        contributingFactors: [{
                            id: 'cfSomeId',
                            reason: 'late-recognition',
                            category: 'Danger Recognition',
                            details: null,
                            evidenceIds: []
                        }]
                    };
                    const expectedUpdatedEvent = {...updatedEvent};
                    expectedUpdatedEvent.involvedParties[0] = expectedInvolvedParty;

                    wrapper.find('MegaMenu').simulate('select', {value: 'late-recognition', label: 'Late recognition'});

                    expect(mockUpdateEventAction).toBeCalledWith('123', expectedUpdatedEvent);
                });

                it('should not clear out details when the same contributing factor is reselected', () => {
                    mockUpdateEventAction.mockClear();

                    wrapper.find('MegaMenu').simulate('select', {
                        value: 'driver-compromised',
                        label: 'Driver Compromised'
                    });

                    expect(mockUpdateEventAction).not.toBeCalled();
                });

                it('should not render details dropdown when a contributing factor with no details is selected', () => {
                    wrapper.setProps({contributingFactor: {reason: 'late-recognition'}});

                    expect(wrapper.find('#contributing-factor-qualifier-0').exists()).toBe(false);
                });

                it('should render details dropdown with value in contributingFactors prop', () => {
                    const contributingFactor = {reason: 'proper-lookout', details: 'saw-other-party'};
                    wrapper.setProps({contributingFactor});

                    expect(wrapper.find('#contributing-factor-qualifier-0').props().initialSelectedItem).toEqual({
                        value: 'saw-other-party',
                        label: 'Saw other party'
                    });
                });

                it('should dispatch update event action when details option is selected', () => {
                    const clonedEvent = _.cloneDeep(event);
                    const newInvolvedParty = {...clonedEvent.involvedParties[0]};

                    newInvolvedParty.contributingFactors = [{reason: 'proper-lookout', details: 'saw-other-party'}];
                    wrapper.setProps({involvedParty: newInvolvedParty});

                    wrapper.find('#contributing-factor-qualifier-0').simulate('select', {value: 'saw-other-party'});
                    const expectedInvolvedParty = {
                        ...newInvolvedParty,
                        contributingFactors: [{reason: 'proper-lookout', details: 'saw-other-party'}]
                    };
                    const expectedUpdatedEvent = {...clonedEvent};
                    expectedUpdatedEvent.involvedParties[0] = expectedInvolvedParty;

                    expect(mockUpdateEventAction).toBeCalledWith('123', expectedUpdatedEvent);
                });

                it('should set hasError to true on CustomDropdown when no dropdown details were selected', () => {
                    const eventsValidation = [
                        {
                            error: true,
                            involvedParties: [
                                {
                                    minOneCfError: false,
                                    contributingFactors: [
                                        {
                                            missingCfReasonError: false,
                                            missingCfDetailsError: false,
                                        },
                                        {
                                            missingCfReasonError: false,
                                            missingCfDetailsError: true,
                                        },
                                    ]
                                },
                            ]
                        },
                        {},
                        {},
                    ];

                    wrapper.setProps({eventsValidation, cfIndex: 1});
                    expect(wrapper.find('#contributing-factor-qualifier-1').props().hasError).toBe(true);

                    wrapper.setProps({eventsValidation, cfIndex: 0});
                    expect(wrapper.find('#contributing-factor-qualifier-0').props().hasError).toBe(false);
                });
            });

            describe('comments box', () => {
                it('should render a comments FormField if one of the "Other" reasons is selected', () => {
                    const commentBoxContributingFactors = ['additional-factors-other', 'timely-recognition-other', 'evasive-action-other'];
                    commentBoxContributingFactors.forEach(cf => {
                        wrapper.setProps({contributingFactor: {reason: cf}});

                        expect(wrapper.find('#comments-field-0').exists()).toBe(true);
                        expect(wrapper.find('#comments-field-0').props().maxLength).toBe(50);
                        expect(wrapper.find('#comments-field-0').props().autoFocus).toBe(true);
                    });
                });

                it('should not render a comments FormField when reason is not one of the "Other" reasons', () => {
                    wrapper.setProps({contributingFactor: {reason: 'another one'}});

                    expect(wrapper.find('#comments-field-0').exists()).toBe(false);
                });

                it('should render a comments FormField with the saved comment if it exists', () => {
                    const contributingFactor = {
                        reason: 'additional-factors-other',
                        details: 'my saved comment'
                    };
                    wrapper.setProps({contributingFactor});

                    expect(wrapper.find('#comments-field-0').props().value).toBe('my saved comment');
                });

                it('should save the comments when the FormField is blurred', () => {
                    const clonedEvent = _.cloneDeep(event);
                    const newInvolvedParty = {...clonedEvent.involvedParties[0]};
                    newInvolvedParty.contributingFactors = [{reason: 'additional-factors-other'}];
                    wrapper.setProps({
                        contributingFactor: {reason: 'additional-factors-other'},
                        involvedParty: newInvolvedParty,
                    });

                    const expectedInvolvedParty = {
                        ...newInvolvedParty,
                        contributingFactors: [{reason: 'additional-factors-other', details: 'this is a comment'}]
                    };
                    const expectedUpdatedEvent = {...clonedEvent};
                    expectedUpdatedEvent.involvedParties[0] = expectedInvolvedParty;

                    wrapper.find('#comments-field-0').simulate('blur', {target: {value: 'this is a comment'}});
                    expect(mockUpdateEventAction).toBeCalledWith('123', expectedUpdatedEvent);
                });

                it('should be in disabled state when user is read only or in locked mode', () => {
                    wrapper.setProps({
                        contributingFactor: {reason: 'additional-factors-other', details: '',},
                    });
                    expect(wrapper.find('#comments-field-0').props().disabled).toBeFalsy();

                    wrapper.setProps({
                        contributingFactor: {reason: 'additional-factors-other', details: '',},
                        readOnly: true,
                    });
                    expect(wrapper.find('#comments-field-0').props().disabled).toBeTruthy();
                });

                it('should set hasError prop as the missingCfDetailsError value', () => {
                    const eventsValidation = [{
                        error: true,
                        involvedParties: [
                            {
                                minOneCfError: false,
                                contributingFactors: [
                                    {
                                        missingCfReasonError: false,
                                        missingCfDetailsError: false,
                                    },
                                    {
                                        missingCfReasonError: false,
                                        missingCfDetailsError: true,
                                    },
                                ]
                            },
                        ]
                    }];
                    wrapper.setProps({
                        contributingFactor: {reason: 'evasive-action-other'},
                        eventsValidation,
                        cfIndex: 1
                    });
                    expect(wrapper.find('#comments-field-1').props().hasError).toBe(true);

                    wrapper.setProps({
                        contributingFactor: {reason: 'evasive-action-other'},
                        eventsValidation,
                        cfIndex: 0
                    });
                    expect(wrapper.find('#comments-field-0').props().hasError).toBe(false);
                });

                it('should set autoComplete to false', () => {
                    wrapper.setProps({contributingFactor: {reason: 'evasive-action-other'}});
                    expect(wrapper.find('FormField').props().autoComplete).toBe(false);
                });
            });
        });

        describe('Add Evidence', () => {
            describe('SupportingEvidenceModal', () => {
                it('should not show the supporting evidence modal by default', () => {
                    expect(wrapper.find('Connect(SupportingEvidenceModal)').exists()).toBe(false);
                });

                it('should show the supporting evidence modal when Add Evidence is clicked', () => {
                    wrapper.find('#cf-add-evidence-link-0').simulate('click');
                    expect(wrapper.find('Connect(SupportingEvidenceModal)').exists()).toBe(true);
                });

                it('should track add evidence click event in site catalyst', () => {
                    wrapper.find('#cf-add-evidence-link-0').simulate('click');
                    expect(analyticsHelper.trackEvent).toBeCalledWith({
                        message: 'success',
                        eventAction: 'LiabilityPage_AddEvidence_LinkClicked',
                        eventSource: 'link',
                        errorCode: '',
                    });
                });

                it('should pass props to the SupportingEvidenceModal', () => {
                    wrapper.find('#cf-add-evidence-link-0').simulate('click');
                    expect(wrapper.find('Connect(SupportingEvidenceModal)').props().isActive).toBe(true);
                    expect(wrapper.find('Connect(SupportingEvidenceModal)').props().onClose).toEqual(wrapper.instance().onCloseSupportingEvidenceModal);
                    expect(wrapper.find('Connect(SupportingEvidenceModal)').props().cfIndex).toEqual(0);
                    expect(wrapper.find('Connect(SupportingEvidenceModal)').props().involvedParty).toEqual(event.involvedParties[0]);
                    expect(wrapper.find('Connect(SupportingEvidenceModal)').props().event).toBe(event);
                    expect(wrapper.find('Connect(SupportingEvidenceModal)').props().involvedPartyIndex).toEqual(0);

                });
                it('should set showSupportingEvidenceModal state to false when onClose callback if invoked', () => {
                    wrapper.find('#cf-add-evidence-link-0').simulate('click');
                    wrapper.find('Connect(SupportingEvidenceModal)').simulate('close');
                    expect(wrapper.find('Connect(SupportingEvidenceModal)').exists()).toBe(false);
                });
            });

            describe('when cf has no details or comments section', () => {
                beforeEach(() => {
                    wrapper.setProps({contributingFactor: {reason: 'participant-has-right-of-way'}});
                });

                it('should render a plus icon and \'Add Evidence\' in the second column', () => {
                    expect(wrapper.find('#cf-column2-0').text()).toContain('Add Evidence');
                });

                it('should render a plus icon and Evidence Added (3) in the second column if supporting evidences exist', () => {
                    wrapper.setProps({
                        contributingFactor: {
                            reason: 'participant-has-right-of-way',
                            evidenceIds: ['1', '2', '3']
                        }
                    });
                    expect(wrapper.find('#cf-column2-0').text()).toContain('Evidence Added (3)');
                });

                it('should render an "plus icon" in the second column', () => {
                    expect(wrapper.find('#cf-column2-0').find('#cf-add-evidence-link-0').find('Icon').at(0).props().icon).toEqual('plus');
                    expect(wrapper.find('#cf-column2-0').find('#cf-add-evidence-link-0').find('Icon').at(0).props().size).toEqual(0.875);
                    expect(wrapper.find('#cf-column2-0').find('#cf-add-evidence-link-0').find('Icon').at(0).props().color).toEqual('action');
                    expect(wrapper.find('#cf-column2-0').find('#cf-add-evidence-link-0').find('Icon').at(1).props().icon).toEqual('star');
                    expect(wrapper.find('#cf-column2-0').find('#cf-add-evidence-link-0').find('Icon').at(1).props().size).toEqual(0.8125);
                    expect(wrapper.find('#cf-column2-0').find('#cf-add-evidence-link-0').find('Icon').at(1).props().color).toEqual('bookmark');
                });

                it('should have an empty third column', () => {
                    expect(wrapper.find('#cf-column3-0').text()).toBe('');
                });

                it('should have an empty second and third column when contributing factor is empty', () => {
                    wrapper.setProps({contributingFactor: {}});
                    expect(wrapper.find('#cf-column2-0').text()).toBe('');
                    expect(wrapper.find('#cf-column3-0').text()).toBe('');
                });
            });

            describe('when cf has a detail sub dropdown', () => {
                beforeEach(() => {
                    wrapper.setProps({
                        contributingFactor: {
                            reason: 'improper-lookout',
                            details: 'didnt-see-obstruction-in-roadway'
                        }
                    });
                });

                it('should not render a plus icon or \'Add Evidence\' text in the second column', () => {
                    expect(wrapper.find('#cf-column2-0').text()).not.toContain('Add Evidence');
                    expect(wrapper.find('#cf-column2-0').find('#add-evidence-icon-0').exists()).toBe(false);
                });

                it('should render a plus icon and \'Add Evidence\' text in the third column', () => {
                    expect(wrapper.find('#cf-column3-0').text()).toContain('Add Evidence');
                    expect(wrapper.find('#cf-column3-0').find('#cf-add-evidence-link-0').find('Icon').at(0).props().icon).toEqual('plus');
                    expect(wrapper.find('#cf-column3-0').find('#cf-add-evidence-link-0').find('Icon').at(0).props().size).toEqual(0.875);
                    expect(wrapper.find('#cf-column3-0').find('#cf-add-evidence-link-0').find('Icon').at(0).props().color).toEqual('action');
                    expect(wrapper.find('#cf-column3-0').find('#cf-add-evidence-link-0').find('Icon').at(1).props().icon).toEqual('star');
                    expect(wrapper.find('#cf-column3-0').find('#cf-add-evidence-link-0').find('Icon').at(1).props().size).toEqual(0.8125);
                    expect(wrapper.find('#cf-column3-0').find('#cf-add-evidence-link-0').find('Icon').at(1).props().color).toEqual('bookmark');
                });

                it('should render the plus icon  and the Add Evidence text with magenta color when there is a missingSupportingEvidence error', () => {
                    const eventsValidation = [{
                        error: true,
                        involvedParties: [{
                            contributingFactors: [
                                {
                                    missingSupportingEvidenceError: true
                                }]
                        }]
                    }];
                    wrapper.setProps({eventsValidation});
                    expect(wrapper.find('#cf-column3-0').find('#cf-add-evidence-link-0').find('Icon').at(0).props().color).toEqual('magenta');
                    expect(wrapper.find('#cf-column3-0').find('#cf-add-evidence-link-0').find('.error-link').exists()).toBe(true);
                });

                it('should not render a plus icon or \'Add Evidence\' text in the third column when the cf has no details', () => {
                    wrapper.setProps({contributingFactor: {reason: 'improper-lookout'}});
                    expect(wrapper.find('#cf-column3-0').text()).not.toContain('Add Evidence');
                    expect(wrapper.find('#cf-column3-0').find('#add-evidence-icon-0').exists()).toBe(false);
                });
            });

            describe('when cf has a comment textbox', () => {
                beforeEach(() => {
                    const newInvolvedParty = {...event.involvedParties[0]};

                    newInvolvedParty.contributingFactors = [{reason: 'additional-factors-other'}];
                    wrapper.setProps({involvedParty: newInvolvedParty});
                });

                it('should not render a plus icon or \'Add Evidence\' text in the second column', () => {
                    expect(wrapper.find('#cf-column2-0').text()).not.toContain('Add Evidence');
                    expect(wrapper.find('#cf-column2-0').find('#add-evidence-icon-0').exists()).toBe(false);
                });

                it('should render a plus icon and \'Add Evidence\' text in the third column', () => {
                    expect(wrapper.find('#cf-column3-0').find('#cf-column3-0').text()).toContain('Add Evidence');
                    expect(wrapper.find('#cf-column3-0').find('#cf-add-evidence-link-0').find('Icon').at(0).props().icon).toEqual('plus');
                    expect(wrapper.find('#cf-column3-0').find('#cf-add-evidence-link-0').find('Icon').at(0).props().size).toEqual(0.875);
                    expect(wrapper.find('#cf-column3-0').find('#cf-add-evidence-link-0').find('Icon').at(0).props().color).toEqual('action');
                    expect(wrapper.find('#cf-column3-0').find('#cf-add-evidence-link-0').find('Icon').at(1).props().icon).toEqual('star');
                    expect(wrapper.find('#cf-column3-0').find('#cf-add-evidence-link-0').find('Icon').at(1).props().size).toEqual(0.8125);
                    expect(wrapper.find('#cf-column3-0').find('#cf-add-evidence-link-0').find('Icon').at(1).props().color).toEqual('bookmark');
                });

                it('should not render a plus icon or \'Add Evidence\' text in the third column when the cf has no details', () => {
                    wrapper.setProps({contributingFactor: {reason: 'additional-factors-other'}});
                    expect(wrapper.find('#cf-column3-0').text()).not.toContain('Add Evidence');
                    expect(wrapper.find('#cf-column3-0').find('#add-evidence-icon-0').exists()).toBe(false);
                });
            });
        });
    });

    describe('connect', () => {
        it('mapDispatchToProps', () => {
            expect(mapDispatchToProps).toEqual({
                updateEventAction,
                setEventsValidationAction
            });
        });

        it('mapStateToProps ', () => {
            const claimData = {
                evidences: [
                    {evidenceId: '123'}
                ],
            };
            const featureSwitches = {validateContributingFactorEvidence: true }

            const state = {claimData, featureSwitches};

            const result = mapStateToProps(state);
            expect(result.evidences).toEqual(claimData.evidences);
            expect(result.validateContributingFactorEvidence).toEqual(true);
        });
    });
});
