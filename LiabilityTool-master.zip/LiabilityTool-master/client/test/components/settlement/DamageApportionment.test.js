jest.unmock('../../../src/main/components/settlement/DamageApportionment');
jest.unmock('../../../src/main/helpers/claimDataHelper');

import React from 'react';
import { shallow } from 'enzyme';
import { DamageApportionment } from '../../../src/main/components/settlement/DamageApportionment';
import {convertZuluTimeToLocalTime} from '../../../src/main/helpers/dateTimeHelper'

describe('Damage Apportionment', () => {
    let wrapper, lossState, apportionedFault, allocationIsRecent, liabilitySubjects, insured, claimant1, claimant2 , apportionedAllocatedFaultSaveTime;

    beforeEach(() => {
        allocationIsRecent = true;
        apportionedAllocatedFaultSaveTime = '2019-04-29T17:59:20.610+0000';
        apportionedFault = {
            comparativeNegligenceRule: "Mod. Comparative - 51%",
            owingParties: [
                {
                    participantId: '03',
                    collectingParties: [
                        {
                            participantId: '01',
                            damages: [
                                {
                                    damageLocation: 'passenger side',
                                    allocation: 11
                                },
                                {
                                    damageLocation: 'rear',
                                    allocation: 11
                                }
                            ]
                        },
                        {
                            participantId: '02',
                            damages: [
                                {
                                    damageLocation: 'hasDamage',
                                    allocation: 22
                                },
                                {
                                    damageLocation: 'rear',
                                    allocation: 22
                                }
                            ]
                        }
                    ]
                },
                {
                    participantId: '01',
                    collectingParties: [
                        {
                            participantId: '03',
                            damages: [
                                {
                                    allocation: 31,
                                    damageLocation: 'front'
                                },
                                {
                                    allocation: 31,
                                    damageLocation: 'driver side'
                                },
                            ],
                        },
                        {
                            participantId: '02',
                            damages: [
                                {
                                    allocation: 23,
                                    damageLocation: 'front'
                                },
                                {
                                    allocation: 23,
                                    damageLocation: 'driver side'
                                },
                            ],
                        }
                    ]
                },
                {
                    participantId: '02',
                    collectingParties: [
                        {
                            participantId: '03',
                            damages: [
                                {
                                    allocation: 31,
                                    damageLocation: 'front'
                                },
                                {
                                    allocation: 31,
                                    damageLocation: 'passenger side'
                                },
                            ],
                        },
                        {
                            participantId: '01',
                            damages: [
                                {
                                    allocation: 13,
                                    damageLocation: 'front'
                                },
                                {
                                    allocation: 13,
                                    damageLocation: 'rear'
                                },
                            ],
                        }
                    ]
                }
            ],
        };
        lossState = 'Illinois';
        insured = {
            role: 'INSURED',
            firstName: 'first1',
            lastName: 'last1',
            name: 'first1 last1',
            participantPartyId: '01',
            asset: {
                assetTypeDescription: 'Auto'
            }
        };

        claimant1 = {
            role: 'CLAIMANT',
            firstName: 'first2',
            lastName: 'last2',
            name: 'first2 last2',
            participantPartyId: '02',
            asset: {
                assetTypeDescription: 'Motorcycle'
            }
        };

        claimant2 = {
            role: 'CLAIMANT',
            firstName: 'first3',
            lastName: 'last3',
            name: 'first3 last3',
            participantPartyId: '03',
            asset: {
                assetTypeDescription: 'Auto'
            }
        };

        liabilitySubjects = [claimant1, insured, claimant2];
        wrapper = shallow(<DamageApportionment liabilitySubjects={liabilitySubjects}
                                               lossState={lossState}
                                               apportionedFault={apportionedFault}
                                               allocationIsRecent={allocationIsRecent}
                                               apportionedAllocatedFaultSaveTime={apportionedAllocatedFaultSaveTime}/>)
    });


    describe('Alert Banner', () => {
        it('should render an Alert banner in blue if the allocationIsRecent prop is true', () => {
            convertZuluTimeToLocalTime.mockReturnValue('Tue, Apr 30, 2019 at 11:30AM CDT');
            expect(wrapper.find('Alert').props().type).toEqual('info');
            expect(wrapper.find('Alert').props().className).toEqual('u-text-gray-dark u-text-xs recent-allocation-banner');
            expect(wrapper.find('Alert').props().children[0]).toEqual(<span><b>Fault Allocation Updated: </b></span>);
            expect(convertZuluTimeToLocalTime).toBeCalledWith('2019-04-29T17:59:20.610+0000')
        });

        it('should render an Alert banner in pink if the allocationIsRecent prop is false', () => {
            wrapper.setProps({allocationIsRecent: false})
            expect(wrapper.find('Alert').props().type).toEqual('error')
            expect(wrapper.find('Alert').props().className).toEqual('non-recent-allocation-banner');
            expect(wrapper.find('Alert').props().children[0].props.children).toEqual('No Fault Allocation recorded.')
            expect(wrapper.find('Alert').props().children[1]).toEqual(' ')
            expect(wrapper.find('Alert').props().children[2]).toEqual('Percentages based on Initial Fault.')
        });
    });

    it('should display Damage Apportionment Header', () => {
        expect(wrapper.find('#damage-recovery-header-text').exists()).toBe(true);
    });

    it('should display Comparative Negilgence ', () => {
        expect(wrapper.find('#comp-neg-rule').text()).toBe('Based on the state negligence laws in the state of Illinois Mod. Comparative - 51%')
    });

    describe('rendering owing participants', () => {
        it("should display the insured ParticipantPill before the claimant", () => {
            expect(wrapper.find('ParticipantPill').length).toBe(3);
            expect(wrapper.find('ParticipantPill').get(0).props.liabilitySubject).toBe(insured);
            expect(wrapper.find('ParticipantPill').get(1).props.liabilitySubject).toBe(claimant1);
            expect(wrapper.find('ParticipantPill').get(2).props.liabilitySubject).toBe(claimant2);
        });

        it("should display the name of the owingParties", () => {
            expect(wrapper.find('#owing-party-name').length).toBe(3);
            expect(wrapper.find('#owing-party-0').find('#owing-party-name').text()).toBe('first1 last1');
            expect(wrapper.find('#owing-party-1').find('#owing-party-name').text()).toBe('first2 last2');
            expect(wrapper.find('#owing-party-2').find('#owing-party-name').text()).toBe('first3 last3');
        });

        describe("collecting parties", () => {
            it('should render list of collecting parties', () => {
                expect(wrapper.find('#owing-party-0')
                    .find('#collecting-party-0')
                    .find('#collecting-party-label').text()).toBe("OWES DAMAGES TO");

                expect(wrapper.find('#collecting-party-label').length).toBe(6);

                expect(wrapper.find('#owing-party-0')
                    .find('#collecting-party-0').find('#arrow-icon').props().icon).toBe("line-arrow");

                expect(wrapper.find('#owing-party-0').find('#collecting-party-0').find('#collecting-party-name').text()).toBe("first3 last3");
                expect(wrapper.find('#owing-party-0').find('#collecting-party-1').find('#collecting-party-name').text()).toBe("first2 last2");
                expect(wrapper.find('#owing-party-1').find('#collecting-party-0').find('#collecting-party-name').text()).toBe("first3 last3");
                expect(wrapper.find('#owing-party-1').find('#collecting-party-1').find('#collecting-party-name').text()).toBe("first1 last1");
                expect(wrapper.find('#owing-party-2').find('#collecting-party-0').find('#collecting-party-name').text()).toBe("first1 last1");
                expect(wrapper.find('#owing-party-2').find('#collecting-party-1').find('#collecting-party-name').text()).toBe("first2 last2");
            });

            describe("damages", () => {
                it('should display the damage location and allocation for each collecting party, and display Damages if damage location is hasDamage', () => {
                    expect(wrapper.find('#owing-party-0').find('#collecting-party-0').find('#damage-0').find('#allocation').text()).toBe("31 %");
                    expect(wrapper.find('#owing-party-0').find('#collecting-party-0').find('#damage-0').find('#location-0').text()).toBe("front");
                    expect(wrapper.find('#owing-party-0').find('#collecting-party-0').find('#damage-0').find('#location-1').text()).toBe("driver side");

                    expect(wrapper.find('#owing-party-0').find('#collecting-party-1').find('#damage-0').find('#allocation').text()).toBe("23 %");
                    expect(wrapper.find('#owing-party-0').find('#collecting-party-1').find('#damage-0').find('#location-0').text()).toBe("front");
                    expect(wrapper.find('#owing-party-0').find('#collecting-party-1').find('#damage-0').find('#location-1').text()).toBe("driver side");

                    expect(wrapper.find('#owing-party-1').find('#collecting-party-0').find('#damage-0').find('#allocation').text()).toBe("31 %");
                    expect(wrapper.find('#owing-party-1').find('#collecting-party-0').find('#damage-0').find('#location-0').text()).toBe("front");
                    expect(wrapper.find('#owing-party-1').find('#collecting-party-0').find('#damage-0').find('#location-1').text()).toBe("passenger side");

                    expect(wrapper.find('#owing-party-1').find('#collecting-party-1').find('#damage-0').find('#allocation').text()).toBe("13 %");
                    expect(wrapper.find('#owing-party-1').find('#collecting-party-1').find('#damage-0').find('#location-0').text()).toBe("front");
                    expect(wrapper.find('#owing-party-1').find('#collecting-party-1').find('#damage-0').find('#location-1').text()).toBe("rear");

                    expect(wrapper.find('#owing-party-2').find('#collecting-party-0').find('#damage-0').find('#allocation').text()).toBe("11 %");
                    expect(wrapper.find('#owing-party-2').find('#collecting-party-0').find('#damage-0').find('#location-0').text()).toBe("passenger side");
                    expect(wrapper.find('#owing-party-2').find('#collecting-party-0').find('#damage-0').find('#location-1').text()).toBe("rear");

                    expect(wrapper.find('#owing-party-2').find('#collecting-party-1').find('#damage-0').find('#allocation').text()).toBe("22 %");
                    expect(wrapper.find('#owing-party-2').find('#collecting-party-1').find('#damage-0').find('#location-0').text()).toBe("Damages");
                    expect(wrapper.find('#owing-party-2').find('#collecting-party-1').find('#damage-0').find('#location-1').text()).toBe("rear");

                    expect(wrapper.find('#allocation').length).toBe(6);
                });
            });
        });
    });
});
