jest.unmock('../../../src/main/components/settlement/SettlementEvent');

import React from 'react';
import {shallow} from 'enzyme';
import {mapDispatchToProps, SettlementEvent} from '../../../src/main/components/settlement/SettlementEvent';
import {getAssetTypeShortName, getParticipantName, isInsured} from '../../../src/main/helpers/claimDataHelper';
import {updateEventAction} from '../../../src/main/actions/eventActions';
import LiabilityPercentage from '../../../src/main/components/common/LiabilityPercentage';
import ParticipantPill from '../../../src/main/components/common/ParticipantPill';

describe('Settlement Event', () => {
    let wrapper, mockUpdateEventAction;

    const claimNumber = '123';

    const insured = {
            role: 'INSURED',
            firstName: 'first1',
            lastName: 'last1',
            participantSourceId: 'jordanSourceId',
            asset: {
                assetTypeDescription: 'Auto'
            },
        },
        claimant = {
            role: 'CLAIMANT',
            firstName: 'first2',
            lastName: 'last2',
            participantSourceId: 'sujanSourceId',
            asset: {
                assetTypeDescription: 'Motorcycle'
            }
        };
    let liabilitySubjects = [insured, claimant];

    const involvedParty1 = {
            participantId: '1',
            participantSourceId: 'jordanSourceId',
            affectedParties: [{
                participantId: '2',
                participantSourceId: 'sujanSourceId',
                initialFaultPercent: 22,
                beginNegotiatingRange: 15,
                endNegotiatingRange: 25,
                submittedInitialFaultPercent: 10,
                faultAllocationPercent: 20,
            }]
        },
        involvedParty2 = {
            participantId: '2',
            participantSourceId: 'sujanSourceId',
            affectedParties: [{
                participantId: '1',
                participantSourceId: 'jordanSourceId',
                initialFaultPercent: 88,
                beginNegotiatingRange: 65,
                endNegotiatingRange: 75,
                submittedInitialFaultPercent: 40,
            }, {
                participantId: '',
                participantSourceId: '',
                initialFaultPercent: 88,
                beginNegotiatingRange: 65,
                endNegotiatingRange: 75,
                submittedInitialFaultPercent: 40
            }]
        };
    const event = {
        id: '0',
        title: 'Title 1',
        damageSections: [],
        contributingFactors: [],
        involvedParties: [involvedParty1, involvedParty2]
    };

    beforeEach(() => {
        getAssetTypeShortName.mockReturnValue('auto');
        isInsured.mockReturnValue(true);
        getParticipantName.mockReturnValue('first1 last1');
        mockUpdateEventAction = jest.fn();
        wrapper = shallow(
            <SettlementEvent
                isReadOnly={false}
                claimNumber={claimNumber}
                lossDetailType={'Intersection Accident'}
                event={event}
                eventIndex={0}
                liabilitySubjects={liabilitySubjects}
                updateEventAction={mockUpdateEventAction}
            />
        );
    });

    it('should render the event name for two party claim with loss detail type', () => {
        expect(wrapper.find('#event-title').text()).toBe('Intersection Accident - Title 1');
    });

    it('should render the event name for more than two party claim with event index', () => {
        wrapper.setProps({liabilitySubjects: [insured, claimant, claimant]});
        expect(wrapper.find('#event-title').text()).toBe('Event 1 - Title 1');
    });

    it('should render a insured pill when involved participant is insured', () => {
        expect(wrapper.find(ParticipantPill).at(0).props().liabilitySubject).toBe(insured);
    });

    it('should render a claimant pill when involved participant is claimant', () => {
        expect(wrapper.find(ParticipantPill).at(1).props().liabilitySubject).toBe(claimant);
    });

    it('should render TO -> affectedParticipant for each affected participant', () => {
        expect(wrapper.find('#to-label').at(0).text()).toBe('TO');
        expect(wrapper.find('#arrow-icon').at(0).props().icon).toBe('line-arrow');
        expect(wrapper.find('#participant-name').at(0).text()).toBe('first1 last1');
        expect(wrapper.find('#participant-name').at(2).text()).toBe('UNKNOWN');
    });

    it('should render submitted-affected-percent', () => {
        expect(wrapper.find('#submitted-affected-percent').get(0).props.children).toEqual('10 %');
        expect(wrapper.find('#submitted-affected-percent').get(1).props.children).toEqual('40 %');
    });

    it('should render submitted-affected-percent', () => {
        expect(wrapper.find('#negotiating-range').get(0).props.children).toEqual('15-25 %');
        expect(wrapper.find('#negotiating-range').get(1).props.children).toEqual('65-75 %');
    });

    it('should render agreed-affected-percent', () => {
        expect(wrapper.find(LiabilityPercentage).at(0).props().value).toEqual(20);
        expect(wrapper.find(LiabilityPercentage).at(0).props().readOnly).toEqual(false);

        expect(wrapper.find(LiabilityPercentage).at(1).props().value).toEqual(undefined);
    });

    it('should disable agreed-fault input when readOnly prop is true', () => {
        wrapper.setProps({isReadOnly: true});
        expect(wrapper.find(LiabilityPercentage).at(0).props().readOnly).toBe(true);
    });

    it('should raise an updateEventAction with the claimNumber and updated current event when on blur of the settlement amount field when there is a change to affected percent', () => {
        wrapper.find(LiabilityPercentage).at(1).simulate('blurCallback', 33);

        const involvedParty1 = {
                participantId: '1',
                participantSourceId: 'jordanSourceId',
                affectedParties: [{
                    participantId: '2',
                    participantSourceId: 'sujanSourceId',
                    initialFaultPercent: 22,
                    beginNegotiatingRange: 15,
                    endNegotiatingRange: 25,
                    submittedInitialFaultPercent: 10,
                    faultAllocationPercent: 20
                }]
            },
            involvedParty2 = {
                participantId: '2',
                participantSourceId: 'sujanSourceId',
                affectedParties: [{
                    participantId: '1',
                    participantSourceId: 'jordanSourceId',
                    initialFaultPercent: 88,
                    beginNegotiatingRange: 65,
                    endNegotiatingRange: 75,
                    submittedInitialFaultPercent: 40,
                    faultAllocationPercent: 33,
                }, {
                    participantId: '',
                    participantSourceId: '',
                    initialFaultPercent: 88,
                    beginNegotiatingRange: 65,
                    endNegotiatingRange: 75,
                    submittedInitialFaultPercent: 40
                }]
            };
        const expectedEvent = {
            id: '0',
            title: 'Title 1',
            damageSections: [],
            contributingFactors: [],
            involvedParties: [involvedParty1, involvedParty2],
        };

        expect(mockUpdateEventAction).toBeCalledWith(claimNumber, expectedEvent);
    });

    it('should not display the participant with no affected parties', () => {
        const involvedParty1 = {
                participantId: '1',
                participantSourceId: 'jordanSourceId',
                affectedParties: [{
                    participantId: '2',
                    participantSourceId: 'sujanSourceId',
                    initialFaultPercent: 22,
                    beginNegotiatingRange: 15,
                    endNegotiatingRange: 25,
                    submittedInitialFaultPercent: 10,
                    faultAllocationPercent: 20,
                }]
            },
            involvedParty2 = {
                participantId: '2',
                participantSourceId: 'sujanSourceId',
                affectedParties: []
            };

        const event = {
            id: '0',
            title: 'Title 1',
            damageSections: [],
            contributingFactors: [],
            involvedParties: [involvedParty1, involvedParty2]
        };

        wrapper.setProps({event: event});

        expect(wrapper.find('#involved-party-name').length).toBe(1);
    });

    describe('Connect', () => {
        it('should map actions', () => {
            expect(mapDispatchToProps).toEqual({updateEventAction});
        });
    });
});
