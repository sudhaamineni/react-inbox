jest.unmock('../../../src/main/components/settlement/Settlement');

import React from 'react';
import {shallow} from 'enzyme';
import {saveNoFaultAllocationIndicatorAction} from '../../../src/main/actions/claimDataActions';
import {
    submitSettlementAction,
    submitSettlementCancelAction,
    updateDamageApportionmentAction
} from '../../../src/main/actions/submitActions';
import {mapDispatchToProps, mapStateToProps, Settlement} from '../../../src/main/components/settlement/Settlement';
import analyticsHelper from '../../../src/main/helpers/analyticsHelper';
import {isReadOnlyUser} from '../../../src/main/helpers/claimDataHelper';

describe('Given Settlement Tab', () => {
    let wrapper;

    const insured = {
            role: 'INSURED',
            firstName: 'first1',
            lastName: 'last1',
            participantSourceId: 'jordanSourceId',
            asset: {
                assetTypeDescription: 'Auto'
            }
        },
        claimant1 = {
            role: 'CLAIMANT',
            firstName: 'first2',
            lastName: 'last2',
            participantSourceId: 'sujanSourceId',
            asset: {
                assetTypeDescription: 'Motorcycle'
            }
        },
        claimant2 = {
            role: 'CLAIMANT',
            firstName: 'first3',
            lastName: 'last3',
            participantSourceId: 'johnSourceId',
            asset: {
                assetTypeDescription: 'Auto'
            }
        },
        event1 = {
            id: '0',
            title: 'Event 1',
            damageSections: [],
            contributingFactors: [],
            involvedParties: [
                {
                    participantId: '1',
                    participantSourceId: 'jordanSourceId',
                    affectedParties: [{
                        participantId: '2',
                        participantSourceId: 'sujanSourceId',
                        initialFaultPercent: 22,
                        beginNegotiatingRange: 15,
                        endNegotiatingRange: 25,
                        submittedInitialFaultPercent: 10,
                        faultAllocationPercent: 20,
                    }]
                },
                {
                    participantId: '2',
                    participantSourceId: 'sujanSourceId',
                    affectedParties: [{
                        participantId: '1',
                        participantSourceId: 'jordanSourceId',
                        initialFaultPercent: 88,
                        beginNegotiatingRange: 65,
                        endNegotiatingRange: 75,
                        submittedInitialFaultPercent: 40,
                        faultAllocationPercent: 50,
                    }]
                }
            ]
        },
        event2 = {
            id: '1',
            title: 'Event 2',
            damageSections: [],
            contributingFactors: [],
            involvedParties: [
                {
                    participantId: '1',
                    participantSourceId: 'jordanSourceId',
                    affectedParties: [{
                        participantId: '2',
                        participantSourceId: 'sujanSourceId',
                        initialFaultPercent: 75,
                        beginNegotiatingRange: 70,
                        endNegotiatingRange: 80,
                        submittedInitialFaultPercent: 77,
                    }]
                },
                {
                    participantId: '3',
                    participantSourceId: 'johnSourceId',
                    affectedParties: [{
                        participantId: '1',
                        participantSourceId: 'jordanSourceId',
                        initialFaultPercent: 25,
                        beginNegotiatingRange: 20,
                        endNegotiatingRange: 30,
                        submittedInitialFaultPercent: 28,
                    }]
                }
            ]
        },
        liabilitySubjects = [insured, claimant1, claimant2],
        events = [event1, event2],
        claimData = {
            claimNumber: '123',
            lossDetailType: 'Intersection Accident',
            liabilitySubjects,
            events,
            noFaultAllocationAgreement: true
        },
        mockSaveNoFaultAllocationIndicatorAction = jest.fn(),
        mockUpdateDamageApportionmentAction = jest.fn(),
        mockSubmitSettlementAction = jest.fn(),
        mockSettlementSubmittedAction = jest.fn(),
        mockSubmitSettlementCancelAction = jest.fn(),
        mockHistory = {push: jest.fn()},
        mockSetErrorMessagesAction = jest.fn();

    beforeEach(() => {
        wrapper = shallow(
            <Settlement
                claimData={claimData}
                readOnlyUser={false}
                updatingDamageApportionment={false}
                saveNoFaultAllocationIndicatorAction={mockSaveNoFaultAllocationIndicatorAction}
                updateDamageApportionmentAction={mockUpdateDamageApportionmentAction}
                submitSettlementAction={mockSubmitSettlementAction}
                submitState={'SUBMITTED'}
                settlementSubmittedAction={mockSettlementSubmittedAction}
                submitSettlementCancelAction={mockSubmitSettlementCancelAction}
                history={mockHistory}
                events={events}
                setErrorMessagesAction={mockSetErrorMessagesAction}
            />
        );
    });

    describe('ComponentDidMount', () => {
        beforeEach(() => {
            jest.clearAllMocks();
        });

        it('tracks page using SiteCatalyst', () => {
            wrapper.instance().componentDidMount();
            expect(analyticsHelper.trackPage).toHaveBeenCalledWith('claims/loon/settlementPage');
        });

        it('should redirect to home page when submitted time is not available ', () => {
            wrapper.setProps({claimData: {...claimData, initialFaultSubmitTime: null, locked: true}});
            wrapper.instance().componentDidMount();

            expect(mockSetErrorMessagesAction).toBeCalledWith('Settlement unavailable', 'Settlement not available for this claim.');
            expect(mockHistory.push).toBeCalledWith('/');
        });

        it('should redirect to home page claim is not locked ', () => {
            wrapper.setProps({claimData: {...claimData, initialFaultSubmitTime: 'initialFaultSubmitTime', locked: false}});
            wrapper.instance().componentDidMount();

            expect(mockSetErrorMessagesAction).toBeCalledWith('Settlement unavailable', 'Settlement not available for this claim.');
            expect(mockHistory.push).toBeCalledWith('/');
        });

        it('should not redirect to home page when submitted time is available and claim is locked ', () => {
            wrapper.setProps({claimData: {...claimData, initialFaultSubmitTime: 'initialFaultSubmitTime', locked: true}});
            wrapper.instance().componentDidMount();

            expect(mockSetErrorMessagesAction).not.toBeCalled();
            expect(mockHistory.push).not.toBeCalled();
        });
    });

    describe('Title of the page', () => {
        it('should have the title as Loon - {claimNumber} when claim number is available', () => {
            wrapper.setProps({claimData: {claimNumber: '000123456789', events}});
            wrapper.instance().componentDidMount();
            expect(document.title).toEqual('Loon - 123456789');
        });

        it('should have the title as Loon - {claimNumber} when claim number is not available', () => {
            wrapper.setProps({claimData: {claimNumber: '', events}});
            wrapper.instance().componentDidMount();
            expect(document.title).toEqual('Loon -');
        });
    });

    it('should have the settlement header', () => {
        expect(wrapper.find('#settlement-header').text()).toBe('Settlement');
    });

    describe('Fault Allocation Container', () => {
        describe('Render static text', () => {
            it('should render fault allocation header', () => {
                expect(wrapper.find('#fault-allocation-header-text').text()).toBe('Fault Allocation');
            });

            it('should render No Agreement checkbox and text', () => {
                expect(wrapper.find('#fault-agreement-no-agreement').props().children.props.children).toBe('No Agreement');
            });

            it('should render No Response checkbox and text', () => {
                expect(wrapper.find('#fault-agreement-no-response').props().children.props.children).toBe('No Response');
            });

            it('should call saveNoFaultAllocationIndicatorAction when checkbox for no agreement is clicked', () => {
                wrapper.find('FormOption').at(0).props().onChange({target: {checked: true}});
                expect(mockSaveNoFaultAllocationIndicatorAction).toHaveBeenCalledWith('123', true, false);
            });

            it('should call saveNoFaultAllocationIndicatorAction when checkbox for no response is clicked', () => {
                wrapper.find('FormOption').at(1).props().onChange({target: {checked: true}});
                expect(mockSaveNoFaultAllocationIndicatorAction).toHaveBeenCalledWith('123', false, true);
            });

            it('should render fault agreement column headers', () => {
                expect(wrapper.find('#fault-agreement-determined-column').text()).toBe('Initial Fault');
                expect(wrapper.find('#fault-agreement-negotiation-column').text()).toBe('Negotiating Range');
                expect(wrapper.find('#fault-allocation-agreed-column').text()).toBe('Fault Allocation');
            });
        });

        describe('Settlement Fault Events', () => {
            it('should render a SettlementEvent for each event from props', () => {
                expect(wrapper.find('Connect(SettlementEvent)').length).toBe(2);
            });

            it('should pass the events and liabilitySubjects as props to each SettlementEvent', () => {
                wrapper.setProps({readOnlyUser: true});

                expect(wrapper.find('Connect(SettlementEvent)').get(0).props.claimNumber).toEqual('123');
                expect(wrapper.find('Connect(SettlementEvent)').get(0).props.lossDetailType).toEqual('Intersection Accident');
                expect(wrapper.find('Connect(SettlementEvent)').get(0).props.event).toEqual(event1);
                expect(wrapper.find('Connect(SettlementEvent)').get(0).props.eventIndex).toEqual(0);
                expect(wrapper.find('Connect(SettlementEvent)').get(0).props.liabilitySubjects).toEqual([insured, claimant1, claimant2]);
                expect(wrapper.find('Connect(SettlementEvent)').get(0).props.isReadOnly).toEqual(true);

                expect(wrapper.find('Connect(SettlementEvent)').get(1).props.claimNumber).toEqual('123');
                expect(wrapper.find('Connect(SettlementEvent)').get(1).props.event).toEqual(event2);
                expect(wrapper.find('Connect(SettlementEvent)').get(1).props.eventIndex).toEqual(1);
                expect(wrapper.find('Connect(SettlementEvent)').get(1).props.liabilitySubjects).toEqual([insured, claimant1, claimant2]);
                expect(wrapper.find('Connect(SettlementEvent)').get(1).props.isReadOnly).toEqual(true);
            });
        });

        describe('Update Damage Apportionment', () => {
            it('should render the button', () => {
                expect(wrapper.find('#fault-agreement-section').find('#update-damage-apportionment-btn').exists()).toBe(true);
                expect(wrapper.find('#update-damage-apportionment-btn').props().children).toBe('Update Damage Apportionment');
            });

            it('should render the button with a spinner and disable it while damage apportionment is being updated', () => {
                wrapper.setProps({updatingDamageApportionment: true, claimData: {...claimData, events: [event1]}});
                expect(wrapper.find('#update-damage-apportionment-btn').props().children.props.className).toBe('c-loader--sm');
                expect(wrapper.find('#update-damage-apportionment-btn').props().disabled).toBe(true);
            });

            it('should be disabled in readOnly mode', () => {
                wrapper.setState({updatedForTest: true});
                expect(wrapper.find('#update-damage-apportionment-btn').props().disabled).toBe(true);
            });

            describe('when all Fault Allocation fields are filled', () => {
                const newEvents = [event1];

                it('should be enabled when neither No Agreement nor No Response is checked', () => {
                    wrapper.setProps({
                        claimData: {
                            ...claimData,
                            events: newEvents,
                            noFaultAllocationAgreement: false,
                            noFaultAllocationResponse: false
                        }
                    });
                    expect(wrapper.find('#update-damage-apportionment-btn').props().disabled).toBe(false);
                });

                it('should be disabled when No Agreement is checked', () => {
                    wrapper.setProps({
                        claimData: {
                            ...claimData,
                            events: newEvents,
                            noFaultAllocationAgreement: true,
                            noFaultAllocationResponse: false
                        }
                    });
                    expect(wrapper.find('#update-damage-apportionment-btn').props().disabled).toBe(true);
                });

                it('should be disabled when No Response is checked', () => {
                    wrapper.setProps({
                        claimData: {
                            ...claimData,
                            events: newEvents,
                            noFaultAllocationAgreement: false,
                            noFaultAllocationResponse: true
                        }
                    });
                    expect(wrapper.find('#update-damage-apportionment-btn').props().disabled).toBe(true);
                });
            });


            it('should be disabled if any Fault Allocation field is empty', () => {
                let event3 = {
                    id: '1',
                    title: 'Event 3',
                    damageSections: [],
                    contributingFactors: [],
                    involvedParties: [
                        {
                            participantId: '1',
                            participantSourceId: 'jordanSourceId',
                            affectedParties: [{
                                participantId: '2',
                                participantSourceId: 'sujanSourceId',
                                initialFaultPercent: 75,
                                beginNegotiatingRange: 70,
                                endNegotiatingRange: 80,
                                submittedInitialFaultPercent: 77,
                                faultAllocationPercent: '',
                            }]
                        },
                        {
                            participantId: '3',
                            participantSourceId: 'johnSourceId',
                            affectedParties: [{
                                participantId: '1',
                                participantSourceId: 'jordanSourceId',
                                initialFaultPercent: 25,
                                beginNegotiatingRange: 20,
                                endNegotiatingRange: 30,
                                submittedInitialFaultPercent: 28,
                            }]
                        }
                    ]
                };
                let newEvents = [event1, event3];
                wrapper.setProps({claimData: {...claimData, noFaultAllocationAgreement: false, events: newEvents}});
                expect(wrapper.find('#update-damage-apportionment-btn').props().disabled).toBe(true);
            });

            it('should be disabled if any Fault Allocation field is undefined', () => {
                let event3 = {
                    id: '1',
                    title: 'Event 3',
                    damageSections: [],
                    contributingFactors: [],
                    involvedParties: [
                        {
                            participantId: '1',
                            participantSourceId: 'jordanSourceId',
                            affectedParties: [{
                                participantId: '2',
                                participantSourceId: 'sujanSourceId',
                                initialFaultPercent: 75,
                                beginNegotiatingRange: 70,
                                endNegotiatingRange: 80,
                                submittedInitialFaultPercent: 77,
                                faultAllocationPercent: undefined,
                            }]
                        },
                        {
                            participantId: '3',
                            participantSourceId: 'johnSourceId',
                            affectedParties: [{
                                participantId: '1',
                                participantSourceId: 'jordanSourceId',
                                initialFaultPercent: 25,
                                beginNegotiatingRange: 20,
                                endNegotiatingRange: 30,
                                submittedInitialFaultPercent: 28,
                            }]
                        }
                    ]
                };
                let newEvents = [event1, event3];
                wrapper.setProps({claimData: {...claimData, noFaultAllocationAgreement: false, events: newEvents}});
                expect(wrapper.find('#update-damage-apportionment-btn').props().disabled).toBe(true);
            });

            it('should be disabled if any Fault Allocation field is null', () => {
                let event3 = {
                    id: '1',
                    title: 'Event 3',
                    damageSections: [],
                    contributingFactors: [],
                    involvedParties: [
                        {
                            participantId: '1',
                            participantSourceId: 'jordanSourceId',
                            affectedParties: [{
                                participantId: '2',
                                participantSourceId: 'sujanSourceId',
                                initialFaultPercent: 75,
                                beginNegotiatingRange: 70,
                                endNegotiatingRange: 80,
                                submittedInitialFaultPercent: 77,
                                faultAllocationPercent: null,
                            }]
                        },
                        {
                            participantId: '3',
                            participantSourceId: 'johnSourceId',
                            affectedParties: [{
                                participantId: '1',
                                participantSourceId: 'jordanSourceId',
                                initialFaultPercent: 25,
                                beginNegotiatingRange: 20,
                                endNegotiatingRange: 30,
                                submittedInitialFaultPercent: 28,
                            }]
                        }
                    ]
                };
                let newEvents = [event1, event3];
                wrapper.setProps({claimData: {...claimData, noFaultAllocationAgreement: false, events: newEvents}});
                expect(wrapper.find('#update-damage-apportionment-btn').props().disabled).toBe(true);
            });

            it('should be disabled if the No Agreement box is checked', () => {
                wrapper.setProps({claimData: {...claimData, noFaultAllocationAgreement: true}});

                expect(wrapper.find('#update-damage-apportionment-btn').props().disabled).toBe(true);
            });
            it('should dispatch the updateDamageApportionment action when clicked', () => {
                wrapper.find('#update-damage-apportionment-btn').simulate('click');
                expect(mockUpdateDamageApportionmentAction).toBeCalledWith('123');
            });
        });

        describe('Submit Settlement Button', () => {
            it('should render settlement button', () => {
                expect(wrapper.find('#submit-settlement-button').text()).toBe('Submit Settlement');
            });

            it('should be disabled when there is no apportionedAllocatedFault and the "No Response" and "No Agreement" checkboxes are not checked', () => {
                let newClaimData = {
                    ...claimData,
                    noFaultAllocationAgreement: false,
                    noFaultAllocationResponse: false,
                    apportionedAllocatedFault: null
                };
                wrapper.setProps({claimData: newClaimData, readOnlyUser: false});

                expect(wrapper.find('#submit-settlement-button').props().disabled).toBe(true);
            });

            it('should be disabled when user has updated faultAllocationPercent but not resubmitted to griffin', () => {
                let newClaimData = {...claimData};
                newClaimData.noFaultAllocationAgreement = false;
                newClaimData.noFaultAllocationResponse = false;
                newClaimData.apportionedAllocatedFault = {};
                newClaimData.apportionedAllocatedFaultSaveTime = new Date('2019-02-01');
                newClaimData.events = [{...event1, faultAllocationPercentSaveTime: new Date('2019-02-02')}];
                wrapper.setProps({claimData: newClaimData, readOnlyUser: false});

                expect(wrapper.find('#submit-settlement-button').props().disabled).toBe(true);
            });

            it('should be enabled when No Agreement is checked', () => {
                wrapper.setProps({claimData: {...claimData, noFaultAllocationAgreement: true}});

                expect(wrapper.find('#submit-settlement-button').props().disabled).toBe(false);
            });

            it('should be enabled when No Response is checked', () => {
                wrapper.setProps({claimData: {...claimData, noFaultAllocationResponse: true}});

                expect(wrapper.find('#submit-settlement-button').props().disabled).toBe(false);
            });

            it('should be enabled when apportionedAllocatedFault is available and faultAllocation has not been updated since griffin responded', () => {
                let newClaimData = {...claimData};
                newClaimData.noFaultAllocationAgreement = false;
                newClaimData.noFaultAllocationResponse = false;
                newClaimData.apportionedAllocatedFault = {};
                newClaimData.apportionedAllocatedFaultSaveTime = new Date('2019-02-03');
                newClaimData.events = [
                    {...event1, faultAllocationPercentSaveTime: new Date('2019-02-01')},
                    {...event2, faultAllocationPercentSaveTime: new Date('2019-02-02')}
                ];
                wrapper.setProps({claimData: newClaimData, readOnlyUser: false});

                expect(wrapper.find('#submit-settlement-button').props().disabled).toBe(false);
            });

            it('should set openConfirmModal state to true', () => {
                wrapper.setState({openConfirmModal: false});
                wrapper.find('#submit-settlement-button').simulate('click');
                expect(wrapper.instance().state.openConfirmModal).toBe(true);
            });
        });
    });

    describe('Submit Settlement Modals', () => {
        describe('Confirm Submit Settlement Modal', () => {
            it('should render SubmitModal with isActive true when openConfirmModal is true', () => {
                wrapper.setState({openConfirmModal: true});
                expect(wrapper.find('SubmitModal').filter('#confirm-modal').props().isActive).toBe(true);
            });

            it('should render SubmitModal with isActive false when openConfirmModal is false', () => {
                wrapper.setState({openConfirmModal: false});
                expect(wrapper.find('SubmitModal').filter('#confirm-modal').props().isActive).toBe(false);
            });

            describe('confirmation modal text', () => {

                it('should pass \'Are you sure you want to submit your Damage Apportionment?\' as modalText', () => {
                    wrapper.setProps({
                        claimData: {
                            ...claimData,
                            noFaultAllocationAgreement: undefined,
                            noFaultAllocationResponse: undefined
                        }
                    })
                    expect(wrapper.find('SubmitModal').filter('#confirm-modal').props().modalText).toBe("Are you sure you want to submit your Damage Apportionment?");
                });

                it('should pass \'Are you sure you want to submit your No Agreement decision?\' as modalText if No Agreement is checked', () => {
                    wrapper.setProps({
                        claimData: {
                            ...claimData,
                            noFaultAllocationAgreement: true,
                            noFaultAllocationResponse: undefined
                        }
                    })
                    expect(wrapper.find('SubmitModal').filter('#confirm-modal').props().modalText).toBe("Are you sure you want to submit your No Agreement decision?");
                });

                it('should pass \'Are you sure you want to submit your No Response decision\' as modalText if No Response is checked', () => {
                    wrapper.setProps({
                        claimData: {
                            ...claimData,
                            noFaultAllocationAgreement: undefined,
                            noFaultAllocationResponse: true
                        }
                    })
                    expect(wrapper.find('SubmitModal').filter('#confirm-modal').props().modalText).toBe("Are you sure you want to submit your No Response decision?");
                });

            });

            it('should pass activeModal props as Confirm', () => {
                expect(wrapper.find('SubmitModal').filter('#confirm-modal').props().activeModal).toBe("Confirm");
            });

            it('should pass a spinner prop as true when submitState prop is SUBMITTING', () => {
                wrapper.setProps({submitState: 'SUBMITTING'});
                expect(wrapper.find('SubmitModal').filter('#confirm-modal').props().spinner).toBe(true);
            });

            it('should pass a spinner prop as false when submitState prop is not SUBMITTING', () => {
                wrapper.setProps({submitState: 'DEFAULT_STATE'});
                expect(wrapper.find('SubmitModal').filter('#confirm-modal').props().spinner).toBe(false);
            });

            it('should set openConfirmModal to false and call submitSettlementAction when firstButtonCallback is called', () => {
                wrapper.find('SubmitModal').filter('#confirm-modal').props().firstButtonCallback();
                expect(wrapper.instance().state.openConfirmModal).toBe(false);
                expect(mockSubmitSettlementAction).toBeCalledWith('123');
            });

            it('should set openConfirmModal to false when secondButtonCallback is called', () => {
                wrapper.find('SubmitModal').filter('#confirm-modal').props().secondButtonCallback();
                expect(wrapper.instance().state.openConfirmModal).toBe(false);
            });
        });

        describe('Success Submit Settlement Modal', () => {
            it('should render SubmitModal with isActive true when submitState is SUBMITTED', () => {
                wrapper.setProps({submitState: 'SUBMITTED'});
                expect(wrapper.find('SubmitModal').filter('#success-modal').props().isActive).toBe(true);
            });

            it('should render SubmitModal with isActive false when submitState is not SUBMITTED', () => {
                wrapper.setProps({submitState: 'DEFAULT_STATE'});
                expect(wrapper.find('SubmitModal').filter('#success-modal').props().isActive).toBe(false);
            });

            describe('success modal text', () => {

                it('should pass \'Your Damage Apportionment has been successfully submitted.?\' as modalText', () => {
                    wrapper.setProps({
                        claimData: {
                            ...claimData,
                            noFaultAllocationAgreement: undefined,
                            noFaultAllocationResponse: undefined
                        }
                    })
                    expect(wrapper.find('SubmitModal').filter('#success-modal').props().modalText).toBe("Your Damage Apportionment has been successfully submitted.");
                });

                it('should pass \'Your No Agreement decision has been successfully submitted\' as modalText if No Agreement is checked', () => {
                    wrapper.setProps({
                        claimData: {
                            ...claimData,
                            noFaultAllocationAgreement: true,
                            noFaultAllocationResponse: undefined
                        }
                    })
                    expect(wrapper.find('SubmitModal').filter('#success-modal').props().modalText).toBe("Your No Agreement decision has been successfully submitted.");
                });

                it('should pass \' "Your No Response decision has been successfully submitted"\' as modalText if No Response is checked', () => {
                    wrapper.setProps({
                        claimData: {
                            ...claimData,
                            noFaultAllocationAgreement: undefined,
                            noFaultAllocationResponse: true
                        }
                    })
                    expect(wrapper.find('SubmitModal').filter('#success-modal').props().modalText).toBe("Your No Response decision has been successfully submitted.");
                });

            });

            it('should pass activeModal props as Confirm', () => {
                expect(wrapper.find('SubmitModal').filter('#success-modal').props().activeModal).toBe('Success');
            });

            it('should pass \'Start a New Claim\' as secondButtonLabel', () => {
                expect(wrapper.find('SubmitModal').filter('#success-modal').props().secondButtonLabel).toBe('Back to Settlement');
            });

            it('should call settlementSubmittedAction and route to home page when firstButtonCallback is called', () => {
                wrapper.find('SubmitModal').filter('#success-modal').props().firstButtonCallback();
                expect(mockSettlementSubmittedAction).toBeCalled();
                expect(mockHistory.push).toBeCalledWith('/');
            });

            it('should call settlementSubmittedAction when secondButtonCallback is called', () => {
                wrapper.find('SubmitModal').filter('#success-modal').props().secondButtonCallback();
                expect(mockSettlementSubmittedAction).toBeCalled();
            });

            it('should pass a spinner prop as false', () => {
                expect(wrapper.find('SubmitModal').filter('#success-modal').props().spinner).toBe(false);
            });
        });

        describe('Error Submit Settlement Modal', () => {
            it('should render SubmitModal with isActive true when submitState is ERROR_SUBMITTING', () => {
                wrapper.setProps({submitState: 'ERROR_SUBMITTING'});
                expect(wrapper.find('SubmitModal').filter('#error-modal').props().isActive).toBe(true);
            });

            it('should render SubmitModal with isActive false when submitState is not ERROR_SUBMITTING', () => {
                wrapper.setState({submitState: 'SUBMITTED'});
                expect(wrapper.find('SubmitModal').filter('#error-modal').props().isActive).toBe(false);
            });

            it('should pass \'We are unable to submit your Damage Apportionment. Would you like to try submitting this again?\' as modalText', () => {
                expect(wrapper.find('SubmitModal').filter('#error-modal').props().modalText).toBe('We are unable to submit your Damage Apportionment. Would you like to try submitting this again?');
            });

            it('should pass activeModal props as Error', () => {
                expect(wrapper.find('SubmitModal').filter('#error-modal').props().activeModal).toBe('Error');
            });

            it('should pass a spinner prop as true when submitState prop is SUBMITTING', () => {
                wrapper.setProps({submitState: 'SUBMITTING'});
                expect(wrapper.find('SubmitModal').filter('#error-modal').props().spinner).toBe(true);
            });

            it('should pass a spinner prop as false when submitState prop is not SUBMITTING', () => {
                wrapper.setProps({submitState: 'DEFAULT_STATE'});
                expect(wrapper.find('SubmitModal').filter('#error-modal').props().spinner).toBe(false);
            });

            it('should set openConfirmModal to false and call submitSettlementAction when firstButtonCallback is called', () => {
                wrapper.find('SubmitModal').filter('#error-modal').props().firstButtonCallback();
                expect(wrapper.instance().state.openConfirmModal).toBe(false);
                expect(mockSubmitSettlementAction).toBeCalledWith('123');
            });

            it('should set openConfirmModal to false when secondButtonCallback is called', () => {
                wrapper.find('SubmitModal').filter('#error-modal').props().secondButtonCallback();
                expect(wrapper.instance().state.openConfirmModal).toBe(false);
                expect(mockSubmitSettlementCancelAction).toBeCalled();
            });
        });
    });

    describe('Damage Apportionment Component', () => {
        it('should pass apportionedAllocatedFault when apportionedAllocatedFaultSaveTime > initialFaultSubmitTime', () => {
            const apportionedAllocatedFault = {
                comparativeNegligenceRule: 'Mod. Comparative - 51%',
                summary: {
                    participants: [
                        {
                            affectedParticipantId: 'BE03DC4D9C0FEEFA',
                            barredFromRecovery: false,
                            pointOfImpacts: [
                                {
                                    location: 'Front',
                                    damages: [
                                        {
                                            mainParticipantId: '3CED103092F68F68',
                                            fault: null
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            affectedParticipantId: '3CED103092F68F68',
                            barredFromRecovery: false,
                            pointOfImpacts: [
                                {
                                    location: 'Front',
                                    damages: [
                                        {
                                            mainParticipantId: 'BE03DC4D9C0FEEFA',
                                            fault: null
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            };
            wrapper.setProps({claimData: {...claimData, apportionedAllocatedFault, initialFaultSubmitTime:'2019-04-29T16:59:20.610+0000', apportionedAllocatedFaultSaveTime:'2019-04-29T17:59:20.610+0000' }});
            expect(wrapper.find('Connect(DamageApportionment)').exists()).toBe(true);
            expect(wrapper.find('Connect(DamageApportionment)').get(0).props.apportionedFault).toEqual(apportionedAllocatedFault);
            expect(wrapper.find('Connect(DamageApportionment)').get(0).props.allocationIsRecent).toEqual(true);
            expect(wrapper.find('Connect(DamageApportionment)').get(0).props.apportionedAllocatedFaultSaveTime).toEqual('2019-04-29T17:59:20.610+0000');
        });

        it('should pass apportionedInitialFault when apportionedAllocatedFaultSaveTime < initialFaultSubmitTime', () => {
            const apportionedInitialFault = {
                comparativeNegligenceRule: 'Initial Mod. Comparative - 51%',
                summary: {
                    participants: [
                        {
                            affectedParticipantId: 'BE03DC4D9C0FEEFA',
                            barredFromRecovery: false,
                            pointOfImpacts: [
                                {
                                    location: 'Front',
                                    damages: [
                                        {
                                            mainParticipantId: '3CED103092F68F68',
                                            fault: null
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            affectedParticipantId: '3CED103092F68F68',
                            barredFromRecovery: false,
                            pointOfImpacts: [
                                {
                                    location: 'Front',
                                    damages: [
                                        {
                                            mainParticipantId: 'BE03DC4D9C0FEEFA',
                                            fault: null
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            };

            const apportionedAllocatedFault = {
                comparativeNegligenceRule: 'Mod. Comparative - 51%',
                summary: {
                    participants: [
                        {
                            affectedParticipantId: 'BE03DC4D9C0FEEFA',
                            barredFromRecovery: false,
                            pointOfImpacts: [
                                {
                                    location: 'Front',
                                    damages: [
                                        {
                                            mainParticipantId: '3CED103092F68F68',
                                            fault: null
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            affectedParticipantId: '3CED103092F68F68',
                            barredFromRecovery: false,
                            pointOfImpacts: [
                                {
                                    location: 'Front',
                                    damages: [
                                        {
                                            mainParticipantId: 'BE03DC4D9C0FEEFA',
                                            fault: null
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            };
            wrapper.setProps({claimData: {...claimData, apportionedInitialFault, apportionedAllocatedFault, initialFaultSubmitTime:'2019-05-29T16:59:20.610+0000', apportionedAllocatedFaultSaveTime:'2019-04-29T17:59:20.610+0000' }});
            expect(wrapper.find('Connect(DamageApportionment)').exists()).toBe(true);
            expect(wrapper.find('Connect(DamageApportionment)').get(0).props.apportionedFault).toEqual(apportionedInitialFault);
        });

        it('should pass apportionedFaultDamages when apportionedAllocatedFaultSaveTime does not exists', () => {
            const apportionedInitialFault = {
                comparativeNegligenceRule: 'Mod. Comparative - 51%',
                summary: {
                    participants: [
                        {
                            affectedParticipantId: 'BE03DC4D9C0FEEFA',
                            barredFromRecovery: false,
                            pointOfImpacts: [
                                {
                                    location: 'Front',
                                    damages: [
                                        {
                                            mainParticipantId: '3CED103092F68F68',
                                            fault: null
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            affectedParticipantId: '3CED103092F68F68',
                            barredFromRecovery: false,
                            pointOfImpacts: [
                                {
                                    location: 'Front',
                                    damages: [
                                        {
                                            mainParticipantId: 'BE03DC4D9C0FEEFA',
                                            fault: null
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            };
            wrapper.setProps({claimData: {...claimData, apportionedInitialFault, apportionedAllocatedFault: null}});
            expect(wrapper.find('Connect(DamageApportionment)').exists()).toBe(true);
            expect(wrapper.find('Connect(DamageApportionment)').get(0).props.apportionedFault).toEqual(apportionedInitialFault);
        });

        it('should not render DamageApportionment when initialFaultSubmitTime and apportionedAllocatedFaultSaveTime are null', () => {
            wrapper.setProps({
                claimData: {
                    ...claimData,
                    apportionedInitialFault: null,
                    apportionedAllocatedFault: null
                }
            });
            expect(wrapper.find('Connect(DamageApportionment)').exists()).toBe(false);
        });
    });

    describe('Read Only Case', () => {
        beforeEach(() => {
            wrapper.setProps({readOnlyUser: true});
        });

        it('should render the FormOptions with readOnly and disabled prop true', () => {
            const formOptions = wrapper.find('FormOption');
            formOptions.forEach((o) => {
                expect(o.props().readOnly).toBe(true);
                expect(o.props().disabled).toBe(true);
            });
        });

        it('should render the updateDamageApportionment button as disabled', () => {
            wrapper.setProps({claimData: {...claimData, events: [event1], noFaultAllocationAgreement: false}});
            expect(wrapper.find('#update-damage-apportionment-btn').props().disabled).toBe(true);
        });

        it('should render the submit settlement button as disabled', () => {
            wrapper.setProps({claimData});
            expect(wrapper.find('#submit-settlement-button').props().disabled).toBe(true);
        });
    });

    describe('Not Read Only', () => {
        beforeEach(() => {
            wrapper.setProps({readOnlyUser: false});
        });

        it('should render the FormOptions with readOnly and disabled prop false', () => {
            const formOptions = wrapper.find('FormOption');
            formOptions.forEach((o) => {
                expect(o.props().readOnly).toBe(false);
                expect(o.props().disabled).toBe(false);
            });
        });

        it('should render the updateDamageApportionment button as enabled if all other conditions are met', () => {
            wrapper.setProps({claimData: {...claimData, events: [event1], noFaultAllocationAgreement: false}});
            expect(wrapper.find('#update-damage-apportionment-btn').props().disabled).toBe(false);
        });
    });

    describe('Connect', () => {
        it('mapStateToProps', () => {
            isReadOnlyUser.mockReturnValue(true);

            const claimData = {claimNumber: '123'};
            const history = {field1: "value1"};
            const user = {userRoles: ['LOON_USER']};
            const status = {updatingDamageApportionment: true, submitState: 'SUBMITTED'};
            const state = {claimData, user, status};

            const result = mapStateToProps(state, {history});
            expect(result.claimData).toEqual(claimData);
            expect(result.readOnlyUser).toEqual(true);
            expect(result.updatingDamageApportionment).toEqual(true);
            expect(result.submitState).toEqual('SUBMITTED');
            expect(result.history).toEqual(history);

            expect(isReadOnlyUser).toBeCalledWith(user.userRoles);
        });

        it('mapDispatchToProps', () => {
            expect(mapDispatchToProps.saveNoFaultAllocationIndicatorAction).toBe(saveNoFaultAllocationIndicatorAction);
            expect(mapDispatchToProps.updateDamageApportionmentAction).toBe(updateDamageApportionmentAction);
            expect(mapDispatchToProps.submitSettlementAction).toBe(submitSettlementAction);
            expect(mapDispatchToProps.submitSettlementCancelAction).toBe(submitSettlementCancelAction);
        });
    });
});
