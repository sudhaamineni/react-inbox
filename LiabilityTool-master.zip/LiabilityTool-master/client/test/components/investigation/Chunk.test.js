jest.unmock('../../../src/main/components/investigation/Chunk');

import React from 'react';
import {shallow} from 'enzyme';

import Chunk from '../../../src/main/components/investigation/Chunk';

describe('Given Chunk component', () => {
    let wrapper;
    const chunk = {
            speaker: 'Speaker',
            beginTime: 1,
            endTime: 11,
            beginIndex: 0,
            endIndex: 20,
            text: 'Test text for chunk ',
            highlightTexts: [],
            nlp: {Category: [{beginIndex: 0, endIndex: 4}]}
        },
        mockSetSeekTo = jest.fn(), mockHandleHighlightClick = jest.fn();

    document.getElementById = jest.fn().mockReturnValue({offsetTop: 100});

    beforeEach(() => {
        wrapper = shallow(
            <Chunk
                id={1}
                chunk={chunk}
                elapsedTime={12}
                onSetSeekTo={mockSetSeekTo}
                autoScroll={true}
                highlightMode={false}
                handleHighlightClick={mockHandleHighlightClick}
                nlpCategory=''
                nlpCategoryIndex={0}
            />
        );
    });

    describe('and render function', () => {
        describe('and when there are no highlights and no NLP selected', () => {
            it('should render with default style when not playing along', () => {
                expect(wrapper.find('#chunk1').text()).toBe('Test text for chunk ');
                expect(wrapper.find('#chunk1').props().className).toBe('chunk-default');
                expect(wrapper.find('#chunk1').props().onClick).not.toBe(undefined);

                expect(wrapper.find('#chunk1-text0').text()).toBe('Test text for chunk ');
                expect(wrapper.find('#chunk1-text0').props().className).toBe('');
                expect(wrapper.find('#chunk1-text0').props().onClick).toBe(undefined);
            });

            it('should render with play along style when playing along', () => {
                wrapper.setProps({elapsedTime: 10});

                expect(wrapper.find('#chunk1').text()).toBe('Test text for chunk ');
                expect(wrapper.find('#chunk1').props().className).toBe('chunk-play u-text-active');
                expect(wrapper.find('#chunk1').props().onClick).not.toBe(undefined);
            });
        });

        describe('and when there are highlights and no NLP selected', () => {
            it('should render with default style when not playing along', () => {
                const newChunk = {...chunk};
                newChunk.highlightTexts = [
                    {beginIndex: 14, endIndex: 20, entityIndex: 0, text: 'chunk '},
                    {beginIndex: 5, endIndex: 9, entityIndex: 1, text: 'text'},
                    {beginIndex: 0, endIndex: 4, entityIndex: 2, text: 'Test'},
                ];
                wrapper.setProps({chunk: newChunk});

                expect(wrapper.find('#chunk1').text()).toBe('Test text for chunk ');
                expect(wrapper.find('#chunk1').props().className).toBe('chunk-default');
                expect(wrapper.find('#chunk1').props().onClick).not.toBe(undefined);

                expect(wrapper.find('#chunk1-text0-highlight2').text()).toBe('Test');
                expect(wrapper.find('#chunk1-text0-highlight2').props().className).toBe('chunk-highlight');
                expect(wrapper.find('#chunk1-text0-highlight2').props().onClick).not.toBe(undefined);

                expect(wrapper.find('#chunk1-text4').text()).toBe(' ');
                expect(wrapper.find('#chunk1-text4').props().className).toBe('');
                expect(wrapper.find('#chunk1-text4').props().onClick).toBe(undefined);

                expect(wrapper.find('#chunk1-text5-highlight1').text()).toBe('text');
                expect(wrapper.find('#chunk1-text5-highlight1').props().className).toBe('chunk-highlight');
                expect(wrapper.find('#chunk1-text5-highlight1').props().onClick).not.toBe(undefined);

                expect(wrapper.find('#chunk1-text9').text()).toBe(' for ');
                expect(wrapper.find('#chunk1-text9').props().className).toBe('');
                expect(wrapper.find('#chunk1-text9').props().onClick).toBe(undefined);

                expect(wrapper.find('#chunk1-text14-highlight0').text()).toBe('chunk ');
                expect(wrapper.find('#chunk1-text14-highlight0').props().className).toBe('chunk-highlight');
                expect(wrapper.find('#chunk1-text14-highlight0').props().onClick).not.toBe(undefined);
            });

            it('should render with play along style when playing along', () => {
                const newChunk = {...chunk};
                newChunk.highlightTexts = [
                    {beginIndex: 0, endIndex: 4, entityIndex: 2, text: 'Test'},
                ];
                wrapper.setProps({chunk: newChunk, elapsedTime: 10});

                expect(wrapper.find('#chunk1').text()).toBe('Test text for chunk ');
                expect(wrapper.find('#chunk1').props().className).toBe('chunk-play u-text-active');
                expect(wrapper.find('#chunk1').props().onClick).not.toBe(undefined);
            });

            it('should invoke handleHighlightClick callback onClick of a highlighted span', () => {
                const newChunk = {...chunk};
                newChunk.highlightTexts = [
                    {beginIndex: 0, endIndex: 4, entityIndex: 2, text: 'Test'},
                ];
                wrapper.setProps({chunk: newChunk});

                wrapper.find('#chunk1-text0-highlight2').props().onClick({target: {id: 'chunk1-text0-highlight2'}});
                expect(mockHandleHighlightClick).toHaveBeenCalledWith({target: {id: 'chunk1-text0-highlight2'}});
            });
        });

        describe('and when NLP selected with no values', () => {
            it('should render with default style when not playing along', () => {
                wrapper.setProps({chunk: {...chunk, nlp: {}}, nlpCategory: 'Category'});

                expect(wrapper.find('#chunk1').text()).toBe('Test text for chunk ');
                expect(wrapper.find('#chunk1').props().className).toBe('chunk-nlp-nosel');
                expect(wrapper.find('#chunk1').props().onClick).not.toBe(undefined);

                expect(wrapper.find('#chunk1-text0').text()).toBe('Test text for chunk ');
                expect(wrapper.find('#chunk1-text0').props().className).toBe('');
                expect(wrapper.find('#chunk1-text0').props().onClick).toBe(undefined);
            });

            it('should render with play along style when playing along', () => {
                wrapper.setProps({elapsedTime: 10, nlpCategory: 'Category'});

                expect(wrapper.find('#chunk1').text()).toBe('Test text for chunk ');
                expect(wrapper.find('#chunk1').props().className).toBe('chunk-play u-text-active');
                expect(wrapper.find('#chunk1').props().onClick).not.toBe(undefined);
            });
        });

        describe('and when NLP selected with values and no highlights', () => {
            it('should render with default style when not playing along', () => {
                const newChunk = {...chunk};
                newChunk.nlp = {
                    Category: [
                        {categoryIndex: 1, beginIndex: 0, endIndex: 4},
                        {beginIndex: 5, endIndex: 9},
                        {categoryIndex: 2, beginIndex: 14, endIndex: 20},
                    ]
                };
                wrapper.setProps({chunk: newChunk, nlpCategory: 'Category'});

                expect(wrapper.find('#chunk1').text()).toBe('<Icon />1Test text for chunk ');
                expect(wrapper.find('#chunk1').props().className).toBe('chunk-nlp-nosel');
                expect(wrapper.find('#chunk1').props().onClick).not.toBe(undefined);

                expect(wrapper.find('#chunk1-text0').text()).toBe('Test');
                expect(wrapper.find('#chunk1-text0').props().className).toBe(' chunk-nlp u-text-gray-dark');
                expect(wrapper.find('#chunk1-text0').props().onClick).toBe(undefined);

                expect(wrapper.find('#chunk1-text4').text()).toBe(' ');
                expect(wrapper.find('#chunk1-text4').props().className).toBe('');
                expect(wrapper.find('#chunk1-text4').props().onClick).toBe(undefined);

                expect(wrapper.find('#chunk1-text5').text()).toBe('text');
                expect(wrapper.find('#chunk1-text5').props().className).toBe(' chunk-nlp u-text-gray-dark');
                expect(wrapper.find('#chunk1-text5').props().onClick).toBe(undefined);

                expect(wrapper.find('#chunk1-text9').text()).toBe(' for ');
                expect(wrapper.find('#chunk1-text9').props().className).toBe('');
                expect(wrapper.find('#chunk1-text9').props().onClick).toBe(undefined);

                expect(wrapper.find('#chunk1-text14').text()).toBe('chunk ');
                expect(wrapper.find('#chunk1-text14').props().className).toBe(' chunk-nlp u-text-gray-dark');
                expect(wrapper.find('#chunk1-text14').props().onClick).toBe(undefined);

                expect(wrapper.find('Icon').length).toBe(1);
                expect(wrapper.find('.u-text-x-tiny').get(0).props.children).toBe(1);
                //expect(wrapper.find('.u-text-x-tiny').get(1).props.children).toBe(2);
            });

            it('should render with play along style when playing along', () => {
                wrapper.setProps({chunk: {...chunk}, elapsedTime: 10, nlpCategory: 'Category'});

                expect(wrapper.find('#chunk1').text()).toBe('Test text for chunk ');
                expect(wrapper.find('#chunk1').props().className).toBe('chunk-play u-text-active');
                expect(wrapper.find('#chunk1').props().onClick).not.toBe(undefined);

                expect(wrapper.find('#chunk1-text0').text()).toBe('Test');
                expect(wrapper.find('#chunk1-text0').props().className).toBe(' chunk-nlp u-text-active');
                expect(wrapper.find('#chunk1-text0').props().onClick).toBe(undefined);
            });

            it('should render with hover style', () => {
                wrapper.setProps({nlpCategory: 'Category'});
                wrapper.instance().setState({hovering: true});

                expect(wrapper.find('#chunk1').text()).toBe('Test text for chunk ');
                expect(wrapper.find('#chunk1').props().className).toBe('chunk-nlp-nosel');
                expect(wrapper.find('#chunk1').props().onClick).not.toBe(undefined);

                expect(wrapper.find('#chunk1-text0').text()).toBe('Test');
                expect(wrapper.find('#chunk1-text0').props().className).toBe(' chunk-nlp u-text-active');
                expect(wrapper.find('#chunk1-text0').props().onClick).toBe(undefined);
            });
        });

        describe('and when NLP selected with values and highlights', () => {
            it('should render with default style when not playing along', () => {
                const newChunk = {...chunk};
                newChunk.highlightTexts = [
                    {beginIndex: 14, endIndex: 19, entityIndex: 0, text: 'chunk '},
                    {beginIndex: 5, endIndex: 9, entityIndex: 1, text: 'text'},
                    {beginIndex: 0, endIndex: 4, entityIndex: 2, text: 'Test'},
                ];
                newChunk.nlp = {
                    Category: [
                        {beginIndex: 0, endIndex: 4},
                        {beginIndex: 5, endIndex: 9},
                        {beginIndex: 10, endIndex: 20},
                    ]
                };
                wrapper.setProps({chunk: newChunk, nlpCategory: 'Category'});

                expect(wrapper.find('#chunk1').text()).toBe('Test text for chunk ');
                expect(wrapper.find('#chunk1').props().className).toBe('chunk-nlp-nosel');
                expect(wrapper.find('#chunk1').props().onClick).not.toBe(undefined);

                expect(wrapper.find('#chunk1-text0-highlight2').text()).toBe('Test');
                expect(wrapper.find('#chunk1-text0-highlight2').props().className).toBe('chunk-highlight chunk-nlp u-text-gray-dark');
                expect(wrapper.find('#chunk1-text0-highlight2').props().onClick).not.toBe(undefined);

                expect(wrapper.find('#chunk1-text4').text()).toBe(' ');
                expect(wrapper.find('#chunk1-text4').props().className).toBe('');
                expect(wrapper.find('#chunk1-text4').props().onClick).toBe(undefined);

                expect(wrapper.find('#chunk1-text5-highlight1').text()).toBe('text');
                expect(wrapper.find('#chunk1-text5-highlight1').props().className).toBe('chunk-highlight chunk-nlp u-text-gray-dark');
                expect(wrapper.find('#chunk1-text5-highlight1').props().onClick).not.toBe(undefined);

                expect(wrapper.find('#chunk1-text10').text()).toBe('for ');
                expect(wrapper.find('#chunk1-text10').props().className).toBe(' chunk-nlp u-text-gray-dark');
                expect(wrapper.find('#chunk1-text10').props().onClick).toBe(undefined);

                expect(wrapper.find('#chunk1-text14-highlight0').text()).toBe('chunk');
                expect(wrapper.find('#chunk1-text14-highlight0').props().className).toBe('chunk-highlight chunk-nlp u-text-gray-dark');
                expect(wrapper.find('#chunk1-text14-highlight0').props().onClick).not.toBe(undefined);

                expect(wrapper.find('#chunk1-text19').text()).toBe(' ');
                expect(wrapper.find('#chunk1-text19').props().className).toBe(' chunk-nlp u-text-gray-dark');
                expect(wrapper.find('#chunk1-text19').props().onClick).toBe(undefined);
            });

            it('should render with play along style when playing along', () => {
                const newChunk = {...chunk};
                newChunk.highlightTexts = [
                    {beginIndex: 0, endIndex: 4, entityIndex: 2, text: 'Test'},
                ];
                wrapper.setProps({chunk: newChunk, elapsedTime: 10, nlpCategory: 'Category'});

                expect(wrapper.find('#chunk1').text()).toBe('Test text for chunk ');
                expect(wrapper.find('#chunk1').props().className).toBe('chunk-play u-text-active');
                expect(wrapper.find('#chunk1').props().onClick).not.toBe(undefined);

                expect(wrapper.find('#chunk1-text0-highlight2').text()).toBe('Test');
                expect(wrapper.find('#chunk1-text0-highlight2').props().className).toBe('chunk-highlight chunk-nlp u-text-active');
                expect(wrapper.find('#chunk1-text0-highlight2').props().onClick).not.toBe(undefined);
            });
        });

        describe('and when highlightMode is on', () => {
            it('should render with default style when not playing along', () => {
                wrapper.setProps({highlightMode: true});

                expect(wrapper.find('#chunk1').text()).toBe('Test text for chunk ');
                expect(wrapper.find('#chunk1').props().className).toBe('chunk-highlight-default');
                expect(wrapper.find('#chunk1').props().onClick).toBe(undefined);
            });

            it('should render with play along style when playing along', () => {
                wrapper.setProps({elapsedTime: 10, highlightMode: true});

                expect(wrapper.find('#chunk1').text()).toBe('Test text for chunk ');
                expect(wrapper.find('#chunk1').props().className).toBe('chunk-highlight-default u-text-active');
                expect(wrapper.find('#chunk1').props().onClick).toBe(undefined);
            });
        });

        describe('and when highlightMode is on and NLP category available', () => {
            it('should render with default style when not playing along', () => {
                wrapper.setProps({highlightMode: true, nlpCategory: 'Category'});

                expect(wrapper.find('#chunk1').text()).toBe('Test text for chunk ');
                expect(wrapper.find('#chunk1').props().className).toBe('chunk-highlight-default chunk-highlight-nlp-nosel');
                expect(wrapper.find('#chunk1').props().onClick).toBe(undefined);
            });

            it('should render with play along style when playing along', () => {
                wrapper.setProps({elapsedTime: 10, highlightMode: true, nlpCategory: 'Category'});

                expect(wrapper.find('#chunk1').text()).toBe('Test text for chunk ');
                expect(wrapper.find('#chunk1').props().className).toBe('chunk-highlight-default u-text-active');
                expect(wrapper.find('#chunk1').props().onClick).toBe(undefined);
            });
        });
    });

    describe('and shouldComponentUpdate function', () => {
        it('returns false when the props and state did not change', () => {
            const newProps = {chunk: {...chunk}, elapsedTime: 12, highlightMode: false, nlpCategory: ''};
            const newState = {...wrapper.instance().state};
            expect(wrapper.instance().shouldComponentUpdate(newProps, newState)).toBe(false);
        });

        it('returns false when the elapsedTime change will not change play along style', () => {
            const newProps = {chunk: {...chunk}, elapsedTime: 13, highlightMode: false, nlpCategory: ''};
            const newState = {...wrapper.instance().state};
            expect(wrapper.instance().shouldComponentUpdate(newProps, newState)).toBe(false);
        });

        it('returns true when the elapsedTime change will change play along style', () => {
            const newProps = {chunk: {...chunk}, elapsedTime: 10};
            expect(wrapper.instance().shouldComponentUpdate(newProps)).toBe(true);
        });

        it('returns true when the highlightMode changes', () => {
            const newProps = {chunk: {...chunk}, elapsedTime: 12, highlightMode: true};
            expect(wrapper.instance().shouldComponentUpdate(newProps)).toBe(true);
        });

        it('returns true when the highlightTexts changes', () => {
            const newChunk = {...chunk};
            newChunk.highlightTexts = [{beginIndex: 0, endIndex: 4, entityIndex: 0, text: 'Test'}];
            const newProps = {chunk: newChunk, elapsedTime: 12, highlightMode: false};
            expect(wrapper.instance().shouldComponentUpdate(newProps)).toBe(true);
        });

        it('returns false when the nlpCategory change will not change NLP style', () => {
            wrapper.setProps({nlpCategory: 'Category1'});
            const newProps = {chunk: {...chunk}, elapsedTime: 12, highlightMode: false, nlpCategory: 'Category2'};
            const newState = {...wrapper.instance().state};
            expect(wrapper.instance().shouldComponentUpdate(newProps, newState)).toBe(false);
        });

        it('returns true when the nlpCategory change will change NLP style', () => {
            wrapper.setProps({
                chunk: {
                    ...chunk,
                    nlp: {
                        Category: [{categoryIndex: 0, beginIndex: 0, endIndex: 5}],
                        Category1: [{categoryIndex: 0, beginIndex: 0, endIndex: 5}]
                    }
                }
            });
            const newProps = {chunk: {...chunk}, elapsedTime: 12, highlightMode: false, nlpCategory: 'Category1'};
            expect(wrapper.instance().shouldComponentUpdate(newProps)).toBe(true);
        });

        it('returns true when the hovering changes', () => {
            const newProps = {chunk: {...chunk}, elapsedTime: 12, highlightMode: false, nlpCategory: ''};
            const newState = {hovering: true};
            expect(wrapper.instance().shouldComponentUpdate(newProps, newState)).toBe(true);
        });
    });

    describe('and setScroll function', () => {
        it('should not scroll when the autoScroll is turned off', () => {
            const newProps = {chunk: {...chunk}, autoScroll: false};
            wrapper.instance().setScroll = jest.fn();
            wrapper.instance().setScroll.mockClear();
            wrapper.instance().shouldComponentUpdate(newProps);
            expect(wrapper.instance().setScroll).not.toHaveBeenCalled();
        });

        it('should not scroll when the elapsedTime change is not causing scroll', () => {
            const newProps = {chunk: {...chunk}, elapsedTime: 13, autoScroll: true};
            wrapper.instance().setScroll = jest.fn();
            wrapper.instance().setScroll.mockClear();
            wrapper.instance().shouldComponentUpdate(newProps);
            expect(wrapper.instance().setScroll).not.toHaveBeenCalled();
        });

        it('should scroll when the elapsedTime change is causing scroll', () => {
            const newProps = {chunk: {...chunk}, elapsedTime: 10, autoScroll: true};
            wrapper.instance().setScroll = jest.fn();
            wrapper.instance().setScroll.mockClear();
            wrapper.instance().shouldComponentUpdate(newProps);
            expect(wrapper.instance().setScroll).toHaveBeenCalled();
        });

        it('should scroll when NLP selection changes', () => {
            wrapper.setProps({chunk: {...chunk, nlp: {Category: [{categoryIndex: 1, beginIndex: 0, endIndex: 4}]}}});
            const newProps = {chunk: {...chunk}, nlpCategory: 'Category', nlpCategoryIndex: 1};
            wrapper.instance().setScroll = jest.fn();
            wrapper.instance().setScroll.mockClear();
            wrapper.instance().shouldComponentUpdate(newProps);
            expect(wrapper.instance().setScroll).toHaveBeenCalled();
        });

        it('should scroll with 100px padding', () => {
            const mockTranscriptContent = {scrollTop: 2};
            document.getElementById.mockReturnValueOnce({offsetTop: 100});
            document.getElementById.mockReturnValueOnce({offsetTop: 300});
            document.getElementById.mockReturnValueOnce(mockTranscriptContent);

            wrapper.instance().setScroll();
            expect(document.getElementById).toHaveBeenCalledWith('chunk0');
            expect(document.getElementById).toHaveBeenCalledWith('chunk1');
            expect(document.getElementById).toHaveBeenCalledWith('transcript-content');
            expect(mockTranscriptContent.scrollTop).toBe(100);
        });
    });

    describe('and onClick', () => {
        it('should be invoked when highlightMode is false', () => {
            wrapper.find('#chunk1').simulate('click');
            expect(mockSetSeekTo).toHaveBeenCalledWith(1);
        });

        it('should not be invoked when highlightMode is true', () => {
            wrapper.setProps({highlightMode: true});
            mockSetSeekTo.mockClear();

            wrapper.find('#chunk1').simulate('click');
            expect(mockSetSeekTo).not.toHaveBeenCalled();
        });
    });

    describe('and onMouseOver', () => {
        it('should update state', () => {
            wrapper.setProps({nlpCategory: 'Category'});
            wrapper.find('#chunk1').simulate('mouseover');
            expect(wrapper.instance().state.hovering).toBe(true);
        });
    });

    describe('and onMouseOut', () => {
        it('should update state', () => {
            wrapper.setProps({nlpCategory: 'Category'});
            wrapper.find('#chunk1').simulate('mouseout');
            expect(wrapper.instance().state.hovering).toBe(false);
        });
    });
});
