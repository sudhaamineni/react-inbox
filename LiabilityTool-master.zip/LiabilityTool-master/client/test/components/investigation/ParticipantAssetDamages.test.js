jest.unmock('../../../src/main/components/investigation/ParticipantAssetDamages');

import React from 'react';
import {shallow} from 'enzyme';
import {
    mapDispatchToProps,
    mapStateToProps,
    ParticipantAssetDamages
} from '../../../src/main/components/investigation/ParticipantAssetDamages';
import analyticsHelper from '../../../src/main/helpers/analyticsHelper';
import {
    createId,
    getAssetTypeShortName,
    getParticipantName,
    getQueryStringValue,
    getVehicleInfo,
    isInsured,
    isReadOnly
} from '../../../src/main/helpers/claimDataHelper';
import {photoRotationAction, photoToggleBookmarkAction} from '../../../src/main/actions/photoActions';
import {saveEvidenceAction} from '../../../src/main/actions/attachmentsActions';
import deepFreeze from 'deep-freeze';

describe('ParticipantAssetDamages', () => {
    let wrapper;
    let involvedParty = {
        participantId: '1',
        participantSourceId: '11',
        assetId: 'asset1',
        damageSections: [
            'front',
            'rear'
        ],
        contributingFactors: [
            {
                category: null,
                reason: 'proper-lookout',
                details: 'saw-other-party',
                evidenceIds: ['somephotoid', 'evidence2','evidence5']
            }
        ],
        affectedParties: [
            {
                participantId: '2',
                participantSourceId: '22',
                assetId: 'B9763FCB7D843B1F',
                passengerPartyIds: [],
                affectedPercent: 12,
                beginNegotiatingRange: 7,
                endNegotiatingRange: 17,
                submittedAffectedPercent: 12,
                faultAllocationPercent: 1
            }
        ]
    };
    const event =
        {id: '0', title: 'my first event title', severity: 1, involvedParties: [involvedParty]};
    const events=[event];
    const mockLiabilitySubjects = [
            {
                asset: {
                    vehicleYear: '2019',
                    vehicleMake: 'Tesla',
                    vehicleModel: 'Model S',
                    assetTypeDescription: 'Auto',
                    damages: [{
                        damageArea: 'Passenger',
                        damageParts: ['Bumper', 'Front fender', 'Front door']
                    }],
                },
                isDriver: true,
                role: 'INSURED',
                participantSourceId: 'p1',
                participantPartyId: '01',
                firstName: 'John',
                lastName: 'Larson',
                photoAttachments: [{
                    dcfId: 'url1',
                    url: 'photoUrl1',
                    bookmarked: true,
                    rotation: 90
                }, {
                    dcfId: 'url2',
                    url: 'photoUrl2',
                    bookmarked: false,
                    rotation: 180
                }],
            },
            {
                asset: {
                    vehicleYear: '2019',
                    vehicleMake: 'BMW',
                    vehicleModel: 'X3',
                    assetTypeDescription: 'Motorcycle',
                    damages: [{
                        damageArea: 'Passenger',
                        damageParts: ['Bumper', 'Front fender', 'Front door']
                    }]
                },
                isDriver: false,
                role: 'CLAIMANT',
                firstName: 'Test',
                lastName: 'Claimant',
                driverName: 'Driver Claimant',
                participantPartyId: '02',
                participantSourceId: '456',
                photoAttachments: [{
                    dcfId: 'url3',
                    bookmarked: true,
                    rotation: 90
                }, {
                    dcfId: 'url4',
                    bookmarked: false,
                    rotation: 180
                }],
            }
        ],
        photos = [
            {hasError: false, isBookmarked: true, rotation: 90, url: 'photoUrl1', evidence: 'damages'},
            {hasError: false, isBookmarked: false, rotation: 180, url: 'photoUrl2'}
        ],
        mockEvidences = [
            {id: 'evidence1', sourceId: 'highlight1', type: 'highlight', role: 'INSURED', participantPartyId: '01'},
            {
                id: 'evidence2',
                sourceId: 'url1',
                type: 'photo',
                category: 'damages',
                photoUrl: 'photoUrl1',
                rotation: 90,
                role: 'INSURED',
                participantPartyId: '01',
            },
        ],
        mockPhotoToggleBookmarkAction = jest.fn(),
        mockPhotoRotationAction = jest.fn(),
        mockSaveEvidenceAction = jest.fn();

    deepFreeze(mockLiabilitySubjects);
    deepFreeze(mockEvidences);

    beforeEach(() => {
        getQueryStringValue.mockReturnValue('Gallery');
        isInsured.mockReturnValue(true);
        getAssetTypeShortName.mockReturnValue('getAssetTypeShortNameReturnValue');
        getParticipantName.mockReturnValue('getParticipantNameReturnValue');
        getVehicleInfo.mockReturnValue('getVehicleInfoReturnValue');
        createId.mockReturnValue('evidenceId');

        wrapper = shallow(
            <ParticipantAssetDamages
                claimNumber="123"
                liabilitySubjects={mockLiabilitySubjects}
                evidences={mockEvidences}
                attachmentsRetrievalFailed={false}
                retrievingAttachments={false}
                isGalleryActive={false}
                readOnly={false}
                photoToggleBookmarkAction={mockPhotoToggleBookmarkAction}
                photoRotationAction={mockPhotoRotationAction}
                saveEvidenceAction={mockSaveEvidenceAction}
                events={events}
            />
        );
    });

    describe('Header', () => {
        it('should display the asset damages title', () => {
            expect(wrapper.find('#title').text()).toBe('Asset Damages (2)');
        });
    });

    describe('ParticipantListItem', () => {
        it('should render ParticipantListItem', () => {
            expect(wrapper.find('ParticipantListItem').length).toBe(2);
            expect(wrapper.find('ParticipantListItem').at(0).props().isActive).toBe(true);
            expect(wrapper.find('ParticipantListItem').at(1).props().isActive).toBe(false);
            expect(wrapper.find('ParticipantListItem').at(0).props().isInsured).toBe(true);
            expect(wrapper.find('ParticipantListItem').at(0).props().icon).toBe('getAssetTypeShortNameReturnValue');
            expect(wrapper.find('ParticipantListItem').at(0).props().vehicle).toBe('getVehicleInfoReturnValue');
            expect(wrapper.find('ParticipantListItem').at(0).props().name).toBe('GETPARTICIPANTNAMERETURNVALUE (DRIVER)');
            expect(wrapper.find('ParticipantListItem').at(1).props().name).toBe('GETPARTICIPANTNAMERETURNVALUE');
            expect(wrapper.find('ParticipantListItem').at(0).props().driver).toBe('');
            expect(wrapper.find('ParticipantListItem').at(1).props().driver).toBe('DRIVER CLAIMANT');
        });

        it('should pass isActive based on participantIndex state value', () => {
            wrapper.instance().setState({participantIndex: 1});
            expect(wrapper.find('ParticipantListItem').at(0).props().isActive).toBe(false);
            expect(wrapper.find('ParticipantListItem').at(1).props().isActive).toBe(true);
        });

        it('should update participantIndex state value on click of a participant row', () => {
            wrapper.find('ParticipantListItem').at(1).props().onClick();
            expect(wrapper.instance().state.participantIndex).toBe(1);
        });

        it('should pass icon prop as pedestrian when role is PEDESTRIAN/BICYCLIST', () => {
            const newLiabilitySubjects = JSON.parse(JSON.stringify(mockLiabilitySubjects));
            newLiabilitySubjects[1].role = 'PEDESTRIAN/BICYCLIST';
            wrapper.setProps({liabilitySubjects: newLiabilitySubjects});
            expect(wrapper.find('ParticipantListItem').at(1).props().icon).toBe('pedestrian');
        });
    });

    describe('Gallery', () => {
        it('renders a gallery with default props', () => {
            expect(wrapper.find('Gallery').props().isActive).toBe(false);
            expect(wrapper.find('Gallery').props().name).toBe('getParticipantNameReturnValue');
            expect(wrapper.find('Gallery').props().isInsured).toBe(true);
            expect(wrapper.find('Gallery').props().vehicle).toBe('getVehicleInfoReturnValue');
            expect(wrapper.find('Gallery').props().photos).toEqual(photos);
            expect(wrapper.find('Gallery').props().assetDamages).toEqual(mockLiabilitySubjects[0].asset.damages);
            expect(wrapper.find('Gallery').props().hasError).toBe(false);
            expect(wrapper.find('Gallery').props().isLoading).toBe(false);
            expect(wrapper.find('Gallery').props().readOnly).toEqual(false);
        });

        it('should pass readOnly prop as true to Gallery when userRoles is equal to LOON Read Only User', () => {
            wrapper.setProps({readOnly: true});
            expect(wrapper.find('Gallery').props().readOnly).toBe(true);
        });

        it('calls analyticsHelper trackEvent when opened', () => {
            const expectedEvent = {
                message: 'success',
                eventAction: 'InvestigationPage_Gallery_GalleryOpen',
                eventSource: 'link',
                errorCode: '',
            };

            wrapper.find('Gallery').props().onOpen();
            expect(analyticsHelper.trackEvent).toHaveBeenCalledTimes(1);
            expect(analyticsHelper.trackEvent).toHaveBeenCalledWith(expectedEvent);
        });

        describe('onBookmarksChange', () => {
            beforeEach(() => {
                mockPhotoToggleBookmarkAction.mockReset();
                mockSaveEvidenceAction.mockReset();
            });

            it('should update bookmarked to true and add evidence when bookmarked', () => {
                const photosFromGallery =
                    {url: 'photoUrl2', isBookmarked: true, rotation: 180};
                const expectedPhotoAttachments = [
                    {dcfId: 'url1', url: 'photoUrl1', bookmarked: true, rotation: 90},
                    {dcfId: 'url2', url: 'photoUrl2', bookmarked: true, rotation: 180}
                ];
                const expectedEvidences = [
                    {
                        id: 'evidence1',
                        sourceId: 'highlight1',
                        type: 'highlight',
                        role: 'INSURED',
                        participantPartyId: '01',
                    },
                    {
                        id: 'evidence2',
                        sourceId: 'url1',
                        type: 'photo',
                        category: 'damages',
                        photoUrl: 'photoUrl1',
                        rotation: 90,
                        role: 'INSURED',
                        participantPartyId: '01',
                    },
                    {
                        id: 'evidenceId',
                        sourceId: 'url2',
                        type: 'photo',
                        photoUrl: 'photoUrl2',
                        rotation: 180,
                        role: 'INSURED',
                        participantPartyId: '01',
                        participantSourceId: 'p1'
                    },
                ];

                wrapper.find('Gallery').simulate('bookmarksChange', 0, photosFromGallery);
                expect(mockPhotoToggleBookmarkAction).toBeCalledWith('123', 'p1', expectedPhotoAttachments, expectedEvidences, events);
                expect(mockSaveEvidenceAction).not.toBeCalled();
            });

            it('should update bookmarked to false and remove evidence when trash icon of evidence menu is clicked', () => {
                const newEvidences = [
                    {id: 'evidence1', sourceId: 'highlight1', type: 'highlight'},
                    {id: 'evidence2', sourceId: 'url1', type: 'photo'}
                ];
                wrapper.setProps({evidences: newEvidences});

                const photosFromGallery =
                    {url: 'photoUrl1', isBookmarked: false};
                const expectedPhotoAttachments = [
                    {dcfId: 'url1', url: 'photoUrl1', bookmarked: false, rotation: 90},
                    {dcfId: 'url2', url: 'photoUrl2', bookmarked: false, rotation: 180}
                ];

                let newInvolvedParty = {
                    participantId: '1',
                    participantSourceId: '11',
                    assetId: 'asset1',
                    damageSections: [
                        'front',
                        'rear'
                    ],
                    contributingFactors: [
                        {
                            category: null,
                            reason: 'proper-lookout',
                            details: 'saw-other-party',
                            evidenceIds: ['somephotoid','evidence5']
                        }
                    ],
                    affectedParties: [
                        {
                            participantId: '2',
                            participantSourceId: '22',
                            assetId: 'B9763FCB7D843B1F',
                            passengerPartyIds: [],
                            affectedPercent: 12,
                            beginNegotiatingRange: 7,
                            endNegotiatingRange: 17,
                            submittedAffectedPercent: 12,
                            faultAllocationPercent: 1
                        }
                    ]
                };
                const newEvent =
                    {id: '0', title: 'my first event title', severity: 1, involvedParties: [newInvolvedParty]};
                const newEvents=[newEvent];
                const expectedEvidences = [
                    {id: 'evidence1', sourceId: 'highlight1', type: 'highlight'}
                ];


                wrapper.find('Gallery').simulate('bookmarksChange', 0, photosFromGallery);
                expect(mockPhotoToggleBookmarkAction).toBeCalledWith('123', 'p1', expectedPhotoAttachments, expectedEvidences, newEvents);
                expect(mockSaveEvidenceAction).not.toBeCalled();
            });

            it('should update evidence category when selected', () => {
                const photosFromGallery =
                    {url: 'photoUrl1', isBookmarked: true, evidence: 'point-of-impact', rotation: 90};
                const expectedEvidence = {
                    id: 'evidence2',
                    sourceId: 'url1',
                    type: 'photo',
                    category: 'point-of-impact',
                    photoUrl: 'photoUrl1',
                    rotation: 90,
                    role: 'INSURED',
                    participantPartyId: '01',
                };

                wrapper.find('Gallery').simulate('bookmarksChange', 0, photosFromGallery);
                expect(mockSaveEvidenceAction).toBeCalledWith('123', expectedEvidence);
                expect(mockPhotoToggleBookmarkAction).not.toBeCalled();
            });
        });

        describe('onPhotoRotationChange', () => {
            beforeEach(() => {
                mockPhotoToggleBookmarkAction.mockReset();
                mockSaveEvidenceAction.mockReset();
            });

            it('calls photoRotationAction when onPhotoRotationChange prop received', () => {
                const photosFromGallery = {url: 'photoUrl2', rotation: 90}
                const expectedPhotoAttachments = [
                    {dcfId: 'url1', url: 'photoUrl1', bookmarked: true, rotation: 90},
                    {dcfId: 'url2', url: 'photoUrl2', bookmarked: false, rotation: 90}
                ];

                wrapper.find('Gallery').simulate('photoRotationChange', 0, photosFromGallery);
                expect(mockPhotoRotationAction).toBeCalledWith('123', 'p1', expectedPhotoAttachments, mockEvidences);
            });

            it('calls photoRotationAction with updated evidences when photos are rotated', () => {
                const photosFromGallery =
                    {url: 'photoUrl1', rotation: 180}
                const expectedPhotoAttachments = [
                    {dcfId: 'url1', url: 'photoUrl1', bookmarked: true, rotation: 180},
                    {dcfId: 'url2', url: 'photoUrl2', bookmarked: false, rotation: 180}
                ];

                const expectedEvidences = [
                    {
                        id: 'evidence1',
                        sourceId: 'highlight1',
                        type: 'highlight',
                        role: 'INSURED',
                        participantPartyId: '01',
                    },
                    {
                        id: 'evidence2',
                        sourceId: 'url1',
                        type: 'photo',
                        category: 'damages',
                        photoUrl: 'photoUrl1',
                        rotation: 180,
                        role: 'INSURED',
                        participantPartyId: '01',
                    }
                ];

                wrapper.find('Gallery').simulate('photoRotationChange', 0, photosFromGallery);
                expect(mockPhotoRotationAction).toBeCalledWith('123', 'p1', expectedPhotoAttachments, expectedEvidences);
            });
        });
    });

    it('should pass damages to AssetDamages component', () => {
        expect(wrapper.find('AssetDamages').props().damages).toBe(mockLiabilitySubjects[0].asset.damages);
    });

    describe('Connect', () => {
        it('mapStateToProps', () => {
            isReadOnly.mockReturnValue(true);

            const state = {
                user: {userRoles: ['LOON User']},
                claimData: {
                    claimNumber: '123',
                    locked: true,
                    liabilitySubjects: [{firstName: 'name1'}, {firstName: 'name2'}],
                    evidences: [{id: 'e1', sourceId: 'p1'}],
                    events:[event]
                },
                status: {attachmentsRetrievalFailed: true, retrievingAttachments: true},
            };
            const user = {userRoles: ['LOON User']};
            const claimData = {
                claimNumber: '1234',
                locked: true,
                liabilitySubjects: [{firstName: 'name1'}, {firstName: 'name2'}]
            };
            const router = {
                location: {search: '?activeComponent=Gallery'}
            };
            const result = mapStateToProps(state, router);

            expect(result.readOnly).toEqual(true);
            expect(result.claimNumber).toBe('123');
            expect(result.liabilitySubjects).toEqual([{firstName: 'name1'}, {firstName: 'name2'}]);
            expect(result.evidences).toEqual([{id: 'e1', sourceId: 'p1'}]);
            expect(result.attachmentsRetrievalFailed).toBe(true);
            expect(result.retrievingAttachments).toBe(true);
            expect(result.isGalleryActive).toBe(true);
            expect(result.events).toEqual(events);

            expect(isReadOnly).toBeCalledWith(user.userRoles, claimData.locked);
        });

        it('should associate actions as dispatch props - mapDispatchToProps', () => {
            expect(mapDispatchToProps).toEqual({
                photoToggleBookmarkAction,
                photoRotationAction,
                saveEvidenceAction
            });
        });
    });
});
