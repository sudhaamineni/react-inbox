jest.unmock('../../../src/main/components/investigation/Highlighter');

import {shallow} from 'enzyme';
import React from 'react';
import {Highlighter, mapStateToProps} from '../../../src/main/components/investigation/Highlighter';
import {isReadOnly} from '../../../src/main/helpers/claimDataHelper';

describe('Highlighter', () => {
    let wrapper;
    const mockToggleHighlight = jest.fn();
    beforeEach(() => {
        wrapper = shallow(
            <Highlighter
                highlightMode={false}
                toggleHighlight={mockToggleHighlight}
                isReadOnly={false}
            />
        );
    });

    describe('renders', () => {
        it('with class c-btn--highlighter, when not in highlight mode', () => {
            expect(wrapper.find('button').props().className).toContain('c-btn c-btn--highlighter');
        });

        it('with class c-btn--highlighter--active, when in highlight mode', () => {
            wrapper.setProps({highlightMode: true});
            expect(wrapper.find('button').props().className).toContain('c-btn c-btn--highlighter--active');
        });

        it('should have a label', () => {
            expect(wrapper.find('span').text()).toBe('Highlight Evidence');
        });

        it('should have a star icon', () => {
            expect(wrapper.find('Icon').props().icon).toBe('star');
        });

        it('should have a star icon with size 1.5', () => {
            expect(wrapper.find('Icon').props().size).toBe(1.25);
        });

        it('should pass readOnly prop as false when userRoles is not equal to LOON Read Only User', () => {
            expect(wrapper.find('button').props().disabled).toBe(false);
        });

        it('should pass readOnly prop as true when userRoles is equal to LOON Read Only User', () => {
            wrapper.setProps({isReadOnly: true});
            expect(wrapper.find('button').props().disabled).toBe(true);
        });
    });

    describe('click', () => {
        it('highlight button calls toggleHighlight', () => {
            wrapper.find('button').simulate('click');
            expect(mockToggleHighlight).toBeCalled();
        });
    });

    describe('connect', () => {
        it('mapStateToProps', () => {
            isReadOnly.mockReturnValue(true);

            const user = {userRoles: ['LOON User']};
            const claimData = {locked: true};
            const store = {user, claimData};

            const result = mapStateToProps(store);
            expect(result.isReadOnly).toEqual(true);

            expect(isReadOnly).toBeCalledWith(user.userRoles, claimData.locked);
        });
    });
});
