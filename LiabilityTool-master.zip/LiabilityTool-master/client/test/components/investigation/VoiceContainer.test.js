import analyticsHelper from '../../../src/main/helpers/analyticsHelper';
import React from 'react';
import {shallow} from 'enzyme';
import {
    mapDispatchToProps,
    mapStateToProps,
    VoiceContainer
} from '../../../src/main/components/investigation/VoiceContainer';
import {saveVoiceParticipantAction} from '../../../src/main/actions/transcriptActions';
import {formatVoiceDateTimeString} from '../../../src/main/helpers/dateTimeHelper';

jest.unmock('../../../src/main/components/investigation/VoiceContainer');
jest.unmock('../../../src/main/helpers/claimDataHelper');
jest.unmock('../../../src/main/constants/loonConstants');

describe('VoiceContainer ', () => {
    let wrapper;

    const claimData = {
        mapAddress: '123 SwrappertName, City, State ZipCode',
        updatedLossLocation: undefined,
        claimNumber: '123',
        initialFaultSubmitTime: '2017-08-06 12:12:12',
        lossDetailType: 'Intersection Accident',
        lossDetailTypeCode: '01',
        lossDate: '06/08/2017',
        lossTime: '9:32 am',
        lossState: 'California',
        liabilitySubjects: [{
            role: 'INSURED',
            firstName: 'HOWARD',
            lastName: 'ELLIOTT',
            asset: {
                vehicleYear: '2002',
                vehicleMake: 'TOYOTA',
                vehicleModel: 'COROLLA',
            }
        }],
        participants: [{
            participantId: '01',
            participantSourceId: 'abcd',
            firstName: 'HOWARD',
            lastName: 'ELLIOTT',
            organizationName: null,
            name: 'HOWARD ELLIOTT',
        }, {
            participantId: '02',
            participantSourceId: 'efgh',
            firstName: 'Saira',
            lastName: 'Chirayil',
            organizationName: null,
            name: 'Saira Chirayil',
        }, {
            participantId: '03',
            participantSourceId: 'wxyz',
            firstName: null,
            lastName: null,
            organizationName: 'MORTON GROVE TOWING COMPANY',
            name: 'MORTON GROVE TOWING COMPANY',
        }],
        voiceAttachments: [
            {
                createdDate: '2019-02-06T16:08:30.802',
                sourceVoiceTitle: 'Inquiry',
                sourceVoiceUrl: 'voiceUrl',
                highlightEntities: [
                    {
                        highlightTexts: [
                            {beginIndex: 8, endIndex: 15, text: 'chunk1.'},
                        ],
                        audioHighlightTimeStart: 15.5 + (3.5 / 15) * 8,
                    },
                    {
                        highlightTexts: [
                            {beginIndex: 0, endIndex: 6, text: 'This is'},
                            {beginIndex: 8, endIndex: 15, text: 'chunk1.'}
                        ],
                        audioHighlightTimeStart: 15.5 + (3.5 / 15) * 8,
                    },
                    {
                        highlightTexts: [
                            {beginIndex: 7, endIndex: 15, text: ' chunk1.'},
                            {beginIndex: 0, endIndex: 5, text: 'This i'},
                        ],
                        audioHighlightTimeStart: 15.5 + (3.5 / 15) * 7,
                    },
                ]
            },
            {
                createdDate: '2019-03-06T16:08:30.802',
                sourceVoiceTitle: 'Inquiry',
                sourceVoiceUrl: '/document/allstate/content?id=workspace://SpacesStore/6603373d-8d23-4231-8f4f-6a841b163b7d',
                highlightEntities: [
                    {
                        highlightTexts: [
                            {beginIndex: 8, endIndex: 15, text: 'chunk1.'}
                        ],
                        audioHighlightTimeStart: 15.5 + (3.5 / 15) * 8,

                    },
                    {
                        highlightTexts: [
                            {beginIndex: 0, endIndex: 6, text: 'This is'},
                            {beginIndex: 8, endIndex: 15, text: 'chunk1.'},
                        ],
                        audioHighlightTimeStart: 15.5 + (3.5 / 15) * 8,

                    },
                ],
                participantSourceId: 'ABCDEFG123',
                participantDisplayName: 'LITTLE MAC',
            },
            {
                createdDate: '2019-04-06T16:08:30.802',
                sourceVoiceTitle: 'someOther',
                sourceVoiceUrl: '/document/allstate/content?id=workspace://SpacesStore/aa9b3334-39dd-4d1d-b190-612fdc6efb7d',
                participantDisplayName: 'Other',
            },
            {
                createdDate: '2019-05-06T16:08:30.802',
                sourceVoiceTitle: 'Inquiry',
                sourceVoiceUrl: '/document/allstate/content?id=workspace://SpacesStore/7968f6af-6f1d-48fa-8f08-913375327ac6',
                participantSourceId: 'ABCDEFG123',
            },
        ]
    };
    let mockSaveVoiceParticipant;

    beforeEach(() => {
        window.addEventListener = jest.fn();
        window.removeEventListener = jest.fn();
        document.getElementById = jest.fn().mockReturnValue({
            getBoundingClientRect: jest.fn().mockReturnValue({
                height: 777,
                top: 888,
            })
        });
        document.body.getBoundingClientRect = jest.fn().mockReturnValue({
            height: 1200,
        });
        window.scrollTo = jest.fn();
        mockSaveVoiceParticipant = jest.fn();
        formatVoiceDateTimeString.mockReturnValue('Wed, Feb 6, 2019 at 4:08PM CST');

        wrapper = shallow(
            <VoiceContainer
                claimData={claimData}
                retrievingAttachments={false}
                attachmentsRetrievalFailed={false}
                readOnly={false}
                saveVoiceParticipant={mockSaveVoiceParticipant}
            />
        );
    });

    describe('Voice and Transcript', () => {
        describe('When Rendered with the insured and no organization name', () => {
            it('sets state to default values', () => {
                expect(wrapper.instance().state.audioIndex).toBe(0);
                expect(wrapper.instance().state.elapsedTime).toBe(0.00);
                expect(wrapper.instance().state.seekTo).toEqual({track: 0, time: 0.00});
                expect(wrapper.instance().state.audioPlaying).toBe(false);
            });
        });

        describe('AudioPlayer component', () => {
            describe('When Rendered with AudioPlayer', () => {
                it('displays the insured title when Audio Player is loaded', () => {
                    expect(wrapper.find('AudioPlayer').props().tracks[0].title).toEqual('Inquiry');
                });

                it('passed the isInsured prop as false when claimant', () => {
                    const newClaimData = {...claimData};
                    newClaimData.liabilitySubjects = [{
                        role: 'CLAIMANT',
                        firstName: 'HOWARD',
                        lastName: 'ELLIOTT',
                        asset: {
                            vehicleYear: '2002',
                            vehicleMake: 'TOYOTA',
                            vehicleModel: 'COROLLA',
                        }
                    }];
                    wrapper.setProps({claimData: newClaimData});
                    expect(wrapper.find('AudioPlayer').props().isInsured).toBe(false);
                });

                it('when voice attachment is available, renders the voice label with the number of voice attachments', () => {
                    expect(wrapper.find('#voice').text()).toContain('Voice (4)');
                });

                it('should pass a waveForm prop that has length equal to number of track details', () => {
                    expect(wrapper.find('AudioPlayer').props().waveforms.length).toBe(claimData.voiceAttachments.length);
                });

                it('when voice attachment is not available, renders the voice label without the number of voice attachments', () => {
                    let newClaimData = {...claimData, voiceAttachments: []};
                    wrapper = shallow(
                        <VoiceContainer
                            claimData={newClaimData}
                            retrievingAttachments={false}
                            attachmentsRetrievalFailed={false}
                            readOnly={false}
                            saveVoiceParticipant={mockSaveVoiceParticipant}
                        />
                    );
                    expect(wrapper.find('#voice').text()).toContain('Voice');
                });

                it('should display a text with Transcribed message and an information icon.', () => {
                    expect(wrapper.find('#voice-transcription-message').text()).toContain('Calls recorded in the last 30 minutes may still be processing.');
                    expect(wrapper.find('#voice-info-icon').props().icon).toBe('info-circle');
                });

                it('passed the bookmarks prop when highlighted text is available', () => {
                    expect(wrapper.find('AudioPlayer').props().bookmarks.length).toBe(5);
                    expect(wrapper.find('AudioPlayer').props().bookmarks[0].time).toBe(17.366666666666667);
                });

                it('should pass the tracks with their associated bookmarks', () => {
                    expect(wrapper.find('AudioPlayer').props().tracks[0].bookmarks.length).toBe(3);
                    expect(wrapper.find('AudioPlayer').props().tracks[1].bookmarks.length).toBe(2);
                    expect(wrapper.find('AudioPlayer').props().tracks[2].bookmarks.length).toBe(0);
                    expect(wrapper.find('AudioPlayer').props().tracks[3].bookmarks.length).toBe(0);
                });

                it('should call formatVoiceDateTimeString with voice created date and pass the result as a prop', () => {
                    expect(formatVoiceDateTimeString).toHaveBeenCalledWith('2019-02-06T16:08:30.802');
                    expect(formatVoiceDateTimeString).toHaveBeenCalledWith('2019-03-06T16:08:30.802');
                    expect(formatVoiceDateTimeString).toHaveBeenCalledWith('2019-04-06T16:08:30.802');
                    expect(formatVoiceDateTimeString).toHaveBeenCalledWith('2019-05-06T16:08:30.802');
                    expect(wrapper.find('AudioPlayer').props().tracks[0].timestamp).toEqual('Wed, Feb 6, 2019 at 4:08PM CST');
                });

                it('sets elapsedTime in state on onSeekTimeline callback', () => {
                    wrapper.find('AudioPlayer').props().onSeekTimeline(0, {
                        time: 5.431877,
                        formattedTime: '0:05',
                        duration: 739.58,
                    });
                    expect(wrapper.instance().state.elapsedTime).toBe(5.431877);
                });

                it('sets elapsedTime in state on onTimeChange callback', () => {
                    wrapper.find('AudioPlayer').props().onTimeChange(0, {
                        time: 5.431877,
                        formattedTime: '0:05',
                        duration: 739.58,
                    });
                    expect(wrapper.instance().state.elapsedTime).toBe(5.431877);
                });

                it('should call the onTrackChange callback when track is changed', () => {
                    wrapper.find('AudioPlayer').props().onTrackChange(2);
                    expect(wrapper.instance().state.audioIndex).toBe(2);
                });

                it('passed the seekTo value from state to seekTo prop', () => {
                    wrapper.setState({seekTo: {track: 0, time: 2.5}});
                    expect(wrapper.find('AudioPlayer').props().seekTo).toEqual({track: 0, time: 2.5});
                });

                it('passed the attachmentsRetrievalFailed prop  into the players hasError', () => {
                    expect(wrapper.find('AudioPlayer').props().hasError).toBe(false);
                });

                it('displays the claimant title when Audio Player is loaded', () => {
                    const newClaimData = {...claimData};
                    newClaimData.liabilitySubjects = [{
                        role: 'CLAIMANT',
                        firstName: 'HOWARD',
                        lastName: 'ELLIOTT',
                        asset: {
                            vehicleYear: '2002',
                            vehicleMake: 'TOYOTA',
                            vehicleModel: 'COROLLA',
                        }
                    }];

                    wrapper.setProps({claimData: newClaimData});
                    expect(wrapper.find('AudioPlayer').props().tracks[1].title).toEqual('Inquiry from LITTLE MAC');
                });

                describe('editVoiceModal', () => {
                    it('should show the close button', () => {
                        wrapper.find('AudioPlayer').simulate('editClick', 0);
                        expect(wrapper.find('ModalDialog').props().showCloseBtn).toBe(true);
                    });

                    it('opens edit voice modal for the correct voiceAttachment and calls trackevent siteCatalyst when pencil icon is clicked', () => {
                        const expectedEvent = {
                            message: 'success',
                            eventAction: 'Investigation_VoiceContainer_EditVoice_Clicked',
                            eventSource: 'button',
                            errorCode: '',
                        };
                        expect(wrapper.find('ModalDialog').props().isActive).toBe(false);
                        wrapper.find('AudioPlayer').simulate('editClick', 0);
                        expect(wrapper.find('ModalDialog').props().isActive).toBe(true);
                        expect(wrapper.instance().state.audioIndex).toEqual(0);
                        expect(wrapper.instance().state.selectedParticipantId).toEqual('SELECT');
                        expect(analyticsHelper.trackEvent).toHaveBeenCalledWith(expectedEvent);
                    });

                    it('should set the selectedParticipantId if one was previously selected for the voiceAttachment', () => {
                        expect(wrapper.find('ModalDialog').props().isActive).toBe(false);
                        wrapper.find('AudioPlayer').simulate('editClick', 1);
                        expect(wrapper.find('ModalDialog').props().isActive).toBe(true);

                        expect(wrapper.instance().state.audioIndex).toEqual(1);
                        expect(wrapper.instance().state.selectedParticipantId).toEqual('ABCDEFG123');
                    });

                    it('should set the selectParticipantId to OTHER if the Other option was previously selected for the voiceAttachment', () => {
                        expect(wrapper.find('ModalDialog').props().isActive).toBe(false);
                        wrapper.find('AudioPlayer').simulate('editClick', 2);
                        expect(wrapper.find('ModalDialog').props().isActive).toBe(true);
                        expect(wrapper.instance().state.audioIndex).toEqual(2);
                        expect(wrapper.instance().state.selectedParticipantId).toEqual('OTHER');
                    });

                    it('should set the selectedCallType if one was previously selected for the voiceAttachment', () => {
                        expect(wrapper.find('ModalDialog').props().isActive).toBe(false);
                        wrapper.find('AudioPlayer').simulate('editClick', 1);
                        expect(wrapper.find('ModalDialog').props().isActive).toBe(true);
                        expect(wrapper.instance().state.audioIndex).toEqual(1);
                        expect(wrapper.instance().state.selectedCallType).toEqual('Inquiry');
                    });

                    it('should set the selectedCallType to Other if some other title is set for the voiceAttachment', () => {
                        const newClaimData = {...claimData};
                        newClaimData.voiceAttachments[1].sourceVoiceTitle = 'fnolText';
                        wrapper = shallow(
                            <VoiceContainer
                                claimData={newClaimData}
                                retrievingAttachments={false}
                                attachmentsRetrievalFailed={false}
                                readOnly={false}
                                saveVoiceParticipant={mockSaveVoiceParticipant}
                            />
                        );

                        expect(wrapper.find('ModalDialog').props().isActive).toBe(false);
                        wrapper.find('AudioPlayer').simulate('editClick', 1);
                        expect(wrapper.find('ModalDialog').props().isActive).toBe(true);
                        expect(wrapper.instance().state.audioIndex).toEqual(1);
                        expect(wrapper.instance().state.selectedCallType).toEqual('Other');
                    });

                    it('opens edit voice modal for the correct voiceAttachment when pencil icon is clicked', () => {
                        expect(wrapper.find('ModalDialog').props().isActive).toBe(false);
                        wrapper.find('AudioPlayer').simulate('editClick', 3);
                        expect(wrapper.find('ModalDialog').props().isActive).toBe(true);
                        expect(wrapper.instance().state.audioIndex).toEqual(3);
                        expect(wrapper.instance().state.selectedParticipantId).toEqual('SELECT');
                    });

                });

                it('Audio player passes trigger play pause callback function', () => {
                    expect(wrapper.find('AudioPlayer').props().triggerPlayPause).toBe(wrapper.instance().triggerPlayPauseCallback);
                });

                it('Audio player passes on play change callback function', () => {
                    expect(wrapper.find('AudioPlayer').props().onPlayChange).toBe(wrapper.instance().onPlayChangeCallback);
                });

                it('scroll and resize event registers adjustTranscriptContainerHeight on mount', () => {
                    wrapper.instance().componentDidMount();
                    expect(window.addEventListener).toBeCalledWith('scroll', wrapper.instance().adjustTranscriptContainerHeight);
                    expect(window.addEventListener).toBeCalledWith('resize', wrapper.instance().adjustTranscriptContainerHeight);
                });

                it('scroll event unregisters adjustTranscriptContainerHeight on unmount', () => {
                    wrapper.instance().componentWillUnmount();
                    expect(window.removeEventListener).toBeCalledWith('scroll', wrapper.instance().adjustTranscriptContainerHeight);
                    expect(window.removeEventListener).toBeCalledWith('resize', wrapper.instance().adjustTranscriptContainerHeight);
                });

                it('adjusts the transcript container height to the window height on scroll and resize', () => {
                    wrapper.instance().getTranscriptContainerPosition = jest.fn().mockReturnValue(3);
                    wrapper.instance().getTranscriptContainerHeight = jest.fn().mockReturnValue('400px');
                    wrapper.instance().adjustTranscriptContainerHeight();
                    expect(wrapper.instance().state.transcriptContentStyle).toEqual({
                        maxHeight: '400px',
                        overflowY: 'auto',
                        scrollBehavior: 'smooth',
                        borderTop: 'solid 1px #d6d6d6',
                    });

                    wrapper.instance().getTranscriptContainerPosition = jest.fn().mockReturnValue(11);
                    wrapper.instance().adjustTranscriptContainerHeight();
                    expect(wrapper.instance().state.transcriptContentStyle).toEqual({
                        maxHeight: '800px',
                        overflowY: 'auto',
                        scrollBehavior: 'smooth',
                        borderTop: 'solid 1px #d6d6d6',
                    });
                });

                it('getTranscriptContainerPosition', () => {
                    expect(wrapper.instance().getTranscriptContainerPosition()).toBe(111);
                });

                it('getTranscriptContainerHeight', () => {
                    expect(wrapper.instance().getTranscriptContainerHeight()).toBe('-386px');
                });

                it('Renders the insured section with AudioPlayer and passes it props', () => {
                    expect(wrapper.find('AudioPlayer').length).toBe(1);
                    expect(wrapper.find('AudioPlayer').props().tracks[0]).toEqual({
                        src: 'voiceUrl',
                        title: 'Inquiry',
                        timestamp: 'Wed, Feb 6, 2019 at 4:08PM CST',
                        bookmarks: [
                            {
                                time: 17.366666666666667,
                                track: 0,
                            },
                            {
                                time: 17.366666666666667,
                                track: 0,
                            },
                            {
                                time: 17.133333333333333,
                                track: 0,
                            },
                        ],
                    });
                });
            });

            describe('and togglePlayPause prop', () => {
                it('sets triggerPlayPause to method passed in as parameter', () => {
                    const expectedMethod = jest.fn();
                    wrapper.instance().triggerPlayPauseCallback(expectedMethod);
                    expect(wrapper.instance().triggerPlayPause).toBe(expectedMethod);
                });
            });

            describe('and onPlayChange prop', () => {
                it('sets audioIndex and audioPlaying state values to same as parameters that are passed in', () => {
                    wrapper.instance().onPlayChangeCallback(1, true);
                    expect(wrapper.instance().state.audioIndex).toBe(1);
                    expect(wrapper.instance().state.audioPlaying).toBe(true);
                });
            });

            describe('and togglePlayPause prop', () => {
                it('sets triggerPlayPause to method passed in as parameter', () => {
                    wrapper.instance().triggerPlayPause = jest.fn();
                    wrapper.instance().togglePlayPause();
                    expect(wrapper.instance().triggerPlayPause).toHaveBeenCalledWith(0);
                });
            });

            describe('AudioPlayer Loader', () => {
                it('should not display Loader when voice attachment has been retrieved', () => {
                    expect(wrapper.find('#audio-player-loader').exists()).toBe(false);
                    expect(wrapper.find('AudioPlayer').exists()).toBe(true);
                });

                it('should not display Loader when voice attachment is being retrieved', () => {
                    wrapper.setProps({retrievingAttachments: true});
                    expect(wrapper.find('#audio-player-loader').exists()).toBe(true);
                    expect(wrapper.find('AudioPlayer').exists()).toBe(false);
                });
            });
        });

        describe('TranscriptSection component', () => {
            it('should render', () => {
                expect(wrapper.find('withRouter(Connect(TranscriptSection))').props().claimNumber).toBe('123');
                expect(wrapper.find('withRouter(Connect(TranscriptSection))').props().audioPlaying).toBe(false);
                expect(wrapper.find('withRouter(Connect(TranscriptSection))').props().audioIndex).toBe(0);
                expect(wrapper.find('withRouter(Connect(TranscriptSection))').props().elapsedTime).toBe(0.00);
                expect(wrapper.find('withRouter(Connect(TranscriptSection))').props().togglePlayPause).toBe(wrapper.instance().togglePlayPause);
                expect(wrapper.find('withRouter(Connect(TranscriptSection))').props().transcriptContentStyle).toEqual({
                    maxHeight: '800px',
                    overflowY: 'auto',
                    scrollBehavior: 'smooth',
                    borderTop: 'solid 1px #d6d6d6',
                });
                expect(wrapper.find('withRouter(Connect(TranscriptSection))').props().readOnly).toBe(false);
            });

            it('should update state when setSeekTo prop is invoked', () => {
                wrapper.find('withRouter(Connect(TranscriptSection))').simulate('setSeekTo', 1);
                expect(wrapper.find('AudioPlayer').props().seekTo).toEqual({track: 0, time: 1});
                expect(wrapper.find('withRouter(Connect(TranscriptSection))').props().audioPlaying).toBe(true);
            });

            it('should render Transcript Section as read only when in read only mode', () => {
                wrapper.setProps({readOnly: true});
                expect(wrapper.find('withRouter(Connect(TranscriptSection))').props().readOnly).toBe(true);
            });
        });

        describe('Edit Recording Modal', () => {
            describe('Recording Participant Dropdown', () => {
                it('should render a dropdown for Recording Participant with correct props and label', () => {
                    expect(wrapper.find('#recording-participant-label').text()).toEqual('Recording Participant');
                    let dropdown = wrapper.find('CustomDropdown').filter('#recordingParticipantDropdown');

                    let expectedItems = [
                        {value: 'abcd', label: 'HOWARD ELLIOTT', disabled: false},
                        {value: 'efgh', label: 'Saira Chirayil', disabled: false},
                        {value: 'wxyz', label: 'MORTON GROVE TOWING COMPANY', disabled: false},
                        {value: 'OTHER', label: 'Other', disabled: false}
                    ];

                    expect(dropdown.exists()).toBe(true);
                    expect(dropdown.props().hasError).toBe(false);
                    expect(dropdown.props().errorText).toBe('Please choose a participant');
                    expect(dropdown.props().items).toEqual(expectedItems);
                    expect(dropdown.props().readonly).toEqual(false);
                });

                it('should render a dropdown for Recording Participant with correct props in readOnlyMode', () => {
                    wrapper.setProps({readOnly: true});

                    let dropdown = wrapper.find('CustomDropdown').filter('#recordingParticipantDropdown');

                    let expectedItems = [
                        {value: 'abcd', label: 'HOWARD ELLIOTT', disabled: true},
                        {value: 'efgh', label: 'Saira Chirayil', disabled: true},
                        {value: 'wxyz', label: 'MORTON GROVE TOWING COMPANY', disabled: true},
                        {value: 'OTHER', label: 'Other', disabled: true}
                    ];

                    expect(dropdown.exists()).toBe(true);
                    expect(dropdown.props().hasError).toBe(false);
                    expect(dropdown.props().errorText).toBe('Please choose a participant');
                    expect(dropdown.props().items).toEqual(expectedItems);
                    expect(dropdown.props().readonly).toEqual(true);
                });

                it('should set the value of the dropdown when option is selected', () => {
                    let dropdown = wrapper.find('CustomDropdown').filter('#recordingParticipantDropdown');
                    dropdown.simulate('select', {value: 'abcd'});

                    let updatedDropdown = wrapper.find('CustomDropdown').filter('#recordingParticipantDropdown');
                    expect(updatedDropdown.props().initialSelectedItem.value).toBe('abcd');
                });

                it('should set the value of the dropdown when the Other option is selected', () => {
                    const dropdown = wrapper.find('CustomDropdown').filter('#recordingParticipantDropdown');
                    dropdown.simulate('select', {value: 'OTHER'});

                    const updatedDropdown = wrapper.find('CustomDropdown').filter('#recordingParticipantDropdown');
                    expect(updatedDropdown.props().initialSelectedItem.value).toBe('OTHER');
                    expect(wrapper.instance().state.selectedParticipantId).toBe('OTHER');
                });
            });

            describe('Call Type Dropdown', () => {
                it('should render a dropdown for Call Type with correct props', () => {
                    expect(wrapper.find('#callType-dropdown-label').text()).toEqual('Call Type');

                    let dropdown = wrapper.find('CustomDropdown').filter('#callTypeDropdown');
                    let expectedItems = [
                        {label: 'FNOL', value: 'FNOL', disabled: false},
                        {label: 'Inquiry', value: 'Inquiry', disabled: false},
                        {label: 'Loss Investigation', value: 'Loss Investigation', disabled: false},
                        {label: 'Attempted Contact', value: 'Attempted Contact', disabled: false},
                        {label: 'Settlement', value: 'Settlement', disabled: false},
                        {label: 'Vendor/Provider Contact', value: 'Vendor/Provider Contact', disabled: false},
                        {label: 'Other', value: 'Other', disabled: false},
                    ];

                    expect(dropdown.exists()).toBe(true);
                    expect(dropdown.props().items).toEqual(expectedItems);
                    expect(dropdown.props().readonly).toEqual(false);
                });

                it('should render a dropdown for Call Type with correct props in readonly mode', () => {
                    wrapper.setProps({readOnly: true});
                    let dropdown = wrapper.find('CustomDropdown').filter('#callTypeDropdown');

                    let expectedItems = [
                        {label: 'FNOL', value: 'FNOL', disabled: true},
                        {label: 'Inquiry', value: 'Inquiry', disabled: true},
                        {label: 'Loss Investigation', value: 'Loss Investigation', disabled: true},
                        {label: 'Attempted Contact', value: 'Attempted Contact', disabled: true},
                        {label: 'Settlement', value: 'Settlement', disabled: true},
                        {label: 'Vendor/Provider Contact', value: 'Vendor/Provider Contact', disabled: true},
                        {label: 'Other', value: 'Other', disabled: true},
                    ];

                    expect(dropdown.exists()).toBe(true);
                    expect(dropdown.props().items).toEqual(expectedItems);
                    expect(dropdown.props().readonly).toEqual(true);
                });

                it('should set the value of the dropdown when option is selected', () => {
                    let dropdown = wrapper.find('CustomDropdown').filter('#callTypeDropdown');
                    dropdown.simulate('select', {value: 'abcd'});

                    let updatedDropdown = wrapper.find('CustomDropdown').filter('#callTypeDropdown');
                    expect(updatedDropdown.props().initialSelectedItem.value).toBe('abcd');
                });
            });

            it('closes edit voice modal without updating when Cancel button is clicked', () => {
                wrapper.find('AudioPlayer').simulate('editClick', 0); // click on pencil icon
                const participantDropdown = wrapper.find('CustomDropdown').filter('#recordingParticipantDropdown');
                const callTypeDropdown = wrapper.find('CustomDropdown').filter('#callTypeDropdown');
                let modalFooter = shallow(wrapper.find('ModalDialog').props().footer);
                modalFooter.find('button').at(0).simulate('click'); //click on save, get error state
                participantDropdown.simulate('select', {value: 'abcd'}); //change dropdown
                callTypeDropdown.simulate('select', {value: 'abcd'}); //change dropdown
                modalFooter.find('button').at(1).simulate('click'); //click cancel

                const updatedParticipantDropdown = wrapper.find('CustomDropdown').filter('#recordingParticipantDropdown');
                const updatedCallTypeDropdown = wrapper.find('CustomDropdown').filter('#callTypeDropdown');
                expect(wrapper.find('ModalDialog').props().isActive).toBe(false);
                expect(updatedParticipantDropdown.props().hasError).toBe(false);
                expect(updatedParticipantDropdown.props().initialSelectedItem.value).toBe('SELECT');
                expect(updatedCallTypeDropdown.props().initialSelectedItem.value).toBe('Other');
            });

            it('should render Save button as enabled when not in read only mode', () => {
                expect(wrapper.find('ModalDialog').props().footer.props.children[0].props.children.props.disabled).toBe(false);
            });

            it('should render Save button as disabled when in read only mode', () => {
                wrapper.setProps({readOnly: true});

                expect(wrapper.find('ModalDialog').props().footer.props.children[0].props.children.props.disabled).toBe(true);
            });

            it('should set error state on RecordingParticipant dropdown when Save is clicked', () => {
                let modalFooter = shallow(wrapper.find('ModalDialog').props().footer);
                modalFooter.find('button').at(0).simulate('click');
                let dropdown = wrapper.find('CustomDropdown').filter('#recordingParticipantDropdown');

                expect(dropdown.props().hasError).toBe(true);
            });

            it('should clear out dropdown error when error is present and option is selected from participant list', () => {
                let modalFooter = shallow(wrapper.find('ModalDialog').props().footer);
                modalFooter.find('button').at(0).simulate('click');
                let dropdown = wrapper.find('CustomDropdown').filter('#recordingParticipantDropdown');
                dropdown.simulate('select', {value: 'abcd'});

                let updatedDropdown = wrapper.find('CustomDropdown').filter('#recordingParticipantDropdown');
                expect(updatedDropdown.props().hasError).toBe(false);
            });

            it('should not clear out dropdown error when error is present and option stays as Select', () => {
                let modalFooter = shallow(wrapper.find('ModalDialog').props().footer);
                modalFooter.find('button').at(0).simulate('click');
                let dropdown = wrapper.find('CustomDropdown').filter('#recordingParticipantDropdown');
                dropdown.simulate('select', {value: 'SELECT'});

                let updatedDropdown = wrapper.find('CustomDropdown').filter('#recordingParticipantDropdown');
                expect(updatedDropdown.props().hasError).toBe(true);
            });

            it('should not have dropdown error when error is not present and option changes to SELECT', () => {
                let modalFooter = shallow(wrapper.find('ModalDialog').props().footer);
                let dropdown = wrapper.find('CustomDropdown').filter('#recordingParticipantDropdown');

                dropdown.simulate('select', {value: 'abcd'});
                dropdown.simulate('select', 'SELECT');

                let updatedDropdown = wrapper.find('CustomDropdown').filter('#recordingParticipantDropdown');
                modalFooter.find('button').at(0).simulate('click');

                expect(updatedDropdown.props().hasError).toBe(false);
            });

            it('should dispatch save voice action when participant selected and Save is clicked', () => {
                wrapper.setState({
                    showEditModal: true,
                    audioIndex: 1,
                    selectedParticipantId: 'SELECT',
                    selectedCallType: 'Other',
                });
                let modalFooter = shallow(wrapper.find('ModalDialog').props().footer);
                let dropdown1 = wrapper.find('ModalDialog').find('CustomDropdown').filter('#recordingParticipantDropdown');
                let dropdown2 = wrapper.find('ModalDialog').find('CustomDropdown').filter('#callTypeDropdown');
                dropdown1.simulate('select', {value: 'abcd'});
                dropdown2.simulate('select', {value: 'abcd'});
                modalFooter.find('button').at(0).simulate('click');

                let updatedDropdown1 = wrapper.find('CustomDropdown').filter('#recordingParticipantDropdown');
                let updatedDropdown2 = wrapper.find('CustomDropdown').filter('#callTypeDropdown');
                expect(mockSaveVoiceParticipant).toBeCalledWith('123', 1, 'abcd', 'abcd');
                expect(wrapper.find('ModalDialog').props().isActive).toBe(false);
                expect(updatedDropdown1.props().hasError).toBe(false);
                expect(updatedDropdown1.props().initialSelectedItem.value).toBe('SELECT');
                expect(updatedDropdown2.props().initialSelectedItem.value).toBe('Other');
            });

            it('should pass participantDisplayName as label in initialSelectedItem on load', () => {
                wrapper.instance().setState({audioIndex: 1});

                expect(wrapper.find('#recordingParticipantDropdown').props().initialSelectedItem.label).toBe('LITTLE MAC');
            });
        });
    });

    describe('Connect helper', () => {
        it('maps required store items to props', () => {
            const claimData = {claimNumber: '1234', locked: true};
            const status = {retrievingAttachments: true, attachmentsRetrievalFailed: true};
            const user = {userRoles: ['Loon Read Only User']};
            const state = {claimData, status, user};

            const result = mapStateToProps(state);
            expect(result.claimData).toEqual(claimData);
            expect(result.retrievingAttachments).toEqual(true);
            expect(result.attachmentsRetrievalFailed).toEqual(true);
            expect(result.readOnly).toEqual(true);
        });

        it('maps dispatch to Props', () => {
            expect(mapDispatchToProps.saveVoiceParticipant).toEqual(saveVoiceParticipantAction);
        });
    });
});
