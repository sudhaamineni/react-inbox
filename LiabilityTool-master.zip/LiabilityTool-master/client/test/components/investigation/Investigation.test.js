jest.unmock('../../../src/main/components/investigation/Investigation');

import React from 'react';
import {shallow} from 'enzyme';
import {Investigation, mapStateToProps, mapDispatchToProps } from '../../../src/main/components/investigation/Investigation';
import {getQueryStringValue} from '../../../src/main/helpers/claimDataHelper';
import analyticsHelper from '../../../src/main/helpers/analyticsHelper';
import {evidenceModalErrorAction, showEvidenceModalAction} from '../../../src/main/actions/evidenceActions';
describe('InvestigationPage ', () => {
    let wrapper;
    let mockHistory;
    let mockShowEvidenceModalAction, mockEvidenceModalErrorAction;

    beforeEach(() => {
        mockHistory = { block: jest.fn().mockReturnValue(true) };
        window.scrollTo = jest.fn();
        mockShowEvidenceModalAction = jest.fn();
        mockEvidenceModalErrorAction = jest.fn();

        wrapper = shallow(
            <Investigation
                claimNumber={'123'}
                scrollTo={''}
                history={mockHistory}
                showEvidenceModalAction={mockShowEvidenceModalAction}
                evidenceModalErrorAction={mockEvidenceModalErrorAction}
            />
        );
    });

    it('should render GoogleMapContainer', () => {
        expect(wrapper.find('Connect(GoogleMapContainer)').exists()).toBe(true);
    });

    it('should render VoiceContainer', () => {
        expect(wrapper.find('Connect(VoiceContainer)').length).toBe(1);
    });

    describe('life cycle methods are called', () => {
        describe('componentDidUpdate', () => {
            it('scrolls if scrollTo is available as a prop', () => {
                window.pageYOffset = 100;
                document.getElementById = jest.fn().mockReturnValue({
                    getBoundingClientRect: jest.fn().mockReturnValue({top: 200})
                });
                wrapper.instance().shouldScroll = true;
                wrapper.setProps({scrollTo: 'someId'});

                expect(window.scrollTo).toBeCalledWith(0, 245);
            });

            it('scrolls if scrollTo is available as a prop with smooth behavior', () => {
                window.pageYOffset = 100;
                document.documentElement.style.scrollBehavior = 'smooth';
                document.getElementById = jest.fn().mockReturnValue({
                    getBoundingClientRect: jest.fn().mockReturnValue({top: 200})
                });
                wrapper.instance().shouldScroll = true;
                wrapper.setProps({scrollTo: 'someId'});

                expect(window.scrollTo).toBeCalledWith({top: 245, behavior: 'smooth'});
            });

            it('should only scroll once per page render', () => {
                window.pageYOffset = 100;
                document.documentElement.style.scrollBehavior = 'smooth';
                document.getElementById = jest.fn().mockReturnValue({
                    getBoundingClientRect: jest.fn().mockReturnValue({top: 200})
                });
                wrapper.instance().shouldScroll = true;
                wrapper.setProps({scrollTo: 'someId'});

                expect(window.scrollTo).toBeCalledWith({top: 245, behavior: 'smooth'});
                window.scrollTo.mockReset();
                wrapper.instance().componentDidUpdate();
                expect(window.scrollTo).not.toHaveBeenCalled();
            });

            it('does not scroll if scrollTo is not available as a prop', () => {
                wrapper.instance().shouldScroll = true;
                wrapper.setProps({scrollTo: undefined});

                expect(window.scrollTo).not.toBeCalled();
            });

            it('does not scroll if scrollTo id is not available', () => {
                document.getElementById = jest.fn().mockReturnValue(null);
                wrapper.instance().shouldScroll = true;
                wrapper.setProps({scrollTo: 'someId'});

                expect(window.scrollTo).not.toBeCalled();
            });
        });

        describe('componentDidMount', () => {
            it('should set unblock to the return value of history block method', () => {
                wrapper.instance().unblock = undefined;
                wrapper.instance().componentDidMount();
                expect(wrapper.instance().unblock).toBe(true);
            });

            it('should set unblock to the return value of history block method', () => {
                mockHistory = { block: jest.fn().mockReturnValue(false) };
                wrapper.setProps({history: mockHistory});

                wrapper.instance().unblock = undefined;
                wrapper.instance().componentDidMount();
                expect(wrapper.instance().unblock).toBe(false);
            });

            it('should call history block method with historyBlockCallback as parameter', () => {
                jest.clearAllMocks();

                wrapper.instance().componentDidMount();
                expect(mockHistory.block).toBeCalledWith(wrapper.instance().historyBlockCallback);
            });

            describe('historyBlockCallback', () => {
                it('should return true when target route is not initial fault', () => {
                    expect(wrapper.instance().historyBlockCallback({ pathname: '/not-initial-fault' })).toBe(true);
                    expect(mockShowEvidenceModalAction).not.toBeCalled();
                    expect(mockEvidenceModalErrorAction).not.toBeCalled();
                });

                it('should return true when target route is initial-fault and evidence list is empty', () => {
                    wrapper.setProps({evidences: []});
                    expect(wrapper.instance().historyBlockCallback({ pathname: '/initial-fault' })).toBe(true);
                    expect(mockShowEvidenceModalAction).not.toBeCalled();
                    expect(mockEvidenceModalErrorAction).not.toBeCalled();
                });

                it('should return true when target route is initial-fault and all evidences has category', () => {
                    wrapper.setProps({evidences: [{id:1, category: "my category"}]});
                    expect(wrapper.instance().historyBlockCallback({ pathname: '/initial-fault' })).toBe(true);
                    expect(mockShowEvidenceModalAction).not.toBeCalled();
                    expect(mockEvidenceModalErrorAction).not.toBeCalled();
                });

                it('should return false and invoke showEvidenceModalAction with true' +
                    ' when target route is initial-fault and evidence category is not valid', () => {
                    const invalidCategories = ['', undefined, null];

                    invalidCategories.forEach(invalidCategory => {
                        wrapper.setProps({evidences: [{id:1, category: invalidCategory}]});
                        expect(wrapper.instance().historyBlockCallback({ pathname: '/initial-fault' })).toBe(false);
                        expect(mockShowEvidenceModalAction).toBeCalledWith(true);
                        expect(mockEvidenceModalErrorAction).toBeCalledWith(true);
                    });
                });
            });

        });
        describe('componentWillUnmount', () => {
            it('should call unblock function', () => {
                wrapper.instance().unblock = jest.fn();
                wrapper.instance().componentWillUnmount();
                expect(wrapper.instance().unblock).toBeCalled();
            });
        });
    });

    describe('Connect helper', () => {
        const claimData = {claimNumber: '123', evidences: [{id: 1, category: 'myCategory'}]};
        const state = {claimData};
        const router = {
            location: {search: '?a=b&c=d&scrollTo=someId'},
        };

        it('maps required store items to props', () => {
            getQueryStringValue.mockReturnValue('someId');

            const result = mapStateToProps(state, router);
            expect(result.claimNumber).toEqual('123');
            expect(result.evidences).toEqual([{id: 1, category: 'myCategory'}]);
            expect(result.scrollTo).toEqual('someId');
        });

        it('maps dispatch to props', () => {
            expect(mapDispatchToProps.showEvidenceModalAction).toEqual(showEvidenceModalAction);
            expect(mapDispatchToProps.evidenceModalErrorAction).toEqual(evidenceModalErrorAction);
        });
    });

    describe('when page loads', () => {
        it('should have the title as Loon - {claimNumber} when claim number is available', () => {
            wrapper.setProps({claimNumber: '000123456789'});
            wrapper.instance().componentDidMount();
            expect(document.title).toEqual('Loon - 123456789');
        });

        it('should have the title as Loon - {claimNumber} when claim number is not available', () => {
            wrapper.setProps({claimNumber: ''});
            wrapper.instance().componentDidMount();
            expect(document.title).toEqual('Loon -');
        });

        it('tracks page using SiteCatalyst', () => {
            analyticsHelper.trackPage.mockReset();
            wrapper.instance().componentDidMount();
            expect(analyticsHelper.trackPage).toHaveBeenCalledWith('claims/loon/investigationPage')
        });
    });

    it('should render ParticipantAssetDamages', () => {
        expect(wrapper.find('withRouter(Connect(ParticipantAssetDamages))').exists()).toBe(true);
    });
});