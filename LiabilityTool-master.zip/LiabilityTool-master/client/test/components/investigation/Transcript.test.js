jest.unmock('../../../src/main/components/investigation/Transcript');
jest.unmock('../../../src/main/constants/loonConstants');

import React from 'react';
import {shallow} from 'enzyme';
import deepFreeze from 'deep-freeze';
import {mapDispatchToProps, mapStateToProps, Transcript} from '../../../src/main/components/investigation/Transcript';
import {saveHighlightAction} from '../../../src/main/actions/transcriptActions';
import {saveEvidenceAction} from '../../../src/main/actions/attachmentsActions';
import {createId, getCallTypeLabel} from '../../../src/main/helpers/claimDataHelper';

describe('Given Transcript component', () => {
    let wrapper;

    const mockSetSeekTo = jest.fn(),
        mockTranscripts = {
            voiceId: [{
                beginTime: 5.5,
                endTime: 9,
                speaker: 'Customer12345678',
                text: 'This is chunk0.'
            }, {
                beginTime: 15.5,
                endTime: 19,
                speaker: 'Allstate',
                text: 'This is chunk1.'
            }, {
                beginTime: 25.5,
                endTime: 29,
                speaker: 'Allstate',
                text: 'This is chunk2.'
            }, {
                beginTime: 35.5,
                endTime: 39,
                speaker: 'Allstate',
                text: 'This is chunk3.'
            }]
        },
        mockTogglePlayPause = jest.fn(),
        mockEvent = {
            target: {id: 'id'},
            pageX: 10,
            pageY: 5,
            preventDefault: jest.fn()
        },
        mockVoiceAttachments = [{
            sourceVoiceId: 'voiceId',
            sourceTranscriptUrl: 'transcriptUrl',
            createdDate: '2019-03-08T14:26:41',
            participantDisplayName: 'JOE BOB',
            participantSourceId: '1',
            sourceVoiceTitle: 'FNOL',
            highlightEntities: [
                {
                    id: 'highlightId1',
                    highlightTexts: [
                        {
                            speaker: 'Allstate',
                            chunkIndex: 1,
                            beginIndex: 8,
                            endIndex: 15,
                            text: 'middle'
                        }
                    ]
                },
                {
                    id: 'highlightId2',
                    highlightTexts: [
                        {
                            speaker: 'Allstate',
                            chunkIndex: 2,
                            beginIndex: 0,
                            endIndex: 6,
                            text: 'end'
                        },
                    ]
                },
            ]
        }],
        mockEvidences = [
            {
                id: 'evidenceId1',
                sourceId: 'highlightId1',
                type: 'highlight',
                category: 'loss-address',
                sourceVoiceId: 'voiceId',
                participantDisplayName: 'JOE BOB',
                participantSourceId: '1',
                callType: 'my call type',
                transcriptCreatedDate: '2019-03-08T14:26:41',
                highlightTexts: [
                    {
                        speaker: 'Allstate',
                        chunkIndex: 3,
                        beginIndex: 0,
                        endIndex: 4,
                        text: 'This'
                    },
                ]
            },
            {id: 'evidenceId2', sourceId: 'photoId', type: 'photo'},
            {
                id: 'evidenceId3',
                sourceId: 'highlightId2',
                type: 'highlight',
                sourceVoiceId: 'voiceId',
                participantDisplayName: 'JOE BOB',
                participantSourceId: '1',
                callType: 'my call type',
                transcriptCreatedDate: '2019-03-08T14:26:41',
                highlightTexts: [
                    {
                        speaker: 'Allstate',
                        chunkIndex: 2,
                        beginIndex: 0,
                        endIndex: 6,
                        text: 'end'
                    },
                ]
            }
        ],
        mockSaveEvidenceAction = jest.fn(),
        mockSaveHighlightAction = jest.fn(),
        mockSelectionRemoveRanges = jest.fn();

    deepFreeze(mockVoiceAttachments);
    deepFreeze(mockEvidences);
    getCallTypeLabel.mockReturnValue('my call type');
    createId.mockImplementation(type => (type + 'Id'));
    let involvedParty = {
        participantId: '1',
        participantSourceId: '11',
        assetId: 'asset1',
        damageSections: [
            'front',
            'rear'
        ],
        contributingFactors: [
            {
                category: null,
                reason: 'proper-lookout',
                details: 'saw-other-party',
                evidenceIds: ['evidenceId1', 'evidenceId3','evidence5']
            }
        ],
        affectedParties: [
            {
                participantId: '2',
                participantSourceId: '22',
                assetId: 'B9763FCB7D843B1F',
                passengerPartyIds: [],
                affectedPercent: 12,
                beginNegotiatingRange: 7,
                endNegotiatingRange: 17,
                submittedAffectedPercent: 12,
                faultAllocationPercent: 1
            }
        ]
    };
    const event =
        {id: '0', title: 'my first event title', severity: 1, involvedParties: [involvedParty]};
    const events = [event];

    beforeEach(() => {
        window.addEventListener = jest.fn();
        window.removeEventListener = jest.fn();
        window.getSelection = jest.fn().mockReturnValue({
            toString: () => '',
            removeAllRanges: mockSelectionRemoveRanges
        });
        document.getElementById = jest.fn().mockReturnValue({
            getBoundingClientRect: jest.fn().mockReturnValue({top: 0, left: 0, height: 0}),
            style: {},
            children: [{id: 'chunk0-text0'}],
        });
        document.getElementsByClassName = jest.fn().mockReturnValue([{
            style: {top: '1111px', left: '222px'},
        }]);

        wrapper = shallow(
            <Transcript
                claimNumber="123456789000"
                audioPlaying={false}
                audioIndex={0}
                elapsedTime={5.51234}
                togglePlayPause={mockTogglePlayPause}
                onSetSeekTo={mockSetSeekTo}
                autoScroll={true}
                highlightMode={true}
                nlpCategory="Category"
                nlpCategoryIndex={0}
                voiceAttachments={mockVoiceAttachments}
                evidences={mockEvidences}
                transcripts={mockTranscripts}
                saveHighlightAction={mockSaveHighlightAction}
                saveEvidenceAction={mockSaveEvidenceAction}
                events={events}
            />
        );
    });

    describe('on load', () => {
        it('defaults lastProcessId to be 0', () => {
            expect(wrapper.instance().lastProcessId).toBe(0);
        });

        it('should default state values', () => {
            expect(wrapper.instance().state.evidenceMenu).toEqual({});
        });

        it('renders chunks', () => {
            expect(wrapper.find('Chunk').length).toBe(4);

            expect(wrapper.find('Chunk').get(0).props.id).toBe(0);
            expect(wrapper.find('Chunk').get(0).props.chunk).toBe(mockTranscripts.voiceId[0]);
            expect(wrapper.find('Chunk').get(0).props.elapsedTime).toBe(5.51234);
            expect(wrapper.find('Chunk').get(0).props.autoScroll).toBe(true);
            expect(wrapper.find('Chunk').get(0).props.highlightMode).toBe(true);
            expect(wrapper.find('Chunk').get(0).props.nlpCategory).toBe('Category');
            expect(wrapper.find('Chunk').get(0).props.nlpCategoryIndex).toBe(0);

            expect(wrapper.find('Chunk').get(1).props.id).toBe(1);
            expect(wrapper.find('Chunk').get(1).props.chunk).toBe(mockTranscripts.voiceId[1]);
            expect(wrapper.find('Chunk').get(1).props.elapsedTime).toBe(5.51234);
            expect(wrapper.find('Chunk').get(1).props.autoScroll).toBe(true);
            expect(wrapper.find('Chunk').get(1).props.highlightMode).toBe(true);
            expect(wrapper.find('Chunk').get(1).props.nlpCategory).toBe('Category');
            expect(wrapper.find('Chunk').get(1).props.nlpCategoryIndex).toBe(0);

            expect(wrapper.find('Chunk').get(2).props.id).toBe(2);
            expect(wrapper.find('Chunk').get(2).props.chunk).toBe(mockTranscripts.voiceId[2]);
            expect(wrapper.find('Chunk').get(2).props.elapsedTime).toBe(5.51234);
            expect(wrapper.find('Chunk').get(2).props.autoScroll).toBe(true);
            expect(wrapper.find('Chunk').get(2).props.highlightMode).toBe(true);
            expect(wrapper.find('Chunk').get(2).props.nlpCategory).toBe('Category');
            expect(wrapper.find('Chunk').get(2).props.nlpCategoryIndex).toBe(0);

            expect(wrapper.find('Chunk').get(3).props.id).toBe(3);
            expect(wrapper.find('Chunk').get(3).props.chunk).toBe(mockTranscripts.voiceId[3]);
            expect(wrapper.find('Chunk').get(3).props.elapsedTime).toBe(5.51234);
            expect(wrapper.find('Chunk').get(3).props.autoScroll).toBe(true);
            expect(wrapper.find('Chunk').get(3).props.highlightMode).toBe(true);
            expect(wrapper.find('Chunk').get(3).props.nlpCategory).toBe('Category');
            expect(wrapper.find('Chunk').get(3).props.nlpCategoryIndex).toBe(0);
        });
    });

    describe('speaker labels', () => {
        it('renders speakers', () => {
            expect(wrapper.find('.speaker').length).toEqual(4);
        });

        it('sets the className of speakers to chunk-highlight-default when highlightMode is on ', () => {
            expect(wrapper.find('.speaker').get(0).props.className).toContain('chunk-highlight-default');
        });

        it('sets the id of speakers to speaker-chunk when rendering ', () => {
            expect(wrapper.find('.speaker').get(0).props.id).toContain('chunk0-speaker');
            expect(wrapper.find('.speaker').get(1).props.id).toContain('chunk1-speaker');
        });

        it('sets the cursorClassName to empty string when highlightMode is off ', () => {
            wrapper.setProps({highlightMode: false});
            expect(wrapper.find('.speaker').get(0).props.className).not.toContain('chunk-highlight-default');
        });

        it('displays the paragraph start times in M:SS format', () => {
            expect(wrapper.find('#chunk0-begin-time').props().children).toEqual('0:05');
            expect(wrapper.find('#chunk1-begin-time').props().children).toEqual('0:15');
        });

        it('sets the className of the speaker to follow along color when the one of the chunks for the speaker is being played', () => {
            expect(wrapper.find('.speaker').get(0).props.className).toContain('u-text-light-blue');
            expect(wrapper.find('.speaker').get(0).props.className).toContain('u-text-bold');
        });

        it('sets the className of the speaker to non follow along color when the one of the chunks for the speaker is not being played', () => {
            expect(wrapper.find('.speaker').get(1).props.className).toContain('u-text-gray-lighter');
        });

        it('display full speaker name if length is less than 14', () => {
            mockTranscripts.voiceId[0].speaker = 'Customer12345';
            wrapper.setProps({chunks: mockTranscripts.voiceId});
            expect(wrapper.find('.speaker').get(0).props.children).toEqual('Customer12345');

        });

        it('displays full speaker name if length is exactly 14', () => {
            mockTranscripts.voiceId[0].speaker = 'Customer123456';
            wrapper.setProps({chunks: mockTranscripts.voiceId});
            expect(wrapper.find('.speaker').get(0).props.children).toEqual('Customer123456');
        });

        it('displays first twelve characters of speaker name and two dots if length is greater than 14', () => {
            mockTranscripts.voiceId[0].speaker = 'Customer12345678';
            wrapper.setProps({chunks: mockTranscripts.voiceId});
            expect(wrapper.find('.speaker').get(0).props.children).toEqual('Customer1234..');
        });
    });

    describe('audio follow along', () => {
        it('sets the color of audio start time to u-text-gray-lighter when chunk is not being played ', () => {
            expect(wrapper.find('#chunk0-begin-time').props().className.includes('u-text-light-blue')).toBe(true);
            expect(wrapper.find('#chunk1-begin-time').props().className.includes('u-text-gray-lighter')).toBe(true);

            expect(wrapper.find('#chunk0-begin-time').props().className.includes('u-text-gray-lighter')).toBe(false);
            expect(wrapper.find('#chunk1-begin-time').props().className.includes('u-text-light-blue')).toBe(false);

            wrapper.setProps({elapsedTime: 15.51234});

            expect(wrapper.find('#chunk0-begin-time').props().className.includes('u-text-gray-lighter')).toBe(true);
            expect(wrapper.find('#chunk1-begin-time').props().className.includes('u-text-light-blue')).toBe(true);
            expect(wrapper.find('#chunk0-begin-time').props().className.includes('u-text-light-blue')).toBe(false);
            expect(wrapper.find('#chunk1-begin-time').props().className.includes('u-text-gray-lighter')).toBe(false);
        });

        it('calls onSetSeekTo with time', () => {
            const mockElement = {
                time: '1:20'
            };
            mockSetSeekTo.mockReturnValue(mockElement);
            wrapper.find('Chunk').at(0).simulate('setSeekTo', mockElement);
            expect(mockSetSeekTo).toBeCalledWith(mockElement);
        });
    });

    describe('Bars component', () => {
        it('does not render when elapsedTime is 0.00', () => {
            wrapper.setProps({elapsedTime: 0.00});
            expect(wrapper.find('Bars').exists()).toBe(false);
        });

        it('renders in animated state for the chunk where elapsedTime is within its beginTime and endTime and audioPlaying is true', () => {
            wrapper.setProps({audioPlaying: true});
            expect(wrapper.find('Bars').length).toBe(1);
            expect(wrapper.find('Bars').at(0).props().isPlaying).toBe(true);
        });

        it('renders in unanimated state for the chunk where elapsedTime is within its beginTime and endTime and audioPlaying is false', () => {
            expect(wrapper.find('Bars').length).toBe(1);
            expect(wrapper.find('Bars').at(0).props().isPlaying).toBe(false);
        });
    });

    describe('Highlighting', () => {
        it('sets highlightMode prop on chunks', () => {
            expect(wrapper.find('Chunk').get(0).props.highlightMode).toBe(true);
            expect(wrapper.find('Chunk').get(1).props.highlightMode).toBe(true);
        });

        it('invokes handleMouseUp when onMouseUp prop is called', () => {
            wrapper.instance().handleMouseUp = jest.fn();
            wrapper.find('#transcript-container').props().onMouseUp();
            expect(wrapper.instance().handleMouseUp).toBeCalled();
        });

        describe('Mouse up scenarios', () => {
            describe('handleMouseUp scenarios', () => {
                it('calls addHighlight', () => {
                    window.getSelection.mockReturnValue({
                        toString: () => 'asdf',
                        anchorNode: {
                            parentNode: {
                                id: 'chunk0-text0'
                            },
                            compareDocumentPosition: jest.fn().mockReturnValue(0)
                        },
                        focusNode: {
                            parentNode: {
                                id: 'chunk0-text0'
                            }
                        },
                        removeAllRanges: mockSelectionRemoveRanges
                    });
                    document.getElementById.mockReturnValue({
                        children: [{
                            id: 'chunk0-text0'
                        }],
                        innerText: {
                            length: 0
                        },
                        style: {
                            visibility: ''
                        }
                    });
                    wrapper.setProps({highlightMode: true});

                    wrapper.instance().addHighlight = jest.fn();
                    wrapper.instance().handleMouseUp(mockEvent);
                    expect(wrapper.instance().addHighlight).toBeCalled();
                    expect(mockSelectionRemoveRanges).toBeCalled();
                });

                it('does not call addHighlight when highlightMode is false', () => {
                    window.getSelection.mockReturnValue({
                        toString: () => 'asdf',
                        anchorNode: {
                            parentNode: {
                                id: 'chunk0-text0'
                            },
                            compareDocumentPosition: jest.fn().mockReturnValue(0)
                        },
                        focusNode: {
                            parentNode: {
                                id: 'chunk0-text0'
                            }
                        },
                        removeAllRanges: mockSelectionRemoveRanges
                    });
                    wrapper.setProps({highlightMode: false});

                    wrapper.instance().addHighlight = jest.fn();
                    wrapper.instance().handleMouseUp(mockEvent);
                    expect(wrapper.instance().addHighlight).not.toBeCalled();
                });

                it('does not call addHighlight when window selection is empty', () => {
                    window.getSelection.mockReturnValue({
                        toString: () => '',
                        anchorNode: {
                            parentNode: {
                                id: 'chunk0-text0'
                            },
                            compareDocumentPosition: jest.fn().mockReturnValue(0)
                        },
                        focusNode: {
                            parentNode: {
                                id: 'chunk0-text0'
                            }
                        },
                        removeAllRanges: mockSelectionRemoveRanges
                    });
                    wrapper.setProps({highlightMode: true});

                    wrapper.instance().addHighlight = jest.fn();
                    wrapper.instance().handleMouseUp(mockEvent);
                    expect(wrapper.instance().addHighlight).not.toBeCalled();
                });

                it('does not call addHighlight when window selection anchor node id does not contain chunk', () => {
                    window.getSelection.mockReturnValue({
                        toString: () => 'asdf',
                        anchorNode: {
                            parentNode: {
                                id: 'blah blah'
                            }
                        },
                        focusNode: {
                            parentNode: {
                                id: 'chunk0-text0'
                            }
                        },
                        removeAllRanges: mockSelectionRemoveRanges
                    });
                    wrapper.setProps({highlightMode: true});

                    wrapper.instance().addHighlight = jest.fn();
                    wrapper.instance().handleMouseUp(mockEvent);
                    expect(wrapper.instance().addHighlight).not.toBeCalled();
                });

                it('does not call addHighlight when window selection focus node id does not contain chunk', () => {
                    window.getSelection.mockReturnValue({
                        toString: () => 'asdf',
                        anchorNode: {
                            parentNode: {
                                id: 'chunk0-text0'
                            }
                        },
                        focusNode: {
                            parentNode: {
                                id: 'blah blah'
                            }
                        },
                        removeAllRanges: mockSelectionRemoveRanges
                    });
                    wrapper.setProps({highlightMode: true});

                    wrapper.instance().addHighlight = jest.fn();
                    wrapper.instance().handleMouseUp(mockEvent);
                    expect(wrapper.instance().addHighlight).not.toBeCalled();
                });

                it('does not call addHighlight when window selection begins and ends on the same speaker label', () => {
                    window.getSelection.mockReturnValue({
                        toString: () => 'asdf',
                        anchorNode: {
                            parentNode: {
                                id: 'chunk0-speaker'
                            }
                        },
                        focusNode: {
                            parentNode: {
                                id: 'chunk0-speaker'
                            }
                        },
                        removeAllRanges: mockSelectionRemoveRanges
                    });
                    wrapper.setProps({highlightMode: true});

                    wrapper.instance().addHighlight = jest.fn();
                    wrapper.instance().handleMouseUp(mockEvent);
                    expect(wrapper.instance().addHighlight).not.toBeCalled();
                });

                it('does not call addHighlight when window selection begins and ends on the same time label', () => {
                    window.getSelection.mockReturnValue({
                        toString: () => 'asdf',
                        anchorNode: {
                            parentNode: {
                                id: 'chunk0-begin-time'
                            }
                        },
                        focusNode: {
                            parentNode: {
                                id: 'chunk0-begin-time'
                            }
                        },
                        removeAllRanges: mockSelectionRemoveRanges
                    });
                    wrapper.setProps({highlightMode: true});

                    wrapper.instance().addHighlight = jest.fn();
                    wrapper.instance().handleMouseUp(mockEvent);
                    expect(wrapper.instance().addHighlight).not.toBeCalled();
                });

                it('does not call saveHighlightAction when the selection is in between an already highlighted entity', () => {
                    jest.clearAllMocks();
                    window.getSelection.mockReturnValue({
                        anchorOffset: 8,
                        focusOffset: 16,
                        anchorNode: {
                            parentNode: {
                                id: 'chunk1-text11-highlight0'
                            },
                            compareDocumentPosition: jest.fn().mockReturnValue(0)
                        },
                        focusNode: {
                            parentNode: {
                                id: 'chunk1-text11-highlight0'
                            }
                        },
                        toString: jest.fn().mockReturnValue('123'),
                        removeAllRanges: mockSelectionRemoveRanges
                    });
                    wrapper.find('#transcript-container').simulate('mouseup', mockEvent);
                    expect(mockSaveHighlightAction).not.toBeCalled();
                });
            });

            describe('getWindowSelection', () => {
                let expected = {
                    beginNodeId: 'chunk3-text0',
                    endNodeId: 'chunk3-text4',
                    beginTextIndex: 2,
                    endTextIndex: 6
                };

                let expectedSpeaker = {
                    beginNodeId: 'chunk0-text0',
                    endNodeId: 'chunk3-text4',
                    beginTextIndex: 0,
                    endTextIndex: 6
                };

                it('returns selection values - compareDocumentPosition return 0', () => {
                    window.getSelection.mockReturnValue({
                        anchorNode: {
                            parentNode: {
                                id: 'chunk3-text0'
                            },
                            compareDocumentPosition: jest.fn().mockReturnValue(0)
                        },
                        focusNode: {
                            parentNode: {
                                id: 'chunk3-text4'
                            }
                        },
                        anchorOffset: 2,
                        focusOffset: 6
                    });
                    expect(wrapper.instance().getWindowSelection()).toEqual(expected);
                });

                it('returns selection values - compareDocumentPosition return 1', () => {
                    window.getSelection.mockReturnValue({
                        anchorNode: {
                            parentNode: {
                                id: 'chunk3-text0'
                            },
                            compareDocumentPosition: jest.fn().mockReturnValue(1)
                        },
                        focusNode: {
                            parentNode: {
                                id: 'chunk3-text4'
                            }
                        },
                        anchorOffset: 2,
                        focusOffset: 6
                    });
                    expect(wrapper.instance().getWindowSelection()).toEqual(expected);
                });

                it('returns selection values - anchorOffset is greater than focus beginTime', () => {
                    window.getSelection.mockReturnValue({
                        anchorNode: {
                            parentNode: {
                                id: 'chunk3-text4'
                            },
                            compareDocumentPosition: jest.fn().mockReturnValue(0)
                        },
                        focusNode: {
                            parentNode: {
                                id: 'chunk3-text0'
                            }
                        },
                        anchorOffset: 6,
                        focusOffset: 2
                    });
                    expect(wrapper.instance().getWindowSelection()).toEqual(expected);
                });

                it('returns selection values - anchorOffset is greater than focus beginTime', () => {
                    expected = {
                        beginNodeId: 'chunk3-text0',
                        endNodeId: 'chunk3-text4',
                        beginTextIndex: 3,
                        endTextIndex: 3
                    };
                    window.getSelection.mockReturnValue({
                        anchorNode: {
                            parentNode: {
                                id: 'chunk3-text4'
                            },
                            compareDocumentPosition: jest.fn().mockReturnValue(2)
                        },
                        focusNode: {
                            parentNode: {
                                id: 'chunk3-text0'
                            }
                        },
                        anchorOffset: 3,
                        focusOffset: 3
                    });
                    expect(wrapper.instance().getWindowSelection()).toEqual(expected);
                });

                it('returns selection values - selection begins with speaker label', () => {
                    window.getSelection.mockReturnValue({
                        anchorNode: {
                            parentNode: {
                                id: 'chunk3-speaker',
                                parentNode: {
                                    id: 'chunk3',
                                    children: [{id: 'chunk3-text0'}]
                                }
                            },
                            compareDocumentPosition: jest.fn().mockReturnValue(0)
                        },
                        focusNode: {
                            parentNode: {
                                id: 'chunk3-text4'
                            }
                        },
                        anchorOffset: 2,
                        focusOffset: 6
                    });
                    expect(wrapper.instance().getWindowSelection()).toEqual(expectedSpeaker);
                });

                it('returns selection values - selection end with speaker label', () => {
                    window.getSelection.mockReturnValue({
                        anchorNode: {
                            parentNode: {
                                id: 'chunk0-text0'
                            },
                            compareDocumentPosition: jest.fn().mockReturnValue(0)
                        },
                        focusNode: {
                            parentNode: {
                                id: 'chunk4-speaker',
                                parentNode: {
                                    id: 'chunk3',
                                    children: [{id: 'chunk3-text4'}]
                                }
                            },
                            compareDocumentPosition: jest.fn().mockReturnValue(0)
                        },
                        anchorOffset: 0,
                        focusOffset: 6
                    });
                    document.getElementById.mockReturnValue({
                        children: [{id: 'chunk3-text4'}],
                        innerHTML: 'ABCDEF'
                    });
                    expect(wrapper.instance().getWindowSelection()).toEqual(expectedSpeaker);
                });
            });

            describe('highlighting scenarios', () => {
                beforeEach(() => {
                    jest.clearAllMocks();
                    wrapper.setProps({
                        voiceAttachments: [{
                            sourceVoiceId: 'voiceId',
                            sourceTranscriptUrl: 'transcriptUrl',
                            createdDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            sourceVoiceTitle: 'FNOL',
                            highlightEntities: [
                                {
                                    id: 'highlightId1',
                                    highlightTexts: [
                                        {
                                            speaker: 'Allstate',
                                            chunkIndex: 3,
                                            beginIndex: 0,
                                            endIndex: 4,
                                            text: 'This'
                                        },
                                    ],
                                    audioHighlightTimeStart: 35.5 + (3.5 / 15) * 0
                                },
                                {
                                    id: 'highlightId2',
                                    highlightTexts: [
                                        {
                                            speaker: 'Allstate',
                                            chunkIndex: 1,
                                            beginIndex: 0,
                                            endIndex: 4,
                                            text: 'This'
                                        }
                                    ],
                                    audioHighlightTimeStart: 15.5 + (3.5 / 15) * 0
                                },
                            ]
                        }],
                        highlightMode: true,
                        evidences: [
                            {
                                id: 'evidenceId1',
                                sourceId: 'highlightId1',
                                type: 'highlight',
                                category: 'loss-address',
                                sourceVoiceId: 'voiceId',
                                participantDisplayName: 'JOE BOB',
                                participantSourceId: '1',
                                callType: 'my call type',
                                transcriptCreatedDate: '2019-03-08T14:26:41',
                                highlightTexts: [
                                    {
                                        speaker: 'Allstate',
                                        chunkIndex: 3,
                                        beginIndex: 0,
                                        endIndex: 4,
                                        text: 'This'
                                    },
                                ]
                            },
                            {id: 'evidenceId2', sourceId: 'photoId', type: 'photo'},
                            {
                                id: 'evidenceId3',
                                sourceId: 'highlightId2',
                                type: 'highlight',
                                sourceVoiceId: 'voiceId',
                                participantDisplayName: 'JOE BOB',
                                participantSourceId: '1',
                                callType: 'my call type',
                                transcriptCreatedDate: '2019-03-08T14:26:41',
                                highlightTexts: [
                                    {
                                        speaker: 'Allstate',
                                        chunkIndex: 1,
                                        beginIndex: 0,
                                        endIndex: 4,
                                        text: 'This'
                                    },
                                ]
                            }
                        ]
                    });
                    wrapper.instance().isRightToLeft = jest.fn().mockReturnValue(false);
                    document.getElementById = jest.fn().mockReturnValue({
                        innerHTML: {
                            length: 5
                        },
                        innerText: 'chunk3',
                        style: {},
                        children: [
                            {id: 'chunk0-text0'},
                            {id: 'chunk0-text5-highlight0'},
                            {id: 'chunk0-text7'},
                        ],
                        getBoundingClientRect: jest.fn().mockReturnValue({left: 15, top: 55})
                    });
                });

                it('calls saveHighlightAction', () => {
                    const expectedHighlightEntities = [
                        {
                            id: 'highlightId1',
                            highlightTexts: [
                                {
                                    speaker: 'Allstate',
                                    chunkIndex: 3,
                                    beginIndex: 0,
                                    endIndex: 4,
                                    text: 'This'
                                },
                            ],
                            audioHighlightTimeStart: 35.5 + (3.5 / 15) * 0
                        },
                        {
                            id: 'highlightId2',
                            highlightTexts: [
                                {
                                    speaker: 'Allstate',
                                    chunkIndex: 1,
                                    beginIndex: 0,
                                    endIndex: 4,
                                    text: 'This'
                                }
                            ],
                            audioHighlightTimeStart: 15.5 + (3.5 / 15) * 0
                        },
                        {
                            id: 'highlightId',
                            highlightTexts: [
                                {
                                    speaker: 'Allstate',
                                    chunkIndex: 1,
                                    beginIndex: 8,
                                    endIndex: 16,
                                    text: 'chunk1.'
                                }
                            ],
                            audioHighlightTimeStart: 15.5 + (3.5 / 15) * 8
                        }
                    ];
                    const expectedEvidences = [
                        {
                            id: 'evidenceId1',
                            sourceId: 'highlightId1',
                            type: 'highlight',
                            category: 'loss-address',
                            sourceVoiceId: 'voiceId',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            callType: 'my call type',
                            transcriptCreatedDate: '2019-03-08T14:26:41',
                            highlightTexts: [
                                {
                                    speaker: 'Allstate',
                                    chunkIndex: 3,
                                    beginIndex: 0,
                                    endIndex: 4,
                                    text: 'This'
                                },
                            ]
                        },
                        {id: 'evidenceId2', sourceId: 'photoId', type: 'photo'},
                        {
                            id: 'evidenceId3',
                            sourceId: 'highlightId2',
                            type: 'highlight',
                            sourceVoiceId: 'voiceId',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            callType: 'my call type',
                            transcriptCreatedDate: '2019-03-08T14:26:41',
                            highlightTexts: [
                                {
                                    speaker: 'Allstate',
                                    chunkIndex: 1,
                                    beginIndex: 0,
                                    endIndex: 4,
                                    text: 'This'
                                }
                            ],
                        },
                        {
                            id: 'evidenceId',
                            sourceId: 'highlightId',
                            type: 'highlight',
                            sourceVoiceId: 'voiceId',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            callType: 'my call type',
                            transcriptCreatedDate: '2019-03-08T14:26:41',
                            highlightTexts: [
                                {
                                    speaker: 'Allstate',
                                    chunkIndex: 1,
                                    beginIndex: 8,
                                    endIndex: 16,
                                    text: 'chunk1.'
                                }
                            ],
                        }
                    ];
                    window.getSelection.mockReturnValue({
                        anchorOffset: 8,
                        focusOffset: 16,
                        anchorNode: {
                            parentNode: {
                                id: 'chunk1-text0'
                            }
                        },
                        focusNode: {
                            parentNode: {
                                id: 'chunk1-text0'
                            }
                        }
                    });
                    jest.clearAllMocks();
                    wrapper.instance().addHighlight(mockEvent);

                    const expected = JSON.parse(JSON.stringify(mockVoiceAttachments));
                    expected[0].highlightEntities = expectedHighlightEntities;
                    expect(mockSaveHighlightAction).toBeCalledWith('123456789000', 'voiceId', expectedHighlightEntities, expectedEvidences, events);
                });

                it('calls saveHighlightAction - new highlight begins within existing highlight', () => {
                    wrapper.setProps({
                        voiceAttachments: [{
                            sourceVoiceId: 'voiceId',
                            sourceTranscriptUrl: 'transcriptUrl',
                            createdDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            sourceVoiceTitle: 'FNOL',
                            highlightEntities: [
                                {
                                    id: 'highlightId1',
                                    highlightTexts: [
                                        {
                                            speaker: 'Customer',
                                            chunkIndex: 0,
                                            beginIndex: 5,
                                            endIndex: 6,
                                            text: 'is'
                                        },
                                    ],
                                    audioHighlightTimeStart: 5.5 + (3.5 / 15) * 5
                                },
                                {
                                    id: 'highlightId2',
                                    highlightTexts: [
                                        {
                                            speaker: 'Allstate',
                                            chunkIndex: 3,
                                            beginIndex: 0,
                                            endIndex: 4,
                                            text: 'This'
                                        },
                                    ],
                                    audioHighlightTimeStart: 35.5 + (3.5 / 15) * 0
                                }
                            ]
                        }],
                        highlightMode: true,
                        evidences: [
                            {
                                id: 'evidenceId1',
                                sourceId: 'highlightId1',
                                type: 'highlight',
                                category: 'loss-address',
                                sourceVoiceId: 'voiceId',
                                participantDisplayName: 'JOE BOB',
                                participantSourceId: '1',
                                callType: 'my call type',
                                transcriptCreatedDate: '2019-03-08T14:26:41',
                                highlightTexts: [
                                    {
                                        speaker: 'Customer',
                                        chunkIndex: 0,
                                        beginIndex: 5,
                                        endIndex: 6,
                                        text: 'is'
                                    },
                                ],
                            },
                            {id: 'evidenceId2', sourceId: 'photoId', type: 'photo'},
                            {
                                id: 'evidenceId3',
                                sourceId: 'highlightId2',
                                type: 'highlight',
                                sourceVoiceId: 'voiceId',
                                participantDisplayName: 'JOE BOB',
                                participantSourceId: '1',
                                callType: 'my call type',
                                transcriptCreatedDate: '2019-03-08T14:26:41',
                                highlightTexts: [
                                    {
                                        speaker: 'Allstate',
                                        chunkIndex: 3,
                                        beginIndex: 0,
                                        endIndex: 4,
                                        text: 'This'
                                    },
                                ],
                            }
                        ]
                    });
                    const expectedHighlightEntities = [
                        {
                            id: 'highlightId1',
                            highlightTexts: [
                                {
                                    speaker: 'Customer',
                                    chunkIndex: 0,
                                    beginIndex: 5,
                                    endIndex: 6,
                                    text: 'is'
                                },
                            ],
                            audioHighlightTimeStart: 5.5 + (3.5 / 15) * 5
                        },
                        {
                            id: 'highlightId',
                            highlightTexts: [
                                {
                                    speaker: 'Allstate',
                                    chunkIndex: 3,
                                    beginIndex: 0,
                                    endIndex: 6,
                                    text: 'This i'
                                },
                            ],
                            audioHighlightTimeStart: 35.5 + (3.5 / 15) * 0
                        }
                    ];
                    const expectedEvidences = [
                        {
                            id: 'evidenceId1',
                            sourceId: 'highlightId1',
                            type: 'highlight',
                            category: 'loss-address',
                            sourceVoiceId: 'voiceId',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            callType: 'my call type',
                            transcriptCreatedDate: '2019-03-08T14:26:41',
                            highlightTexts: [
                                {
                                    speaker: 'Customer',
                                    chunkIndex: 0,
                                    beginIndex: 5,
                                    endIndex: 6,
                                    text: 'is'
                                },
                            ],
                        },
                        {id: 'evidenceId2', sourceId: 'photoId', type: 'photo'},
                        {
                            id: 'evidenceId',
                            sourceId: 'highlightId',
                            type: 'highlight',
                            sourceVoiceId: 'voiceId',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            callType: 'my call type',
                            transcriptCreatedDate: '2019-03-08T14:26:41',
                            highlightTexts: [
                                {
                                    speaker: 'Allstate',
                                    chunkIndex: 3,
                                    beginIndex: 0,
                                    endIndex: 6,
                                    text: 'This i'
                                },
                            ]
                        }
                    ];
                    window.getSelection.mockReturnValue({
                        anchorOffset: 2,
                        focusOffset: 2,
                        anchorNode: {
                            parentNode: {
                                id: 'chunk3-text0-highlight1'
                            }
                        },
                        focusNode: {
                            parentNode: {
                                id: 'chunk3-text4'
                            }
                        }
                    });
                    wrapper.instance().addHighlight(mockEvent);

                    const expected = JSON.parse(JSON.stringify(mockVoiceAttachments));
                    expected[0].highlightEntities = expectedHighlightEntities;
                    expect(mockSaveHighlightAction).toBeCalledWith('123456789000', 'voiceId', expectedHighlightEntities, expectedEvidences, events);
                });

                it('calls saveHighlightAction - new highlight ends within existing highlight', () => {
                    wrapper.setProps({
                        voiceAttachments: [{
                            sourceVoiceId: 'voiceId',
                            sourceTranscriptUrl: 'transcriptUrl',
                            createdDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            sourceVoiceTitle: 'FNOL',
                            highlightEntities: [
                                {
                                    id: 'highlightId1',
                                    highlightTexts: [
                                        {
                                            speaker: 'Customer',
                                            chunkIndex: 0,
                                            beginIndex: 5,
                                            endIndex: 6,
                                            text: 'is'
                                        },
                                    ],
                                    audioHighlightTimeStart: 5.5 + (3.5 / 15) * 5
                                },
                                {
                                    id: 'highlightId2',
                                    highlightTexts: [
                                        {
                                            speaker: 'Allstate',
                                            chunkIndex: 3,
                                            beginIndex: 8,
                                            endIndex: 15,
                                            text: 'chunk3'
                                        },
                                    ],
                                    audioHighlightTimeStart: 35.5 + (3.5 / 15) * 8
                                }
                            ]
                        }],
                        highlightMode: true,
                        evidences: [
                            {
                                id: 'evidenceId1',
                                sourceId: 'highlightId1',
                                type: 'highlight',
                                category: 'loss-address',
                                sourceVoiceId: 'voiceId',
                                participantDisplayName: 'JOE BOB',
                                participantSourceId: '1',
                                callType: 'my call type',
                                transcriptCreatedDate: '2019-03-08T14:26:41',
                                highlightTexts: [
                                    {
                                        speaker: 'Customer',
                                        chunkIndex: 0,
                                        beginIndex: 5,
                                        endIndex: 6,
                                        text: 'is'
                                    },
                                ],
                            },
                            {id: 'evidenceId2', sourceId: 'photoId', type: 'photo'},
                            {
                                id: 'evidenceId3',
                                sourceId: 'highlightId2',
                                type: 'highlight',
                                sourceVoiceId: 'voiceId',
                                participantDisplayName: 'JOE BOB',
                                participantSourceId: '1',
                                callType: 'my call type',
                                transcriptCreatedDate: '2019-03-08T14:26:41',
                                highlightTexts: [
                                    {
                                        speaker: 'Allstate',
                                        chunkIndex: 3,
                                        beginIndex: 8,
                                        endIndex: 15,
                                        text: 'chunk3'
                                    },
                                ],
                            }
                        ]

                    });
                    const expectedHighlightEntities = [
                        {
                            id: 'highlightId1',
                            highlightTexts: [
                                {
                                    speaker: 'Customer',
                                    chunkIndex: 0,
                                    beginIndex: 5,
                                    endIndex: 6,
                                    text: 'is'
                                },
                            ],
                            audioHighlightTimeStart: 5.5 + (3.5 / 15) * 5
                        },
                        {
                            id: 'highlightId',
                            highlightTexts: [
                                {
                                    speaker: 'Allstate',
                                    chunkIndex: 3,
                                    beginIndex: 5,
                                    endIndex: 15,
                                    text: 'is chunk3.'
                                },
                            ],
                            audioHighlightTimeStart: 35.5 + (3.5 / 15) * 5
                        }
                    ];
                    const expectedEvidences = [
                        {
                            id: 'evidenceId1',
                            sourceId: 'highlightId1',
                            type: 'highlight',
                            category: 'loss-address',
                            sourceVoiceId: 'voiceId',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            callType: 'my call type',
                            transcriptCreatedDate: '2019-03-08T14:26:41',
                            highlightTexts: [
                                {
                                    speaker: 'Customer',
                                    chunkIndex: 0,
                                    beginIndex: 5,
                                    endIndex: 6,
                                    text: 'is'
                                },
                            ],
                        },
                        {id: 'evidenceId2', sourceId: 'photoId', type: 'photo'},
                        {
                            id: 'evidenceId',
                            sourceId: 'highlightId',
                            type: 'highlight',
                            sourceVoiceId: 'voiceId',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            callType: 'my call type',
                            transcriptCreatedDate: '2019-03-08T14:26:41',
                            highlightTexts: [
                                {
                                    speaker: 'Allstate',
                                    chunkIndex: 3,
                                    beginIndex: 5,
                                    endIndex: 15,
                                    text: 'is chunk3.'
                                },
                            ],
                        }
                    ];

                    document.getElementById = jest.fn().mockReturnValue({
                        innerText: 'chunk3',
                        children: [
                            {id: 'chunk0-text0'},
                            {id: 'chunk0-text5-highlight0'},
                            {id: 'chunk0-text7'},
                        ],
                        style: {},
                        getBoundingClientRect: jest.fn().mockReturnValue({left: 15, top: 55})
                    });
                    window.getSelection.mockReturnValue({
                        anchorOffset: 5,
                        focusOffset: 3,
                        anchorNode: {
                            parentNode: {
                                id: 'chunk3-text0'
                            }
                        },
                        focusNode: {
                            parentNode: {
                                id: 'chunk3-text8-highlight1'
                            }
                        }
                    });
                    wrapper.instance().addHighlight(mockEvent);

                    const expected = JSON.parse(JSON.stringify(mockVoiceAttachments));
                    expected[0].highlightEntities = expectedHighlightEntities;
                    expect(mockSaveHighlightAction).toBeCalledWith('123456789000', 'voiceId', expectedHighlightEntities, expectedEvidences, events);
                });

                it('calls saveHighlightAction - new highlight begins adjacent to an existing highlight', () => {
                    wrapper.setProps({
                        voiceAttachments: [{
                            sourceVoiceId: 'voiceId',
                            sourceTranscriptUrl: 'transcriptUrl',
                            createdDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            sourceVoiceTitle: 'FNOL',
                            highlightEntities: [
                                {
                                    id: 'highlightId1',
                                    highlightTexts: [
                                        {
                                            speaker: 'Customer',
                                            chunkIndex: 0,
                                            beginIndex: 5,
                                            endIndex: 7,
                                            text: 'is'
                                        },
                                    ],
                                    audioHighlightTimeStart: 5.5 + (3.5 / 15) * 5
                                },
                                {
                                    id: 'highlightId2',
                                    highlightTexts: [
                                        {
                                            speaker: 'Allstate',
                                            chunkIndex: 3,
                                            beginIndex: 0,
                                            endIndex: 4,
                                            text: 'This'
                                        },
                                    ],
                                    audioHighlightTimeStart: 35.5 + (3.5 / 15) * 0
                                }
                            ]
                        }],
                        highlightMode: true,
                        evidences: [
                            {
                                id: 'evidenceId1',
                                sourceId: 'highlightId1',
                                type: 'highlight',
                                category: 'loss-address',
                                sourceVoiceId: 'voiceId',
                                transcriptCreatedDate: '2019-03-08T14:26:41',
                                participantDisplayName: 'JOE BOB',
                                participantSourceId: '1',
                                callType: 'my call type',
                                highlightTexts: [
                                    {
                                        speaker: 'Customer',
                                        chunkIndex: 0,
                                        beginIndex: 5,
                                        endIndex: 7,
                                        text: 'is'
                                    },
                                ],
                            },
                            {id: 'evidenceId2', sourceId: 'photoId', type: 'photo'},
                            {
                                id: 'evidenceId3',
                                sourceId: 'highlightId2',
                                type: 'highlight',
                                sourceVoiceId: 'voiceId',
                                transcriptCreatedDate: '2019-03-08T14:26:41',
                                participantDisplayName: 'JOE BOB',
                                participantSourceId: '1',
                                callType: 'my call type',
                                highlightTexts: [
                                    {
                                        speaker: 'Allstate',
                                        chunkIndex: 3,
                                        beginIndex: 0,
                                        endIndex: 4,
                                        text: 'This'
                                    },
                                ],
                            }
                        ]
                    });
                    const expectedHighlightEntities = [
                        {
                            id: 'highlightId2',
                            highlightTexts: [
                                {
                                    speaker: 'Allstate',
                                    chunkIndex: 3,
                                    beginIndex: 0,
                                    endIndex: 4,
                                    text: 'This'
                                },
                            ],
                            audioHighlightTimeStart: 35.5 + (3.5 / 15) * 0
                        },
                        {
                            id: 'highlightId',
                            highlightTexts: [
                                {
                                    speaker: 'Customer12345678',
                                    chunkIndex: 0,
                                    beginIndex: 5,
                                    endIndex: 11,
                                    text: 'is chu'
                                },
                            ],
                            audioHighlightTimeStart: 5.5 + (3.5 / 15) * 5
                        }
                    ];
                    const expectedEvidences = [
                        {id: 'evidenceId2', sourceId: 'photoId', type: 'photo'},
                        {
                            id: 'evidenceId3',
                            sourceId: 'highlightId2',
                            type: 'highlight',
                            sourceVoiceId: 'voiceId',
                            transcriptCreatedDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            callType: 'my call type',
                            highlightTexts: [
                                {
                                    speaker: 'Allstate',
                                    chunkIndex: 3,
                                    beginIndex: 0,
                                    endIndex: 4,
                                    text: 'This'
                                },
                            ],
                        },
                        {
                            id: 'evidenceId',
                            sourceId: 'highlightId',
                            type: 'highlight',
                            sourceVoiceId: 'voiceId',
                            transcriptCreatedDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            callType: 'my call type',
                            highlightTexts: [
                                {
                                    speaker: 'Customer12345678',
                                    chunkIndex: 0,
                                    beginIndex: 5,
                                    endIndex: 11,
                                    text: 'is chu'
                                },
                            ],
                        }
                    ];

                    document.getElementById = jest.fn().mockReturnValue({
                        children: [
                            {id: 'chunk0-text0'},
                            {id: 'chunk0-text5-highlight0'},
                            {id: 'chunk0-text7'},
                        ],
                        innerText: {
                            length: 0
                        },
                        style: {},
                        getBoundingClientRect: jest.fn().mockReturnValue({left: 15, top: 55})
                    });
                    window.getSelection.mockReturnValue({
                        anchorOffset: 0,
                        focusOffset: 4,
                        anchorNode: {
                            parentNode: {
                                id: 'chunk0-text7'
                            }
                        },
                        focusNode: {
                            parentNode: {
                                id: 'chunk0-text7'
                            }
                        }
                    });
                    wrapper.instance().addHighlight(mockEvent);

                    const expected = JSON.parse(JSON.stringify(mockVoiceAttachments));
                    expected[0].highlightEntities = expectedHighlightEntities;
                    expect(mockSaveHighlightAction).toBeCalledWith('123456789000', 'voiceId', expectedHighlightEntities, expectedEvidences, events);
                });

                it('calls saveHighlightAction - new highlight ends adjacent to an existing highlight', () => {
                    wrapper.setProps({
                        voiceAttachments: [{
                            sourceVoiceId: 'voiceId',
                            sourceTranscriptUrl: 'transcriptUrl',
                            createdDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            sourceVoiceTitle: 'FNOL',
                            highlightEntities: [
                                {
                                    id: 'highlightId1',
                                    highlightTexts: [
                                        {
                                            speaker: 'Customer',
                                            chunkIndex: 0,
                                            beginIndex: 5,
                                            endIndex: 7,
                                            text: 'is'
                                        },
                                    ],
                                    audioHighlightTimeStart: 5.5 + (3.5 / 15) * 5
                                },
                                {
                                    id: 'highlightId2',
                                    highlightTexts: [
                                        {
                                            speaker: 'Allstate',
                                            chunkIndex: 3,
                                            beginIndex: 0,
                                            endIndex: 4,
                                            text: 'This'
                                        },
                                    ],
                                    audioHighlightTimeStart: 35.5 + (3.5 / 15) * 0
                                }
                            ]
                        }],
                        highlightMode: true,
                        evidences: [
                            {
                                id: 'evidenceId1',
                                sourceId: 'highlightId1',
                                type: 'highlight',
                                category: 'loss-address',
                                sourceVoiceId: 'voiceId',
                                participantDisplayName: 'JOE BOB',
                                participantSourceId: '1',
                                callType: 'my call type',
                                transcriptCreatedDate: '2019-03-08T14:26:41',
                                highlightTexts: [
                                    {
                                        speaker: 'Customer',
                                        chunkIndex: 0,
                                        beginIndex: 5,
                                        endIndex: 7,
                                        text: 'is'
                                    },
                                ],
                            },
                            {id: 'evidenceId2', sourceId: 'photoId', type: 'photo'},
                            {
                                id: 'evidenceId3',
                                sourceId: 'highlightId2',
                                type: 'highlight',
                                sourceVoiceId: 'voiceId',
                                transcriptCreatedDate: '2019-03-08T14:26:41',
                                participantDisplayName: 'JOE BOB',
                                participantSourceId: '1',
                                callType: 'my call type',
                                highlightTexts: [
                                    {
                                        speaker: 'Allstate',
                                        chunkIndex: 3,
                                        beginIndex: 0,
                                        endIndex: 4,
                                        text: 'This'
                                    },
                                ],
                            }
                        ]
                    });
                    const expectedHighlightEntities = [
                        {
                            id: 'highlightId2',
                            highlightTexts: [
                                {
                                    speaker: 'Allstate',
                                    chunkIndex: 3,
                                    beginIndex: 0,
                                    endIndex: 4,
                                    text: 'This'
                                },
                            ],
                            audioHighlightTimeStart: 35.5 + (3.5 / 15) * 0
                        },
                        {
                            id: 'highlightId',
                            highlightTexts: [
                                {
                                    speaker: 'Customer12345678',
                                    chunkIndex: 0,
                                    beginIndex: 1,
                                    endIndex: 7,
                                    text: 'his is'
                                },
                            ],
                            audioHighlightTimeStart: 5.5 + (3.5 / 15) * 1
                        }
                    ];
                    const expectedEvidences = [
                        {id: 'evidenceId2', sourceId: 'photoId', type: 'photo'},
                        {
                            id: 'evidenceId3',
                            sourceId: 'highlightId2',
                            type: 'highlight',
                            sourceVoiceId: 'voiceId',
                            transcriptCreatedDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            callType: 'my call type',
                            highlightTexts: [
                                {
                                    speaker: 'Allstate',
                                    chunkIndex: 3,
                                    beginIndex: 0,
                                    endIndex: 4,
                                    text: 'This'
                                },
                            ],
                        },
                        {
                            id: 'evidenceId',
                            sourceId: 'highlightId',
                            type: 'highlight',
                            sourceVoiceId: 'voiceId',
                            transcriptCreatedDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            callType: 'my call type',
                            highlightTexts: [
                                {
                                    speaker: 'Customer12345678',
                                    chunkIndex: 0,
                                    beginIndex: 1,
                                    endIndex: 7,
                                    text: 'his is'
                                },
                            ],
                        }
                    ];

                    document.getElementById = jest.fn().mockReturnValue({
                        children: [
                            {id: 'chunk0-text0'},
                            {id: 'chunk0-text5-highlight0'},
                            {id: 'chunk0-text7'},
                        ],
                        style: {},
                        innerText: 'This ',
                        getBoundingClientRect: jest.fn().mockReturnValue({left: 15, top: 55})
                    });
                    window.getSelection.mockReturnValue({
                        anchorOffset: 1,
                        focusOffset: 5,
                        anchorNode: {
                            parentNode: {
                                id: 'chunk0-text0'
                            }
                        },
                        focusNode: {
                            parentNode: {
                                id: 'chunk0-text0'
                            }
                        }
                    });
                    wrapper.instance().addHighlight(mockEvent);

                    const expected = JSON.parse(JSON.stringify(mockVoiceAttachments));
                    expected[0].highlightEntities = expectedHighlightEntities;
                    expect(mockSaveHighlightAction).toBeCalledWith('123456789000', 'voiceId', expectedHighlightEntities, expectedEvidences, events);
                });

                it('calls saveHighlightAction - new highlight begins and ends adjacent to existing highlights', () => {
                    const newEvidences = [
                        {
                            id: 'evidenceId1',
                            sourceId: 'highlightId1',
                            type: 'highlight',
                            sourceVoiceId: 'voiceId',
                            transcriptCreatedDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            callType: 'my call type',
                            highlightTexts: [
                                {
                                    speaker: 'Customer',
                                    chunkIndex: 0,
                                    beginIndex: 5,
                                    endIndex: 7,
                                    text: 'is'
                                },
                            ],
                        },
                        {id: 'evidenceId2', sourceId: 'photoId', type: 'photo'},
                        {
                            id: 'evidenceId3',
                            sourceId: 'highlightId2',
                            type: 'highlight',
                            sourceVoiceId: 'voiceId',
                            transcriptCreatedDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            callType: 'my call type',
                            highlightTexts: [
                                {
                                    speaker: 'Customer',
                                    chunkIndex: 0,
                                    beginIndex: 11,
                                    endIndex: 15,
                                    text: 'ase0'
                                },
                            ],
                        },
                        {
                            id: 'evidenceId4',
                            sourceId: 'highlightId3',
                            type: 'highlight',
                            sourceVoiceId: 'voiceId',
                            transcriptCreatedDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            callType: 'my call type',
                            highlightTexts: [
                                {
                                    speaker: 'Allstate',
                                    chunkIndex: 3,
                                    beginIndex: 0,
                                    endIndex: 4,
                                    text: 'This'
                                },
                            ],
                        },
                    ];
                    wrapper.setProps({
                        voiceAttachments: [{
                            sourceVoiceId: 'voiceId',
                            sourceTranscriptUrl: 'transcriptUrl',
                            createdDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            sourceVoiceTitle: 'FNOL',
                            highlightEntities: [
                                {
                                    id: 'highlightId1',
                                    highlightTexts: [
                                        {
                                            speaker: 'Customer',
                                            chunkIndex: 0,
                                            beginIndex: 5,
                                            endIndex: 7,
                                            text: 'is'
                                        },
                                    ],
                                    audioHighlightTimeStart: 5.5 + (3.5 / 15) * 5
                                },
                                {
                                    id: 'highlightId2',
                                    highlightTexts: [
                                        {
                                            speaker: 'Customer',
                                            chunkIndex: 0,
                                            beginIndex: 11,
                                            endIndex: 15,
                                            text: 'ase0'
                                        },
                                    ],
                                    audioHighlightTimeStart: 5.5 + (3.5 / 15) * 5
                                },
                                {
                                    id: 'highlightId3',
                                    highlightTexts: [
                                        {
                                            speaker: 'Allstate',
                                            chunkIndex: 3,
                                            beginIndex: 0,
                                            endIndex: 4,
                                            text: 'This'
                                        },
                                    ],
                                    audioHighlightTimeStart: 35.5 + (3.5 / 15) * 0
                                }
                            ]
                        }],
                        highlightMode: true,
                        evidences: newEvidences,
                    });
                    const expectedHighlightEntities = [
                        {
                            id: 'highlightId3',
                            highlightTexts: [
                                {
                                    speaker: 'Allstate',
                                    chunkIndex: 3,
                                    beginIndex: 0,
                                    endIndex: 4,
                                    text: 'This'
                                },
                            ],
                            audioHighlightTimeStart: 35.5 + (3.5 / 15) * 0
                        },
                        {
                            id: 'highlightId',
                            highlightTexts: [
                                {
                                    speaker: 'Customer12345678',
                                    chunkIndex: 0,
                                    beginIndex: 5,
                                    endIndex: 15,
                                    text: 'is chunk0.'
                                },
                            ],
                            audioHighlightTimeStart: 5.5 + (3.5 / 15) * 5
                        }
                    ];
                    const expectedEvidences = [
                        {id: 'evidenceId2', sourceId: 'photoId', type: 'photo'},
                        {
                            id: 'evidenceId4',
                            sourceId: 'highlightId3',
                            type: 'highlight',
                            sourceVoiceId: 'voiceId',
                            transcriptCreatedDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            callType: 'my call type',
                            highlightTexts: [
                                {
                                    speaker: 'Allstate',
                                    chunkIndex: 3,
                                    beginIndex: 0,
                                    endIndex: 4,
                                    text: 'This'
                                },
                            ],
                        },
                        {
                            id: 'evidenceId',
                            sourceId: 'highlightId',
                            type: 'highlight',
                            sourceVoiceId: 'voiceId',
                            transcriptCreatedDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            callType: 'my call type',
                            highlightTexts: [
                                {
                                    speaker: 'Customer12345678',
                                    chunkIndex: 0,
                                    beginIndex: 5,
                                    endIndex: 15,
                                    text: 'is chunk0.'
                                },
                            ],
                        },
                    ];

                    document.getElementById = jest.fn().mockReturnValue({
                        children: [
                            {id: 'chunk0-text0'},
                            {id: 'chunk0-text5-highlight0'},
                            {id: 'chunk0-text7'},
                            {id: 'chunk0-text11-highlight1'},
                            {id: 'chunk0-text15'},
                        ],
                        style: {},
                        innerText: 'ase0',
                        getBoundingClientRect: jest.fn().mockReturnValue({left: 15, top: 55})
                    });
                    window.getSelection.mockReturnValue({
                        anchorOffset: 0,
                        focusOffset: 4,
                        anchorNode: {
                            parentNode: {
                                id: 'chunk0-text7'
                            }
                        },
                        focusNode: {
                            parentNode: {
                                id: 'chunk0-text7'
                            }
                        }
                    });
                    wrapper.instance().addHighlight(mockEvent);

                    const expected = JSON.parse(JSON.stringify(mockVoiceAttachments));
                    expected[0].highlightEntities = expectedHighlightEntities;
                    expect(mockSaveHighlightAction).toBeCalledWith('123456789000', 'voiceId', expectedHighlightEntities, expectedEvidences, events);
                });

                it('calls saveHighlightAction - new highlight fully overlaps existing highlights', () => {
                    const newEvidences = [
                        {
                            id: 'evidenceId1',
                            sourceId: 'highlightId1',
                            type: 'highlight',
                            sourceVoiceId: 'voiceId',
                            transcriptCreatedDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            callType: 'my call type',
                            highlightTexts: [
                                {
                                    speaker: 'Customer',
                                    chunkIndex: 0,
                                    beginIndex: 5,
                                    endIndex: 6,
                                    text: 'is'
                                },
                            ],
                        },
                        {id: 'evidenceId2', sourceId: 'photoId', type: 'photo'},
                        {
                            id: 'evidenceId3',
                            sourceId: 'highlightId2',
                            type: 'highlight',
                            sourceVoiceId: 'voiceId',
                            transcriptCreatedDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            callType: 'my call type',
                            highlightTexts: [
                                {
                                    speaker: 'Customer',
                                    chunkIndex: 0,
                                    beginIndex: 8,
                                    endIndex: 9,
                                    text: 'ph'
                                },
                            ],
                        },
                        {
                            id: 'evidenceId4',
                            sourceId: 'highlightId3',
                            type: 'highlight',
                            sourceVoiceId: 'voiceId',
                            transcriptCreatedDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            callType: 'my call type',
                            highlightTexts: [
                                {
                                    speaker: 'Allstate',
                                    chunkIndex: 3,
                                    beginIndex: 8,
                                    endIndex: 14,
                                    text: 'chunk3'
                                },
                            ],
                        },
                    ];
                    wrapper.setProps({
                        voiceAttachments: [{
                            sourceVoiceId: 'voiceId',
                            sourceTranscriptUrl: 'transcriptUrl',
                            createdDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            sourceVoiceTitle: 'FNOL',
                            highlightEntities: [
                                {
                                    id: 'highlightId1',
                                    highlightTexts: [
                                        {
                                            speaker: 'Customer',
                                            chunkIndex: 0,
                                            beginIndex: 5,
                                            endIndex: 6,
                                            text: 'is'
                                        },
                                    ],
                                    audioHighlightTimeStart: 5.5 + (3.5 / 15) * 5
                                },
                                {
                                    id: 'highlightId2',
                                    highlightTexts: [
                                        {
                                            speaker: 'Customer',
                                            chunkIndex: 0,
                                            beginIndex: 8,
                                            endIndex: 9,
                                            text: 'ph'
                                        },
                                    ],
                                    audioHighlightTimeStart: 5.5 + (3.5 / 15) * 9
                                },
                                {
                                    id: 'highlightId3',
                                    highlightTexts: [
                                        {
                                            speaker: 'Allstate',
                                            chunkIndex: 3,
                                            beginIndex: 8,
                                            endIndex: 14,
                                            text: 'chunk3'
                                        },
                                    ],
                                    audioHighlightTimeStart: 35.5 + (3.5 / 15) * 8
                                }
                            ]
                        }],
                        highlightMode: true,
                        evidences: newEvidences,
                    });
                    const expectedHighlightEntities = [
                        {
                            id: 'highlightId3',
                            highlightTexts: [
                                {
                                    speaker: 'Allstate',
                                    chunkIndex: 3,
                                    beginIndex: 8,
                                    endIndex: 14,
                                    text: 'chunk3'
                                },
                            ],
                            audioHighlightTimeStart: 35.5 + (3.5 / 15) * 8
                        },
                        {
                            id: 'highlightId',
                            highlightTexts: [
                                {
                                    speaker: 'Customer12345678',
                                    chunkIndex: 0,
                                    beginIndex: 1,
                                    endIndex: 15,
                                    text: 'his is chunk0.'
                                },
                            ],
                            audioHighlightTimeStart: 5.5 + (3.5 / 15) * 1
                        },
                    ];
                    const expectedEvidences = [
                        {id: 'evidenceId2', sourceId: 'photoId', type: 'photo'},
                        {
                            id: 'evidenceId4',
                            sourceId: 'highlightId3',
                            type: 'highlight',
                            sourceVoiceId: 'voiceId',
                            transcriptCreatedDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            callType: 'my call type',
                            highlightTexts: [
                                {
                                    speaker: 'Allstate',
                                    chunkIndex: 3,
                                    beginIndex: 8,
                                    endIndex: 14,
                                    text: 'chunk3'
                                },
                            ],
                        },
                        {
                            id: 'evidenceId',
                            sourceId: 'highlightId',
                            type: 'highlight',
                            sourceVoiceId: 'voiceId',
                            transcriptCreatedDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            callType: 'my call type',
                            highlightTexts: [
                                {
                                    speaker: 'Customer12345678',
                                    chunkIndex: 0,
                                    beginIndex: 1,
                                    endIndex: 15,
                                    text: 'his is chunk0.'
                                },
                            ],
                        },
                    ];

                    window.getSelection.mockReturnValue({
                        anchorOffset: 1,
                        focusOffset: 5,
                        anchorNode: {
                            parentNode: {
                                id: 'chunk0-text0'
                            }
                        },
                        focusNode: {
                            parentNode: {
                                id: 'chunk0-text10'
                            }
                        }
                    });
                    wrapper.instance().addHighlight(mockEvent);

                    const expected = JSON.parse(JSON.stringify(mockVoiceAttachments));
                    expected[0].highlightEntities = expectedHighlightEntities;
                    expect(mockSaveHighlightAction).toBeCalledWith('123456789000', 'voiceId', expectedHighlightEntities, expectedEvidences, events);
                });

                it('calls saveHighlightAction - new highlight begins and ends within existing highlights', () => {
                    const newEvidences = [
                        {
                            id: 'evidenceId1',
                            sourceId: 'highlightId1',
                            type: 'highlight',
                            sourceVoiceId: 'voiceId',
                            transcriptCreatedDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            callType: 'my call type',
                            highlightTexts: [
                                {
                                    speaker: 'Customer',
                                    chunkIndex: 0,
                                    beginIndex: 1,
                                    endIndex: 3,
                                    text: 'his'
                                },
                            ],
                        },
                        {id: 'evidenceId2', sourceId: 'photoId', type: 'photo'},
                        {
                            id: 'evidenceId3',
                            sourceId: 'highlightId2',
                            type: 'highlight',
                            sourceVoiceId: 'voiceId',
                            transcriptCreatedDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            callType: 'my call type',
                            highlightTexts: [
                                {
                                    speaker: 'Customer',
                                    chunkIndex: 0,
                                    beginIndex: 8,
                                    endIndex: 11,
                                    text: 'phr'
                                },
                            ],
                        },
                        {
                            id: 'evidenceId4',
                            sourceId: 'highlightId3',
                            type: 'highlight',
                            sourceVoiceId: 'voiceId',
                            transcriptCreatedDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            callType: 'my call type',
                            highlightTexts: [
                                {
                                    speaker: 'Allstate',
                                    chunkIndex: 3,
                                    beginIndex: 8,
                                    endIndex: 14,
                                    text: 'chunk3'
                                },
                            ],
                        },
                    ];
                    wrapper.setProps({
                        voiceAttachments: [{
                            sourceVoiceId: 'voiceId',
                            sourceTranscriptUrl: 'transcriptUrl',
                            createdDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            sourceVoiceTitle: 'FNOL',
                            highlightEntities: [
                                {
                                    id: 'highlightId1',
                                    highlightTexts: [
                                        {
                                            speaker: 'Customer',
                                            chunkIndex: 0,
                                            beginIndex: 1,
                                            endIndex: 3,
                                            text: 'his'
                                        },
                                    ],
                                    audioHighlightTimeStart: 5.5 + (3.5 / 15) * 5
                                },
                                {
                                    id: 'highlightId2',
                                    highlightTexts: [
                                        {
                                            speaker: 'Customer',
                                            chunkIndex: 0,
                                            beginIndex: 8,
                                            endIndex: 11,
                                            text: 'phr'
                                        },
                                    ],
                                    audioHighlightTimeStart: 5.5 + (3.5 / 15) * 9
                                },
                                {
                                    id: 'highlightId3',
                                    highlightTexts: [
                                        {
                                            speaker: 'Allstate',
                                            chunkIndex: 3,
                                            beginIndex: 8,
                                            endIndex: 14,
                                            text: 'chunk3'
                                        },
                                    ],
                                    audioHighlightTimeStart: 35.5 + (3.5 / 15) * 8
                                }
                            ]
                        }],
                        highlightMode: true,
                        evidences: newEvidences,
                    });
                    const expectedHighlightEntities = [
                        {
                            id: 'highlightId3',
                            highlightTexts: [
                                {
                                    speaker: 'Allstate',
                                    chunkIndex: 3,
                                    beginIndex: 8,
                                    endIndex: 14,
                                    text: 'chunk3'
                                },
                            ],
                            audioHighlightTimeStart: 35.5 + (3.5 / 15) * 8
                        },
                        {
                            id: 'highlightId',
                            highlightTexts: [
                                {
                                    speaker: 'Customer12345678',
                                    chunkIndex: 0,
                                    beginIndex: 1,
                                    endIndex: 11,
                                    text: 'his is chu'
                                },
                            ],
                            audioHighlightTimeStart: 5.5 + (3.5 / 15) * 1
                        },
                    ];
                    const expectedEvidences = [
                        {id: 'evidenceId2', sourceId: 'photoId', type: 'photo'},
                        {
                            id: 'evidenceId4',
                            sourceId: 'highlightId3',
                            type: 'highlight',
                            sourceVoiceId: 'voiceId',
                            transcriptCreatedDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            callType: 'my call type',
                            highlightTexts: [
                                {
                                    speaker: 'Allstate',
                                    chunkIndex: 3,
                                    beginIndex: 8,
                                    endIndex: 14,
                                    text: 'chunk3'
                                },
                            ],
                        },
                        {
                            id: 'evidenceId',
                            sourceId: 'highlightId',
                            type: 'highlight',
                            sourceVoiceId: 'voiceId',
                            transcriptCreatedDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            callType: 'my call type',
                            highlightTexts: [
                                {
                                    speaker: 'Customer12345678',
                                    chunkIndex: 0,
                                    beginIndex: 1,
                                    endIndex: 11,
                                    text: 'his is chu'
                                },
                            ],
                        },
                    ];

                    document.getElementById = jest.fn().mockReturnValue({
                        innerHTML: {
                            length: 3
                        },
                        innerText: 'phr',
                        style: {},
                        children: [
                            {id: 'chunk0-text0'},
                            {id: 'chunk0-text1-highlight0'},
                            {id: 'chunk0-text4'},
                            {id: 'chunk0-text8-highlight1'},
                            {id: 'chunk0-text10'},
                        ],
                        getBoundingClientRect: jest.fn().mockReturnValue({left: 15, top: 55})
                    });
                    window.getSelection.mockReturnValue({
                        anchorOffset: 1,
                        focusOffset: 1,
                        anchorNode: {
                            parentNode: {
                                id: 'chunk0-text1-highlight0'
                            }
                        },
                        focusNode: {
                            parentNode: {
                                id: 'chunk0-text8-highlight1'
                            }
                        }
                    });
                    wrapper.instance().addHighlight(mockEvent);

                    const expected = JSON.parse(JSON.stringify(mockVoiceAttachments));
                    expected[0].highlightEntities = expectedHighlightEntities;
                    expect(mockSaveHighlightAction).toBeCalledWith('123456789000', 'voiceId', expectedHighlightEntities, expectedEvidences, events);
                });

                xit('calls saveHighlightAction - new highlight begins within existing highlight and ends at the middle of the speaker name', () => {
                    jest.clearAllMocks();
                    wrapper.setProps({
                        voiceAttachments: [{
                            sourceVoiceId: 'voiceId',
                            sourceTranscriptUrl: 'transcriptUrl',
                            createdDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            sourceVoiceTitle: 'FNOL',
                            highlightEntities: [
                                {
                                    id: 'highlightId1',
                                    highlightTexts: [
                                        {
                                            speaker: 'Customer12345678',
                                            chunkIndex: 0,
                                            beginIndex: 5,
                                            endIndex: 7,
                                            text: 'is'
                                        },
                                    ],
                                    audioHighlightTimeStart: 5.5 + (3.5 / 15) * 5
                                },
                                {
                                    id: 'highlightId2',
                                    highlightTexts: [
                                        {
                                            speaker: 'Allstate',
                                            chunkIndex: 3,
                                            beginIndex: 0,
                                            endIndex: 4,
                                            text: 'This'
                                        },
                                    ],
                                    audioHighlightTimeStart: 35.5 + (3.5 / 15) * 0
                                }
                            ]
                        }],
                        highlightMode: true,
                    });
                    const expectedHighlightEntities = [
                        {
                            id: 'highlightId1',
                            highlightTexts: [
                                {
                                    speaker: 'Customer12345678',
                                    chunkIndex: 0,
                                    beginIndex: 5,
                                    endIndex: 7,
                                    text: 'is'
                                },
                            ],
                            audioHighlightTimeStart: 5.5 + (3.5 / 15) * 5
                        },
                        {
                            id: 'highlightId2',
                            highlightTexts: [
                                {
                                    speaker: 'Allstate',
                                    chunkIndex: 3,
                                    beginIndex: 0,
                                    endIndex: 6,
                                    text: 'This i'
                                },
                            ],
                            audioHighlightTimeStart: 35.5 + (3.5 / 15) * 0
                        }
                    ];
                    const expectedEvidences = [
                        {
                            id: 'evidenceId1',
                            sourceId: 'highlightId1',
                            type: 'highlight',
                            sourceVoiceId: 'voiceId',
                            callType: 'my call type',
                            transcriptCreatedDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                        },
                        {id: 'evidenceId2', sourceId: 'photoId', type: 'photo'},
                        {
                            id: 'evidenceId3',
                            sourceId: 'highlightId2',
                            type: 'highlight',
                            sourceVoiceId: 'voiceId',
                            callType: 'my call type',
                            transcriptCreatedDate: '2019-03-08T14:26:41',
                            participantDisplayName: 'JOE BOB',
                            participantSourceId: '1',
                            highlightTexts: [
                                {
                                    speaker: 'Customer12345678',
                                    chunkIndex: 0,
                                    beginIndex: 1,
                                    endIndex: 11,
                                    text: 'his is chu'
                                },
                            ],
                        },
                    ];

                    window.getSelection.mockReturnValue({
                        anchorOffset: 2,
                        focusOffset: 2,
                        anchorNode: {
                            parentNode: {
                                id: 'chunk3-text0-highlight0'
                            }
                        },
                        focusNode: {
                            parentNode: {
                                id: 'chunk3-speaker'
                            }
                        }
                    });
                    wrapper.instance().addHighlight(mockEvent);

                    const expected = JSON.parse(JSON.stringify(mockVoiceAttachments));
                    expected[0].highlightEntities = expectedHighlightEntities;
                    expect(mockSaveHighlightAction).toBeCalledWith('123456789000', 'voiceId', expectedHighlightEntities, expectedEvidences);
                });
            });
        });
    });

    describe('Evidence menu', () => {
        beforeEach(() => {
            wrapper.setProps({
                voiceAttachments: [{
                    sourceVoiceId: 'voiceId',
                    sourceTranscriptUrl: 'transcriptUrl',
                    highlightEntities: [
                        {
                            id: 'highlightId1',
                            highlightTexts: [
                                {
                                    speaker: 'Allstate',
                                    chunkIndex: 3,
                                    beginIndex: 0,
                                    endIndex: 4,
                                    text: 'This'
                                },
                            ],
                            audioHighlightTimeStart: 35.5 + (3.5 / 15) * 0
                        },
                        {
                            id: 'highlightId2',
                            highlightTexts: [
                                {
                                    speaker: 'Allstate',
                                    chunkIndex: 1,
                                    beginIndex: 0,
                                    endIndex: 4,
                                    text: 'This'
                                }
                            ],
                            audioHighlightTimeStart: 15.5 + (3.5 / 15) * 0
                        },
                    ]
                }],
                highlightMode: true,
            });
            wrapper.instance().isRightToLeft = jest.fn().mockReturnValue(false);
            document.getElementById = jest.fn().mockReturnValue({
                innerHTML: {length: 5},
                innerText: 'mocked',
                style: {},
                children: [
                    {id: 'chunk0-text0'},
                    {id: 'chunk0-text5-highlight0'},
                    {id: 'chunk0-text7'},
                ],
                getBoundingClientRect: jest.fn().mockReturnValue({left: 15, top: 55, height: 10})
            });
        });

        it('should render by default passing appropriate props', () => {
            const options = [
                {label: 'Loss Address', value: 'loss-address'},
                {label: 'Road Attributes', value: 'road-attributes'},
                {label: 'Condition of Roadway', value: 'condition-of-roadway'},
                {label: 'Weather', value: 'weather'},
                {label: 'Traffic Control Measures', value: 'traffic-control-measures'},
                {label: 'Amount of Traffic', value: 'amount-of-traffic'},
                {label: 'Time of Day', value: 'time-of-day'},
                {label: 'Direction of Travel', value: 'direction-of-travel'},
                {label: 'Participant Speed', value: 'participant-speed'},
                {label: 'Point of Impact', value: 'point-of-impact'},
                {label: 'Damages', value: 'damages'},
                {label: 'Driver Actions', value: 'driver-actions'},
                {label: 'Injuries', value: 'injuries'},
                {label: 'Other', value: 'other'},
            ];

            wrapper.instance().setState({evidenceMenu: {}});
            expect(wrapper.find('EvidenceMenu').props().columns).toBe(2);
            expect(wrapper.find('EvidenceMenu').props().options).toEqual(options);
            expect(wrapper.find('EvidenceMenu').props().isActive).toBe(false);
            expect(wrapper.find('EvidenceMenu').props().align).toBe('center');
            expect(wrapper.find('EvidenceMenu').props().position).toBe('top');
            expect(wrapper.find('EvidenceMenu').props().positioning).toEqual({});
        });

        it('should pass prop when chunk is highlighted', () => {
            const getBoundingClientRect = id => {
                if (id === 'transcript-content') {
                    return jest.fn().mockReturnValue({top: 1000});
                }
                return jest.fn().mockReturnValue({top: 1251});
            };
            document.getElementById.mockImplementation(id => {
                return {
                    innerHTML: {length: 5},
                    innerText: 'mocked',
                    style: {},
                    children: [
                        {id: 'chunk0-text0'},
                        {id: 'chunk0-text5-highlight0'},
                        {id: 'chunk0-text7'},
                    ],
                    getBoundingClientRect: getBoundingClientRect(id)
                }
            });
            window.getSelection.mockReturnValue({
                anchorOffset: 8,
                focusOffset: 16,
                anchorNode: {
                    parentNode: {
                        id: 'chunk1-text0'
                    }
                },
                focusNode: {
                    parentNode: {
                        id: 'chunk1-text0'
                    }
                }
            });

            wrapper.instance().addHighlight(mockEvent);
            expect(wrapper.find('EvidenceMenu').props().isActive).toBe(true);
            expect(wrapper.find('EvidenceMenu').props().position).toBe('top');

            expect(document.getElementById).toBeCalledWith('chunk1');
        });

        it('should clear evidenceMenu state to empty onClose', () => {
            wrapper.instance().setState({evidenceMenu: {category: "damages"}});

            wrapper.find('EvidenceMenu').simulate('close');
            expect(wrapper.find('EvidenceMenu').props().isActive).toBe(false);
            expect(wrapper.find('EvidenceMenu').props().selected).toBe('');
            expect(wrapper.instance().state.evidenceMenu.category).toBe(undefined);
        });

        it('should update the evidence category and close the evidence menu when an option is selected', () => {
            wrapper.instance().setState({
                evidenceMenu: {
                    refId: 'chunk1-text6-highlight0',
                    positioning: {top: '1000px', left: '250px'}
                }
            });
            wrapper.find('EvidenceMenu').simulate('select', 'something else');

            const expected = {
                id: 'evidenceId1',
                sourceId: 'highlightId1',
                type: 'highlight',
                category: 'something else',
                participantDisplayName: 'JOE BOB',
                participantSourceId: '1',
                transcriptCreatedDate: '2019-03-08T14:26:41',
                callType: 'my call type',
                sourceVoiceId: 'voiceId',
                highlightTexts: [{
                    'beginIndex': 0,
                    'chunkIndex': 3,
                    'endIndex': 4,
                    'speaker': 'Allstate',
                    'text': 'This'
                }]
            };
            expect(mockSaveEvidenceAction).toBeCalledWith('123456789000', expected);
            expect(wrapper.find('EvidenceMenu').props().isActive).toBe(false);
        });

        it('should close the evidence menu and not update the evidence category when the same option is selected', () => {
            mockSaveEvidenceAction.mockReset();
            wrapper.instance().setState({
                evidenceMenu: {
                    refId: 'chunk1-text6-highlight0',
                    category: 'damages',
                    positioning: {top: '1000px', left: '250px'}
                }
            });
            wrapper.find('EvidenceMenu').simulate('select', 'damages');

            expect(mockSaveEvidenceAction).not.toBeCalled();
            expect(wrapper.find('EvidenceMenu').props().isActive).toBe(false);
        });

        it('should open the evidence menu when handleHighlightClick is called', () => {
            let mockTooltip = {
                style: {visibility: 'notHidden'},
                getBoundingClientRect: jest.fn().mockReturnValue({})
            };
            document.getElementById = jest.fn().mockReturnValue(mockTooltip);
            wrapper.instance().setState({evidenceMenu: {}});
            wrapper.find('Chunk').get(0).props.handleHighlightClick({target: {id: 'chunk0-text0-highlight0'}});
            expect(wrapper.find('EvidenceMenu').props().isActive).toBe(true);
            expect(wrapper.find('EvidenceMenu').props().selected).toBe('loss-address');

            expect(document.getElementById).toBeCalledWith('edit-evidence-tooltip');
            expect(mockTooltip.style.visibility).toBe('hidden');
        });

        it('should pass evidence menu align as right when there is not enough space on the right', () => {
            document.getElementById.mockImplementation(id => {
                if (id === 'transcript-content') {
                    return {
                        getBoundingClientRect: jest.fn().mockReturnValue({right: 1500, x: 100})
                    };
                }
                return {
                    clientHeight: 1000
                };
            });
            const mockEvent = {pageX: 1200, pageY: 600};
            wrapper.instance().setEvidenceMenuState(mockEvent, 'chunk0-text0-highlight0');

            expect(wrapper.find('EvidenceMenu').props().align).toBe('right');
        });

        it('should remove highlight and tag on click of trash icon', () => {
            wrapper.instance().setState({
                evidenceMenu: {
                    refId: 'chunk0-text0-highlight1',
                    evidenceCategory: 'something',
                    positioning: {
                        top: '1000px',
                        left: '200px'
                    }
                }
            });

            const highlightEntities = [
                {
                    id: 'highlightId1',
                    highlightTexts: [
                        {
                            speaker: 'Allstate',
                            chunkIndex: 3,
                            beginIndex: 0,
                            endIndex: 4,
                            text: 'This'
                        },
                    ],
                    audioHighlightTimeStart: 35.5 + (3.5 / 15) * 0
                }
            ];
            const evidences = [
                {
                    id: 'evidenceId1',
                    sourceId: 'highlightId1',
                    type: 'highlight',
                    category: 'loss-address',
                    callType: 'my call type',
                    highlightTexts: [
                        {
                            speaker: 'Allstate',
                            chunkIndex: 3,
                            beginIndex: 0,
                            endIndex: 4,
                            text: 'This'
                        },
                    ],
                    sourceVoiceId: 'voiceId',
                    transcriptCreatedDate: '2019-03-08T14:26:41',
                    participantDisplayName: 'JOE BOB',
                    participantSourceId: '1',
                },
                {id: 'evidenceId2', sourceId: 'photoId', type: 'photo'}
            ];
            let newInvolvedParty = {
                participantId: '1',
                participantSourceId: '11',
                assetId: 'asset1',
                damageSections: [
                    'front',
                    'rear'
                ],
                contributingFactors: [
                    {
                        category: null,
                        reason: 'proper-lookout',
                        details: 'saw-other-party',
                        evidenceIds: ['evidenceId1', 'evidence5']
                    }
                ],
                affectedParties: [
                    {
                        participantId: '2',
                        participantSourceId: '22',
                        assetId: 'B9763FCB7D843B1F',
                        passengerPartyIds: [],
                        affectedPercent: 12,
                        beginNegotiatingRange: 7,
                        endNegotiatingRange: 17,
                        submittedAffectedPercent: 12,
                        faultAllocationPercent: 1
                    }
                ]
            };

            const newEvents = [{
                id: '0',
                title: 'my first event title',
                severity: 1,
                involvedParties: [newInvolvedParty]
            }];
            wrapper.find('EvidenceMenu').simulate('removeClick');
            expect(mockSaveHighlightAction).toBeCalledWith('123456789000', 'voiceId', highlightEntities, evidences, newEvents);
            expect(wrapper.find('EvidenceMenu').props().isActive).toBe(false);
            expect(wrapper.find('EvidenceMenu').props().selected).toBe('');
            expect(wrapper.instance().state.evidenceMenu.category).toBe(undefined);
        });

        describe('Evidence confirmation tooltip', () => {
            it('should render with Evidence Added and Tagged text when evidence category is added', () => {
                const tooltip = {
                    style: {top: '50px', left: '100px', visibility: 'hidden'},
                    innerText: 'text',
                };
                document.getElementById.mockImplementation(id => {
                    if (id === 'evidence-confirmation-tooltip') {
                        return tooltip;
                    }
                    return {
                        style: {},
                        getBoundingClientRect: jest.fn().mockReturnValue({})
                    }
                });
                wrapper.instance().setState({
                    evidenceMenu: {
                        refId: 'chunk1-text6-highlight0',
                        category: undefined,
                        positioning: {top: '1000px', left: '250px'}
                    }
                });

                wrapper.find('EvidenceMenu').simulate('select', 'injuries');
                expect(tooltip.style.top).toEqual('1200px');
                expect(tooltip.style.left).toEqual('425px');
                expect(tooltip.style.visibility).toEqual('visible');
                expect(tooltip.innerText).toEqual('Evidence Added and Tagged');

                setTimeout(() => {
                    it('should change visibility to hidden after 2 seconds', () => {
                        expect(tooltip.style.visibility).toEqual('hidden');
                    });
                }, 2001);
            });

            it('should render with Evidence Tagged text when evidence category is updated', () => {
                const tooltip = {
                    style: {top: '50px', left: '100px', visibility: 'hidden'},
                    innerText: 'text',
                };
                document.getElementById.mockImplementation(id => {
                    if (id === 'evidence-confirmation-tooltip') {
                        return tooltip;
                    }
                    return {
                        style: {},
                        getBoundingClientRect: jest.fn().mockReturnValue({})
                    }
                });
                wrapper.instance().setState({
                    evidenceMenu: {
                        refId: 'chunk1-text6-highlight0',
                        category: 'damages',
                        positioning: {top: '1000px', left: '250px'}
                    }
                });

                wrapper.find('EvidenceMenu').simulate('select', 'injuries');
                expect(tooltip.style.top).toEqual('1200px');
                expect(tooltip.style.left).toEqual('425px');
                expect(tooltip.style.visibility).toEqual('visible');
                expect(tooltip.innerText).toEqual('Evidence Tagged');

                setTimeout(() => {
                    it('should change visibility to hidden after 2 seconds', () => {
                        expect(tooltip.style.visibility).toEqual('hidden');
                    });
                }, 2001);
            });

            it('should render with Evidence removed text when evidence category is removed', () => {
                const tooltip = {
                    style: {top: '50px', left: '100px', visibility: 'hidden'},
                    innerText: 'text',
                };
                document.getElementById.mockImplementation(id => {
                    if (id === 'evidence-confirmation-tooltip') {
                        return tooltip;
                    }
                    return {
                        style: {},
                        getBoundingClientRect: jest.fn().mockReturnValue({})
                    };
                });
                wrapper.instance().setState({
                    evidenceMenu: {
                        refId: 'chunk1-text6-highlight0',
                        positioning: {top: '1000px', left: '250px'}
                    },
                });

                wrapper.find('EvidenceMenu').simulate('removeClick', 'injuries');
                expect(tooltip.style.top).toEqual('1200px');
                expect(tooltip.style.left).toEqual('425px');
                expect(tooltip.style.visibility).toEqual('visible');
                expect(tooltip.innerText).toEqual('Evidence Removed');

                setTimeout(() => {
                    it('should change visibility to hidden after 2 seconds', () => {
                        expect(tooltip.style.visibility).toEqual('hidden');
                    });
                }, 2001);
            });
        });

        describe('Edit Evidence Tooltip', () => {
            it('renders a tooltip', () => {
                expect(wrapper.find('.edit-evidence-tooltip').text()).toEqual('Edit Evidence');
            });

            it('should display the evidenceCategory state value in the tooltip', () => {
                wrapper.setState({evidenceMenu: {category: 'loss-address'}});
                expect(wrapper.find('#evidence-category-tooltip').text()).toEqual('Loss Address');
                expect(wrapper.find('.edit-evidence-tooltip').text()).toEqual('Loss AddressEdit Evidence');
            });

            describe('componentDidMount and componentWillUnmount', () => {
                it('calls window.addEventListener with mousemove and positionEditEvidenceTooltip method on componentDidMount', () => {
                    window.addEventListener.mockReset();
                    wrapper.instance().componentDidMount();
                    expect(window.addEventListener).toHaveBeenCalledWith('mousemove', wrapper.instance().positionEditEvidenceTooltip);
                });

                it('calls window.removeEventListener with mousemove and positionEditEvidenceTooltip method on componentWillUnmount ', () => {
                    window.removeEventListener.mockReset();
                    wrapper.instance().componentWillUnmount();
                    expect(window.removeEventListener).toHaveBeenCalledWith('mousemove', wrapper.instance().positionEditEvidenceTooltip);
                });
            });

            it('should set visibility to visible when highlightMode is true and it enters a highlight,' +
                'using 60 as offset for tooltipTop when highlight has evidence category', () => {
                let mockTooltip = {
                    style: {top: '3px', left: '3px', visibility: 'hidden'},
                    getBoundingClientRect: jest.fn().mockReturnValue({left: 15, top: 55})
                };
                let mockEvent = {
                    pageX: 80,
                    pageY: 100,
                    target: {id: 'chunk0-text0-highlight0', classList: {contains: () => true}}
                };
                document.getElementById = jest.fn().mockImplementation(id => {
                    switch (id) {
                        case('google-map'):
                        case('liability-analysis--container'):
                            return {clientHeight: 10};
                        default:
                            return mockTooltip;
                    }
                });

                document.body.getBoundingClientRect = jest.fn().mockReturnValue({left: 5, top: 5});

                wrapper.instance().positionEditEvidenceTooltip(mockEvent);

                expect(mockTooltip.style.left).toBe('45px');
                expect(mockTooltip.style.top).toBe('20px');
                expect(mockTooltip.style.visibility).toBe('visible');
            });

            it('should set visibility to visible when highlightMode is true and it enters a highlight,' +
                'using 45 as offset for tooltipTop when highlight has no evidence category', () => {
                let mockTooltip = {
                    style: {top: '3px', left: '3px', visibility: 'hidden'},
                    getBoundingClientRect: jest.fn().mockReturnValue({left: 15, top: 55})
                };
                let mockEvent = {
                    pageX: 80,
                    pageY: 100,
                    target: {id: 'chunk0-text0-highlight1', classList: {contains: () => true}}
                };
                document.getElementById = jest.fn().mockImplementation(id => {
                    switch (id) {
                        case('google-map'):
                        case('liability-analysis--container'):
                            return {clientHeight: 10};
                        default:
                            return mockTooltip;
                    }
                });

                document.body.getBoundingClientRect = jest.fn().mockReturnValue({left: 5, top: 5});

                wrapper.instance().positionEditEvidenceTooltip(mockEvent);

                expect(mockTooltip.style.left).toBe('45px');
                expect(mockTooltip.style.top).toBe('35px');
                expect(mockTooltip.style.visibility).toBe('visible');
            });

            it('should set visibility to hidden when highlightMode is true and it enters a non-highlight', () => {
                let mockTooltip = {style: {top: '3px', left: '3px', visibility: 'hidden'}};
                let mockEvent = {pageX: 80, pageY: 100, target: {classList: {contains: () => false}}};
                document.getElementById = jest.fn().mockReturnValue(mockTooltip);

                document.body.getBoundingClientRect = jest.fn().mockReturnValue({left: 5, top: 5});

                wrapper.instance().positionEditEvidenceTooltip(mockEvent);

                expect(mockTooltip.style.left).toBe('3px');
                expect(mockTooltip.style.top).toBe('3px');
                expect(mockTooltip.style.visibility).toBe('hidden');
            });

            it('should set visibility to hidden when highlightMode is true and it enters a non-highlight', () => {
                let mockTooltip = {style: {top: '3px', left: '3px', visibility: 'visible'}};
                let mockEvent = {pageX: 80, pageY: 100, target: {classList: {contains: () => false}}};
                document.getElementById = jest.fn().mockReturnValue(mockTooltip);
                document.body.getBoundingClientRect = jest.fn().mockReturnValue({left: 5, top: 5});

                wrapper.instance().positionEditEvidenceTooltip(mockEvent);

                expect(mockTooltip.style.left).toBe('3px');
                expect(mockTooltip.style.top).toBe('3px');
                expect(mockTooltip.style.visibility).toBe('hidden');
            });

            it('do set visibility to hidden when highlightMode is false', () => {
                let mockTooltip = {
                    style: {top: '3px', left: '3px', visibility: 'visible'},
                    getBoundingClientRect: jest.fn().mockReturnValue({left: 15, top: 55})
                };
                let mockEvent = {pageX: 80, pageY: 100, target: {classList: {contains: () => false}}};

                document.getElementById = jest.fn().mockReturnValue(mockTooltip);
                document.body.getBoundingClientRect = jest.fn().mockReturnValue({left: 5, top: 5});
                wrapper.setProps({highlightMode: false});

                wrapper.instance().positionEditEvidenceTooltip(mockEvent);

                expect(mockTooltip.style.left).toBe('3px');
                expect(mockTooltip.style.top).toBe('3px');
                expect(mockTooltip.style.visibility).toBe('hidden');
            });

            it('should set category state to the evidence category in the edit evidence tooltip ', () => {
                let mockTooltip = {
                    style: {top: '3px', left: '3px', visibility: 'hidden'},
                    getBoundingClientRect: jest.fn().mockReturnValue({left: 15, top: 55})
                };
                let mockEvent = {
                    pageX: 80,
                    pageY: 100,
                    target: {id: 'chunk0-text0-highlight0', classList: {contains: () => true}}
                };
                document.getElementById = jest.fn().mockReturnValue(mockTooltip);
                document.body.getBoundingClientRect = jest.fn().mockReturnValue({left: 5, top: 5});

                wrapper.instance().positionEditEvidenceTooltip(mockEvent);

                expect(wrapper.instance().state.evidenceMenu.category).toBe('loss-address');
            });

            it('should not render when evidence menu is open', () => {
                let mockTooltip = {
                    style: {visibility: 'notHidden'},
                    getBoundingClientRect: jest.fn().mockReturnValue({})
                };
                document.getElementById = jest.fn().mockReturnValue(mockTooltip);
                wrapper.instance().setState({evidenceMenu: {positioning: {}}});

                wrapper.instance().positionEditEvidenceTooltip();
                expect(mockTooltip.style.visibility).toBe('hidden');
            });
        });

        describe('Connect', () => {
            it('mapStateToProps', () => {
                const state = {
                    claimData: {
                        claimNumber: '123',
                        voiceAttachments: mockVoiceAttachments,
                        evidences: mockEvidences,
                        events: events
                    },
                    transcripts: {sourceVoiceId: []}
                };
                const result = mapStateToProps(state);
                expect(result.voiceAttachments).toEqual(mockVoiceAttachments);
                expect(result.evidences).toEqual(mockEvidences);
                expect(result.transcripts).toEqual({sourceVoiceId: []});
                expect(result.events).toEqual(events);
            });

            it('mapDispatchToProps', () => {
                expect(mapDispatchToProps.saveHighlightAction).toEqual(saveHighlightAction);
                expect(mapDispatchToProps.saveEvidenceAction).toEqual(saveEvidenceAction);
            });
        });
    });
});
