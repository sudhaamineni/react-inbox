jest.unmock('../../../src/main/components/investigation/AssetDamages');

import {shallow} from 'enzyme';
import React from 'react';

import AssetDamages from '../../../src/main/components/investigation/AssetDamages';

describe('Asset Damages', () => {
    describe('Given damages prop not available', () => {
        let wrapper;
        beforeEach(() => {
            wrapper = shallow(
                <AssetDamages
                    damages={[]}
                />
            );
        });

        it('renders not available message', () => {
            expect(wrapper.find("#noAssetDamages").text()).toBe("No damages available.");
        });
    });

    describe('Given damages prop is available', () => {
        let wrapper;
        beforeEach(() => {
            wrapper = shallow(
                <AssetDamages
                    damages={[
                        {
                            "damageArea": "FRONT",
                            "damageParts": [
                                "Bumper",
                                "Grille"
                            ]
                        },
                        {
                            "damageArea": "MECHANICAL",
                            "damageParts": [
                                "Exhaust System",
                                "Fuel Tank"
                            ]
                        }
                    ]}
                />
            );
        });

        it('renders damage area headers', () => {
            expect(wrapper.find('#damage-area0').text()).toBe('FRONT');
            expect(wrapper.find('#damage-area1').text()).toBe('MECHANICAL');
        });

        it('renders damage parts', () => {
            expect(wrapper.find('#damage-area0-part0').text()).toBe('Bumper');
            expect(wrapper.find('#damage-area0-part1').text()).toBe('Grille');

            expect(wrapper.find('#damage-area1-part0').text()).toBe('Exhaust System');
            expect(wrapper.find('#damage-area1-part1').text()).toBe('Fuel Tank');
        });
    });
});