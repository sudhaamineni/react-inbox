import {shallow} from 'enzyme';
import React from 'react';
import {
    mapDispatchToProps,
    mapStateToProps,
    TranscriptSection
} from '../../../src/main/components/investigation/TranscriptSection';
import {saveReportedPciAction} from '../../../src/main/actions/claimDataActions';
import {convertZuluTimeToLocalTime} from '../../../src/main/helpers/dateTimeHelper';

jest.unmock('../../../src/main/components/investigation/TranscriptSection');
jest.unmock('../../../src/main/helpers/claimDataHelper');

describe('Given TranscriptSection component', () => {
    let wrapper;
    let mockSaveReportedPciAction = jest.fn();

    const mockVoiceAttachments = [{
        sourceVoiceId: 'voiceId',
        sourceTranscriptUrl: '/transcriptId',
        reportedPciDate: null,
    }, {
        sourceVoiceId: 'voiceId2',
        sourceTranscriptUrl: '/transcriptId2',
        reportedPciDate: 'someReportedDate',
    }];
    const mockTranscriptContentStyle = {
        maxHeight: '800px',
        overflowY: 'auto',
        scrollBehavior: 'smooth',
        borderTop: 'solid 1px #d6d6d6'
    };
    const mockTranscripts = {
        voiceId: [{text: 'My text'}],
        success: ['voiceId', 'voiceId2'],
        errors: [],
        nlp: {
            voiceId: [
                {
                    categoryName: 'Category 2',
                    categoryIndices: [
                        {
                            startIndex: 0,
                            endIndex: 21,
                            text: 'Some sample data here',

                        },
                        {
                            startIndex: 31,
                            endIndex: 50,
                            text: 'Some more data here',

                        },
                    ]
                },
                {
                    categoryName: 'Category 1',
                    categoryIndices: [
                        {
                            startIndex: 100,
                            endIndex: 126,
                            text: 'Some more sample data here',

                        },
                    ]
                },
                {categoryName: 'Category 3'}
            ],
            voiceId2: []
        }
    };
    const mockSetSeekTo = jest.fn();
    const mockTogglePlayPause = jest.fn();

    beforeEach(() => {
        wrapper = shallow(
            <TranscriptSection
                claimNumber="123"
                participantIndex={0}
                audioPlaying={false}
                audioIndex={0}
                elapsedTime={1.11}
                togglePlayPause={mockTogglePlayPause}
                onSetSeekTo={mockSetSeekTo}
                transcriptContentStyle={mockTranscriptContentStyle}
                retrievingAttachments={false}
                voiceAttachments={mockVoiceAttachments}
                transcripts={mockTranscripts}
                highlightMode={false}
                filterMode={false}
                readOnly={false}
                saveReportedPciAction={mockSaveReportedPciAction}
            />
        );
    });

    it('should initialize state', () => {
        expect(wrapper.instance().state).toEqual({
            autoScroll: true,
            highlightMode: false,
            filterMode: true,
            nlpCategory: '',
            nlpCategoryIndex: 0,
            showSensitiveModal: false,
        });
    });

    describe('and Transcript component', () => {
        it('should pass the props', () => {
            expect(wrapper.find('Connect(Transcript)').props().claimNumber).toBe('123');
            expect(wrapper.find('Connect(Transcript)').props().audioPlaying).toBe(false);
            expect(wrapper.find('Connect(Transcript)').props().audioIndex).toBe(0);
            expect(wrapper.find('Connect(Transcript)').props().elapsedTime).toBe(1.11);
            expect(wrapper.find('Connect(Transcript)').props().autoScroll).toBe(true);
            expect(wrapper.find('Connect(Transcript)').props().highlightMode).toBe(false);
            expect(wrapper.find('Connect(Transcript)').props().nlpCategory).toBe('');
            expect(wrapper.find('Connect(Transcript)').props().nlpCategoryIndex).toBe(0);

            expect(wrapper.find('#transcriptLabel').props().children).toBe('Transcript');
            expect(wrapper.find('#miniAudioPlayerImage').props().className).toContain('play-icon');
            expect(wrapper.find('Connect(Highlighter)').length).toBe(1);
        });

        it('should call togglePlayPause when togglePlayPause prop is invoked', () => {
            wrapper.find('Connect(Transcript)').props().togglePlayPause();
            expect(mockTogglePlayPause).toBeCalled();
        });

        it('should call setSeekTo when setSeekTo prop is invoked', () => {
            wrapper.find('Connect(Transcript)').simulate('setSeekTo', 1.8);
            expect(mockSetSeekTo).toBeCalledWith(1.8);
        });

        it('renders with transcript-content of max height as 800px', () => {
            expect(wrapper.find('#transcript-content').props().style).toEqual({
                maxHeight: '800px',
                overflowY: 'auto',
                scrollBehavior: 'smooth',
                borderTop: 'solid 1px #d6d6d6',
            });
        });

        it('renders a pause icon when transcript playback is running', () => {
            wrapper.setProps({audioPlaying: true});
            expect(wrapper.find('#miniAudioPlayerImage').props().className).toContain('pause-icon');
        });

        it('invokes the togglePlayPause prop when the play icon is clicked ', () => {
            wrapper.find('#miniAudioPlayerImage').simulate('click');
            expect(mockTogglePlayPause).toBeCalled();
        });
    });

    it('should render the loading section when attachments are being retrieved', () => {
        wrapper.setProps({retrievingAttachments: true});
        expect(wrapper.find('Loader').length).toBe(1);
    });

    it('should render the loading section when transcripts are being retrieved', () => {
        wrapper.setProps({retrievingAttachments: false, transcripts: {success: [], errors: []}});
        expect(wrapper.find('Loader').length).toBe(1);
    });

    it('should render the empty transcript section', () => {
        wrapper.setProps({voiceAttachments: [{someOtherProperty: ''}]});
        expect(wrapper.find('#empty-transcript-title').text()).toBe('Transcript');
        expect(wrapper.find('#empty-transcript').text()).toBe('No transcripts available');
        expect(wrapper.find('Icon').props().icon).toBe('request');
        expect(wrapper.find('#empty-transcript-req-info').text()).toBe('Request Information');
    });

    describe('and when there is an error retrieving a transcript', () => {
        beforeEach(() => {
            wrapper.setProps({
                transcripts: {
                    success: [],
                    errors: ['voiceId'],
                }
            });
        });

        it('renders the transcript error section', () => {
            expect(wrapper.find('#transcript-error-title').text()).toBe('Transcript');
            expect(wrapper.find('#unable-to-load').text()).toBe('Unable to load transcript');
            expect(wrapper.find('#transcript-file-alert').props().icon).toEqual('file-alert');
        });

        it('renders Try again later or refresh message', () => {
            expect(wrapper.find('#try-again').text()).toBe('Try again later or ');
            expect(wrapper.find('#transcript-refresh').props().children).toBe('Refresh');
            expect(wrapper.find('#transcript-refresh').props().to).toBe('/investigate?scrollTo=investigation-page--participants');
        });
    });

    describe('and Highlighter component', () => {
        it('should pass the props', () => {
            expect(wrapper.find('Connect(Highlighter)').props().highlightMode).toBe(false);
        });

        it('should update state when highlighter button is clicked', () => {
            wrapper.find('Connect(Highlighter)').props().toggleHighlight();
            expect(wrapper.instance().state.autoScroll).toBe(false);
            expect(wrapper.instance().state.highlightMode).toBe(true);
        });
    });

    describe('and NLP filter button', () => {
        it('should have the right label and icon', () => {
            expect(wrapper.find('.c-btn--show-transcript-filters__text').text()).toBe('Filter Transcript');
            expect(wrapper.find('#filterTranscriptLabel').find('Icon').props().icon).toBe('filter');
        });

        it('should render Hide button with correct styles when filterMode is true', () => {
            expect(wrapper.find('button').props().className.includes('c-btn--show-transcript-filters--active')).toBe(true);
        });

        it('should render Hide button with correct styles when filterMode is false', () => {
            wrapper.setState({filterMode: false});
            expect(wrapper.find('button').props().className.includes('c-btn--show-transcript-filters')).toBe(true);
        });

        it('should change the filterMode on click', () => {
            wrapper.find('button').simulate('click');
            expect(wrapper.instance().state.filterMode).toBe(false);
            wrapper.find('button').simulate('click');
            expect(wrapper.instance().state.filterMode).toBe(true);
        });
    });

    describe('Report Sensitive Information', () => {
        it('should render Report sensitive information label and icon', () => {
            wrapper.find('#reportSensitiveInfoLabel').text('Report sensitive information');
            expect(wrapper.find('#reportSensitiveInfoLabel').find('Icon').props().icon).toBe('danger-recognition');
        });

        it('should show PCI Modal when Report Sensitive Information is clicked', () => {
            wrapper.find('#reportSensitiveInfoLabel').simulate('click');
            expect(wrapper.find('PCIModal').exists()).toBe(true);
        });

        it('should hide PCI Modal when Report button is clicked in modal', () => {
            wrapper.find('#reportSensitiveInfoLabel').simulate('click');
            wrapper.setProps({voiceAttachment: {sourceVoiceId: 'voiceId', transcriptId: 'transcriptId'}});

            expect(wrapper.find('PCIModal').exists()).toBe(true);
            wrapper.find('PCIModal').simulate('submit');
            expect(mockSaveReportedPciAction).toBeCalledWith('123', 'voiceId', 'transcriptId', undefined);
            expect(wrapper.find('PCIModal').exists()).toBe(false);
        });

        it('should hide PCI Modal when modal is closed via close button', () => {
            wrapper.find('#reportSensitiveInfoLabel').simulate('click');
            wrapper.setProps({voiceAttachment: {sourceVoiceId: 'voiceId', transcriptId: 'transcriptId'}});

            expect(wrapper.find('PCIModal').exists()).toBe(true);
            wrapper.find('PCIModal').simulate('close');
            expect(wrapper.find('PCIModal').exists()).toBe(false);
        });

        it('should render PCI Modal as read only if read only is set to true', () => {
            wrapper.setProps({readOnly: true});
            wrapper.find('#reportSensitiveInfoLabel').simulate('click');
            expect(wrapper.find('PCIModal').props().readOnly).toBe(true);
        });

        it('should only show reportedSensitiveInformationLabel when reportedPci is true', () => {
            convertZuluTimeToLocalTime.mockReturnValue('Wed. Aug 06, 2017 12:12PM CDT');
            wrapper.setProps({audioIndex:1});
            expect(wrapper.find('#reported-sensitive-label').props().children).toContain('Sensitive Information Reported');
            expect(wrapper.find('#reported-sensitive-icon').find('Icon').props().icon).toBe('danger-recognition');
            expect(wrapper.find('#reported-sensitive-icon').find('Icon').props().color).toBe('loon-gray-dark');
            expect(wrapper.find('#reported-sensitive-date-label').props().children).toBe('Wed. Aug 06, 2017 12:12PM CDT');
        });

        it('should only render reportedSensitiveInformationLabel', () => {
            wrapper.setProps({audioIndex: 1});
        });
    });

    describe('and FilterList component', () => {
        describe('when filter mode is on', () => {
            it('should pass items prop based on categories', () => {
                const expected = [
                    {value: 'Category 1', label: 'Category 1', matches: 1},
                    {value: 'Category 2', label: 'Category 2', matches: 2},
                    {value: 'Category 3', label: 'Category 3', matches: 0},
                ];
                expect(wrapper.find('FilterList').props().items).toEqual(expected);
            });

            it('should update state when a category is selected', () => {
                wrapper.find('FilterList').props().onSelect('Category', 1);
                expect(wrapper.instance().state.autoScroll).toBe(false);
                expect(wrapper.instance().state.nlpCategory).toBe('Category');
                expect(wrapper.instance().state.nlpCategoryIndex).toBe(1);
            });

            it('should update state when the selected category is closed', () => {
                wrapper.find('FilterList').props().onClose();
                expect(wrapper.instance().state.autoScroll).toBe(false);
                expect(wrapper.instance().state.nlpCategory).toBe('');
                expect(wrapper.instance().state.nlpCategoryIndex).toBe(0);
            });

            it('should update state on next arrow click of the selected category', () => {
                wrapper.instance().setState({
                    nlpCategory: 'Category'
                });
                wrapper.find('FilterList').props().onNextClick(1);
                expect(wrapper.instance().state.autoScroll).toBe(false);
                expect(wrapper.instance().state.nlpCategory).toBe('Category');
                expect(wrapper.instance().state.nlpCategoryIndex).toBe(1);
            });

            it('should update state on previous arrow click of the selected category', () => {
                wrapper.instance().setState({
                    nlpCategory: 'Category'
                });
                wrapper.find('FilterList').props().onPrevClick(1);
                expect(wrapper.instance().state.autoScroll).toBe(false);
                expect(wrapper.instance().state.nlpCategory).toBe('Category');
                expect(wrapper.instance().state.nlpCategoryIndex).toBe(1);
            });
        });

        it('should not render when filter mode is off', () => {
            wrapper.setState({filterMode: false});
            expect(wrapper.find('FilterList').length).toEqual(0);
        });
    });

    describe('Connect', () => {
        describe('mapStateToProps', () => {
            const state = {
                claimData: {
                    claimNumber: '123',
                    voiceAttachments: mockVoiceAttachments
                },
                transcripts: {voiceId: []},
                status: {retrievingAttachments: true}
            };
            const router = {location: {search: '?scrollTo=transcript&c=d&highlightMode=on'}};

            it('maps required store items to props', () => {
                const result = mapStateToProps(state, router);
                expect(result.retrievingAttachments).toEqual(true);
                expect(result.voiceAttachments).toEqual(mockVoiceAttachments);
                expect(result.transcripts).toEqual({voiceId: []});
                expect(result.highlightMode).toEqual(true);
            });
        });

        describe('mapDispatchToProps', () => {
            it('should have saveReportedPciAction', () => {
                expect(mapDispatchToProps.saveReportedPciAction).toEqual(saveReportedPciAction);
            });
        });
    });
});
