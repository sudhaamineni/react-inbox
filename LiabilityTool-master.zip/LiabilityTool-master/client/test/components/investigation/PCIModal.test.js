import {shallow} from 'enzyme';
import React from 'react';
import PCIModal from '../../../src/main/components/investigation/PCIModal';

jest.unmock('../../../src/main/components/investigation/PCIModal');
jest.unmock('../../../src/main/helpers/claimDataHelper');
jest.unmock('../../../src/main/constants/loonConstants');


describe('Given TranscriptSection component', () => {
    let wrapper;

    let mockOnSubmit = jest.fn();
    let mockOnClose = jest.fn();

    const expectedPciOptions = [
        { displayText: 'Credit Card/Debit Card Number', value: 'creditCardNumber' },
        { displayText: 'Social Security Number', value: 'socialSecurityNumber' },
        { displayText: 'Driver\'s License Number', value: 'driversLicense' },
    ];

    beforeEach(() => {
        wrapper = shallow(
            <PCIModal
                readOnly={false}
                onSubmit={mockOnSubmit}
                onClose={mockOnClose}
            />
        );
    });

    describe('Report button', () => {
        it('should render a button with the word Report', () => {
            expect(wrapper.find('ModalDialog').props().footer.props.children
                .props.children.props.children).toBe('Report');
        });

        it('should disable the report button when the user has not selected any values', () => {
            expect(wrapper.find('ModalDialog').props().footer.props.children
                .props.children.props.disabled).toBe(true);

            wrapper.find('FormOption').at(0).props().onChange();

            expect(wrapper.find('ModalDialog').props().footer.props.children
                .props.children.props.disabled).toBe(false);

        });

        it('should call the onSubmit callback and pass the selected options when the Report button is clicked', () => {
            wrapper.find('FormOption').at(0).props().onChange();

            wrapper.find('ModalDialog').props().footer.props.children
                .props.children.props.onClick();
            expect(mockOnSubmit).toBeCalledWith(['creditCardNumber']);

        });
    });

    describe('modal dialog text and checkboxes', () => {
        it('should render a checkbox for each pciOption', () => {
            expect(wrapper.find('FormOption').length).toBe(expectedPciOptions.length);

        });

        expectedPciOptions.forEach((option, index) => {
            it(`should render ${option.displayText}`, () => {
                expect(wrapper.find('FormOption').at(index).props().children.props.children).toBe(option.displayText);
            });
        });

        describe('Read Only', () => {
            beforeEach(() => {
                wrapper = shallow(
                    <PCIModal
                        readOnly={true}
                        onSubmit={mockOnSubmit}
                        onClose={mockOnClose}
                    />
                );
            });

            it('should disable the checkboxes when read only', () => {
                expectedPciOptions.forEach((option, index) => {
                    expect(wrapper.find('FormOption').at(index).props().readOnly).toBe(true);
                });
            });
        });
    });
});
