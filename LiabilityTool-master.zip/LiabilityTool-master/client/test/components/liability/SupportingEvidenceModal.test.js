jest.unmock('../../../src/main/components/liability/SupportingEvidenceModal');
jest.unmock('../../../src/main/constants/loonConstants');
jest.unmock('../../../src/main/constants/contributingFactorConstants');
jest.unmock('lodash');

import React from 'react';
import {shallow} from 'enzyme';
import {
    mapDispatchToProps,
    mapStateToProps,
    SupportingEvidenceModal
} from '../../../src/main/components/liability/SupportingEvidenceModal';

import {getParticipantName, isReadOnly} from '../../../src/main/helpers/claimDataHelper';
import {setEventsValidationAction, updateEventAction} from '../../../src/main/actions/eventActions';
import {revalidateEvent} from '../../../src/main/helpers/eventValidationHelper';

describe('SupportingEvidenceModal', () => {
    let wrapper,
        mockOnClose,
        involvedParty,
        mockEvidences,
        mockUpdateEventAction,
        mockSetEventsValidationAction,
        liabilitySubjects,
        validateContributingFactorEvidence;

    validateContributingFactorEvidence = true;
    liabilitySubjects = [
        {
            role: 'INSURED',
            firstName: 'first1',
            lastName: 'last1',
            participantPartyId: '1',
            participantSourceId: '11',
            asset: {
                assetTypeDescription: 'Auto',
                vehicleItemId: 'asset1',
                vehicleMake: 'Honda',
                vehicleModel: 'Accord',
                vehicleYear: 2000,
            },
        },
        {
            role: 'CLAIMANT',
            firstName: 'first2',
            lastName: 'last2',
            participantPartyId: '2',
            participantSourceId: '22',
            asset: {
                assetTypeDescription: 'Motorcycle',
                vehicleItemId: 'asset2',
            }
        }
    ];

    involvedParty = {
        participantId: '1',
        participantSourceId: '11',
        assetId: 'asset1',
        damageSections: [
            'front',
            'rear'
        ],
        contributingFactors: [
            {
                category: null,
                reason: 'proper-lookout',
                details: 'saw-other-party',
                evidenceIds: ['evidence1', 'evidence5']
            }
        ],
        affectedParties: [
            {
                participantId: '2',
                participantSourceId: '22',
                assetId: 'B9763FCB7D843B1F',
                passengerPartyIds: [],
                initialFaultPercent: 12,
                beginNegotiatingRange: 7,
                endNegotiatingRange: 17,
                submittedInitialFaultPercent: 12,
                faultAllocationPercent: 1
            }
        ]
    };

    mockEvidences = [
        {id: 'evidence1', sourceId: 'highlight1', type: 'highlight', category: 'damages'},
        {id: 'evidence2', sourceId: 'highlight2', type: 'highlight', category: null},
        {
            id: 'evidence5',
            sourceId: 'photo3',
            type: 'photo',
            category: 'condition-of-roadway',
            photoUrl: 'my/photo3'
        },
        {id: 'evidence3', sourceId: 'photo1', type: 'photo', category: null, photoUrl: 'my/photo1'},
        {id: 'evidence4', sourceId: 'photo2', type: 'photo', category: null, photoUrl: 'my/photo2'},
        {id: 'evidence6', sourceId: 'highlight3', type: 'highlight', category: 'condition-of-roadway'}
    ];
    const event =
        {id: '0', title: 'my first event title', severity: 1, involvedParties: [involvedParty]};
    getParticipantName.mockReturnValue('Joe Bob');

    const eventsValidation = [{
        error: true,
        involvedParties: [{
            contributingFactors: [
                {
                    missingSupportingEvidenceError: true
                }]
        }]
    }];
    beforeEach(() => {
        mockOnClose = jest.fn();
        mockUpdateEventAction = jest.fn();
        mockSetEventsValidationAction = jest.fn();
        wrapper = shallow(
            <SupportingEvidenceModal
                isActive
                onClose={mockOnClose}
                cfIndex={0}
                involvedParty={involvedParty}
                liabilitySubjects={liabilitySubjects}
                evidences={mockEvidences}
                event={event}
                eventIndex={0}
                involvedPartyIndex={0}
                updateEventAction={mockUpdateEventAction}
                eventsValidation={eventsValidation}
                setEventsValidationAction={mockSetEventsValidationAction}
                validateContributingFactorEvidence={validateContributingFactorEvidence}
                claimNumber={'123'}
                readOnly={false}
            />);
    });

    describe('ModalDialog props', () => {
        it('should pass the isActive prop', () => {
            wrapper.setProps({isActive: true});
            expect(wrapper.find('ModalDialog').props().isActive).toBe(true);
            wrapper.setProps({isActive: false});
            expect(wrapper.find('ModalDialog').props().isActive).toBe(false);
        });

        it('should hide the trigger', () => {
            expect(wrapper.find('ModalDialog').props().hideTrigger).toBe(true);
        });

        it('should invoke onClose prop when ModalDialog is closed', () => {
            wrapper.find('ModalDialog').simulate('close');
            expect(mockOnClose).toBeCalled();
        });
    });

    describe('ModalDialog header', () => {
        let modalHeader;

        beforeEach(() => {
            modalHeader = shallow(wrapper.find('ModalDialog').props().header);
        });

        it('should contain the word Evidence and evidence count', () => {
            expect(modalHeader.text()).toEqual(expect.stringContaining('Add Supporting Evidence (2)'));
        });

        it('should have a star', () => {
            expect(modalHeader.find('Icon').at(0).props().icon).toBe('star');
            expect(modalHeader.find('Icon').at(0).props().color).toBe('bookmark');
            expect(modalHeader.find('Icon').at(0).props().size).toBe(1.5);
        });

        describe('Involved Party header', () => {
            let modalHeader;
            beforeEach(() => {
                modalHeader = shallow(wrapper.find('ModalDialog').props().header);
            });

            it('should render the participant Name', () => {
                expect(modalHeader.find('#supporting-participantName').text()).toBe('Joe Bob');
                expect(modalHeader.find('ParticipantPill').length).toBe(1);
                expect(modalHeader.find('ParticipantPill').get(0).props.liabilitySubject).toBe(liabilitySubjects[0]);
                expect(modalHeader.find('#supporting-contributingFactor').at(0).props(0).children[0].props.icon).toBe('danger-recognition');
                expect(modalHeader.find('#supporting-contributingFactor').at(0).props(0).children[1]).toBe('Proper Lookout: Saw other party');
            });

            it('should render the participant Name', () => {
                involvedParty = {
                    participantId: '1',
                    participantSourceId: '11',
                    assetId: 'asset1',
                    damageSections: [
                        'front',
                        'rear'
                    ],
                    contributingFactors: [
                        {
                            category: null,
                            reason: 'participant-has-right-of-way',
                            details: '',
                            evidenceIds: ['evidence1', 'evidence5']
                        }
                    ],
                    affectedParties: [
                        {
                            participantId: '2',
                            participantSourceId: '22',
                            assetId: 'B9763FCB7D843B1F',
                            passengerPartyIds: [],
                            initialFaultPercent: 12,
                            beginNegotiatingRange: 7,
                            endNegotiatingRange: 17,
                            submittedInitialFaultPercent: 12,
                            faultAllocationPercent: 1
                        }
                    ]
                };

                wrapper = shallow(
                    <SupportingEvidenceModal
                        isActive
                        onClose={mockOnClose}
                        cfIndex={0}
                        involvedParty={involvedParty}
                        liabilitySubjects={liabilitySubjects}
                        evidences={mockEvidences}
                        event={event}
                        involvedPartyIndex={0}
                        claimNumber={'123'}
                        updateEventAction={mockUpdateEventAction}
                        readOnly={false}
                        eventIndex={0}
                        eventsValidation={eventsValidation}
                        setEventsValidationAction={mockSetEventsValidationAction}
                    />);

                modalHeader = shallow(wrapper.find('ModalDialog').props().header);

                expect(modalHeader.find('#supporting-participantName').text()).toBe('Joe Bob');
                expect(modalHeader.find('ParticipantPill').length).toBe(1);
                expect(modalHeader.find('ParticipantPill').get(0).props.liabilitySubject).toBe(liabilitySubjects[0]);
                expect(modalHeader.find('#supporting-contributingFactor').at(0).props(0).children[1]).toBe('Has Right of Way');
            });

            it('should render the participant Name', () => {
                involvedParty = {
                    participantId: '1',
                    participantSourceId: '11',
                    assetId: 'asset1',
                    damageSections: [
                        'front',
                        'rear'
                    ],
                    contributingFactors: [
                        {
                            category: 'Additional Factors',
                            reason: 'additional-factors-other',
                            details: 'Other manually entered information',
                            evidenceIds: ['evidence1', 'evidence5']
                        }
                    ],
                    affectedParties: [
                        {
                            participantId: '2',
                            participantSourceId: '22',
                            assetId: 'B9763FCB7D843B1F',
                            passengerPartyIds: [],
                            initialFaultPercent: 12,
                            beginNegotiatingRange: 7,
                            endNegotiatingRange: 17,
                            submittedInitialFaultPercent: 12,
                            faultAllocationPercent: 1
                        }
                    ]
                };

                wrapper = shallow(
                    <SupportingEvidenceModal
                        isActive
                        onClose={mockOnClose}
                        cfIndex={0}
                        involvedParty={involvedParty}
                        liabilitySubjects={liabilitySubjects}
                        evidences={mockEvidences}
                        event={event}
                        involvedPartyIndex={0}
                        claimNumber={'123'}
                        updateEventAction={mockUpdateEventAction}
                        eventIndex={0}
                        readOnly={false}
                        eventsValidation={eventsValidation}
                        setEventsValidationAction={mockSetEventsValidationAction}
                    />);

                modalHeader = shallow(wrapper.find('ModalDialog').props().header);

                expect(modalHeader.find('#supporting-participantName').text()).toBe('Joe Bob');
                expect(modalHeader.find('ParticipantPill').length).toBe(1);
                expect(modalHeader.find('ParticipantPill').get(0).props.liabilitySubject).toBe(liabilitySubjects[0]);
                expect(modalHeader.find('#supporting-contributingFactor').at(0).props(0).children[1]).toBe('Other: Other manually entered information');
            });

        });
    });

    describe('ModalDialog body', () => {
        describe('category sections', () => {
            it('renders the SupportingEvidenceModalSection for each evidence category', () => {
                expect(wrapper.find('SupportingEvidenceModalSection').length).toBe(2);
            });

            it('renders the SupportingEvidenceModalSection with correct props for each evidence category, ignores untagged evidence, and sorts the categories', () => {
                const expectedDamagesEvidences = [
                    {id: 'evidence1', sourceId: 'highlight1', type: 'highlight', category: 'damages'}];
                const expectedWeatherConditionEvidences = [
                    {
                        id: 'evidence5', sourceId: 'photo3', type: 'photo',
                        category: 'condition-of-roadway',
                        photoUrl: 'my/photo3'
                    },
                    {id: 'evidence6', sourceId: 'highlight3', type: 'highlight', category: 'condition-of-roadway'}];

                expect(wrapper.find('SupportingEvidenceModalSection').at(0).props().category).toBe('condition-of-roadway');
                expect(wrapper.find('SupportingEvidenceModalSection').at(0).props().evidences).toEqual(expectedWeatherConditionEvidences);
                expect(wrapper.find('SupportingEvidenceModalSection').at(0).props().evidenceIds).toEqual(['evidence1', 'evidence5']);
                expect(wrapper.find('SupportingEvidenceModalSection').at(0).props().onEvidenceClick).toEqual(wrapper.instance().onEvidenceClick);
                expect(wrapper.find('SupportingEvidenceModalSection').at(1).props().category).toBe('damages');
                expect(wrapper.find('SupportingEvidenceModalSection').at(1).props().evidences).toEqual(expectedDamagesEvidences);
                expect(wrapper.find('SupportingEvidenceModalSection').at(1).props().evidenceIds).toEqual(['evidence1', 'evidence5']);
                expect(wrapper.find('SupportingEvidenceModalSection').at(1).props().onEvidenceClick).toEqual(wrapper.instance().onEvidenceClick);
            });
        });

        it('should render a horizontal border for each evidence category except the last', () => {
            expect(wrapper.find('#supporting-evidence-modal-section').at(0).find('hr').exists()).toBe(true);
            expect(wrapper.find('#supporting-evidence-modal-section').at(1).find('hr').exists()).toBe(false);
        });
    });

    describe('onEvidenceClick', () => {
        it('should render supporting evidence modal with updated evidenceIds when adding an evidence', () => {
            wrapper.find('SupportingEvidenceModalSection').at(0).simulate('evidenceClick', '1');
            expect(wrapper.find('SupportingEvidenceModalSection').at(0).props().evidenceIds).toEqual(['evidence1', 'evidence5', '1'])
        });

        it('should render supporting evidence modal with updated evidenceIds when removing an evidence', () => {
            wrapper.find('SupportingEvidenceModalSection').at(0).simulate('evidenceClick', 'evidence5');
            expect(wrapper.find('SupportingEvidenceModalSection').at(0).props().evidenceIds).toEqual(['evidence1'])

        });

    });

    describe('ModalDialog footer', () => {
        let footer;
        beforeEach(() => {
            footer = shallow(wrapper.find('ModalDialog').props().footer);
        });

        it('should have a Add Evidence button', () => {
            expect(footer.find('button').text()).toBe('Add Evidence');
        });

        it('should call updateEvents action on click of the add evidence button', () => {
            wrapper.find('SupportingEvidenceModalSection').at(0).simulate('evidenceClick', '2');
            footer.find('button').simulate('click');
            const expectedInvolvedParty = {
                participantId: '1',
                participantSourceId: '11',
                assetId: 'asset1',
                damageSections: [
                    'front',
                    'rear'
                ],
                contributingFactors: [
                    {
                        category: null,
                        reason: 'proper-lookout',
                        details: 'saw-other-party',
                        evidenceIds: ['evidence1', 'evidence5', '2']
                    }
                ],
                affectedParties: [
                    {
                        participantId: '2',
                        participantSourceId: '22',
                        assetId: 'B9763FCB7D843B1F',
                        passengerPartyIds: [],
                        initialFaultPercent: 12,
                        beginNegotiatingRange: 7,
                        endNegotiatingRange: 17,
                        submittedInitialFaultPercent: 12,
                        faultAllocationPercent: 1
                    }
                ]
            };

            const expectedEvent =
                {id: '0', title: 'my first event title', severity: 1, involvedParties: [expectedInvolvedParty]};

            expect(mockUpdateEventAction).toBeCalledWith('123', expectedEvent);
            expect(revalidateEvent).toBeCalledWith(expectedEvent, mockSetEventsValidationAction, 0, eventsValidation,
                mockEvidences, true)
        });


        it('should pass the feature switch validateContributingFactorEvidence to revaliadateEvent', () => {
            wrapper.setProps({validateContributingFactorEvidence: false})
            wrapper.find('SupportingEvidenceModalSection').at(0).simulate('evidenceClick', '2');
            footer.find('button').simulate('click');
            const expectedInvolvedParty = {
                participantId: '1',
                participantSourceId: '11',
                assetId: 'asset1',
                damageSections: [
                    'front',
                    'rear'
                ],
                contributingFactors: [
                    {
                        category: null,
                        reason: 'proper-lookout',
                        details: 'saw-other-party',
                        evidenceIds: ['evidence1', 'evidence5', '2']
                    }
                ],
                affectedParties: [
                    {
                        participantId: '2',
                        participantSourceId: '22',
                        assetId: 'B9763FCB7D843B1F',
                        passengerPartyIds: [],
                        initialFaultPercent: 12,
                        beginNegotiatingRange: 7,
                        endNegotiatingRange: 17,
                        submittedInitialFaultPercent: 12,
                        faultAllocationPercent: 1
                    }
                ]
            };

            const expectedEvent =
                {id: '0', title: 'my first event title', severity: 1, involvedParties: [expectedInvolvedParty]};

            expect(mockUpdateEventAction).toBeCalledWith('123', expectedEvent);
            expect(revalidateEvent).toBeCalledWith(expectedEvent, mockSetEventsValidationAction, 0, eventsValidation, mockEvidences, false)
        });


        it('should disable the button when in read only mode', () => {
            wrapper.setProps({readOnly: true});
            let footer = shallow(wrapper.find('ModalDialog').props().footer);
            expect(footer.find('button').props().disabled).toBe(true);
        });

        it('should close the modal after the button is clicked', () => {
            footer.find('button').simulate('click');
            expect(mockOnClose).toBeCalled();
        });
    });

    describe('Empty State', () => {
        beforeEach(() => {
            wrapper.setProps({evidences: []});
        });

        it('should render the empty state message', () => {
            expect(wrapper.find('.evidence-modal__empty').text()).toEqual(expect.stringContaining('You haven\'t added any evidence'));
            expect(wrapper.find('.evidence-modal__empty').text()).toEqual(expect.stringContaining('Photos and transcript highlights can be added as evidence on <Link />.'));
            expect(wrapper.find('Link').props().children).toEqual('Investigate');
            expect(wrapper.find('.evidence-modal__empty').text()).toEqual(expect.stringContaining('You must add at least one piece of evidence for this contributing factor.'));
        });

        it('should not render any EvidenceModalSection components', () => {
            expect(wrapper.find('EvidenceModalSection').exists()).toBe(false);
        });

        it('should navigate to the investigate page and close the modal when the investigate link is clicked', () => {
            const link = wrapper.find('Link');
            expect(link.props().children).toBe('Investigate');
            expect(link.props().to).toEqual('/investigate');
            // modal closes on navigation because component unmounts.
        });
    });

    describe('Connect', () => {
        it('mapStateToProps maps store to props', () => {
            const claimData = {
                claimNumber: '123',
                liabilitySubjects: liabilitySubjects,
                evidences: mockEvidences,
                locked: true
            };
            const user = {userRoles: ['LOON Read Only User']};
            isReadOnly.mockReset();
            isReadOnly.mockReturnValue(true);
            const featureSwitches = {validateContributingFactorEvidence: true}
            const store = {claimData, user, featureSwitches};
            const result = mapStateToProps(store);
            expect(result.claimNumber).toBe('123');
            expect(result.validateContributingFactorEvidence).toBe(true);
            expect(result.liabilitySubjects).toEqual(liabilitySubjects);
            expect(result.evidences).toEqual(mockEvidences);
            expect(result.readOnly).toBe(true);
            expect(isReadOnly).toBeCalledWith(['LOON Read Only User'], true);
        });

        it('mapDispatchToProps', () => {
            expect(mapDispatchToProps.updateEventAction).toBe(updateEventAction);
            expect(mapDispatchToProps.setEventsValidationAction).toBe(setEventsValidationAction)
        });
    });
});
