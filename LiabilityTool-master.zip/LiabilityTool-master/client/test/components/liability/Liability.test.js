jest.unmock('../../../src/main/components/liability/Liability');

import React from 'react';
import { shallow } from 'enzyme';
import { Liability, mapDispatchToProps, mapStateToProps } from '../../../src/main/components/liability/Liability';
import analyticsHelper from '../../../src/main/helpers/analyticsHelper';
import {
    getAssetTypeShortName,
    getParticipantName,
    isInsured,
    isReadOnly
} from '../../../src/main/helpers/claimDataHelper';
import { createEventAction, setEventsValidationAction } from '../../../src/main/actions/eventActions';
import {
    liabilitySubmittedAction,
    submitLiabilityAction,
    submitLiabilityCancelAction
} from '../../../src/main/actions/submitActions';
import { saveSketchAction } from '../../../src/main/actions/claimDataActions';
import { validateEvent } from '../../../src/main/helpers/eventValidationHelper';

describe('Given Liability component', () => {
    let wrapper;

    const featureSwitches = { validateContributingFactorEvidence: true };

    const liabilitySubjects = [
            {
                role: 'INSURED',
                firstName: 'first1',
                lastName: 'last1',
                asset: { assetTypeDescription: 'Auto' },
                participantSourceId: '1',
            },
            {
                role: 'CLAIMANT',
                firstName: 'first2',
                lastName: 'last2',
                asset: { assetTypeDescription: 'Motorcycle' },
                participantSourceId: '2',
            }
        ],
        mockCreateEventAction = jest.fn(),
        mockSubmitLiabilityAction = jest.fn(),
        mockSubmitLiabilityCancelAction = jest.fn(),
        mockLiabilitySubmittedAction = jest.fn(),
        mockSetEventsValidationAction = jest.fn(),
        mockSaveSketchAction = jest.fn(),
        mockHistory = {
            push: jest.fn()
        },
        events = [
            { id: '0', title: 'my first event title', severity: 1 },
            { id: '1', title: 'my second event title', severity: 1 },
        ],
        claimData = {
            mapAddress: '123 SwrappertName, City, State ZipCode',
            updatedLossLocation: undefined,
            claimNumber: '123',
            initialFaultSubmitTime: '2017-08-06 12:12:12',
            lossDetailType: 'Intersection Accident',
            lossDetailTypeCode: '01',
            lossDate: '06/08/2017',
            lossTime: '9:32 am',
            lossState: 'California',
            latitude: 11.11,
            longitude: 22.22,
            liabilitySubjects: liabilitySubjects,
            events: events,
            sketch: { imageSource: 'image', completed: true }
        };

    beforeEach(() => {
        window.scrollTo = jest.fn();

        getAssetTypeShortName.mockReturnValue('auto');
        isInsured.mockReturnValue(true);
        getParticipantName.mockReturnValue('first1 last1');
        wrapper = shallow(
            <Liability
                claimData={claimData}
                history={mockHistory}
                readOnly={false}
                submitState={'DEFAULT_STATE'}
                createEventAction={mockCreateEventAction}
                submitLiabilityAction={mockSubmitLiabilityAction}
                submitLiabilityCancelAction={mockSubmitLiabilityCancelAction}
                liabilitySubmittedAction={mockLiabilitySubmittedAction}
                setEventsValidationAction={mockSetEventsValidationAction}
                saveSketchAction={mockSaveSketchAction}
                featureSwitches={featureSwitches}
            />
        );
    });

    describe('default states', () => {
        it('should default openConfirmModal state to false', () => {
            expect(wrapper.instance().state.openConfirmModal).toBe(false);
        });
    });

    describe('when there are 2 or less liability subjects and common functionality', () => {
        describe('Common functionality', () => {
            it('tracks page using SiteCatalyst', () => {
                wrapper.instance().componentDidMount();
                expect(analyticsHelper.trackPage).toHaveBeenCalledWith('claims/loon/liabilityPage');
            });

            describe('Title', () => {
                it('should have the title as Loon - {claimNumber} when claim number is available', () => {
                    wrapper.instance().componentDidMount();
                    expect(document.title).toEqual('Loon - 123');
                });

                it('should have the title as Loon - {claimNumber} when claim number is not available', () => {
                    wrapper.setProps({ claimData: { claimNumber: '', liabilitySubjects: [], events: [] } });
                    wrapper.instance().componentDidMount();
                    expect(document.title).toEqual('Loon -');
                });
            });

            it('When renders with submitState as ERROR_SUBMITTING', () => {
                wrapper.setProps({ submitState: 'ERROR_SUBMITTING' });
                expect(wrapper.find('#error-modal').props().isActive).toEqual(true)
            });

            it('When renders with submitState as SUBMITTED', () => {
                wrapper.setProps({ submitState: 'SUBMITTED' });
                expect(wrapper.find('#success-modal').props().isActive).toEqual(true)
            });

            it('When close modal is called, openConfirmModal state is set to false', () => {
                wrapper.instance().closeModal();
                expect(wrapper.instance().state.openConfirmModal).toBe(false);
            });

            describe('Confirm Submit', () => {
                describe('Confirm Submit Modal', () => {
                    it('is rendered with correct props', () => {
                        const confirmModalProps = wrapper.find('#confirm-modal').props();

                        expect(confirmModalProps.activeModal).toBe('Confirm');
                        expect(confirmModalProps.isActive).toBe(false);
                        expect(confirmModalProps.spinner).toBe(wrapper.instance().submitState === 'SUBMITTING');
                        expect(confirmModalProps.modalText).toBe('Are you sure you want to submit your initial fault?');
                        expect(confirmModalProps.onClose).toBe(wrapper.instance().closeModal);
                    });

                    it('isActive prop of Confirm Submit Modal is passed as true when openConfirmModal state is true', () => {
                        wrapper.setState({ openConfirmModal: true });

                        expect(wrapper.find('#confirm-modal').props().isActive).toBe(true);
                    });

                    it('isActive prop of Confirm Submit Modal is passed as true when submitState props is SUBMITTING', () => {
                        wrapper.setProps({ submitState: 'SUBMITTING' });
                        expect(wrapper.find('#confirm-modal').props().isActive).toBe(true);
                    });

                    it('firstButtonCallback is set to onSubmitConfirmClick', () => {
                        wrapper.instance().mapDataUrl = 'map';

                        wrapper.find('#confirm-modal').props().firstButtonCallback();
                        expect(mockSubmitLiabilityAction).toHaveBeenCalledWith(claimData, 'map');
                    });
                });

                describe('Error Submit Modal', () => {
                    it('is rendered with correct props', () => {
                        const errorModalProps = wrapper.find('#error-modal').props();

                        expect(errorModalProps.activeModal).toBe('Error');
                        expect(errorModalProps.promptType).toBe('error');
                        expect(errorModalProps.isActive).toBe(wrapper.instance().submitState === 'ERROR_SUBMITTING');
                        expect(errorModalProps.onCloseCallback).toBe(mockSubmitLiabilityCancelAction);
                        expect(errorModalProps.spinner).toBe(wrapper.instance().submitState === 'SUBMITTING');
                        expect(errorModalProps.modalText).toBe('We are unable to submit your initial fault analysis. Would you like to try submitting this initial fault analysis again?')
                    });

                    it('firstButtonCallback is set to onSubmitConfirmClick', () => {
                        wrapper.instance().mapDataUrl = 'map';

                        wrapper.find('#error-modal').props().firstButtonCallback();
                        expect(mockSubmitLiabilityAction).toHaveBeenCalledWith(claimData, 'map');
                    });
                });

                describe('Success Submit Modal', () => {
                    it('Then renders a Success Modal', () => {
                        const successModalProps = wrapper.find('#success-modal').props();

                        expect(successModalProps.id).toBe('success-modal');
                        expect(successModalProps.activeModal).toBe('Success');
                        expect(successModalProps.isActive).toBe(wrapper.instance().props.submitState === 'SUBMITTED');
                        expect(successModalProps.firstButtonCallback).toBe(wrapper.instance().redirectToHomePage);
                        expect(successModalProps.secondButtonCallback).toBe(wrapper.instance().redirectToSettlementPage);
                        expect(successModalProps.onClose).toBe(mockLiabilitySubmittedAction);
                        expect(successModalProps.spinner).toBe(false);
                        expect(successModalProps.modalText).toBe('Your claim has been successfully submitted.');

                    });
                });
            });

            describe('When onSubmitConfirmClick is called', () => {
                it('then the submitLiabilityAction is called with claimData', () => {
                    wrapper.instance().mapDataUrl = 'map';

                    wrapper.instance().onSubmitConfirmClick();
                    expect(mockSubmitLiabilityAction).toBeCalledWith(claimData, 'map');
                    expect(wrapper.instance().state.openConfirmModal).toBe(false);
                });
            });

            describe('When redirectToHomePage is called', () => {
                it('then the liabilitySubmittedAction is called ', () => {
                    wrapper.instance().redirectToHomePage();
                    expect(mockLiabilitySubmittedAction).toBeCalled();
                    expect(mockHistory.push).toBeCalledWith('/');
                });
            });

            describe('When redirectToSettlementPage is called', () => {
                it('then the liabilitySubmittedAction is called ', () => {
                    wrapper.instance().redirectToSettlementPage();
                    expect(mockLiabilitySubmittedAction).toBeCalled();
                    expect(mockHistory.push).toBeCalledWith('/settlement');
                });
            });
        });

        describe('two or less liability subjects functionality', () => {
            it('should render Initial Fault text only for header', () => {
                expect(wrapper.find('#fault-header').text()).toBe('Initial Fault');
            });
        });

        describe('life cycle methods are called', () => {
            it('componentDidUpdate - scrolls if scrollTo is available as a prop', () => {
                window.pageYOffset = 100;
                document.getElementById = jest.fn().mockReturnValue({
                    getBoundingClientRect: jest.fn().mockReturnValue({ top: 200 })
                });
                wrapper.instance().shouldScroll = true;
                wrapper.instance().componentDidUpdate();

                expect(window.scrollTo).toBeCalledWith(0, 245);
            });

            it('componentDidUpdate - scrolls if scrollTo is available as a prop with smooth behavior', () => {
                window.pageYOffset = 100;
                document.documentElement.style.scrollBehavior = 'smooth';
                document.getElementById = jest.fn().mockReturnValue({
                    getBoundingClientRect: jest.fn().mockReturnValue({ top: 200 })
                });
                wrapper.instance().shouldScroll = true;
                wrapper.instance().componentDidUpdate();
                expect(window.scrollTo).toBeCalledWith({ top: 245, behavior: 'smooth' });
            });
        });
    });

    describe('when there are 3 or more liability subjects', () => {
        beforeEach(() => {
            const newLiabilitySubjects = [
                {
                    role: 'INSURED',
                    firstName: 'firstParticipantName1',
                    lastName: 'lastParticipantName1'
                },
                {
                    role: 'CLAIMANT',
                    firstName: 'firstParticipantName2',
                    lastName: 'lastParticipantName2'
                },
                {
                    role: 'CLAIMANT',
                    firstName: 'firstParticipantName3',
                    lastName: 'lastParticipantName3'
                }
            ];
            const newClaimData = { ...claimData, liabilitySubjects: newLiabilitySubjects };

            wrapper = shallow(
                <Liability
                    claimData={newClaimData}
                    createEventAction={mockCreateEventAction}
                    submitLiabilityAction={mockSubmitLiabilityAction}
                    submitLiabilityCancelAction={mockSubmitLiabilityCancelAction}
                    liabilitySubmittedAction={mockLiabilitySubmittedAction}
                    setEventsValidationAction={mockSetEventsValidationAction}
                    readOnly={false}
                    submitState={'DEFAULT_STATE'}
                />
            );
        });

        it('should render event header', () => {
            expect(wrapper.find('#fault-header').text()).toBe('Determine Initial Fault Using Events');
        });

        it('should render event initial fault text', () => {
            expect(wrapper.find('#fault-event-text').text()).toBe('Your analysis can be separated into events.An event typically starts with an proximate cause of loss. This is a distinct act of negligence resulting in 1 or more impacts.')
        });

        it('should render a button to add events', () => {
            expect(wrapper.find('#create-event-button').text().includes('Create an Event')).toBe(true);
            wrapper.instance().addEvent = jest.fn();
            wrapper.find('#create-event-button').simulate('click');
            expect(wrapper.instance().addEvent).toBeCalled();
        });

        it('should render a Event component for every existing event with properties ', () => {
            const expectedEvents = [
                { id: '0', title: 'my first event title', severity: 1 },
                { id: '1', title: 'my second event title', severity: 1 },
            ];
            expect(wrapper.find('Connect(Event)').length).toBe(2);
            expect(wrapper.find('Connect(Event)').get(0).props.event).toEqual(expectedEvents[0]);
            expect(wrapper.find('Connect(Event)').get(0).props.eventIndex).toBe(0);

            expect(wrapper.find('Connect(Event)').get(1).props.event).toEqual(expectedEvents[1]);
            expect(wrapper.find('Connect(Event)').get(1).props.eventIndex).toBe(1);
        });

        it('should not render a Connect(Event) if there are no existing events', () => {
            wrapper.setProps({ claimData: { ...claimData, events: [] } });
            expect(wrapper.find('Connect(Event)').exists()).toBe(false);
        });

        it('should render Event component on click of create event button ', () => {
            wrapper.find('#create-event-button').simulate('click');
            expect(mockCreateEventAction).toBeCalledWith('123', { involvedParties: [] });
            expect(wrapper.find('Connect(Event)').exists()).toBe(true);
            expect(wrapper.instance().shouldScroll).toBe(true);
        });

        it('should render an add icon within the button to add events', () => {
            expect(wrapper.find('#add-event-icon').exists()).toBe(true);
            expect(wrapper.find('#add-event-icon').props().icon).toEqual('plus')
        });

        it('should not disable the add event button if the user is not a Read Only user', () => {
            expect(wrapper.find('#create-event-button').props().disabled).toBe(false);
        });

        it('should disable the add event button if the user is a Read Only user', () => {
            wrapper.setProps({ readOnly: true });
            expect(wrapper.find('#create-event-button').props().disabled).toBe(true);
        });
    });

    describe('when there are 5 or more events', () => {
        it('should not show the Add Event button', () => {
            const newEvents = [
                { id: '0', title: 'my first event title' },
                { id: '1', title: 'my second event title' },
                { id: '2', title: 'my third event title' },
                { id: '3', title: 'my fourth event title' },
                { id: '4', title: 'my fifth event title' },
            ];
            const newClaimData = { ...claimData, events: newEvents };
            wrapper = shallow(
                <Liability
                    claimData={newClaimData}
                    createEventAction={mockCreateEventAction}
                    submitLiabilityAction={mockSubmitLiabilityAction}
                    submitLiabilityCancelAction={mockSubmitLiabilityCancelAction}
                    liabilitySubmittedAction={mockLiabilitySubmittedAction}
                    setEventsValidationAction={mockSetEventsValidationAction}
                    userRoles={['LOON User']}
                    submitState={'DEFAULT_STATE'}
                    readOnly={false}
                />
            );

            expect(wrapper.find('#create-event-button').exists()).toBe(false);
        });
    });

    describe('Submit Initial Fault button', () => {

        it('should be in disabled state for a read only user', () => {
            wrapper.setProps({ readOnly: true });
            expect(wrapper.find('#submit-initial-fault').props().disabled).toBe(true);
        });

        it('should display  the Submit button when there are events', () => {
            expect(wrapper.find('#submit-initial-fault').exists()).toBe(true);
        });

        it('should not display  the Submit button when there are no events', () => {
            wrapper.setProps({ claimData: { ...claimData, events: [] } });
            expect(wrapper.find('#submit-initial-fault').exists()).toBe(false);
        });

        it('should change openConfirmModal state to true on click when there are no validation errors', () => {
            validateEvent.mockClear();
            validateEvent.mockReturnValue({ error: false });
            wrapper.find('#submit-initial-fault').simulate('click');
            expect(wrapper.find('#confirm-modal').props().isActive).toBe(true);
            expect(mockSetEventsValidationAction).toBeCalledWith([{ error: false }, { error: false }]);
        });

        it('should not change openConfirmModal state to true on click when there are validation errors', () => {
            validateEvent.mockClear();
            validateEvent.mockReturnValue({ error: true });
            const firstEventWithError = { scrollIntoView: jest.fn() };
            document.getElementById = jest.fn().mockReturnValue(firstEventWithError);
            wrapper.find('#submit-initial-fault').simulate('click');
            expect(wrapper.find('#confirm-modal').props().isActive).toBe(false);
            expect(mockSetEventsValidationAction).toBeCalledWith([{ error: true }, { error: true }]);
        });

        it('should scroll to the first event with an error when there are validation errors', () => {
            validateEvent.mockClear();

            validateEvent
                .mockReturnValueOnce({error: false})
                .mockReturnValueOnce({ error: true });
            const firstEventWithError = { scrollIntoView: jest.fn() };
            document.getElementById = jest.fn().mockReturnValue(firstEventWithError);

            wrapper.find('#submit-initial-fault').simulate('click');

            expect(document.getElementById).toBeCalledWith('fault-event-1');
            expect(firstEventWithError.scrollIntoView).toBeCalledWith({block: 'center'});
        });

        it('should scroll to the top when the sketch is not validated', () => {
            validateEvent.mockClear();

            validateEvent.mockReturnValue({error: false});
            document.getElementById = jest.fn();

            wrapper.setProps({claimData: {...claimData, sketch: {completed: false}}});
            window.scrollTo = jest.fn();
            wrapper.find('#submit-initial-fault').simulate('click');
            expect(window.scrollTo).toBeCalledWith(0, 0);
            expect(document.getElementById).not.toBeCalled();
        });

        it('should not open confirm modal when sketch is null', () => {
            validateEvent.mockClear();
            validateEvent.mockReturnValue({ error: false });
            wrapper.setProps({ claimData: { ...claimData, sketch: null } });
            wrapper.find('#submit-initial-fault').simulate('click');
            expect(wrapper.find('#confirm-modal').props().isActive).toBe(false);
        });

        it('should not open confirm modal when sketch is not null but incomplete and no reason given for incompleteness', () => {
            validateEvent.mockClear();
            validateEvent.mockReturnValue({ error: false });
            wrapper.setProps({ claimData: { ...claimData, sketch: { completed: false, notCompletedReason: '' } } });
            wrapper.find('#submit-initial-fault').simulate('click');
            expect(wrapper.find('#confirm-modal').props().isActive).toBe(false);
        });

        it('should open confirm modal when sketch is completed', () => {
            validateEvent.mockClear();
            validateEvent.mockReturnValue({ error: false });
            wrapper.setProps({ claimData: { ...claimData, sketch: { completed: true, notCompletedReason: '' } } });
            wrapper.find('#submit-initial-fault').simulate('click');
            expect(wrapper.find('#confirm-modal').props().isActive).toBe(true);
        });

        it('should open confirm modal when sketch is not completed but reason is given', () => {
            validateEvent.mockClear();
            validateEvent.mockReturnValue({ error: false });
            wrapper.setProps({
                claimData: {
                    ...claimData,
                    sketch: { completed: false, notCompletedReason: 'some reason' }
                }
            });
            wrapper.find('#submit-initial-fault').simulate('click');
            expect(wrapper.find('#confirm-modal').props().isActive).toBe(true);
        });
    });

    it('getGoogleMapImageData', () => {
        const drawImage = jest.fn();
        const getContext = jest.fn().mockReturnValue({ drawImage });
        document.createElement = jest.fn().mockReturnValue({ getContext });
        wrapper.setProps({ toForceRerender: 'test' });

        expect(document.createElement).toBeCalledWith('canvas');
        expect(getContext).toBeCalledWith('2d');
    });

    describe('Sketch validation', () => {
        it('should not render error banner and sketch reason section when sketch is completed', () => {
            expect(wrapper.find('ErrorBanner').exists()).toBe(false);
            expect(wrapper.find('#sketch-not-completed-section').exists()).toBe(false);
        });

        describe('When sketch not completed and no reason provided', () => {
            const testErrorBannerAndSketchErrorWithIcon = () => {
                expect(wrapper.find('ErrorBanner').props().error).toBe(true);
                expect(wrapper.find('ErrorBanner').props().children[0]).toEqual(
                    <span>Missing Information: </span>, 'See details below');

                expect(wrapper.find('#sketch-error-icon').props().icon).toBe('error-circle');

                expect(wrapper.find('#sketch-explanation').text()).toBe('You haven’t added a sketch. Please add a sketch or provide an explanation before submitting.');
                expect(wrapper.find('#sketch-explanation').props().className.includes('u-text-error')).toBe(true);

                expect(wrapper.find('#sketch-question').text()).toBe('Why isn’t a sketch required?');

                expect(wrapper.find('FormField').props().value).toBe(null);
                expect(wrapper.find('FormField').props().maxLength).toBe(75);
                expect(wrapper.find('FormField').props().hasError).toBe(true);
                expect(wrapper.find('FormField').props().disabled).toBe(false);
                expect(wrapper.find('FormField').props().autoComplete).toBe(false);

                expect(wrapper.find('#add-sketch-icon').props().icon).toBe('plus');

                expect(wrapper.find('#add-sketch-label').text()).toBe('Add Sketch');
            };

            it('should render error banner and sketch reason section in error state when sketch data is not available', () => {
                wrapper.setProps({ claimData: { ...claimData, sketch: null } });
                testErrorBannerAndSketchErrorWithIcon();
            });

            it('should render error banner and sketch reason section in error state when sketch is not completed', () => {
                wrapper.setProps({ claimData: { ...claimData, sketch: { completed: false } } });
                testErrorBannerAndSketchErrorWithIcon();
            });
        });

        it('should not render error banner and sketch reason section when sketch is not completed and a reason provided', () => {
            wrapper.setProps({
                claimData: {
                    ...claimData,
                    sketch: { completed: false, notCompletedReason: 'not completed reason' }
                }
            });

            expect(wrapper.find('ErrorBanner').exists()).toBe(false);

            expect(wrapper.find('#sketch-error-icon').exists()).toBe(false);

            expect(wrapper.find('#sketch-explanation').text()).toBe('You haven’t added a sketch. Please add a sketch or provide an explanation before submitting.');
            expect(wrapper.find('#sketch-explanation').props().className.includes('u-text-error')).toBe(false);

            expect(wrapper.find('#sketch-question').text()).toBe('Why isn’t a sketch required?');

            expect(wrapper.find('FormField').props().value).toBe('not completed reason');
            expect(wrapper.find('FormField').props().maxLength).toBe(75);
            expect(wrapper.find('FormField').props().hasError).toBe(false);
            expect(wrapper.find('FormField').props().disabled).toBe(false);
            expect(wrapper.find('FormField').props().autoComplete).toBe(false);

            expect(wrapper.find('#add-sketch-icon').props().icon).toBe('plus');

            expect(wrapper.find('#add-sketch-label').text()).toBe('Add Sketch');
        });

        it('should render not completed reason text field in disabled state in read only mode', () => {
            wrapper.setProps({
                claimData: {
                    ...claimData,
                    sketch: { completed: false, notCompletedReason: 'not completed reason' }
                },
                readOnly: true
            });
            expect(wrapper.find('FormField').props().disabled).toBe(true);
        });

        it('should call saveSketchAction with not completed reason on blur', () => {
            wrapper.setProps({
                claimData: {
                    ...claimData,
                    sketch: { completed: false, notCompletedReason: 'not completed reason' }
                }
            });

            wrapper.find('FormField').simulate('blur', { target: { value: 'some reason' } });
            expect(mockSaveSketchAction).toBeCalledWith({ completed: false, notCompletedReason: 'some reason' });
        });

        it('should redirect to sketch tab on click of add sketch link', () => {
            wrapper.setProps({ claimData: { ...claimData, sketch: null } });
            wrapper.find('a').simulate('click');
            expect(mockHistory.push).toBeCalledWith('/sketch');
        });
    });

    describe('Connect helper', () => {
        const claimData = {
            claimNumber: '123',
            liabilitySubjects: [
                { participantPartyId: '1' },
                { participantPartyId: '2' }],
            events: [
                { id: '1', title: 'title1' },
                { id: '2', title: 'title2' }]
        };
        const user = {
            userRoles: ['ReadOnly']
        };
        const featureSwitches = { validateContributingFactorEvidence: true }
        const status = { submitState: 'submit' };
        const history = { field1: 'value1' };
        const state = { claimData, user, status, featureSwitches };

        it('maps required store items to props', () => {
            isReadOnly.mockReturnValue(true);

            const result = mapStateToProps(state, { history });
            expect(result.claimData).toEqual(claimData);
            expect(result.validateContributingFactorEvidence).toBe(true);
            expect(result.readOnly).toEqual(true);
            expect(result.submitState).toEqual('submit');
            expect(isReadOnly).toBeCalledWith(user.userRoles, claimData.locked);
            expect(result.history).toBe(history);
        });

        it('maps dispatch to props', () => {
            expect(mapDispatchToProps.createEventAction).toEqual(createEventAction);
            expect(mapDispatchToProps.submitLiabilityAction).toEqual(submitLiabilityAction);
            expect(mapDispatchToProps.submitLiabilityCancelAction).toEqual(submitLiabilityCancelAction);
            expect(mapDispatchToProps.liabilitySubmittedAction).toEqual(liabilitySubmittedAction);
            expect(mapDispatchToProps.setEventsValidationAction).toEqual(setEventsValidationAction);
            expect(mapDispatchToProps.saveSketchAction).toEqual(saveSketchAction);
        });
    });
});
