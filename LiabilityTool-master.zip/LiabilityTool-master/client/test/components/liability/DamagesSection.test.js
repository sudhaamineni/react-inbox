jest.unmock('../../../src/main/components/liability/DamagesSection');
import React from 'react';
import {shallow} from 'enzyme';
import {
    DamagesSection,
    mapDispatchToProps,
    mapStateToProps
} from '../../../src/main/components/liability/DamagesSection';
import {validateEvent} from '../../../src/main/helpers/eventValidationHelper';
import {isReadOnly} from "../../../src/main/helpers/claimDataHelper";
import {setEventsValidationAction, updateDamagesAction} from '../../../src/main/actions/eventActions';

describe('DamagesSection', () => {
    let wrapper;
    let mockUpdateDamages;
    let mockSetEventsValidationAction;
    let eventsValidation = [{error: false}];
    let event = {involvedParties: [], damageSections: ['damage area']};

    beforeEach(() => {
        mockUpdateDamages = jest.fn();
        mockSetEventsValidationAction = jest.fn();
        isReadOnly.mockReturnValue(false);
        wrapper = shallow(<DamagesSection
            readOnly={false}
            options={[]}
            isInsured={true}
            event={event}
            eventsValidation={eventsValidation}
            updateDamages={mockUpdateDamages}
            setEventsValidation={mockSetEventsValidationAction}
            eventIndex={0}
            involvedPartyIndex={1}
            evidences={[]}
        />);
    });

    describe('initial render', () => {
        it('should render DamageArea with the right props', () => {
            expect(wrapper.find('DamageArea').exists()).toBe(true);
            expect(wrapper.find('DamageArea').props().isInsured).toBe(true);
            expect(wrapper.find('DamageArea').props().readOnly).toBe(false);
        });

        it('should render No Damages checkbox', () => {
            expect(wrapper.find('FormOption').exists()).toBe(true);
            expect(wrapper.find('FormOption').props().value).toBe('noDamages');
            expect(wrapper.find('FormOption').props().name).toBe('noDamages');
            expect(wrapper.find('FormOption').props().checked).toBe(false);
            expect(wrapper.find('FormOption').children().text()).toBe('No Damages');
        });

        it('should set the ReadOnly property to true if the props readOnly is true', () => {
            wrapper.setProps({readOnly: true});
            expect(wrapper.find('DamageArea').props().readOnly).toBe(true);
        });

        describe('No Damages checkbox', () => {
            it('should check FormOption if noDamages is passed in as option', () => {
                wrapper = shallow(<DamagesSection
                    readOnly={false}
                    options={['noDamages']}
                    isInsured={true}
                    event={event}
                    eventsValidation={eventsValidation}
                    updateDamages={mockUpdateDamages}
                    setEventsValidation={mockSetEventsValidationAction}
                    eventIndex={0}
                    involvedPartyIndex={1}
                    evidences={[]}
                />);

                expect(wrapper.find('FormOption').props().checked).toBe(true);
                expect(wrapper.find('FormOption').props().readOnly).toBe(false);
                expect(wrapper.find('FormOption').props().disabled).toBe(false);
            });

            it('should set the ReadOnly property to true if the props readOnly is true', () => {
                wrapper.setProps({readOnly: true, options: ['noDamages']});
                expect(wrapper.find('FormOption').props().readOnly).toBe(true);
                expect(wrapper.find('FormOption').props().disabled).toBe(true);
                expect(wrapper.find('FormOption').props().className).toBe('c-option__label__text-read-only');
            });

            it('should dispatch updateDamages with noDamages only when no damages checkbox is checked', () => {
                wrapper = shallow(<DamagesSection
                    readOnly={false}
                    options={['front', 'rear']}
                    isInsured={true}
                    event={event}
                    eventsValidation={eventsValidation}
                    updateDamages={mockUpdateDamages}
                    setEventsValidation={mockSetEventsValidationAction}
                    eventIndex={0}
                    involvedPartyIndex={1}
                    evidences={[]}
                />);

                let mockEvent = {target: {checked: true}};
                wrapper.find('FormOption').simulate('change', mockEvent);
                expect(mockUpdateDamages).toBeCalledWith(0, 1, ['noDamages'])
            });

            it('should dispatch updateDamages with empty array when no damages checkbox is unchecked', () => {
                wrapper = shallow(<DamagesSection
                    readOnly={false}
                    options={['noDamages']}
                    isInsured={true}
                    event={event}
                    eventsValidation={eventsValidation}
                    updateDamages={mockUpdateDamages}
                    setEventsValidation={mockSetEventsValidationAction}
                    eventIndex={0}
                    involvedPartyIndex={1}
                    evidences={[]}
                />);

                let mockEvent = {target: {checked: false}};
                wrapper.find('FormOption').simulate('change', mockEvent);
                expect(mockUpdateDamages).toBeCalledWith(0, 1, []);
            });
        });

        describe('DamageArea component', () => {
            it('should render the component with selectedDamages', () => {
                wrapper = shallow(<DamagesSection
                    readOnly={false}
                    options={['front', 'passenger']}
                    isInsured={true}
                    event={event}
                    eventsValidation={eventsValidation}
                    updateDamages={mockUpdateDamages}
                    setEventsValidation={mockSetEventsValidationAction}
                    eventIndex={0}
                    involvedPartyIndex={1}
                    evidences={[]}
                />);

                expect(wrapper.find('DamageArea').props().selectedDamages).toEqual(['front', 'passenger']);
            });

            it('should dispatch updateDamages when a new damage is checked or unchecked', () => {
                wrapper = shallow(<DamagesSection
                    readOnly={false}
                    options={['front', 'passenger']}
                    isInsured={true}
                    event={event}
                    eventsValidation={eventsValidation}
                    updateDamages={mockUpdateDamages}
                    setEventsValidation={mockSetEventsValidationAction}
                    eventIndex={0}
                    involvedPartyIndex={1}
                    evidences={[]}
                />);

                let newOptions = ['rear', 'passenger'];
                wrapper.find('DamageArea').simulate('click', newOptions);
                expect(mockUpdateDamages).toBeCalledWith(0, 1, ['rear', 'passenger']);
            });

            it('should dispatch updateDamages without noDamages value when a damage section is clicked', () => {
                wrapper = shallow(<DamagesSection
                    readOnly={false}
                    options={['noDamages']}
                    isInsured={true}
                    event={event}
                    eventsValidation={eventsValidation}
                    updateDamages={mockUpdateDamages}
                    setEventsValidation={mockSetEventsValidationAction}
                    eventIndex={0}
                    involvedPartyIndex={1}
                    evidences={[]}
                />);

                let newOptions = ['rear'];
                wrapper.find('DamageArea').simulate('click', newOptions);
                expect(mockUpdateDamages).toBeCalledWith(0, 1, ['rear']);
            });

            it('should dispatch setEventsValidationAction and updateDamages without noDamages value when a damage section is clicked and error exists', () => {
                let eventsValidationWithError = [{error: true}];
                let eventWithNoDamages = {
                    involvedParties: [
                        {
                            damageSections: []
                        }
                    ]
                };
                validateEvent.mockReturnValue({error: false, blah: 'blah'});
                wrapper = shallow(<DamagesSection
                    readOnly={false}
                    options={['noDamages']}
                    isInsured={true}
                    event={eventWithNoDamages}
                    updateDamages={mockUpdateDamages}
                    eventsValidation={eventsValidationWithError}
                    setEventsValidation={mockSetEventsValidationAction}
                    eventIndex={0}
                    involvedPartyIndex={0}
                    evidences={[]}
                />);

                let newOptions = ['rear'];
                wrapper.find('DamageArea').simulate('click', newOptions);
                expect(mockSetEventsValidationAction).toBeCalledWith([{error: false, blah: 'blah'}]);
                expect(mockUpdateDamages).toBeCalledWith(0, 0, ['rear']);
            });

            it('should dispatch setEventsValidationAction and updateDamages with noDamages value when noDamages is clicked and error exists', () => {
                let eventsValidationWithError = [{error: true}];
                let eventWithNoDamages = {
                    involvedParties: [
                        {
                            damageSections: []
                        }
                    ]
                };
                validateEvent.mockReturnValue({error: false, blah: 'blah'});
                wrapper = shallow(<DamagesSection
                    readOnly={false}
                    options={['noDamages']}
                    isInsured={true}
                    event={eventWithNoDamages}
                    updateDamages={mockUpdateDamages}
                    eventsValidation={eventsValidationWithError}
                    setEventsValidation={mockSetEventsValidationAction}
                    eventIndex={0}
                    involvedPartyIndex={0}
                    evidences={[]}
                />);

                let event = {target: {checked: true}};
                wrapper.find('FormOption').simulate('change', event);
                expect(mockSetEventsValidationAction).toBeCalledWith([{error: false, blah: 'blah'}]);
                expect(mockUpdateDamages).toBeCalledWith(0, 0, ['noDamages']);
            });
        });
    });

    describe('Connect', () => {
        it('mapStateToProps', () => {
            const claimData = {claimNumber: '123', locked: false,evidences:[{evidenceId:'1'}]};
            const user = {userRoles: ['LOON_USER']};
            const status = {eventsValidation: 'some events validation'};
            const state = {claimData, user, status};

            const result = mapStateToProps(state);
            expect(result.readOnly).toBe(false);
            expect(result.eventsValidation).toBe('some events validation');
            expect(result.evidences).toEqual([{evidenceId:'1'}]);
        });

        it('mapDispatchToProps', () => {
            expect(mapDispatchToProps.updateDamages).toBe(updateDamagesAction);
            expect(mapDispatchToProps.setEventsValidation).toBe(setEventsValidationAction);
        });
    });
});
