jest.unmock('../../../src/main/constants/loonConstants');
jest.unmock('../../../src/main/components/liability/SupportingEvidenceModalPhotoSection');

import React from 'react';
import {shallow} from 'enzyme';
import {
    mapDispatchToProps,
    mapStateToProps,
    SupportingEvidenceModalPhotoSection
} from '../../../src/main/components/liability/SupportingEvidenceModalPhotoSection';
import {saveEvidenceAction} from '../../../src/main/actions/attachmentsActions';
import {updateEventAction} from '../../../src/main/actions/eventActions';
import {photoToggleBookmarkAction} from '../../../src/main/actions/photoActions';
import deepFreeze from 'deep-freeze';
import {isReadOnly} from '../../../src/main/helpers/claimDataHelper';

describe('SupportingEvidenceModalPhotoSection', () => {
    let wrapper;

    const
        mockSaveEvidenceAction = jest.fn(),
        mockUpdateEventAction = jest.fn(),
        mockPhotoToggleBookmarkAction = jest.fn(),
        mockOnEvidenceClick = jest.fn(),
        photoEvidences = [
            {
                id: '1',
                type: 'photo',
                photoUrl: 'photo/1',
                rotation: 0,
                role: 'CLAIMANT',
                participantPartyId: '02',
                participantSourceId: 'p2',
                category: 'the category'
            },
            {
                id: '2',
                type: 'photo',
                photoUrl: 'photo/2',
                rotation: 90,
                role: 'CLAIMANT',
                participantPartyId: '02',
                participantSourceId: 'p2',
                category: 'the category'
            },
            {
                id: '3',
                type: 'photo',
                photoUrl: 'photo/3',
                rotation: 270,
                role: 'INSURED',
                participantPartyId: '01',
                participantSourceId: 'p1',
                category: 'the category',
                sourceId: 'dcf1'
            },
        ],
        liabilitySubjects = [
            {participantSourceId: 'p1', photoAttachments: [{dcfId: 'dcf1', bookmarked: true}]},
            {participantSourceId: 'p2'}
        ];

    deepFreeze(photoEvidences);
    deepFreeze(liabilitySubjects);

    beforeEach(() => {
        wrapper = shallow(
            <SupportingEvidenceModalPhotoSection
                photoEvidences={photoEvidences}
                claimNumber={'123'}
                liabilitySubjects={liabilitySubjects}
                evidences={photoEvidences}
                saveEvidenceAction={mockSaveEvidenceAction}
                updateEventAction={mockUpdateEventAction}
                photoToggleBookmarkAction={mockPhotoToggleBookmarkAction}
                evidenceIds={['1','3']}
                onEvidenceClick={mockOnEvidenceClick}
                readOnly={false}
            />
        );
    });

    it('should render photos from evidences in sorted order with icon at the bottom', () => {
        expect(wrapper.find('img').at(0).props().src).toBe('photo/3');
        expect(wrapper.find('img').at(1).props().src).toBe('photo/1');
        expect(wrapper.find('img').at(2).props().src).toBe('photo/2');

        expect(wrapper.find('button').at(0).find('Icon').props().icon).toBe('check');
        expect(wrapper.find('button').at(0).props().disabled).toBe(false);
        expect(wrapper.find('button').at(0).props().className.includes('c-btn__gallery-icon--check--active')).toBe(true);
        expect(wrapper.find('button').at(2).props().className.includes('c-btn__gallery-icon--check--active')).toBe(false);
    });

    it('should render photos from evidences when Insured is the first evidence', () => {
        const newPhotoEvidences = [
            {
                id: '3',
                type: 'photo',
                photoUrl: 'photo/3',
                rotation: 270,
                role: 'INSURED',
                participantPartyId: '01',
                participantSourceId: 'p1',
                category: 'the category',
                sourceId: 'dcf1'
            },
            {
                id: '1',
                type: 'photo',
                photoUrl: 'photo/1',
                rotation: 0,
                role: 'CLAIMANT',
                participantPartyId: '02',
                participantSourceId: 'p2',
                category: 'the category'
            },
            {
                id: '2',
                type: 'photo',
                photoUrl: 'photo/2',
                rotation: 90,
                role: 'CLAIMANT',
                participantPartyId: '02',
                participantSourceId: 'p2',
                category: 'the category'
            },

        ];
        wrapper.setProps({photoEvidences: newPhotoEvidences});
        expect(wrapper.find('img').at(0).props().src).toBe('photo/3');
        expect(wrapper.find('img').at(1).props().src).toBe('photo/1');
        expect(wrapper.find('img').at(2).props().src).toBe('photo/2');
    });

    it('should have a transform rotation style based on rotation value from props', () => {
        const rotate0 = {transform: 'rotate(0deg)'};
        const rotate90 = {transform: 'rotate(90deg)'};
        const rotate270 = {transform: 'rotate(270deg)'};

        expect(wrapper.find('img').at(0).props().style).toEqual(rotate270);
        expect(wrapper.find('img').at(1).props().style).toEqual(rotate0);
        expect(wrapper.find('img').at(2).props().style).toEqual(rotate90);
    });

    it('should call the callback when the photo is clicked', () => {
        wrapper.find('button').at(0).simulate('click');
        expect(mockOnEvidenceClick).toBeCalledWith('3');
    });

    it('should have disabled true and not call evidenceCallback if the user is readOnly', () => {
        wrapper.setProps({readOnly: true});
        expect(wrapper.find('button').at(0).props().disabled).toBe(true);
    });

    describe('Connect', () => {
        it('mapStateToProps', () => {
            const state = {
                claimData: {
                    claimNumber: '123',
                    liabilitySubjects: [{id: 's1'}],
                    evidences: [{id: 'e1'}],
                    events: [{id: '0'}],
                    locked: true
                },
                user: {userRoles: ['LOON Read Only User']}
            };
            isReadOnly.mockReset();
            isReadOnly.mockReturnValue(true);
            const result = mapStateToProps(state);
            expect(result.claimNumber).toEqual('123');
            expect(result.liabilitySubjects).toEqual([{id: 's1'}]);
            expect(result.evidences).toEqual([{id: 'e1'}]);
            expect(result.events).toEqual([{id: '0'}]);
            expect(result.readOnly).toBe(true);
            expect(isReadOnly).toBeCalledWith(['LOON Read Only User'], true);
        });

        it('mapDispatchToProps', () => {
            expect(mapDispatchToProps.saveEvidenceAction).toEqual(saveEvidenceAction);
            expect(mapDispatchToProps.updateEventAction).toEqual(updateEventAction);
            expect(mapDispatchToProps.photoToggleBookmarkAction).toEqual(photoToggleBookmarkAction);
        });
    });
});
