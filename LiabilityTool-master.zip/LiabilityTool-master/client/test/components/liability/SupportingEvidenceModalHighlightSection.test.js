import React from 'react';
import {shallow} from 'enzyme';
import {
    mapStateToProps,
    SupportingEvidenceModalHighlightSection
} from '../../../src/main/components/liability/SupportingEvidenceModalHighlightSection';
import deepFreeze from 'deep-freeze';
import {isReadOnly} from '../../../src/main/helpers/claimDataHelper';

jest.unmock('../../../src/main/components/liability/SupportingEvidenceModalHighlightSection');
jest.unmock('../../../src/main/constants/loonConstants');


describe('SupportingEvidenceModalHighlightSection', () => {
    let wrapper,
        mockOnEvidenceClick,
        highlightEvidences = [
            {
                // last evidence after sort
                id: 'e1',
                sourceId: 'he1',
                type: 'highlight',
                category: 'damages',
                transcriptCreatedDate: '2019-03-08T14:26:41.509+0000',
                participantSourceId: 'p1',
                sourceVoiceId: 'v1',
                callType: 'Inquiry',
                highlightTexts: [{chunkIndex: 0}, {chunkIndex: 1}]
            },
            {
                // first evidence after sort
                id: 'e2',
                sourceId: 'he2',
                type: 'highlight',
                category: 'damages',
                transcriptCreatedDate: '2019-03-06T14:26:41.509+0000',
                participantSourceId: 'p2',
                participantDisplayName: 'Participant2',
                sourceVoiceId: 'v1',
                callType: 'Inquiry',
                highlightTexts: [
                    {chunkIndex: 1, speaker: 'caller', text: 'hey'},
                    {chunkIndex: 2, speaker: 'rep', text: 'hi'},
                    {chunkIndex: 2, speaker: 'rep', text: 'how are you'},
                    {chunkIndex: 3, speaker: 'caller', text: 'fine'},
                ]
            },
            {
                // second evidence after sort
                id: 'e3',
                sourceId: 'he3',
                type: 'highlight',
                category: 'damages',
                transcriptCreatedDate: '2019-03-07T14:26:41.509+0000',
                participantSourceId: 'p3',
                participantDisplayName: 'Participant3',
                sourceVoiceId: 'v1',
                callType: 'Inquiry',
                highlightTexts: [{chunkIndex: 2}, {chunkIndex: 3}]
            },
        ];
    mockOnEvidenceClick = jest.fn();
    deepFreeze(highlightEvidences);

    beforeEach(() => {
        wrapper = shallow(
            <SupportingEvidenceModalHighlightSection
                highlightEvidences={highlightEvidences}
                readOnly={false}
                onEvidenceClick={mockOnEvidenceClick}
                evidenceIds={['e1', 'e3']}
            />
        );
    });

    it('should render highlight sections based on number of highlight evidences prop', () => {
        expect(wrapper.find('.highlight-section').length).toBe(3);
    });

    describe('Header pill', () => {
        it('should render the name of the participant inside a pill in sorted order', () => {
            expect(wrapper.find('#highlight-pill-0').text()).toBe('<Icon />Inquiry from Participant2');
            expect(wrapper.find('#highlight-pill-1').text()).toBe('<Icon />Inquiry from Participant3');
        });

        it('should default the participant name to Unknown', () => {
            expect(wrapper.find('#highlight-pill-2').text()).toBe('<Icon />Inquiry from Unknown');
        });

        it('should not show cursor not allowed if not read only', () => {
            expect(wrapper.find('.c-btn.c-btn--recorded-statement-pill').at(0).props().disabled).toBe(false);
        });

        it('should show cursor not allowed if read only', () => {
            wrapper.setProps({readOnly: true});
            expect(wrapper.find('.c-btn.c-btn--recorded-statement-pill').at(0).props().disabled).toBe(true);
        });

        it('should render a tag icon in the pill for all evidences', () => {
            const indices = [0, 1, 2];

            indices.forEach(index => {
                expect(wrapper.find(`#highlight-pill-${index}`).find('Icon').props().icon).toBe('check-solid');
                expect(wrapper.find(`#highlight-pill-${index}`).find('Icon').props().strokeLinecap).toBe('round');
                expect(wrapper.find(`#highlight-pill-${index}`).find('Icon').props().size).toBe(1);
            });
        });

        it('should add a selected class to the pill when the evidence is selected', () => {
            expect(wrapper.find('#highlight-pill-0').props().className).not.toContain('--active');
            expect(wrapper.find('#highlight-pill-1').props().className).toContain('--active');
            expect(wrapper.find('#highlight-pill-2').props().className).toContain('--active');
        });

        it('should invoke the onEvidenceClick prop when highlight pill is clicked and user is not readOnly', () => {
            mockOnEvidenceClick.mockClear();
            wrapper.find('#highlight-pill-0').simulate('click');
            expect(mockOnEvidenceClick).toBeCalledWith('e2');
        });

        it('should not invoke the onEvidenceClick prop when highlight pill is clicked and user is readOnly', () => {
            wrapper.setProps({readOnly: true});
            mockOnEvidenceClick.mockClear();
            wrapper.find('#highlight-pill-0').simulate('click');
            expect(mockOnEvidenceClick).not.toBeCalledWith('e2');
        });
    });

    it('should render highlight texts based on number of highlight texts in the evidence', () => {
        expect(wrapper.find('.highlight-review').length).toBe(3);

        expect(wrapper.find('.highlight-review').at(0).find('.evidence-transcript-chunk').length).toBe(4);
        expect(wrapper.find('.highlight-review').at(1).find('.evidence-transcript-chunk').length).toBe(2);
        expect(wrapper.find('.highlight-review').at(2).find('.evidence-transcript-chunk').length).toBe(2);
    });

    it('should render the highlighted transcript', () => {
        expect(wrapper.find('.highlight-review').at(0).text()).toBe('callerheyrephi how are youcallerfine');
    });

    describe('Connect', () => {
        it('should mapStateToProps', () => {
            const state = {
                claimData: {
                    locked: true
                },
                user: {userRoles: ['LOON Read Only User']}
            };
            isReadOnly.mockReset();
            isReadOnly.mockReturnValue(true);
            const actualProps = mapStateToProps(state);
            expect(actualProps.readOnly).toBe(true);
            expect(isReadOnly).toBeCalledWith(['LOON Read Only User'], true);
        });
    });
});
