jest.unmock('../../../src/main/components/liability/Damages');

import React from 'react';
import {shallow} from 'enzyme';
import {Damages, mapStateToProps, mapDispatchToProps} from '../../../src/main/components/liability/Damages';
import {validateEvent} from '../../../src/main/helpers/eventValidationHelper';
import {isReadOnly} from '../../../src/main/helpers/claimDataHelper';
import {updateDamagesAction, setEventsValidationAction} from '../../../src/main/actions/eventActions';

describe('Given Damages component', () => {
    let wrapper;
    let mockUpdateDamagesAction;
    let mockSetEventsValidationAction;
    let eventsValidation = [{error: false}];
    let event = {involvedParties: [], damageSections: ['damage area']};

    beforeEach(() => {
        mockUpdateDamagesAction = jest.fn();
        mockSetEventsValidationAction = jest.fn();
        isReadOnly.mockReturnValue(false);
        let options = [
            {value: 'front', label: 'Front', checked: true},
            {value: 'rear', label: 'Rear', checked: false},
            {value: 'passengerSide', label: 'Passenger Side', checked: true},
            {value: 'driverSide', label: 'Driver Side', checked: false},
            {value: 'noDamages', label: 'No Damages', checked: false}];
        wrapper = shallow(
            <Damages
                options={options}
                readOnly={false}
                updateDamages={mockUpdateDamagesAction}
                setEventsValidation={mockSetEventsValidationAction}
                eventsValidation={eventsValidation}
                event={event}
                eventIndex={1}
                involvedPartyIndex={2}
                evidences={[]}
            />
        );
    });

    it('should render FormOption for options and No Damage', () => {
        let checkboxes = wrapper.find('FormOption');
        expect(checkboxes.length).toBe(5);
        expect(checkboxes.at(0).children().text()).toBe('Front');
        expect(checkboxes.at(1).children().text()).toBe('Rear');
        expect(checkboxes.at(2).children().text()).toBe('Passenger Side');
        expect(checkboxes.at(3).children().text()).toBe('Driver Side');
        expect(checkboxes.at(4).children().text()).toBe('No Damages');
    });

    it('should render FormOption with the correct values', () => {
        let checkboxes = wrapper.find('FormOption');
        expect(checkboxes.length).toBe(5);
        expect(checkboxes.at(0).props().value).toBe('front');
        expect(checkboxes.at(1).props().value).toBe('rear');
        expect(checkboxes.at(2).props().value).toBe('passengerSide');
        expect(checkboxes.at(3).props().value).toBe('driverSide');
        expect(checkboxes.at(4).props().value).toBe('noDamages');
    });

    it('should disable the formoption when readOnly property is true', () => {
        wrapper.setProps({readOnly:true});
        let checkboxes = wrapper.find('FormOption');
        expect(checkboxes.at(0).props().readOnly).toBe(true);
        expect(checkboxes.at(1).props().readOnly).toBe(true);
        expect(checkboxes.at(2).props().readOnly).toBe(true);
        expect(checkboxes.at(3).props().readOnly).toBe(true);
        expect(checkboxes.at(4).props().readOnly).toBe(true);

        expect(checkboxes.at(0).props().disabled).toBe(true);
        expect(checkboxes.at(1).props().disabled).toBe(true);
        expect(checkboxes.at(2).props().disabled).toBe(true);
        expect(checkboxes.at(3).props().disabled).toBe(true);
        expect(checkboxes.at(4).props().disabled).toBe(true);

        expect(checkboxes.at(0).props().className).toBe('u-vr c-option__label__text-read-only');
        expect(checkboxes.at(1).props().className).toBe('u-vr c-option__label__text-read-only');
        expect(checkboxes.at(2).props().className).toBe('u-vr c-option__label__text-read-only');
        expect(checkboxes.at(3).props().className).toBe('u-vr c-option__label__text-read-only');
        expect(checkboxes.at(4).props().className).toBe('u-vr c-option__label__text-read-only');

    });

    describe('when options are checked', () => {
        it('should have all form options by default unchecked', () => {
            let checkboxes = wrapper.find('FormOption');
            expect(checkboxes.length).toBe(5);
            expect(checkboxes.at(0).props().checked).toBe(true);
            expect(checkboxes.at(1).props().checked).toBe(false);
            expect(checkboxes.at(2).props().checked).toBe(true);
            expect(checkboxes.at(3).props().checked).toBe(false);
            expect(checkboxes.at(4).props().checked).toBe(false);
        });

        it('should dispatch action with all checked options on the check of an unchecked textbox', () => {
            let driverSide = wrapper.find('FormOption').at(3);
            let event = {target: {value: 'driverSide', checked: true}};
            driverSide.simulate('change', event);

            expect(mockUpdateDamagesAction).toBeCalledWith(1, 2, ['front', 'passengerSide', 'driverSide']);
        });

        it('should dispatch action with all checked options on the uncheck of a checked textbox', () => {
            let passengerSide = wrapper.find('FormOption').at(2);
            let event = {target: {value: 'passengerSide', checked: false}};
            passengerSide.simulate('change', event);

            expect(mockUpdateDamagesAction).toBeCalledWith(1, 2, ['front']);
        });

        it('should dispatch action with no damages only when no damage is checked', () => {
            let noDamages = wrapper.find('FormOption').at(4);
            let event = {target: {value: 'noDamages', checked: true}};
            noDamages.simulate('change', event);

            expect(mockUpdateDamagesAction).toBeCalledWith(1, 2, ['noDamages']);
        });

        it('should dispatch action without no damages another damage part is checked', () => {
            mockUpdateDamagesAction = jest.fn();
            let options = [
                {value: 'front', label: 'Front', checked: false},
                {value: 'rear', label: 'Rear', checked: false},
                {value: 'passengerSide', label: 'Passenger Side', checked: false},
                {value: 'driverSide', label: 'Driver Side', checked: false},
                {value: 'noDamages', label: 'No Damages', checked: true}];
            wrapper = shallow(
                <Damages
                    options={options}
                    setEventsValidation={mockSetEventsValidationAction}
                    eventsValidation={eventsValidation}
                    event={event}
                    readOnly={false}
                    updateDamages={mockUpdateDamagesAction}
                    eventIndex={1}
                    involvedPartyIndex={2}
                    evidences={[]}
                />
            );

            let front = wrapper.find('FormOption').at(0);
            let mockEvent = {target: {value: 'front', checked: true}};
            front.simulate('change', mockEvent);

            expect(mockUpdateDamagesAction).toBeCalledWith(1, 2, ['front']);
        });

        it('should dispatch setEventsValidationAction action when there is already an error', () => {
            mockUpdateDamagesAction = jest.fn();
            let event = {involvedParties: [{damageSections: []}]};
            const eventsValidationWithError = [{error: true}];

            let options = [
                {value: 'front', label: 'Front', checked: false},
                {value: 'rear', label: 'Rear', checked: false},
                {value: 'passengerSide', label: 'Passenger Side', checked: false},
                {value: 'driverSide', label: 'Driver Side', checked: false},
                {value: 'noDamages', label: 'No Damages', checked: true}];

            validateEvent.mockReturnValue({error: false, blah: 'blah'});

            const expectedEventsValidation = [{
                error: false,
                blah: 'blah'
            }];

            wrapper = shallow(
                <Damages
                    options={options}
                    setEventsValidation={mockSetEventsValidationAction}
                    eventsValidation={eventsValidationWithError}
                    readOnly={false}
                    event={event}
                    updateDamages={mockUpdateDamagesAction}
                    eventIndex={0}
                    involvedPartyIndex={0}
                    evidences={[]}
                />
            );

            let front = wrapper.find('FormOption').at(0);
            let mockEvent = {target: {value: 'front', checked: true}};
            front.simulate('change', mockEvent);
            expect(mockSetEventsValidationAction).toBeCalledWith(expectedEventsValidation);
            expect(mockUpdateDamagesAction).toBeCalledWith(0, 0, ['front']);
        });
    });

    describe('Render two halves of the options', () => {
        it('should render both halves of the options for odd number of options', () => {
            expect(wrapper.find('.l-grid__col--6').at(0).children().length).toBe(3);
            expect(wrapper.find('.l-grid__col--6').at(1).children().length).toBe(2);
        });

        it('should render both halves of the options for even number of options', () => {
            let options = [
                {value: 'front', label: 'Front', checked: false},
                {value: 'rear', label: 'Rear', checked: false},
                {value: 'passengerSide', label: 'Passenger Side', checked: false},
                {value: 'noDamages', label: 'No Damages', checked: true}];
            wrapper = shallow(
                <Damages
                    options={options}
                    setEventsValidation={mockSetEventsValidationAction}
                    eventsValidation={eventsValidation}
                    event={event}
                    readOnly={false}
                    updateDamages={mockUpdateDamagesAction}
                    eventIndex={1}
                    involvedPartyIndex={2}
                    evidences={[]}
                />
            );
            expect(wrapper.find('.l-grid__col--6').at(0).children().length).toBe(2);
            expect(wrapper.find('.l-grid__col--6').at(1).children().length).toBe(2);
        });
    });

    describe('Connect', () => {
        it('should mapStateToProps', () => {
            const user = {userRoles: ['LOON_USER']};
            const result = mapStateToProps({user, status: {eventsValidation: ['SomeValidation']},
                claimData: {
                liabilitySubjects: [{}],
                evidences:[{evidenceId:'1'}]
                 }});

            expect(result.eventsValidation).toEqual(['SomeValidation']);
            expect(result.isSingleParty).toEqual(true);
            expect(result.readOnly).toBe(false);
            expect(result.evidences).toEqual([{evidenceId:'1'}]);
        });

        it('should mapDispatchToProps', () => {
            const result = mapDispatchToProps;
            expect(result.updateDamages).toBe(updateDamagesAction);
            expect(result.setEventsValidation).toBe(setEventsValidationAction);
        });
    });
});
