jest.unmock('../../../src/main/components/liability/ParticipantFault');
jest.unmock('../../../src/main/constants/contributingFactorConstants');
jest.unmock('../../../src/main/constants/loonConstants');
jest.unmock('../../../src/main/helpers/contributingFactorHelper');
jest.unmock('../../../src/main/components/common/ContributingFactor');
jest.unmock('lodash');

import React from 'react';
import {shallow} from 'enzyme';
import {
    mapDispatchToProps,
    mapStateToProps,
    ParticipantFault
} from '../../../src/main/components/liability/ParticipantFault';
import {
    getAssetTypeShortName,
    getDamageOptions,
    getParticipantName,
    getVehicleInfo,
    isInsured,
    isReadOnly
} from '../../../src/main/helpers/claimDataHelper';
import {revalidateEvent} from '../../../src/main/helpers/eventValidationHelper';
import analyticsHelper from '../../../src/main/helpers/analyticsHelper';
import {setEventsValidationAction, updateEventAction} from '../../../src/main/actions/eventActions';
import LiabilityPercentage from '../../../src/main/components/common/LiabilityPercentage';
import _ from 'lodash';

describe('Given participant fault component', () => {
    let wrapper;

    let liabilitySubjects,
        events,
        mockUpdateEventAction,
        mockSetEventsValidationAction,
        mockEventsValidation,
        validateContributingFactorEvidence;

    beforeEach(() => {
        mockUpdateEventAction = jest.fn();
        mockSetEventsValidationAction = jest.fn();
        liabilitySubjects = [
            {
                role: 'INSURED',
                firstName: 'first1',
                lastName: 'last1',
                participantPartyId: '1',
                participantSourceId: '11',
                asset: {
                    assetTypeDescription: 'Auto',
                    vehicleItemId: 'asset1',
                    vehicleMake: 'Honda',
                    vehicleModel: 'Accord',
                    vehicleYear: 2000,
                },
            },
            {
                role: 'CLAIMANT',
                firstName: 'first2',
                lastName: 'last2',
                participantPartyId: '2',
                participantSourceId: '22',
                asset: {
                    assetTypeDescription: 'Motorcycle',
                    vehicleItemId: 'asset2',
                }
            }
        ];
        mockEventsValidation = [
            {
                error: false,
                involvedParties: [
                    {
                        contributingFactors: [
                            {
                                hasMissingCfDetailError: false,
                                hasMissingCfReasonError: false,
                            },
                            {
                                hasMissingCfDetailError: false,
                                hasMissingCfReasonError: false,
                            }
                        ]
                    }
                ]

            }
        ];

        events = [{
            id: '0',
            title: 'Event 1',
            involvedParties: [
                {
                    contributingFactors: [],
                    participantId: '1',
                    participantSourceId: '11',
                    assetId: 'asset1',
                    affectedParties: [{
                        participantId: '2',
                        participantSourceId: '22',
                        initialFaultPercent: 22,
                        assetId: 'asset2',
                    }]
                },
                {
                    contributingFactors: [],
                    participantId: '2',
                    participantSourceId: '22',
                    assetId: 'asset2',
                    affectedParties: [{
                        participantId: '1',
                        participantSourceId: '11',
                        initialFaultPercent: 88,
                        assetId: 'asset1',
                    }]
                }
            ]
        }];

        validateContributingFactorEvidence = true
        mockUpdateEventAction.mockClear();
        getAssetTypeShortName.mockReturnValue('auto');
        isInsured.mockReturnValue(true);
        getParticipantName.mockImplementation((param) => {
            return param.participantSourceId === '11' ? 'first1 last1' : 'first2 last2';
        });
        getVehicleInfo.mockReturnValue('2000 Honda Accord');
        getDamageOptions.mockReturnValue([{value: 'Front', label: 'Front', checked: true}]);
        wrapper = shallow(
            <ParticipantFault
                eventIndex={0}
                involvedParty={events[0].involvedParties[0]}
                involvedPartyIndex={0}
                claimNumber={'123'}
                liabilitySubjects={liabilitySubjects}
                events={events}
                readOnly={false}
                eventsValidation={mockEventsValidation}
                updateEventAction={mockUpdateEventAction}
                setEventsValidationAction={mockSetEventsValidationAction}
                evidences={[]}
                validateContributingFactorEvidence={validateContributingFactorEvidence}
            />
        );
    });

    describe('When there is only one party', () => {
        describe('renders insured information', () => {
            it('should render the insured pill', () => {
                expect(wrapper.find('ParticipantPill').length).toBe(1);
                expect(wrapper.find('ParticipantPill').get(0).props.liabilitySubject).toBe(liabilitySubjects[0]);
            });

            it('should render participant name for insured', () => {
                expect(wrapper.find('#mainParticipant-name').text()).toBe('first1 last1');
                expect(isInsured).toBeCalledWith(liabilitySubjects[0]);
            });

            it('should render Initial Fault label', () => {
                expect(wrapper.find('#initial-fault').text()).toBe('Initial Fault');
            });

            it('should render To -> Participant name', () => {
                expect(wrapper.find('#initial-fault-to').text()).toBe('TO');
                expect(wrapper.find('#arrow-icon').props().icon).toBe('line-arrow');
                expect(wrapper.find('#fault-party-name').text()).toBe('first2 last2');
            });

            it('should render a fault % text box', () => {
                expect(wrapper.find(LiabilityPercentage).props().value).toBe(22);
            });

            it('should render score updated tooltip', () => {
                expect(wrapper.find('#score-updated-0').props().style.visibility).toBe('hidden');
                expect(wrapper.find('#score-updated-0').text()).toBe('Score Updated');
            });

            it('should call updateEventAction onBlur of score input for both liabilitySubjects when event is available', () => {
                const events = [{
                    id: '0',
                    title: 'Event 1',
                    involvedParties: [
                        {
                            participantId: '1',
                            participantSourceId: '11',
                            assetId: 'asset1',
                            affectedParties: [{
                                participantId: '2',
                                participantSourceId: '22',
                                initialFaultPercent: 22,
                                assetId: 'asset2',
                            }]
                        }
                    ]
                }];

                const liabilitySubjects = [
                    {
                        role: 'INSURED',
                        firstName: 'first1',
                        lastName: 'last1',
                        participantPartyId: '1',
                        participantSourceId: '11',
                        asset: {assetTypeDescription: 'Auto', vehicleItemId: 'asset1'},
                        vehicleMake: 'Honda',
                        vehicleModel: 'Accord',
                        vehicleYear: 2000,
                    }
                ];

                const expectedEvent = {
                    id: '0',
                    title: 'Event 1',
                    involvedParties: [
                        {
                            participantId: '1',
                            participantSourceId: '11',
                            assetId: 'asset1',
                            affectedParties: [{
                                participantId: '2',
                                participantSourceId: '22',
                                initialFaultPercent: 33,
                                assetId: 'asset2',
                            }]
                        }
                    ]
                };

                const mockStyle = {style: {visibility: ''}};
                document.getElementById = jest.fn().mockReturnValue(mockStyle);

                wrapper.setProps({liabilitySubjects, events});
                wrapper.find(LiabilityPercentage).simulate('blurCallback', 33);
                expect(mockUpdateEventAction).toBeCalledWith('123', expectedEvent);
            });

        });
    });

    describe('When there are two parties', () => {
        describe('renders insured information', () => {
            it('should render the insured pill', () => {
                expect(wrapper.find('ParticipantPill').length).toBe(1);
                expect(wrapper.find('ParticipantPill').get(0).props.liabilitySubject).toBe(liabilitySubjects[0]);
            });

            it('should render participant name for insured', () => {
                expect(wrapper.find('#mainParticipant-name').text()).toBe('first1 last1');
                expect(isInsured).toBeCalledWith(liabilitySubjects[0]);
            });

            it('should render Initial Fault label', () => {
                expect(wrapper.find('#initial-fault').text()).toBe('Initial Fault');
            });

            it('should render To -> Participant name', () => {
                expect(wrapper.find('#initial-fault-to').text()).toBe('TO');
                expect(wrapper.find('#arrow-icon').props().icon).toBe('line-arrow');
                expect(wrapper.find('#fault-party-name').text()).toBe('first2 last2');
            });

            it('should render a fault % text box', () => {
                expect(wrapper.find(LiabilityPercentage).props().value).toBe(22);
            });

            it('should render score updated tooltip', () => {
                expect(wrapper.find('#score-updated-0').props().style.visibility).toBe('hidden');
                expect(wrapper.find('#score-updated-0').text()).toBe('Score Updated');
            });

            it('should call updateEventAction onBlur of score input for both liabilitySubjects when event is available', () => {
                const expectedEvent = {
                    id: '0',
                    title: 'Event 1',
                    involvedParties: [
                        {
                            contributingFactors: [],
                            participantId: '1',
                            participantSourceId: '11',
                            assetId: 'asset1',
                            affectedParties: [{
                                participantId: '2',
                                participantSourceId: '22',
                                initialFaultPercent: 33,
                                assetId: 'asset2',
                            }]
                        },
                        {
                            contributingFactors: [],
                            participantId: '2',
                            participantSourceId: '22',
                            assetId: 'asset2',
                            affectedParties: [{
                                participantId: '1',
                                participantSourceId: '11',
                                initialFaultPercent: 67,
                                assetId: 'asset1',
                            }]
                        }
                    ]
                };

                const mockStyle = {style: {visibility: ''}};
                document.getElementById = jest.fn().mockReturnValue(mockStyle);

                wrapper.find(LiabilityPercentage).simulate('blurCallback', 33);
                expect(mockUpdateEventAction).toBeCalledWith('123', expectedEvent);
                expect(document.getElementById).toBeCalledWith('score-updated-1');
                expect(mockStyle.style.visibility).toBe('visible');
                jest.advanceTimersByTime(1999);
                expect(mockStyle.style.visibility).toBe('visible');
                jest.advanceTimersByTime(2001);
                expect(mockStyle.style.visibility).toBe('hidden');
            });

            it('should empty score for claimant when input score for insured is empty', () => {
                const expectedEvent = {
                    id: '0',
                    title: 'Event 1',
                    involvedParties: [
                        {
                            contributingFactors: [],
                            participantId: '1',
                            participantSourceId: '11',
                            assetId: 'asset1',
                            affectedParties: [{
                                participantId: '2',
                                participantSourceId: '22',
                                initialFaultPercent: null,
                                assetId: 'asset2',
                            }]
                        },
                        {
                            contributingFactors: [],
                            participantId: '2',
                            participantSourceId: '22',
                            assetId: 'asset2',
                            affectedParties: [{
                                participantId: '1',
                                participantSourceId: '11',
                                initialFaultPercent: null,
                                assetId: 'asset1',
                            }]
                        }
                    ]
                };
                const mockStyle = {style: {visibility: ''}};
                document.getElementById = jest.fn().mockReturnValue(mockStyle);

                wrapper.find(LiabilityPercentage).simulate('blurCallback', null);
                expect(mockUpdateEventAction).toBeCalledWith('123', expectedEvent);
            });

        });

        describe('renders claimant information', () => {
            beforeEach(() => {
                getAssetTypeShortName.mockReset();
                getAssetTypeShortName.mockReturnValue('motorcycle');
                isInsured.mockReset();
                isInsured.mockReturnValue(false);
                getParticipantName.mockReturnValueOnce('first2 last2');
                getParticipantName.mockReturnValue('first1 last1');
                wrapper = shallow(<ParticipantFault
                    eventIndex={0}
                    involvedParty={events[0].involvedParties[1]}
                    involvedPartyIndex={0}
                    claimNumber={'123'}
                    liabilitySubjects={liabilitySubjects}
                    events={events}
                    readOnly={false}
                    eventsValidation={[]}
                    updateEventAction={mockUpdateEventAction}
                    setEventsValidationAction={mockSetEventsValidationAction}
                    evidences={[]}
                />);
            });

            it('should render participant name for claimant', () => {
                getParticipantName.mockReset();
                getParticipantName.mockReturnValue('first2 last2');
                wrapper.setProps({liabilitySubjects});

                expect(wrapper.find('#mainParticipant-name').text()).toBe('first2 last2');
                expect(isInsured).toBeCalledWith(liabilitySubjects[1]);
            });

            it('should render score updated tooltip', () => {
                expect(wrapper.find('#score-updated-1').props().style.visibility).toBe('hidden');
                expect(wrapper.find('#score-updated-1').text()).toBe('Score Updated');
            });

            it('should render the claimant pill', () => {
                expect(wrapper.find('ParticipantPill').length).toBe(1);
                expect(wrapper.find('ParticipantPill').get(0).props.liabilitySubject).toBe(liabilitySubjects[1]);
            });

            it('should call updateEventAction onBlur of score input for both liabilitySubjects when event is available', () => {
                const expectedEvent = {
                    id: '0',
                    title: 'Event 1',
                    involvedParties: [
                        {
                            contributingFactors: [],
                            participantId: '1',
                            participantSourceId: '11',
                            assetId: 'asset1',
                            affectedParties: [{
                                participantId: '2',
                                participantSourceId: '22',
                                assetId: 'asset2',
                                initialFaultPercent: 67,
                            }]
                        },
                        {
                            contributingFactors: [],
                            participantId: '2',
                            participantSourceId: '22',
                            assetId: 'asset2',
                            affectedParties: [{
                                participantId: '1',
                                participantSourceId: '11',
                                assetId: 'asset1',
                                initialFaultPercent: 33,
                            }],
                        },
                    ],
                };

                const mockStyle = {style: {visibility: ''}};
                document.getElementById = jest.fn().mockReturnValue(mockStyle);

                wrapper.find(LiabilityPercentage).simulate('blurCallback', 33);
                expect(mockUpdateEventAction).toBeCalledWith('123', expectedEvent);
                expect(document.getElementById).toBeCalledWith('score-updated-0');
                expect(mockStyle.style.visibility).toBe('visible');
                jest.advanceTimersByTime(1999);
                expect(mockStyle.style.visibility).toBe('visible');
                jest.advanceTimersByTime(2001);
                expect(mockStyle.style.visibility).toBe('hidden');
            });

            it('should empty score for insured when input score for claimant is empty', () => {
                const expectedEvent = {
                    id: '0',
                    title: 'Event 1',
                    involvedParties: [
                        {
                            contributingFactors: [],
                            participantId: '1',
                            participantSourceId: '11',
                            assetId: 'asset1',
                            affectedParties: [{
                                participantId: '2',
                                participantSourceId: '22',
                                assetId: 'asset2',
                                initialFaultPercent: null,
                            }],
                        },
                        {
                            contributingFactors: [],
                            participantId: '2',
                            participantSourceId: '22',
                            assetId: 'asset2',
                            affectedParties: [{
                                participantId: '1',
                                participantSourceId: '11',
                                assetId: 'asset1',
                                initialFaultPercent: null,
                            }]
                        },
                    ],
                };
                const mockStyle = {style: {visibility: ''}};
                document.getElementById = jest.fn().mockReturnValue(mockStyle);

                wrapper.find(LiabilityPercentage).simulate('blurCallback', null);
                expect(mockUpdateEventAction).toBeCalledWith('123', expectedEvent);
            });
        });
    });

    describe('When there are more than two parties', () => {
        let wrapper;
        isInsured.mockReturnValue(true);

        const liabilitySubjects = [
                {
                    role: 'INSURED',
                    firstName: 'first1',
                    lastName: 'last1',
                    participantPartyId: '1',
                    participantSourceId: '11',
                    asset: {assetTypeDescription: 'Auto', vehicleItemId: 'asset1'},
                    relatedParticipants: [],
                },
                {
                    role: 'CLAIMANT',
                    firstName: 'first2',
                    lastName: 'last2',
                    participantPartyId: '2',
                    participantSourceId: '22',
                    asset: {assetTypeDescription: 'Motorcycle', vehicleItemId: 'asset2'},
                    relatedParticipants: [],
                },
                {
                    role: 'CLAIMANT',
                    firstName: 'first3',
                    lastName: 'last3',
                    participantPartyId: '3',
                    participantSourceId: '33',
                    asset: {assetTypeDescription: 'Auto', vehicleItemId: 'asset3'},
                    relatedParticipants: [],
                },
            ],
            events = [{
                id: '0',
                title: 'Event 1',
                involvedParties: [
                    {participantId: '1', participantSourceId: '11', assetId: 'asset1'},
                    {participantId: '2', participantSourceId: '22', assetId: 'asset2'},
                ]
            }],
            involvedParty = {
                participantId: '1',
                participantSourceId: '11',
                assetId: 'asset1',
                damageSections: ['front', 'passenger']
            },
            involvedPartyPed = {
                participantId: '1',
                participantSourceId: '11',
                assetId: '',
                damageSections: []
            },
            mockUpdateEventAction = jest.fn();

        beforeEach(() => {
            getParticipantName.mockReturnValue('getParticipantNameReturnValueMock');

            wrapper = shallow(
                <ParticipantFault
                    eventIndex={0}
                    involvedParty={involvedParty}
                    involvedPartyIndex={0}
                    claimNumber={'123'}
                    liabilitySubjects={liabilitySubjects}
                    events={events}
                    readOnly={false}
                    eventsValidation={[]}
                    updateEventAction={mockUpdateEventAction}
                    setEventsValidationAction={mockSetEventsValidationAction}
                    evidences={[]}
                />
            );
        });

        it('should render Add Fault link', () => {
            expect(wrapper.find('#add-fault-icon').props().icon).toBe('plus');
            expect(wrapper.find('#add-fault-label').text()).toBe('Add Fault');
        });

        it('should render the fault input on click of the Add Fault', () => {
            const newEvents = JSON.parse(JSON.stringify(events));
            newEvents[0].involvedParties[0].affectedParties = undefined;
            wrapper.setProps({events: newEvents});
            const expectedEvent = {
                id: '0',
                title: 'Event 1',
                involvedParties: [
                    {
                        participantId: '1',
                        participantSourceId: '11',
                        assetId: 'asset1',
                        affectedParties: [
                            {},
                        ]
                    },
                    {participantId: '2', participantSourceId: '22', assetId: 'asset2'},
                ]
            };
            wrapper.find('#add-fault-link').simulate('click');
            expect(mockUpdateEventAction).toBeCalledWith('123', expectedEvent);
        });

        it('should render the fault input on click of the Add Fault when no affected parties are available', () => {
            const expectedEvent = {
                id: '0',
                title: 'Event 1',
                involvedParties: [
                    {
                        participantId: '1',
                        participantSourceId: '11',
                        assetId: 'asset1',
                        affectedParties: [
                            {},
                        ],
                    },
                    {participantId: '2', participantSourceId: '22', assetId: 'asset2'},
                ]
            };
            wrapper.find('#add-fault-link').simulate('click');
            expect(mockUpdateEventAction).toBeCalledWith('123', expectedEvent);
        });

        it('should disable the Add Fault link if the user is a Read Only user', () => {
            wrapper.setProps({readOnly: true});
            expect(wrapper.find('#add-fault-link').props().disabled).toBe(true);
            expect(wrapper.find('#add-fault-link').props().className.includes('cursor-not-allowed')).toBe(true);
            expect(wrapper.find('#add-fault-link').props().onClick).toBe(undefined);
        });

        it('should not disable the Add Fault link if the user is not a Read Only user', () => {
            expect(wrapper.find('#add-fault-link').props().disabled).toBe(false);
            expect(wrapper.find('#add-fault-link').props().className.includes('cursor-not-allowed')).toBe(false);
        });

        describe('Fault input section', () => {
            beforeEach(() => {
                wrapper = shallow(<ParticipantFault
                    eventIndex={0}
                    involvedParty={{...involvedParty, affectedParties: [{participantId: ' '}]}}
                    involvedPartyIndex={0}
                    claimNumber={'123'}
                    liabilitySubjects={liabilitySubjects}
                    events={events}
                    readOnly={false}
                    eventsValidation={[]}
                    updateEventAction={mockUpdateEventAction}
                    setEventsValidationAction={mockSetEventsValidationAction}
                    validateContributingFactorEvidence={true}
                    evidences={[]}
                />);
            });

            it('should render the fault input section based on the affected parties', () => {
                expect(wrapper.find('#fault-input-section').length).toBe(1);
            });

            it('should render X for each affected party', () => {
                expect(wrapper.find('#fault-icon-x-0').props().icon).toBe('cross');
                expect(wrapper.find('#fault-icon-x-0').props().disabled).toBe(false);
                expect(wrapper.find('#fault-icon-x-0').props().className.includes('cursor-not-allowed')).toBe(false);
            });

            it('should render X in disabled state for read only user', () => {
                wrapper.setProps({readOnly: true});
                expect(wrapper.find('#fault-icon-x-0').props().disabled).toBe(true);
                expect(wrapper.find('#fault-icon-x-0').props().className.includes('cursor-not-allowed')).toBe(true);
            });

            it('should not have click event for read only user', () => {
                mockUpdateEventAction.mockReset();
                wrapper.setProps({readOnly: true});
                wrapper.find('#fault-icon-x-0').simulate('click');
                expect(mockUpdateEventAction).not.toBeCalled();
            });

            it('should disable Add Fault link when there are no more possible liabilitySubjects', () => {
                expect(wrapper.find('#add-fault-link').props().className.includes('cursor-not-allowed')).toBe(true);
                expect(wrapper.find('#add-fault-link').props().onClick).toBe(undefined);
            });

            it('should not disable Add Fault link when there are possible liabilitySubjects', () => {
                wrapper.setProps({involvedParty});
                expect(wrapper.find('#add-fault-link').props().className.includes('cursor-not-allowed')).toBe(false);
            });

            it('should render To -> ', () => {
                expect(wrapper.find('#initial-fault-to').text()).toBe('TO');
                expect(wrapper.find('#arrow-icon').props().icon).toBe('line-arrow');
            });

            it('should delete the fault section for the given participant and revalidate the event on click of X icon', () => {
                const newEvents = [{
                    id: '0',
                    title: 'Event 1',
                    involvedParties: [
                        {
                            participantId: '1',
                            participantSourceId: '11',
                            assetId: 'asset1',
                            affectedParties: [{participantId: '2', assetId: 'asset2'}],
                        },
                    ],
                }];

                const oldValidation = [
                    {error: true, blah: 'oldValidation'}
                ];
                revalidateEvent.mockReset();

                wrapper.setProps({events: newEvents, eventsValidation: oldValidation});
                wrapper.find('#fault-icon-x-0').simulate('click', 0);
                const expectedEvent = {
                    id: '0',
                    title: 'Event 1',
                    involvedParties: [
                        {
                            participantId: '1',
                            participantSourceId: '11',
                            assetId: 'asset1',
                            affectedParties: [],
                        }
                    ],
                };
                expect(mockUpdateEventAction).toBeCalledWith('123', expectedEvent);
                expect(revalidateEvent).toBeCalledWith(expectedEvent, mockSetEventsValidationAction, 0, oldValidation, [], true);
            });

            describe('render dropdown', () => {
                it('when no affected parties available', () => {
                    const newEvents = [{
                        id: '0',
                        title: 'Event 1',
                        involvedParties: [
                            {
                                participantId: '1',
                                participantSourceId: '11',
                                assetId: 'asset1',
                                affectedParties: [{participantSourceId: '', assetId: ''}]
                            },
                            {participantId: '2', participantSourceId: '22', assetId: 'asset2'},
                            {participantId: '3', participantSourceId: '33', assetId: 'asset3'},
                        ],
                    }];
                    wrapper.setProps({events: newEvents, involvedParty: newEvents[0].involvedParties[0]});
                    expect(wrapper.find('#participant-dropdown-0').props().items).toEqual([
                        {
                            value: JSON.stringify({participantSourceId: '22', assetId: 'asset2'}),
                            label: 'getParticipantNameReturnValueMock',
                            disabled: false,
                        },
                        {
                            value: JSON.stringify({participantSourceId: '33', assetId: 'asset3'}),
                            label: 'getParticipantNameReturnValueMock',
                            disabled: false,
                        }
                    ]);
                    expect(wrapper.find('#participant-dropdown-0').props().placeHolder).toEqual('Select a Participant');
                });

                it('when no affected parties available and user has read only role', () => {
                    const newEvents = [{
                        id: '0',
                        title: 'Event 1',
                        involvedParties: [
                            {
                                participantId: '1',
                                participantSourceId: '11',
                                assetId: 'asset1',
                                affectedParties: [{participantSourceId: '', assetId: ''}],
                            },
                            {participantId: '2', participantSourceId: '22', assetId: 'asset2'},
                            {participantId: '3', participantSourceId: '33', assetId: 'asset3'},
                        ],
                    }];
                    wrapper.setProps({
                        events: newEvents,
                        involvedParty: newEvents[0].involvedParties[0],
                        readOnly: true,
                    });
                    expect(wrapper.find('#participant-dropdown-0').props().readonly).toBe(true);
                    expect(wrapper.find('LiabilityPercentage').props().readOnly).toBe(true);
                });

                it('when affected parties are available', () => {
                    const newEvents = [{
                        id: '0',
                        title: 'Event 1',
                        involvedParties: [
                            {
                                participantId: '1',
                                participantSourceId: '11',
                                assetId: 'asset1',
                                affectedParties: [
                                    {participantId: '2', participantSourceId: '22', assetId: 'asset2'},
                                    {participantId: '3', participantSourceId: '33', assetId: 'asset3'}
                                ],
                            },
                            {participantId: '2', participantSourceId: '22', assetId: 'asset2'},
                            {participantId: '2', participantSourceId: '22', assetId: 'asset4'},
                            {participantId: '3', participantSourceId: '33', assetId: 'asset3'},
                        ],
                    }];
                    wrapper.setProps({events: newEvents, involvedParty: newEvents[0].involvedParties[0]});
                    expect(wrapper.find('#participant-dropdown-0').props().initialSelectedItem.value).toBe(JSON.stringify({
                        participantSourceId: '22',
                        assetId: 'asset2'
                    }));

                    expect(wrapper.find('#participant-dropdown-0').props().initialSelectedItem.label).toBe('getParticipantNameReturnValueMock');
                    expect(wrapper.find('#participant-dropdown-0').props().items).toEqual([
                        {
                            value: JSON.stringify({participantSourceId: '22', assetId: 'asset2'}),
                            label: 'getParticipantNameReturnValueMock',
                            disabled: false,
                        },
                        {
                            value: JSON.stringify({participantSourceId: '22', assetId: 'asset4'}),
                            label: 'getParticipantNameReturnValueMock',
                            disabled: false,
                        },
                    ]);
                    expect(wrapper.find('#participant-dropdown-1').props().initialSelectedItem.value).toBe(JSON.stringify({
                        participantSourceId: '33',
                        assetId: 'asset3',
                    }));
                    expect(wrapper.find('#participant-dropdown-1').props().initialSelectedItem.label).toBe('getParticipantNameReturnValueMock');
                    expect(wrapper.find('#participant-dropdown-1').props().items).toEqual([
                        {
                            value: JSON.stringify({participantSourceId: '22', assetId: 'asset4'}),
                            label: 'getParticipantNameReturnValueMock',
                            disabled: false,
                        },
                        {
                            value: JSON.stringify({participantSourceId: '33', assetId: 'asset3'}),
                            label: 'getParticipantNameReturnValueMock',
                            disabled: false,
                        },
                    ]);
                });

                it('when dropdown option is changed', () => {
                    const newEvents = [{
                        id: '0',
                        title: 'Event 1',
                        involvedParties: [
                            {
                                participantId: '1',
                                participantSourceId: '11',
                                assetId: 'asset1',
                                affectedParties: [{participantSourceId: '', assetId: ''}],
                            },
                            {participantId: '2', participantSourceId: '22', assetId: 'asset2'},
                            {participantId: '3', participantSourceId: '33', assetId: 'asset3'},
                        ],
                    }];

                    const expectedEvent = {
                        id: '0',
                        title: 'Event 1',
                        involvedParties: [
                            {
                                participantId: '1',
                                participantSourceId: '11',
                                assetId: 'asset1',
                                passengerPartyIds: [],
                                affectedParties: [{
                                    participantId: '2',
                                    participantSourceId: '22',
                                    assetId: 'asset2',
                                    passengerPartyIds: []
                                }]
                            },
                            {participantId: '2', participantSourceId: '22', assetId: 'asset2'},
                            {participantId: '3', participantSourceId: '33', assetId: 'asset3'},
                        ],
                    };
                    wrapper.setProps({events: newEvents, involvedParty: newEvents[0].involvedParties[0]});

                    const mockEvent = {
                        label: 'participantName',
                        value: JSON.stringify({participantSourceId: '22', assetId: 'asset2'})
                    };
                    wrapper.find('#participant-dropdown-0').simulate('select', mockEvent);
                    expect(mockUpdateEventAction).toBeCalledWith('123', expectedEvent);
                });

                it('should add passengers on dropdown option change', () => {
                    const newLiabilitySubjects = JSON.parse(JSON.stringify(liabilitySubjects));
                    newLiabilitySubjects[0] = {
                        ...newLiabilitySubjects[0],
                        relatedParticipants: [
                            {participantPartyId: '4', role: 'PASSENGER'},
                            {participantPartyId: '5', role: 'NOT A PASSENGER'},
                        ],
                    };
                    newLiabilitySubjects[1] = {
                        ...newLiabilitySubjects[1],
                        relatedParticipants: [
                            {participantPartyId: '6', role: 'PASSENGER'},
                            {participantPartyId: '7', role: 'NOT A PASSENGER'},
                        ],
                    };
                    const newEvents = [{
                        id: '0',
                        title: 'Event 1',
                        involvedParties: [
                            {
                                participantId: '1',
                                participantSourceId: '11',
                                assetId: 'asset1',
                                affectedParties: [{participantSourceId: '', assetId: ''}]
                            },
                            {participantId: '2', participantSourceId: '22', assetId: 'asset2'},
                            {participantId: '3', participantSourceId: '33', assetId: 'asset3'},
                        ],
                    }];

                    const expectedEvent = {
                        id: '0',
                        title: 'Event 1',
                        involvedParties: [
                            {
                                participantId: '1',
                                participantSourceId: '11',
                                assetId: 'asset1',
                                passengerPartyIds: ['4'],
                                affectedParties: [{
                                    participantId: '2',
                                    participantSourceId: '22',
                                    assetId: 'asset2',
                                    passengerPartyIds: ['6'],
                                }]
                            },
                            {participantId: '2', participantSourceId: '22', assetId: 'asset2'},
                            {participantId: '3', participantSourceId: '33', assetId: 'asset3'},
                        ],
                    };
                    wrapper.setProps({
                        liabilitySubjects: newLiabilitySubjects,
                        events: newEvents,
                        involvedParty: newEvents[0].involvedParties[0],
                    });

                    const mockEvent = {
                        label: 'someValue',
                        value: JSON.stringify({participantSourceId: '22', assetId: 'asset2'})
                    };
                    wrapper.find('#participant-dropdown-0').simulate('select', mockEvent);
                    expect(mockUpdateEventAction).toBeCalledWith('123', expectedEvent);
                });

                it('when affected party percentage is entered/changed', () => {
                    const newEvents = [{
                        id: '0',
                        title: 'Event 1',
                        involvedParties: [
                            {
                                participantId: '1',
                                participantSourceId: '11',
                                assetId: 'asset1',
                                affectedParties: [{participantSourceId: '', assetId: '', initialFaultPercent: 10}],
                            },
                            {participantId: '2', participantSourceId: '22', assetId: 'asset2'},
                            {participantId: '3', participantSourceId: '33', assetId: 'asset3'},
                        ],
                    }];

                    const expectedEvent = {
                        id: '0',
                        title: 'Event 1',
                        involvedParties: [
                            {
                                participantId: '1',
                                participantSourceId: '11',
                                assetId: 'asset1',
                                affectedParties: [{participantSourceId: '', assetId: '', initialFaultPercent: 11}],
                            },
                            {participantId: '2', participantSourceId: '22', assetId: 'asset2'},
                            {participantId: '3', participantSourceId: '33', assetId: 'asset3'},
                        ],
                    };
                    wrapper.setProps({events: newEvents, involvedParty: newEvents[0].involvedParties[0]});

                    wrapper.find(LiabilityPercentage).simulate('blurCallback', 11);
                    expect(mockUpdateEventAction).toBeCalledWith('123', expectedEvent);
                });

                it('when affected party percentage is entered/changed and there is an error', () => {
                    const newEvents = [{
                        id: '0',
                        title: 'Event 1',
                        involvedParties: [
                            {
                                participantId: '1',
                                participantSourceId: '11',
                                assetId: 'asset1',
                                affectedParties: [{participantSourceId: '', assetId: '', initialFaultPercent: 10}]
                            },
                            {participantId: '2', participantSourceId: '22', assetId: 'asset2'},
                            {participantId: '3', participantSourceId: '33', assetId: 'asset3'},
                        ],
                    }];
                    wrapper.setProps({
                        events: newEvents,
                        involvedParty: newEvents[0].involvedParties[0],
                        eventsValidation: [{error: true}]
                    });
                    wrapper.find(LiabilityPercentage).simulate('blurCallback', 11);
                    expect(revalidateEvent).toBeCalledWith(newEvents[0], mockSetEventsValidationAction, 0, [{error: true}], [], true);
                });

                it('should pass the value of the validateContributingFactorEvidence feature switch to revalidate Event', () => {
                    const newEvents = [{
                        id: '0',
                        title: 'Event 1',
                        involvedParties: [
                            {
                                participantId: '1',
                                participantSourceId: '11',
                                assetId: 'asset1',
                                affectedParties: [{participantId: '2', assetId: 'asset2'}],
                            },
                        ],
                    }];
                    const oldValidation = [
                        {error: true, blah: 'oldValidation'}
                    ];
                    wrapper.setProps({events: newEvents, eventsValidation: oldValidation, validateContributingFactorEvidence: false});
                    wrapper.find('#fault-icon-x-0').simulate('click', 0);
                    const expectedEvent = {
                        id: '0',
                        title: 'Event 1',
                        involvedParties: [
                            {
                                participantId: '1',
                                participantSourceId: '11',
                                assetId: 'asset1',
                                affectedParties: [],
                            }
                        ],
                    };
                    expect(mockUpdateEventAction).toBeCalledWith('123', expectedEvent);
                    expect(revalidateEvent).toBeCalledWith(newEvents[0], mockSetEventsValidationAction, 0, oldValidation, [], false);
                });
            });
        });

        describe('Damage area section', () => {
            beforeEach(() => {
                isInsured.mockReturnValue(true);
            });

            describe('applicable asset types', () => {
                let newLiabilitySubjects = [
                    {
                        role: 'INSURED',
                        firstName: 'first1',
                        lastName: 'last1',
                        participantPartyId: '1',
                        participantSourceId: '11',
                        asset: {assetTypeDescription: 'Auto', vehicleItemId: 'asset1'},
                        relatedParticipants: [],
                    },
                    {
                        role: 'CLAIMANT',
                        firstName: 'first2',
                        lastName: 'last2',
                        participantPartyId: '2',
                        participantSourceId: '22',
                        asset: {assetTypeDescription: 'Motorcycle', vehicleItemId: 'asset2'},
                        relatedParticipants: [],
                    },
                    {
                        role: 'CLAIMANT',
                        firstName: 'first3',
                        lastName: 'last3',
                        participantPartyId: '3',
                        participantSourceId: '33',
                        asset: {assetTypeDescription: 'Auto', vehicleItemId: 'asset3'},
                        relatedParticipants: [],
                    },

                ];

                const applicableAssetTypes = [
                    'Auto',
                    'Pick Up Truck',
                    'RV',
                    'Motorcycle',
                    'UTIL/CAMPER',
                    'PICK/CAMPER',
                    'Boat',
                ];

                applicableAssetTypes.forEach(assetType => {
                    it(`should render damage sections for ${assetType}`, () => {
                        const updatedLiablitySubjects = [...newLiabilitySubjects];
                        updatedLiablitySubjects[0].asset = {assetTypeDescription: assetType, vehicleItemId: 'asset1'};
                        wrapper.setProps({liabilitySubjects: updatedLiablitySubjects});
                        expect(wrapper.find('#involvedPartyDamageArea-11').exists()).toBe(true);
                    });
                });
            });

            it('should not render for asset type of PEDESTRIAN/BICYCLIST', () => {
                let liabilitySubjectsWithPedBike = [
                    {
                        role: 'INSURED',
                        firstName: 'first1',
                        lastName: 'last1',
                        participantPartyId: '1',
                        participantSourceId: '11',
                        asset: {assetTypeDescription: 'PEDESTRIAN/BICYCLIST', vehicleItemId: ''},
                        relatedParticipants: [],
                    },
                    {
                        role: 'CLAIMANT',
                        firstName: 'first2',
                        lastName: 'last2',
                        participantPartyId: '2',
                        participantSourceId: '22',
                        asset: {assetTypeDescription: 'Motorcycle', vehicleItemId: 'asset2'},
                        relatedParticipants: [],
                    },
                    {
                        role: 'CLAIMANT',
                        firstName: 'first3',
                        lastName: 'last3',
                        participantPartyId: '3',
                        participantSourceId: '33',
                        asset: {assetTypeDescription: 'Auto', vehicleItemId: 'asset3'},
                        relatedParticipants: [],
                    },

                ];

                wrapper = shallow(
                    <ParticipantFault
                        eventIndex={0}
                        involvedParty={involvedPartyPed}
                        involvedPartyIndex={0}
                        claimNumber={'123'}
                        liabilitySubjects={liabilitySubjectsWithPedBike}
                        events={events}
                        readOnly={false}
                        eventsValidation={[]}
                        updateEventAction={mockUpdateEventAction}
                        setEventsValidationAction={mockSetEventsValidationAction}
                        evidences={[]}
                    />
                );
                expect(wrapper.find('#involvedPartyDamageArea-11').exists()).toBe(false);
            });

            it('should not render for asset type of Other', () => {
                let liabilitySubjectsWithPedBike = [
                    {
                        role: 'INSURED',
                        firstName: 'first1',
                        lastName: 'last1',
                        participantPartyId: '1',
                        participantSourceId: '11',
                        asset: {assetTypeDescription: 'Other', vehicleItemId: ''},
                        relatedParticipants: [],
                    },
                    {
                        role: 'CLAIMANT',
                        firstName: 'first2',
                        lastName: 'last2',
                        participantPartyId: '2',
                        participantSourceId: '22',
                        asset: {assetTypeDescription: 'Motorcycle', vehicleItemId: 'asset2'},
                        relatedParticipants: [],
                    },
                    {
                        role: 'CLAIMANT',
                        firstName: 'first3',
                        lastName: 'last3',
                        participantPartyId: '3',
                        participantSourceId: '33',
                        asset: {assetTypeDescription: 'Auto', vehicleItemId: 'asset3'},
                        relatedParticipants: [],
                    },

                ];
                wrapper = shallow(
                    <ParticipantFault
                        eventIndex={0}
                        involvedParty={involvedPartyPed}
                        involvedPartyIndex={0}
                        claimNumber={'123'}
                        liabilitySubjects={liabilitySubjectsWithPedBike}
                        events={events}
                        readOnly={false}
                        eventsValidation={[]}
                        updateEventAction={mockUpdateEventAction}
                        setEventsValidationAction={mockSetEventsValidationAction}
                        evidences={[]}
                    />
                );
                expect(wrapper.find('#involvedPartyDamageArea-11').exists()).toBe(false);
            });

            describe('DamagesSection Component', () => {
                describe('Auto asset type', () => {
                    it('should be rendered for asset type Auto', () => {
                        expect(wrapper.find('Connect(DamagesSection)').exists()).toBe(true);
                    });

                    it('should pass props to Damage Area section', () => {
                        expect(wrapper.find('Connect(DamagesSection)').props().isInsured).toBe(true);
                        expect(wrapper.find('Connect(DamagesSection)').props().options).toEqual(['front', 'passenger']);
                        expect(wrapper.find('Connect(DamagesSection)').props().eventIndex).toBe(0);
                        expect(wrapper.find('Connect(DamagesSection)').props().involvedPartyIndex).toBe(0);
                    });
                });

                describe('non-auto asset types', () => {
                    it('should not render for "PEDESTRIAN/BICYCLIST" asset type', () => {
                        let liabilitySubjectsWithPedBike = [
                            {
                                role: 'INSURED',
                                firstName: 'first1',
                                lastName: 'last1',
                                participantPartyId: '1',
                                participantSourceId: '11',
                                asset: {assetTypeDescription: 'PEDESTRIAN/BICYCLIST', vehicleItemId: ''},
                                relatedParticipants: [],
                            },
                            {
                                role: 'CLAIMANT',
                                firstName: 'first2',
                                lastName: 'last2',
                                participantPartyId: '2',
                                participantSourceId: '22',
                                asset: {assetTypeDescription: 'Motorcycle', vehicleItemId: 'asset2'},
                                relatedParticipants: [],
                            },
                            {
                                role: 'CLAIMANT',
                                firstName: 'first3',
                                lastName: 'last3',
                                participantPartyId: '3',
                                participantSourceId: '33',
                                asset: {assetTypeDescription: 'Auto', vehicleItemId: 'asset3'},
                                relatedParticipants: [],
                            },
                        ];

                        wrapper = shallow(
                            <ParticipantFault
                                eventIndex={0}
                                involvedParty={involvedPartyPed}
                                involvedPartyIndex={0}
                                claimNumber={'123'}
                                liabilitySubjects={liabilitySubjectsWithPedBike}
                                events={events}
                                readOnly={false}
                                eventsValidation={[]}
                                updateEventAction={mockUpdateEventAction}
                                setEventsValidationAction={mockSetEventsValidationAction}
                                evidences={[]}
                            />
                        );
                        expect(wrapper.find('Connect(DamagesSection)').exists()).toBe(false);
                    });

                    const nonAutoAssetTypes = ['Other', 'Pick Up Truck', 'RV', 'Motorcycle', 'UTIL/CAMPER', 'PICK/CAMPER', 'Boat'];
                    let nonAutoLiabilitySubjects;
                    nonAutoAssetTypes.forEach((assetType) => {
                        it(`should not render for ${assetType} asset type`, () => {
                            nonAutoLiabilitySubjects = [...liabilitySubjects];
                            nonAutoLiabilitySubjects[0].asset = {
                                assetTypeDescription: assetType,
                                vehicleItemId: 'asset1',
                            };
                            wrapper.setProps({liabilitySubjects: nonAutoLiabilitySubjects});
                            expect(wrapper.find('Connect(DamagesSection)').exists()).toBe(false);
                        });
                    });
                });
            });

            describe('Damages Component', () => {
                const invalidAssetTypes = ['Other', 'Auto'];
                let newLiabilitySubjects;
                const validAssetTypes = ['Pick Up Truck', 'RV', 'Motorcycle', 'UTIL/CAMPER', 'PICK/CAMPER', 'Boat'];
                invalidAssetTypes.forEach((assetType) => {
                    it(`should not be rendered for assetType ${assetType}`, () => {
                        newLiabilitySubjects = [...liabilitySubjects];
                        newLiabilitySubjects[0].asset = {
                            assetTypeDescription: assetType,
                            vehicleItemId: 'asset1',
                        };

                        wrapper = shallow(
                            <ParticipantFault
                                eventIndex={0}
                                involvedParty={involvedParty}
                                involvedPartyIndex={0}
                                claimNumber={'123'}
                                liabilitySubjects={newLiabilitySubjects}
                                events={events}
                                readOnly={false}
                                eventsValidation={[]}
                                updateEventAction={mockUpdateEventAction}
                                setEventsValidationAction={mockSetEventsValidationAction}
                                evidences={[]}
                            />
                        );
                        expect(wrapper.find('Connect(Damages)').exists()).toBe(false);
                    });
                });

                it('should not be rendered for asset type of PEDESTRIAN/BICYCLIST', () => {
                    let liabilitySubjectsWithPedBike = [
                        {
                            role: 'INSURED',
                            firstName: 'first1',
                            lastName: 'last1',
                            participantPartyId: '1',
                            participantSourceId: '11',
                            asset: {assetTypeDescription: 'PEDESTRIAN/BICYCLIST', vehicleItemId: ''},
                            relatedParticipants: [],
                        },
                        {
                            role: 'CLAIMANT',
                            firstName: 'first2',
                            lastName: 'last2',
                            participantPartyId: '2',
                            participantSourceId: '22',
                            asset: {assetTypeDescription: 'Motorcycle', vehicleItemId: 'asset2'},
                            relatedParticipants: [],
                        },
                        {
                            role: 'CLAIMANT',
                            firstName: 'first3',
                            lastName: 'last3',
                            participantPartyId: '3',
                            participantSourceId: '33',
                            asset: {assetTypeDescription: 'Auto', vehicleItemId: 'asset3'},
                            relatedParticipants: [],
                        },

                    ];

                    wrapper = shallow(
                        <ParticipantFault
                            eventIndex={0}
                            involvedParty={involvedPartyPed}
                            involvedPartyIndex={0}
                            claimNumber={'123'}
                            liabilitySubjects={liabilitySubjectsWithPedBike}
                            events={events}
                            readOnly={false}
                            eventsValidation={[]}
                            updateEventAction={mockUpdateEventAction}
                            setEventsValidationAction={mockSetEventsValidationAction}
                            evidences={[]}
                        />
                    );
                    expect(wrapper.find('Connect(Damages)').exists()).toBe(false);
                });

                validAssetTypes.forEach((assetType) => {
                    it(`should be rendered for assetType ${assetType}`, () => {
                        newLiabilitySubjects = [...liabilitySubjects];
                        newLiabilitySubjects[0].asset = {
                            assetTypeDescription: assetType,
                            vehicleItemId: 'asset1',
                        };

                        wrapper = shallow(
                            <ParticipantFault
                                eventIndex={0}
                                involvedParty={involvedParty}
                                involvedPartyIndex={0}
                                claimNumber={'123'}
                                liabilitySubjects={newLiabilitySubjects}
                                events={events}
                                readOnly={false}
                                eventsValidation={[]}
                                updateEventAction={mockUpdateEventAction}
                                setEventsValidationAction={mockSetEventsValidationAction}
                                evidences={[]}
                            />
                        );
                        expect(wrapper.find('Connect(Damages)').exists()).toBe(true);
                    });
                });
            });

            it('should render Select Damage Area and make model text with error color when event is validated and no damages selected', () => {
                const newEventsValidation = [{
                    error: true,
                    involvedParties: [
                        {
                            damagesError: true,
                            affectedParties: [{
                                initialFaultPercentError: true,
                                affectedParticipantNotSelectedError: true
                            }]
                        }
                    ]
                }];
                wrapper.setProps({eventsValidation: newEventsValidation});
                expect(wrapper.find('Icon[color="loon-pink-dark"]').exists()).toBe(true);
                expect(wrapper.find('#damage-areas-label').props().className.includes('u-text-magenta')).toBe(true);
                expect(wrapper.find('#vehicle-make-model-year').props().className.includes('u-text-magenta')).toBe(true);
            });
        });
    });

    describe('Validation', () => {
        it('should render LiabilityPercentage with hasError props when it has empty value', () => {
            const newEventsValidation = [{
                involvedParties: [
                    {affectedParties: [{initialFaultPercentError: true, affectedParticipantNotSelectedError: true}]},
                    {affectedParties: [{initialFaultPercentError: false, affectedParticipantNotSelectedError: false}]}
                ]
            }];
            wrapper.setProps({eventsValidation: newEventsValidation});

            expect(wrapper.find(LiabilityPercentage).props().hasError).toBe(true);
        });

        it('should render LiabilityPercentage with hasError props when the event has a participant with over 100% owed fault', () => {
            const newEventsValidation = [{
                involvedParties: [
                    {affectedParties: [{initialFaultPercentError: true, affectedParticipantNotSelectedError: true}]},
                    {affectedParties: [{initialFaultPercentError: false, affectedParticipantNotSelectedError: false}]}
                ]
            }];
            wrapper.setProps({eventsValidation: newEventsValidation});

            expect(wrapper.find(LiabilityPercentage).props().hasError).toBe(true);
        });

        it('should render Dropdown with error when no participant selected and event was validated', () => {
            const newLiabilitySubjects = [
                {
                    role: 'INSURED',
                    firstName: 'first1',
                    lastName: 'last1',
                    participantPartyId: '1',
                    participantSourceId: '11',
                    asset: {
                        assetTypeDescription: 'Auto',
                        vehicleItemId: 'asset1',
                        vehicleMake: 'Honda',
                        vehicleModel: 'Accord',
                        vehicleYear: 2000,
                    },

                },
                {
                    role: 'CLAIMANT',
                    firstName: 'first2',
                    lastName: 'last2',
                    participantPartyId: '2',
                    participantSourceId: '22',
                    asset: {assetTypeDescription: 'Motorcycle', vehicleItemId: 'asset2'},
                },
                {
                    role: 'CLAIMANT',
                    firstName: 'first3',
                    lastName: 'last3',
                    participantPartyId: '3',
                    participantSourceId: '33',
                    asset: {assetTypeDescription: 'Motorcycle', vehicleItemId: 'asset3'},
                }
            ];

            const newEventsValidation = [{
                involvedParties: [
                    {affectedParties: [{initialFaultPercentError: true, affectedParticipantNotSelectedError: true}]},
                    {affectedParties: [{initialFaultPercentError: false, affectedParticipantNotSelectedError: false}]}
                ]
            }];

            const newEvents = [{
                id: '0',
                title: 'Event 1',
                involvedParties: [
                    {
                        participantId: '1',
                        participantSourceId: '11',
                        assetId: 'asset1',
                        affectedParties: [{participantSourceId: ''}, {participantSourceId: 'id1'}],
                    },
                    {participantId: '2', participantSourceId: '22', assetId: 'asset2'},
                    {participantId: '3', participantSourceId: '33', assetId: 'asset3'},
                ],
            }];
            wrapper.setProps({
                eventsValidation: newEventsValidation,
                events: newEvents,
                liabilitySubjects: newLiabilitySubjects,
            });

            expect(wrapper.find('#participant-dropdown-0').props().hasError).toBe(true);
        });

        it('should clear Dropdown errors when a participant is selected', () => {
            const newLiabilitySubjects = [
                {
                    role: 'INSURED',
                    firstName: 'first1',
                    lastName: 'last1',
                    participantPartyId: '1',
                    participantSourceId: '11',
                    asset: {
                        assetTypeDescription: 'Auto',
                        vehicleItemId: 'asset1',
                        vehicleMake: 'Honda',
                        vehicleModel: 'Accord',
                        vehicleYear: 2000,
                    },
                    relatedParticipants: []
                },
                {
                    role: 'CLAIMANT',
                    firstName: 'first2',
                    lastName: 'last2',
                    participantPartyId: '2',
                    participantSourceId: '22',
                    asset: {assetTypeDescription: 'Motorcycle', vehicleItemId: 'asset2'},
                    relatedParticipants: [],
                },
                {
                    role: 'CLAIMANT',
                    firstName: 'first3',
                    lastName: 'last3',
                    participantPartyId: '3',
                    participantSourceId: '33',
                    asset: {assetTypeDescription: 'Motorcycle', vehicleItemId: 'asset3'},
                    relatedParticipants: [],
                }
            ];

            const newEvents = [{
                id: '0',
                title: 'Event 1',
                involvedParties: [
                    {
                        participantId: '1',
                        participantSourceId: '11',
                        assetId: 'asset1',
                        affectedParties: [{participantSourceId: '', assetId: ''}],
                    },
                    {participantId: '2', participantSourceId: '22', assetId: 'asset2'},
                    {participantId: '3', participantSourceId: '33', assetId: 'asset3'},
                ],
            }];

            const expectedEvent = {
                id: '0',
                title: 'Event 1',
                involvedParties: [
                    {
                        participantId: '1',
                        participantSourceId: '11',
                        assetId: 'asset1',
                        passengerPartyIds: [],
                        affectedParties: [{
                            participantId: '2',
                            participantSourceId: '22',
                            assetId: 'asset2',
                            passengerPartyIds: [],
                        }]
                    },
                    {participantId: '2', participantSourceId: '22', assetId: 'asset2'},
                    {participantId: '3', participantSourceId: '33', assetId: 'asset3'},
                ]
            };
            mockSetEventsValidationAction.mockClear();
            revalidateEvent.mockClear();
            const oldEventsValidation = [{error: true}];
            wrapper.setProps({
                events: newEvents,
                liabilitySubjects: newLiabilitySubjects,
                involvedParty: newEvents[0].involvedParties[0],
                eventsValidation: oldEventsValidation
            });
            const mockEvent = {value: JSON.stringify({participantSourceId: '22', assetId: 'asset2'})};

            wrapper.find('#participant-dropdown-0').simulate('select', mockEvent);
            expect(revalidateEvent).toBeCalledWith(expectedEvent, mockSetEventsValidationAction, 0, oldEventsValidation, [], true);
        });

        it('should not have error color in Add Contributing Factor link label and icon when no validation error available', () => {
            expect(wrapper.find('#add-contributing-link').props().className.includes('u-text-error')).toBeFalsy();
            expect(wrapper.find('#add-contributing-icon').props().color).toBe('action');
            expect(wrapper.find('#add-contributing-icon').props().color).toBe('action');
        });

        describe('Minimum One Contributing Factor Error', () => {
            it('should set Add Contributing Factor link label with error colors when minOneCfError is true', () => {
                const eventsValidation = [{
                    error: true,
                    involvedParties: [
                        {minOneCfError: true},
                    ]
                }];
                wrapper.setProps({eventsValidation});

                expect(wrapper.find('#add-contributing-link').props().className.includes('u-text-error')).toBeTruthy();
            });

            it('should set Add Contributing Factor link icon with error colors when minOneCfError is true', () => {
                const eventsValidation = [{
                    error: true,
                    involvedParties: [
                        {minOneCfError: true},
                    ]
                }];
                wrapper.setProps({eventsValidation});

                expect(wrapper.find('#add-contributing-icon').props().color).toBe('magenta');
            });

            it('should show error text for Minimum One Contributing Factor error', () => {
                const eventsValidation = [{
                    error: true,
                    involvedParties: [
                        {minOneCfError: true},
                    ]
                }];
                wrapper.setProps({eventsValidation});

                expect(wrapper.find('#min-one-cf-error-text').text()).toBe('Add at least one contributing factor to support the fault decision.');
            });
        });
    });

    describe('Contributing factors section', () => {
        describe('Adding Contributing Factors', () => {
            it('should render an add icon within the button to add a contributing factor', () => {
                expect(wrapper.find('#add-contributing-icon').props().icon).toEqual('plus');
                expect(wrapper.find('#add-contributing-label').text()).toEqual('Add a Contributing Factor');
            });

            it('should not disable the Add Contributing Factor link if the user is not a Read Only user', () => {
                expect(wrapper.find('#add-contributing-link').props().disabled).toBe(false);
                expect(wrapper.find('#add-contributing-link').props().className.includes('cursor-not-allowed')).toBe(false);
            });

            it('should disable the Add Contributing Factor link if the user is a Read Only user', () => {
                wrapper.setProps({readOnly: true});
                expect(wrapper.find('#add-contributing-link').props().disabled).toBe(true);
                expect(wrapper.find('#add-contributing-link').props().className.includes('cursor-not-allowed')).toBe(true);
                expect(wrapper.find('#add-contributing-link').props().onClick).toBe(undefined);
            });

            it('should track Add a Contributing Factor link event', () => {
                wrapper.find('#add-contributing-link').simulate('click');
                expect(analyticsHelper.trackEvent).toBeCalledWith({
                    message: 'success',
                    eventAction: 'LiabilityPage_AddContributingFactor_LinkClicked',
                    eventSource: 'link',
                    errorCode: '',
                });
            });

            it('should create a contributing factor object on click of the link and render an open Mega Menu', () => {
                wrapper = shallow(
                    <ParticipantFault
                        eventIndex={0}
                        involvedParty={events[0].involvedParties[0]}
                        involvedPartyIndex={0}
                        claimNumber={'123'}
                        liabilitySubjects={liabilitySubjects}
                        events={events}
                        readOnly={false}
                        eventsValidation={[]}
                        updateEventAction={mockUpdateEventAction}
                        setEventsValidationAction={mockSetEventsValidationAction}
                        evidences={[]}
                    />
                );
                const expected = JSON.parse(JSON.stringify(events))[0];
                expected.involvedParties[0].contributingFactors = [{}];

                wrapper.find('#add-contributing-link').simulate('click');
                expect(mockUpdateEventAction).toBeCalledWith('123', expected);
            });
        });

        describe('Missing Supporting Evidence Error', () => {
            it('should render an error message when at least one contributing factor is missing supporting evidence', () => {
                const eventsValidation = [{
                    error: true,
                    involvedParties: [
                        {minOneMissingSupportingEvidenceError: true}
                    ],

                }];
                wrapper.setProps({eventsValidation});
                expect(wrapper.find('#evidence-error-text').text()).toBe('You must add evidence for each contributing factor.')
                expect(wrapper.find('#evidence-error-text').exists()).toBe(true);

            });
        });

        describe('ContributingFactor component', () => {
            it('should render the ContributingFactor component for each contributing factor', () => {
                const clonedEvents = _.cloneDeep(events);
                clonedEvents[0].involvedParties[0].contributingFactors = [
                    {reason: 'contributing-factor-0', details: 'details-0'},
                    {reason: 'contributing-factor-1', details: 'details-1'},
                    {reason: 'contributing-factor-2', details: 'details-2'},
                ];

                const newInvolvedParty = clonedEvents[0].involvedParties[0];
                wrapper.setProps({
                    events: clonedEvents,
                    involvedParty: newInvolvedParty
                });

                const CFComponent = wrapper.find('Connect(ContributingFactor)');
                const indices = [0, 1, 2];

                indices.forEach(index => {
                    expect(CFComponent.at(index).props().cfIndex).toBe(index);
                    expect(CFComponent.at(index).props().contributingFactor)
                        .toEqual({reason: `contributing-factor-${index}`, details: `details-${index}`});

                    expect(CFComponent.at(index).props().readOnly).toBe(false);
                    expect(CFComponent.at(index).props().event).toBe(clonedEvents[0]);
                    expect(CFComponent.at(index).props().eventIndex).toBe(0);
                    expect(CFComponent.at(index).props().involvedParty).toBe(clonedEvents[0].involvedParties[0]);
                    expect(CFComponent.at(index).props().involvedPartyIndex).toBe(0);
                    expect(CFComponent.at(index).props().claimNumber).toBe('123');
                    expect(CFComponent.at(index).props().eventsValidation).toBe(mockEventsValidation);
                })
            });

            it('should not render a ContributingFactor component if there are no contributing factors', () => {
                expect(wrapper.find('Connect(ContributingFactor)').exists()).toBe(false);
            });
        });
    });

    describe('connect', () => {
        it('mapStateToProps', () => {
            const claimData = {
                claimNumber: '123',
                locked: true,
                liabilitySubjects: [
                    {participantPartyId: '01'},
                    {participantPartyId: '02'},
                ],
                events: [
                    {participantId: '01'},
                    {participantId: '02'},
                ],
                evidences: [{
                    evidenceId: '1'
                }]
            };
            const user = {
                userRoles: ['ReadOnly']
            };
            const status = {
                eventsValidation: [{id: 'id'}]
            };
            const featureSwitches = {validateContributingFactorEvidence: true}

            const store = {claimData, user, status, featureSwitches};

            isReadOnly.mockReturnValue(true);

            const actual = mapStateToProps(store);
            expect(actual.claimNumber).toBe('123');
            expect(actual.liabilitySubjects).toEqual([
                {participantPartyId: '01'},
                {participantPartyId: '02'},
            ]);
            expect(actual.validateContributingFactorEvidence).toBe(true);
            expect(actual.events).toEqual([
                {participantId: '01'},
                {participantId: '02'},
            ]);
            expect(actual.readOnly).toEqual(true);
            expect(actual.eventsValidation).toEqual([{id: 'id'}]);
            expect(actual.evidences).toEqual([{
                evidenceId: '1'
            }])

            expect(isReadOnly).toBeCalledWith(user.userRoles, claimData.locked);
        });

        it('mapDispatchToProps', () => {
            expect(mapDispatchToProps).toEqual({
                updateEventAction,
                setEventsValidationAction
            });
        });
    });
});
