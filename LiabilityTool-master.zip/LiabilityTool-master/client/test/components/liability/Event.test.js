jest.unmock('../../../src/main/components/liability/Event');
jest.unmock('../../../src/main/constants/loonConstants');
jest.unmock('lodash');

import React from 'react';
import {shallow} from 'enzyme';
import {Event, mapDispatchToProps, mapStateToProps} from '../../../src/main/components/liability/Event';
import {getParticipantName, isReadOnly} from '../../../src/main/helpers/claimDataHelper';
import {removeEventAction, updateEventAction} from '../../../src/main/actions/eventActions';
import {validateEvent} from '../../../src/main/helpers/eventValidationHelper';

describe('Given Event component', () => {
    let wrapper;

    let liabilitySubjects = [
            {
                role: 'INSURED',
                firstName: 'first1',
                lastName: 'last1',
                asset: {assetTypeDescription: 'Auto', vehicleItemId: 'vehicle1'},
                participantPartyId: '1',
                participantSourceId: '11'
            },
            {
                role: 'INSURED',
                firstName: 'first1',
                lastName: 'last1',
                asset: {assetTypeDescription: 'Boat', vehicleItemId: 'boat2'},
                participantPartyId: '1',
                participantSourceId: '11'
            },
            {
                role: 'CLAIMANT',
                firstName: 'first2',
                lastName: 'last2',
                asset: {assetTypeDescription: 'Motorcycle', vehicleItemId: 'motorcycle2'},
                participantPartyId: '2',
                participantSourceId: '22'
            },
            {
                role: 'CLAIMANT',
                firstName: 'first3',
                lastName: 'last3',
                asset: {assetTypeDescription: 'Pickup/Truck', vehicleItemId: 'truck3'},
                participantPartyId: '3',
                participantSourceId: '33'
            }
        ],
        event = {id: '0', title: 'my first event title'},
        mockUpdateEventAction = jest.fn(),
        mockRemoveEventAction = jest.fn(),
        mockSetEventsValidationAction = jest.fn();


    beforeEach(() => {
        jest.clearAllMocks();
        getParticipantName.mockReturnValue('getParticipantNameReturnValueMock');

        wrapper = shallow(
            <Event
                claimNumber={'123'}
                lossDetailType={'Intersection Accident'}
                liabilitySubjects={liabilitySubjects}
                numberOfEvents={2}
                readOnly={false}
                event={event}
                eventIndex={0}
                eventsValidation={[{error: false, tooMuchAssignedFaultError: []}]}
                updateEventAction={mockUpdateEventAction}
                removeEventAction={mockRemoveEventAction}
                setEventsValidationAction={mockSetEventsValidationAction}
                evidences={[]}
            />
        );
    });

    describe('Event header', () => {
        it('should display event label based on event index', () => {
            expect(wrapper.find('#event-name-label').text()).toBe('Event 1 -');
        });

        describe('Event name', () => {
            it('should display an event name text box with maxLength 60 and place holder Name this event', () => {
                expect(wrapper.find('input').props().defaultValue).toBe('my first event title');
                expect(wrapper.find('input').props().maxLength).toBe(50);
                expect(wrapper.find('input').props().placeholder).toBe('Name This Event');
                expect(wrapper.find('input').props().disabled).toBe(false);
                expect(wrapper.find('input').props().className.includes('cursor-not-allowed')).toBe(false);

            });

            it('should display an event name text box in disabled mode when readonly is true', () => {
                wrapper.setProps({readOnly: true});
                expect(wrapper.find('input').props().disabled).toBe(true);
                expect(wrapper.find('input').props().className.includes('cursor-not-allowed')).toBe(true);
            });

            it('should not call updateEventAction onBlur of event-name text field if no change in the text', () => {
                const mockEvent = {target: {value: 'my first event title'}};
                wrapper.find('input').simulate('blur', mockEvent);
                expect(mockUpdateEventAction).not.toBeCalled();
            });

            it('should call updateEventAction onBlur of event-name text field if there is a change in the text', () => {
                const mockEvent = {target: {value: 'my second event title'}};
                const newEvent = {...event, title: 'my second event title'};
                wrapper.find('input').simulate('blur', mockEvent);
                expect(mockUpdateEventAction).toBeCalledWith('123', newEvent);
            });

            it('should render the detail loss type only if there are less than 3 liability subjects', () => {
                wrapper.setProps({liabilitySubjects: [liabilitySubjects[0], liabilitySubjects[1]]});
                expect(wrapper.find('#event-name-label').text()).toBe('Intersection Accident -');
            });

            it('should have hr in the section', () => {
                expect(wrapper.find('hr').length).toBe(1);
            });
        });

        it('should not display X when eventIndex is zero', () => {
            expect(wrapper.find('Icon').length).toBe(0);
        });

        it('should display X when eventIndex is greater than zero', () => {
            wrapper.setProps({eventIndex: 2});
            expect(wrapper.find('Icon').props().icon).toBe('cross');
            expect(wrapper.find('Icon').props().disabled).toBe(false);
            expect(wrapper.find('Icon').props().className.includes('div-disabled')).toBe(false);
        });

        it('should display X in read only mode for read only user', () => {
            wrapper.setProps({eventIndex: 2, readOnly: true});
            expect(wrapper.find('Icon').props().disabled).toBe(true);
            expect(wrapper.find('Icon').props().className.includes('div-disabled')).toBe(true);
        });

        it('set the autofocus to true when the eventIndex + 1 equal to number of events and no title for that event', () => {
            wrapper.setProps({event: {id: '1'}, eventIndex: 1});
            expect(wrapper.find('input').props().autoFocus).toBe(true);
        });

        it('should call removeEventAction on click of X button', () => {
            wrapper.setProps({eventIndex: 2, event});
            wrapper.find('Icon').simulate('click');
            expect(mockRemoveEventAction).toBeCalledWith('123', event);
        });

        it('should not display button group if eventIndex is 0', () => {
            expect(wrapper.find('#severity-label').exists()).toBe(false);
            expect(wrapper.find('ButtonGroup').exists()).toBe(false);
        });

        it('should set autoComplete to false', () => {
            expect(wrapper.find('input').props().autoComplete).toBe(false);
        });
    });

    describe('Who\'s involved', () => {
        it('should display who involved ', () => {
            expect(wrapper.find('#who-involved').text()).toBe('Who\'s Involved?');
        });

        it('should display checkboxes to select involved parties with role and name', () => {
            expect(wrapper.find('FormOption').at(0).props().value).toBe('11');
            expect(wrapper.find('FormOption').at(1).props().value).toBe('11');
            expect(wrapper.find('FormOption').at(2).props().value).toBe('22');
            expect(wrapper.find('FormOption').at(3).props().value).toBe('33');

            expect(wrapper.find('FormOption').at(0).props().children.props.children[0]).toBe('INSURED');
            expect(wrapper.find('FormOption').at(2).props().children.props.children[0]).toBe('CLAIMANT');
            expect(wrapper.find('FormOption').at(0).props().children.props.children[1]).toBe(' - ');
            expect(wrapper.find('FormOption').at(0).props().children.props.children[2]).toBe('getParticipantNameReturnValueMock');
            expect(wrapper.find('FormOption').at(0).props().children.props.className.includes('cursor-not-allowed')).toBe(false);

            expect(wrapper.find('FormOption').at(0).props().disabled).toBe(false);
        });

        it('should display checkboxes in read only mode for read only user', () => {
            wrapper.setProps({readOnly: true});
            expect(wrapper.find('FormOption').at(0).props().readOnly).toBe(true);
            expect(wrapper.find('FormOption').at(0).props().children.props.className.includes('cursor-not-allowed')).toBe(true);
        });

        it('should call getParticipantName for each participant', () => {
            expect(getParticipantName).toHaveBeenCalledWith(liabilitySubjects[0]);
            expect(getParticipantName).toHaveBeenCalledWith(liabilitySubjects[1]);
            expect(getParticipantName).toHaveBeenCalledWith(liabilitySubjects[2]);
        });

        it('should call updateEventAction onChange event of the checkboxes and it is checked', () => {
            const mockEvent = {target: {checked: true, value: '11'}};
            const newEvent = {
                ...event,
                involvedParties: [{
                    participantId: '1',
                    participantSourceId: '11',
                    assetId: 'vehicle1',
                    damageSections: [],
                    affectedParties: [],
                    contributingFactors: [],
                }],
            };

            wrapper.find('FormOption').at(0).simulate('change', mockEvent);
            expect(mockUpdateEventAction).toBeCalledWith('123', newEvent);
        });

        it('should validate event and call updateEventAction onChange event of the checkboxes when there is already an error', () => {
            mockSetEventsValidationAction.mockClear();
            wrapper.setProps({eventIndex: 0, eventsValidation: [{error: true, tooMuchAssignedFaultError: []}]});
            validateEvent.mockReturnValue({error: false, severityError: false, blah: 'blah'});

            const mockEvent = {target: {checked: true, value: '11'}};
            const newEvent = {
                ...event,
                involvedParties: [{
                    participantId: '1',
                    participantSourceId: '11',
                    assetId: 'vehicle1',
                    damageSections: [],
                    affectedParties: [],
                    contributingFactors: [],
                }],
            };

            const expectedEventsValidation = [{error: false, severityError: false, blah: 'blah'}];

            wrapper.find('FormOption').at(0).simulate('change', mockEvent);
            expect(mockSetEventsValidationAction).toBeCalledWith(expectedEventsValidation);
            expect(mockUpdateEventAction).toBeCalledWith('123', newEvent);
        });

        it('should call updateEventAction onChange event of the checkboxes and it is unchecked', () => {
            mockUpdateEventAction.mockClear();
            const mockEvent = {target: {checked: false}};
            const newEvent = {
                id: '0',
                title: 'Event 1',
                involvedParties: [
                    {
                        participantId: '1',
                        participantSourceId: '11',
                        assetId: 'vehicle1',
                        affectedParties: [{
                            participantId: '2',
                            participantSourceId: '22',
                            initialFaultPercent: 22,
                            assetId: 'motorcycle2',
                        }],
                    },
                    {

                        participantId: '2',
                        participantSourceId: '22',
                        assetId: 'motorcycle2',
                        affectedParties: [{
                            participantId: '1',
                            participantSourceId: '11',
                            initialFaultPercent: 88,
                            assetId: 'vehicle1',
                        }],
                    }
                ],
            };
            wrapper.setProps({event: newEvent});

            const expectedEvent = {
                id: '0',
                title: 'Event 1',
                involvedParties: [{
                    participantId: '2',
                    participantSourceId: '22',
                    assetId: 'motorcycle2',
                    affectedParties: [],
                }],
            };
            wrapper.find('FormOption').at(0).simulate('change', mockEvent);
            expect(mockUpdateEventAction).toBeCalledWith('123', expectedEvent);
        });

        it('should check only the box for which both participantSourceId and assetId match', () => {
            const newEvent = {
                ...event,
                involvedParties: [{
                    participantId: '1',
                    participantSourceId: '11',
                    assetId: 'vehicle1',
                }]
            };

            wrapper.setProps({event: newEvent});
            expect(wrapper.find('FormOption').filter('.c-option--blue').length).toBe(1);
            expect(wrapper.find('FormOption').at(0).props().className.includes('c-option--blue')).toBe(true);
        });

        it('should uncheck only the box for which both participantSourceId and assetId match', () => {
            const newEvent = {
                ...event,
                involvedParties: [
                    {
                        participantId: '1',
                        participantSourceId: '11',
                        assetId: 'vehicle1',
                    }, {
                        participantId: '1',
                        participantSourceId: '11',
                        assetId: 'boat2',
                    }, {
                        participantId: '2',
                        participantSourceId: '22',
                        assetId: 'motorcycle2',
                    },
                ],
            };

            const expectedEvent = {
                ...event,
                involvedParties: [{
                    participantId: '1',
                    participantSourceId: '11',
                    assetId: 'vehicle1',
                }, {
                    participantId: '2',
                    participantSourceId: '22',
                    assetId: 'motorcycle2',
                }]
            };

            wrapper.setProps({event: newEvent});
            expect(wrapper.find('FormOption').filter('.c-option--blue').length).toBe(3);
            expect(wrapper.find('FormOption').at(0).props().className.includes('c-option--blue')).toBe(true);
            expect(wrapper.find('FormOption').at(1).props().className.includes('c-option--blue')).toBe(true);
            expect(wrapper.find('FormOption').at(2).props().className.includes('c-option--blue')).toBe(true);

            const boxToUncheck = wrapper.find('FormOption').filter('.c-option--blue').at(1);
            boxToUncheck.simulate('change', {target: {checked: false}});
            expect(mockUpdateEventAction).toBeCalledWith('123', expectedEvent);
        });

        it('should only remove the affectedParties for which the assetId and participantSourceId match', () => {
            const newEvent = {
                ...event,
                involvedParties: [
                    {
                        participantId: '1',
                        participantSourceId: '11',
                        assetId: 'vehicle1',
                    },
                    {
                        participantId: '1',
                        participantSourceId: '11',
                        assetId: 'boat2',
                    },
                    {
                        participantId: '2',
                        participantSourceId: '22',
                        assetId: 'motorcycle2',
                        affectedParties: [
                            {
                                participantId: '1',
                                participantSourceId: '11',
                                assetId: 'vehicle1',
                            },
                            {
                                participantId: '1',
                                participantSourceId: '11',
                                assetId: 'boat2',
                            },
                        ]
                    },
                ]
            };

            const expectedEvent = {
                ...event,
                involvedParties: [
                    {
                        participantId: '1',
                        participantSourceId: '11',
                        assetId: 'vehicle1',
                    },
                    {
                        participantId: '2',
                        participantSourceId: '22',
                        assetId: 'motorcycle2',
                        affectedParties: [
                            {
                                participantId: '1',
                                participantSourceId: '11',
                                assetId: 'vehicle1',
                            }
                        ]
                    },
                ]
            };

            wrapper.setProps({event: newEvent});
            wrapper.find('FormOption').filter('.c-option--blue').at(1).simulate('change', {target: {checked: false}});
            expect(mockUpdateEventAction).toBeCalledWith('123', expectedEvent);
        });

        it('should not remove any of the affectedParties when assetId and participantSourceId do not match', () => {
            const newEvent = {
                ...event,
                involvedParties: [
                    {
                        participantId: '1',
                        participantSourceId: '11',
                        assetId: 'vehicle1',
                    },
                    {
                        participantId: '1',
                        participantSourceId: '11',
                        assetId: 'boat2',
                    },
                    {
                        participantId: '2',
                        participantSourceId: '22',
                        assetId: 'motorcycle2',
                        affectedParties: [
                            {
                                participantId: '1',
                                participantSourceId: '11',
                                assetId: 'vehicle1',
                            }
                        ]
                    },
                ]
            };

            const expectedEvent = {
                ...event,
                involvedParties: [
                    {
                        participantId: '1',
                        participantSourceId: '11',
                        assetId: 'vehicle1',
                    },
                    {
                        participantId: '2',
                        participantSourceId: '22',
                        assetId: 'motorcycle2',
                        affectedParties: [
                            {
                                participantId: '1',
                                participantSourceId: '11',
                                assetId: 'vehicle1',
                            }
                        ]
                    },
                ]
            };

            wrapper.setProps({event: newEvent});
            wrapper.find('FormOption').filter('.c-option--blue').at(1).simulate('change', {target: {checked: false}});
            expect(mockUpdateEventAction).toBeCalledWith('123', expectedEvent);
        });

        describe('defaulting damage section', () => {

            const damageAreaAssetTypes = [
                'Auto',
                'Pick Up Truck',
                'RV',
                'Motorcycle',
                'UTIL/CAMPER',
                'PICK/CAMPER',
                'Boat',
            ];

            damageAreaAssetTypes.forEach(assetType => {
                it('should default to [] when asset type is within damageAreaAssetTypes', () => {
                    const updatedLiabilitySubjects = [...liabilitySubjects];
                    updatedLiabilitySubjects[0].asset = {assetTypeDescription: assetType, vehicleItemId: 'asset1'};
                    wrapper.setProps({liabilitySubjects: updatedLiabilitySubjects});

                    const mockEvent = {target: {checked: true, value: '11'}};
                    const newEvent = {
                        ...event,
                        involvedParties: [{
                            participantId: '1',
                            participantSourceId: '11',
                            damageSections: [],
                            assetId: 'asset1',
                            affectedParties: [],
                            contributingFactors: [],
                        }]
                    };

                    wrapper.find('FormOption').at(0).simulate('change', mockEvent);
                    expect(mockUpdateEventAction).toBeCalledWith('123', newEvent);
                });
            });

            it('should default to "hasDamage" when assetType is not within damageAreaAssetTypes', () => {
                const updatedLiabilitySubjects = [...liabilitySubjects];
                updatedLiabilitySubjects[0].asset = {
                    assetTypeDescription: 'not a damage area asset type',
                    vehicleItemId: 'asset1'
                };
                wrapper.setProps({liabilitySubjects: updatedLiabilitySubjects});

                const mockEvent = {target: {checked: true, value: '11'}};
                const newEvent = {
                    ...event,
                    involvedParties: [{
                        participantId: '1',
                        participantSourceId: '11',
                        damageSections: ['hasDamage'],
                        assetId: 'asset1',
                        affectedParties: [],
                        contributingFactors: [],
                    }]
                };

                wrapper.find('FormOption').at(0).simulate('change', mockEvent);
                expect(mockUpdateEventAction).toBeCalledWith('123', newEvent);
            });
        });

        it('should not render whos involved for two participants', () => {
            wrapper.setProps({liabilitySubjects: [liabilitySubjects[0], liabilitySubjects[1]]});
            expect(wrapper.find('#who-involved').length).toBe(0);
        });
    });

    describe('Validation', () => {
        it('should render missing information alert in case of validation error', () => {
            wrapper.setProps({eventsValidation: [{error: true}]});
            expect(wrapper.find('ErrorBanner').children().at(0).text()).toBe('Missing Information: ');
            expect(wrapper.find('ErrorBanner').children().at(1).text()).toBe('See details below');
            expect(wrapper.find('ErrorBanner').props().error).toBe(true);
        });

        it('should render the button group with error when no selection is made', () => {
            wrapper.setProps({eventIndex: 1, eventsValidation: [{}, {error: true, severityError: true}]});
            expect(wrapper.find('ButtonGroup').props().hasError).toBe(true);
        });

        it('should render the too few participants error icon and update the class to make text error color', () => {
            wrapper.setProps({
                eventIndex: 1,
                eventsValidation: [{}, {error: true, severityError: false, tooFewInvolvedPartyError: true}],
            });
            expect(wrapper.find('Icon').exists()).toBe(true);
            expect(wrapper.find('#who-involved').props().className.includes('u-text-magenta')).toBe(true);
            expect(wrapper.find('.who-involved-error-text').text()).toBe('You must add at least 2 participants to Who’s Involved for this event.');
        });

        it('should render "involved participants must be associated with fault" error message when fault validation occurs', () => {
            wrapper.setProps({
                eventIndex: 1,
                eventsValidation: [{}, {
                    error: true,
                    severityError: false,
                    tooFewInvolvedPartyError: false,
                    addFaultParticipantError: true,
                    involvedParties: [],
                }],
            });
            expect(wrapper.find('Icon').exists()).toBe(true);
            expect(wrapper.find('.who-involved-error-text').text()).toBe('Involved participants must be included in at least one fault decision pair.');

        });

        it('should render error message if less than 2 participants selected for involved party', () => {
            wrapper.setProps({
                eventIndex: 1,
                eventsValidation: [{}, {error: true, severityError: false, tooFewInvolvedPartyError: true}],
            });
            expect(wrapper.find('.who-involved-error-text').text()).toBe('You must add at least 2 participants to Who’s Involved for this event.');
        });

        describe('when one or more participants has a total assigned fault percentage greater than 100', () => {
            beforeEach(() => {
                getParticipantName.mockImplementation(o => {
                    if (JSON.stringify(liabilitySubjects[0]).includes(JSON.stringify(o))) return 'first1 last1';
                    if (JSON.stringify(liabilitySubjects[3]).includes(JSON.stringify(o))) return 'first3 last3';
                    return 'getParticipantNameReturnValueMock';
                });
            });

            it('should render an error message with the name of the participant with the error', () => {
                const eventsValidation = [{
                    error: true,
                    tooMuchAssignedFaultError: ['11'],
                }];
                wrapper.setProps({eventsValidation: eventsValidation});
                expect(getParticipantName).toBeCalledWith(liabilitySubjects[0]);

                expect(wrapper.find('.who-involved-error-text').text()).toEqual('Cannot assign more than 100% fault to first1 last1 in an event.');
            });

            it('should render the error message with a comma separated list of names when 2 or more participants have errors', () => {
                const eventsValidation = [{
                    error: true,
                    tooMuchAssignedFaultError: ['11', '33'],
                }];
                wrapper.setProps({eventsValidation: eventsValidation});
                expect(wrapper.find('.who-involved-error-text').text()).toEqual('Cannot assign more than 100% fault to first1 last1, first3 last3 in an event.');
            });
        });

    });

    describe('When rendering ParticipantFault component', () => {
        it('should not render any if there are no involvedParties', () => {
            expect(wrapper.find('Connect(ParticipantFault)').length).toBe(0);
        });

        it('should render as many as the involvedParties', () => {
            wrapper.setProps({
                event: {
                    ...event,
                    involvedParties: [
                        {participantId: '2'},
                        {participantId: '1'}
                    ]
                }
            });
            expect(wrapper.find('Connect(ParticipantFault)').at(0).props().eventIndex).toBe(0);
            expect(wrapper.find('Connect(ParticipantFault)').at(0).props().involvedParty).toEqual({participantId: '1'});
            expect(wrapper.find('Connect(ParticipantFault)').at(1).props().involvedParty).toEqual({participantId: '2'});
        });
    });

    describe('Connect helper', () => {
        it('maps store items to props', () => {
            const events = [{id: '0', title: 'my first event title'}, {id: '1', title: 'my second event title'}];
            const claimData = {
                claimNumber: '123',
                lossDetailType: 'loss-detail-type',
                events,
                liabilitySubjects: [{participantPartyId: '1'}, {participantPartyId: '2'}],
                locked: true,
                evidences: [{evidenceId: '1'}]
            };
            const user = {userRoles: ['LOON Read Only User']};
            const status = {eventsValidation: [{id: 'id'}]};
            const state = {claimData, user, status};

            isReadOnly.mockReset();
            isReadOnly.mockReturnValue(true);

            const result = mapStateToProps(state);
            expect(result.claimNumber).toEqual('123');
            expect(result.lossDetailType).toEqual('loss-detail-type');
            expect(result.liabilitySubjects).toEqual([{participantPartyId: '1'}, {participantPartyId: '2'}]);
            expect(result.readOnly).toBe(true);
            expect(result.numberOfEvents).toEqual(2);
            expect(result.eventsValidation).toEqual([{id: 'id'}]);
            expect(result.evidences).toEqual([{evidenceId: '1'}]);

            expect(isReadOnly).toBeCalledWith(user.userRoles, true);
        });

        it('maps dispatch to props', () => {
            expect(mapDispatchToProps.updateEventAction).toEqual(updateEventAction);
            expect(mapDispatchToProps.removeEventAction).toEqual(removeEventAction);
        });
    });

    describe('Events with eventIndex greater than 0', () => {
        beforeEach(() => {
            wrapper.setProps({eventIndex: 1, eventsValidation: [{error: false}, {error: false}]});
        });

        it('should render a button group for each eventIndex greater than zero', () => {
            const expectedOptions = [
                {
                    text: 'Less',
                    value: -1,
                    defaultChecked: false
                },
                {
                    text: 'Same',
                    value: 0,
                    defaultChecked: false
                },
                {
                    text: 'More',
                    value: 1,
                    defaultChecked: false
                }
            ];
            expect(wrapper.find('#severity-label').text()).toBe('Severity Compared to Event 1:');
            expect(wrapper.find('ButtonGroup').props().type).toBe('radio');
            expect(wrapper.find('ButtonGroup').props().disabled).toBe(false);
            expect(wrapper.find('ButtonGroup').props().options).toEqual(expectedOptions);
        });

        it('should call updateEventAction when ButtonGroup clicked', () => {
            const expectedOptions = [
                {
                    text: 'Less',
                    value: -1,
                    defaultChecked: false
                },
                {
                    text: 'Same',
                    value: 0,
                    defaultChecked: false
                },
                {
                    text: 'More',
                    value: 1,
                    defaultChecked: false
                }
            ];
            const mockEvent = {target: {text: 'Less', value: -1}};
            const expectedEvent = {...event, severity: -1};
            expect(wrapper.find('ButtonGroup').props().options).toEqual(expectedOptions);
            wrapper.find('ButtonGroup').simulate('change', mockEvent);

            expect(mockUpdateEventAction).toHaveBeenCalledWith('123', expectedEvent);
        });

        it('should validate event and setEventsValidationAction when ButtonGroup clicked and there is an error', () => {
            mockSetEventsValidationAction.mockClear();
            wrapper.setProps({eventIndex: 1, eventsValidation: [{error: false}, {error: true}]});
            validateEvent.mockReturnValue({error: true, severityError: false});

            const mockEvent = {target: {text: 'Less', value: -1}};
            const expectedEvent = {...event, severity: -1};
            const expectedEventsValidation = [{error: false}, {error: true, severityError: false}];

            wrapper.find('ButtonGroup').simulate('change', mockEvent);
            expect(mockSetEventsValidationAction).toBeCalledWith(expectedEventsValidation);
            expect(mockUpdateEventAction).toHaveBeenCalledWith('123', expectedEvent);
        });

        it('should render a button group for each eventIndex greater than zero with selected option if already selected', () => {
            const expectedOptions = [
                {
                    text: 'Less',
                    value: -1,
                    defaultChecked: true
                },
                {
                    text: 'Same',
                    value: 0,
                    defaultChecked: false
                },
                {
                    text: 'More',
                    value: 1,
                    defaultChecked: false
                }
            ];
            const newEvent = {...event, severity: -1};
            wrapper.setProps({event: newEvent});
            expect(wrapper.find('#severity-label').text()).toBe('Severity Compared to Event 1:');
            expect(wrapper.find('ButtonGroup').props().type).toBe('radio');
            expect(wrapper.find('ButtonGroup').props().disabled).toBe(false);
            expect(wrapper.find('ButtonGroup').props().options).toEqual(expectedOptions);
        });

        it('should render button group with disabled true for readonly user', () => {
            wrapper.setProps({readOnly: true});
            expect(wrapper.find('ButtonGroup').props().disabled).toBe(true);
        });
    });
});
