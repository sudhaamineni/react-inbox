jest.unmock('../../../src/main/components/liability/SupportingEvidenceModalSection');
jest.unmock('../../../src/main/constants/loonConstants');
import React from 'react';
import {shallow} from 'enzyme';
import SupportingEvidenceModalSection from '../../../src/main/components/liability/SupportingEvidenceModalSection';

describe('Supporting Evidence Modal Section', () => {
    let wrapper;
    let evidences = [{id: 1, type: 'photo', category: 'damages'},
        {id: 2, type: 'photo', category: 'damages'},
        {id: 3, type: 'highlight', category: 'damages'}];
    const evidenceIds = ['evidence1', 'evidence2'];
    const expectedEvidenceIds = ['evidence1', 'evidence2'];
    let mockOnEvidenceClick = jest.fn();

    const event = {id: '0', title: 'my first event title', severity: 1};

    describe('common', () => {

        beforeEach(() => {
            wrapper = shallow(<SupportingEvidenceModalSection category="damages"
                                                              evidences={evidences}
                                                              evidenceIds={evidenceIds}
                                                              onEvidenceClick={mockOnEvidenceClick}
            />);
        });

        it('should display the Evidence category and count in the header', () => {
            expect(wrapper.find('#supporting-category-section__header__text').text()).toEqual("Damages (3)");
        });

        it('should display the Evidence category Icon in the header', () => {
            expect(wrapper.find('Icon').props().icon).toEqual("tag");
            expect(wrapper.find('Icon').props().color).toEqual("loon-gray-light");
            expect(wrapper.find('Icon').props().size).toEqual(1.0);
        });

        it('should render the SupportingEvidenceModalPhotoSection with appropriate props if there are photos', () => {
            let expectedPhotoEvidences = [{id: 1, type: 'photo', category: 'damages'},
                {id: 2, type: 'photo', category: 'damages'}];

            expect(wrapper.find('Connect(SupportingEvidenceModalPhotoSection)').props().photoEvidences).toEqual(expectedPhotoEvidences);
            expect(wrapper.find('Connect(SupportingEvidenceModalPhotoSection)').props().evidenceIds).toEqual(expectedEvidenceIds);
            expect(wrapper.find('Connect(SupportingEvidenceModalPhotoSection)').props().onEvidenceClick).toEqual(mockOnEvidenceClick);
        });

        it('should not render the SupportingEvidenceModalPhotoSection when there are no photos', () => {
            let evidences = [{id: 3, type: 'highlight', category: 'damages'}];

            wrapper = shallow(<SupportingEvidenceModalSection category="damages"
                                                              evidences={evidences}
                                                              onEvidenceClick={mockOnEvidenceClick}
                                                              event={event}
                                                              involvedPartyIndex={0}
            />);

            expect(wrapper.find('Connect(SupportingEvidenceModalPhotoSection)').exists()).toBe(false);

        });

        it('should render the SupportingEvidenceModalHighlightSection if there are highlights', () => {
            let expectedHighlightEvidences = [{id: 3, type: 'highlight', category: 'damages'}];

            expect(wrapper.find('Connect(SupportingEvidenceModalHighlightSection)').props().highlightEvidences).toEqual(expectedHighlightEvidences);
            expect(wrapper.find('Connect(SupportingEvidenceModalHighlightSection)').props().evidenceIds).toEqual(expectedEvidenceIds);
            expect(wrapper.find('Connect(SupportingEvidenceModalHighlightSection)').props().onEvidenceClick).toEqual(mockOnEvidenceClick);
        });

        it('should not render the EvidenceModalHighlightSection if there are no highlights', () => {
            let evidences = [{id: 1, type: 'photo', category: 'damages'},
                {id: 2, type: 'photo', category: 'damages'}];

            wrapper = shallow(<SupportingEvidenceModalSection category="damages"
                                                              evidences={evidences}
                                                              onEvidenceClick={mockOnEvidenceClick}
                                                              event={event}
                                                              involvedPartyIndex={0}/>);

            expect(wrapper.find('Connect(SupportingEvidenceModalHighlightSection)').exists()).toBe(false);
        });
    });

});