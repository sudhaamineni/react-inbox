jest.unmock('../../../src/main/components/liability/SubmitModal');

import {shallow} from 'enzyme';
import React from 'react';

import {SubmitModal} from '../../../src/main/components/liability/SubmitModal';

describe('Given Submit Modal', () => {
    let modalText = 'This is my modal text.';

    describe('When confirm modal is displayed', () => {
        let wrapper;
        beforeAll(() => {
            wrapper = shallow(<SubmitModal
                activeModal={'Confirm'}
                isActive={true}
                spinner={false}
                modalText={modalText}
            />);
        });

        it('Then confirm-text id is populated with the message from modalText prop ', () => {
            expect(wrapper.find('#modal-text').text()).toEqual('This is my modal text.');
        });

        it('Then the ModalDialog has an id prop of "confirmModalDialog"', () => {
            expect(wrapper.find('ModalDialog').props().id).toEqual('confirmModalDialog');
        });

        it('Then the ModalDialog has an isActive prop equal to the prop passed into the SubmitModal', () => {
            expect(wrapper.find('ModalDialog').props().isActive).toEqual(true);
        });

        it('Then the ModalDialog has a  prop equal to the prop passed into the SubmitModal for show close button', () => {
            expect(wrapper.find('ModalDialog').props().showCloseBtn).toEqual(true);
        });

        it('Then the ModalDialog has a  prop equal to the prop passed into the SubmitModal for static modal', () => {
            expect(wrapper.find('ModalDialog').props().staticModal).toEqual(true);
        });

        it('Then the ModalDialog has a  prop equal to the prop passed into the SubmitModal for title', () => {
            expect(wrapper.find('ModalDialog').props().title).toEqual('Confirm');
        });

        it('Then the ModalDialog has a  prop equal to the prop passed into the SubmitModal the hide trigger', () => {
            expect(wrapper.find('ModalDialog').props().hideTrigger).toEqual(true);
        });

        it('Then the ModalDialog has a  prop equal to the prop passed into the SubmitModal the show Yes and submit text', () => {
            expect(wrapper.find('ModalDialog').props().footer.props.children[1].props.children).toBe('Yes, Submit');
        });

        it('should render the passed firstButtonLabel prop', () => {
            wrapper.setProps({firstButtonLabel: 'First button label'});
            expect(wrapper.find('ModalDialog').props().footer.props.children[1].props.children).toBe('First button label');
        });

        describe('When the firstButton is clicked', () => {
            let wrapper, mockSuccessSubmit;

            beforeAll(() => {
                mockSuccessSubmit = jest.fn();
                wrapper = shallow(<SubmitModal
                    activeModal={'Confirm'}
                    isActive={true}
                    firstButtonCallback={mockSuccessSubmit}
                    spinner={false}
                />);
                wrapper.find('ModalDialog').props().footer.props.children[1].props.onClick();
            });

            it('Then mock success submitted is called ', () => {
                expect(mockSuccessSubmit).toHaveBeenCalled();
            });
        });

        describe('When the SecondButton is clicked', () => {
            let wrapper, mockCloseModal;

            beforeAll(() => {
                mockCloseModal = jest.fn();
                wrapper = shallow(<SubmitModal
                    activeModal={'Success'}
                    isActive={true}
                    secondButtonCallback={mockCloseModal}
                    spinner={false}
                />);
                wrapper.find('ModalDialog').props().footer.props.children[2].props.onClick();
            });

            it('Then mock success submitted is called ', () => {
                expect(mockCloseModal).toHaveBeenCalled();
            });
        });
    });

    describe('When success modal is displayed', () => {
        let wrapper;

        beforeAll(() => {
            wrapper = shallow(<SubmitModal
                modalText={modalText}
                activeModal={'Success'}
                isActive={true}
                spinner={false}
            />);
        });

        it('Then success-text id is populated with the message', () => {
            expect(wrapper.find('#modal-text').text()).toEqual('This is my modal text.');
        });

        it('Then the ModalDialog has an id prop of "confirmSuccessModalDialog"', () => {
            expect(wrapper.find('ModalDialog').props().id).toEqual('confirmSuccessModalDialog');
        });

        it('Then the ModalDialog has an isActive prop equal to the prop passed into the SubmitModal', () => {
            expect(wrapper.find('ModalDialog').props().isActive).toEqual(true);
        });

        it('Then the ModalDialog has a showCloseBtn prop of false', () => {
            expect(wrapper.find('ModalDialog').props().showCloseBtn).toEqual(true);
        });

        it('Then the ModalDialog has a  prop equal to the prop passed into the SubmitModal for static modal', () => {
            expect(wrapper.find('ModalDialog').props().staticModal).toEqual(true);
        });

        it('Then the ModalDialog has a  prop equal to the prop passed into the SubmitModal for title', () => {
            expect(wrapper.find('ModalDialog').props().title).toEqual('Successfully Submitted');
        });

        it('Then the ModalDialog has a  prop equal to the prop passed into the SubmitModal the hide trigger', () => {
            expect(wrapper.find('ModalDialog').props().hideTrigger).toEqual(true);
        });

        it('Then the ModalDialog has a  prop equal to the prop passed into the SubmitModal the show Yes and submit text', () => {
            wrapper.setProps({firstButtonLabel: undefined});
            expect(wrapper.find('ModalDialog').props().footer.props.children[1].props.children).toBe('Start a New Claim');
        });

        it('should render the passed firstButtonLabel prop', () => {
            wrapper.setProps({firstButtonLabel: 'First button label'});
            expect(wrapper.find('ModalDialog').props().footer.props.children[1].props.children).toBe('First button label');
        });

        it('should render the passed secondButtonLabel prop', () => {
            wrapper.setProps({secondButtonLabel: 'Second button label'});
            expect(wrapper.find('ModalDialog').props().footer.props.children[2].props.children).toBe('Second button label');
        });

        it('Then the ModalDialog has a  prop equal to the prop passed into the SubmitModal the show cancel text', () => {
            wrapper.setProps({secondButtonLabel: undefined});
            expect(wrapper.find('ModalDialog').props().footer.props.children[2].props.children).toBe('Go to Settlement');
        });

        describe('When firstButton is called', () => {
            let wrapper, mockRedirectToSearchPage;

            beforeAll(() => {
                mockRedirectToSearchPage = jest.fn();
                wrapper = shallow(<SubmitModal
                    activeModal={'Success'}
                    isActive={true}
                    firstButtonCallback={mockRedirectToSearchPage}
                    spinner={false}
                />);
                wrapper.find('ModalDialog').props().footer.props.children[1].props.onClick();
            });

            it('Then mock success is called ', () => {
                expect(mockRedirectToSearchPage).toHaveBeenCalled();
            });
        });

        describe('When SecondButton is called', () => {
            let wrapper, mockCloseSuccessModal;

            beforeAll(() => {
                mockCloseSuccessModal = jest.fn();
                wrapper = shallow(<SubmitModal
                    activeModal={'Success'}
                    isActive={true}
                    secondButtonCallback={mockCloseSuccessModal}
                    spinner={false}
                />);
                wrapper.find('ModalDialog').props().footer.props.children[2].props.onClick();
            });

            it('Then mock success is called ', () => {
                expect(mockCloseSuccessModal).toHaveBeenCalled();
            });
        });
    });

    describe('When error modal is displayed', () => {
        let wrapper;
        let mockOnClose;
        let mockOnCloseCallback;

        beforeAll(() => {
            mockOnClose = jest.fn();
            mockOnCloseCallback = jest.fn();
            wrapper = shallow(<SubmitModal
                modalText={modalText}
                activeModal={'Error'}
                isActive={true}
                spinner={false}
                onClose={mockOnClose}
                onCloseCallback={mockOnCloseCallback}
            />);

        });

        it('Then error-text id is populated with the message ', () => {
            expect(wrapper.find('#modal-text').text()).toEqual('This is my modal text.');
        });

        it('Then the ModalDialog has an id prop of "confirmSuccessModalDialog"', () => {
            expect(wrapper.find('ModalDialog').props().id).toEqual('errorModalDialog');
        });

        it('Then the ModalDialog has an isActive prop equal to the prop passed into the SubmitModal', () => {
            expect(wrapper.find('ModalDialog').props().isActive).toEqual(true);
        });

        it('Then the ModalDialog has a showCloseButton prop of true', () => {
            expect(wrapper.find('ModalDialog').props().showCloseBtn).toEqual(true);
        });

        it('Then the ModalDialog has a  prop equal to the prop passed into the SubmitModal for static modal', () => {
            expect(wrapper.find('ModalDialog').props().staticModal).toEqual(true);
        });

        it('Then the ModalDialog has a prop equal to the prop passed into the SubmitModal for title', () => {
            expect(wrapper.find('ModalDialog').props().title).toEqual('Unable to Submit');
        });

        it('should render the passed firstButtonLabel prop', () => {
            wrapper.setProps({firstButtonLabel: 'First button label'});
            expect(wrapper.find('ModalDialog').props().footer.props.children[1].props.children).toBe('First button label');
        });

        it('Then the ModalDialog has a  prop equal to the prop passed into the SubmitModal the hide trigger', () => {
            expect(wrapper.find('ModalDialog').props().hideTrigger).toEqual(true);
        });

        it('Then the ModalDialog has a  prop equal to the prop passed into the SubmitModal the show Yes and submit text', () => {
            wrapper.setProps({firstButtonLabel: undefined});
            expect(wrapper.find('ModalDialog').props().footer.props.children[1].props.children).toBe('Try Again');
        });

        it('Then the ModalDialog has an onClose callback equal to the onClose prop passed in to the SubmitModal', () => {
            wrapper.find('ModalDialog').props().onClose();
            expect(mockOnClose).toBeCalled();
        });

        it('Then the ModalDialog has an onCloseCallback callback equal to the onCloseCallback prop passed in to the SubmitModal', () => {
            wrapper.find('ModalDialog').props().onCloseCallback();
            expect(mockOnCloseCallback).toBeCalled();
        });

        describe('When firstButton is called', () => {
            let wrapper, mockRedirectToSearchPage;

            beforeAll(() => {
                mockRedirectToSearchPage = jest.fn();
                wrapper = shallow(<SubmitModal
                    activeModal={'Error'}
                    isActive={true}
                    firstButtonCallback={mockRedirectToSearchPage}
                    spinner={false}
                />);
                wrapper.find('ModalDialog').props().footer.props.children[1].props.onClick();
            });

            it('Then mock success is called ', () => {
                expect(mockRedirectToSearchPage).toHaveBeenCalled();
            });
        });
    });

    describe('When spinner prop is true', () => {
        let wrapper;

        beforeAll(() => {
            wrapper = shallow(<SubmitModal
                spinner={true}
            />);
        });

        it('Then spinner is present', () => {
            expect(wrapper.find('ModalDialog').props().footer.props.children[0].props.children.props.id).toBe('spinloader');
        });
    });
});
