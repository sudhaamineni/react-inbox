jest.unmock('../../../src/main/components/assignment/NextAssignment');

import React from 'react';
import Enzyme, {shallow} from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import {
    mapDispatchToProps,
    mapStateToProps,
    NextAssignment
} from '../../../src/main/components/assignment/NextAssignment';
import {getNextAssignmentAction} from '../../../src/main/actions/assignmentActions';

Enzyme.configure({adapter: new Adapter()});

describe('Given NextAssignment', () => {
    let wrapper;
    const mockGetNextAssignmentAction = jest.fn(),
        mockHistory = {push: jest.fn()};

    beforeEach(() => {
        wrapper = shallow(
            <NextAssignment
                status='SOMETHING'
                history={mockHistory}
                getNextAssignmentAction={mockGetNextAssignmentAction}
            />
        );
    });

    describe('Lifecycle events', () => {
        it('componentDidMount does not redirect to Review Assignment page if status is not ASSIGNED or IN_PROGRESS', () => {
            wrapper.instance().componentDidMount();
            expect(mockHistory.push).not.toHaveBeenCalled();
        });

        it('componentWillReceiveProps does not redirect to Review Assignment page if status is not ASSIGNED or IN_PROGRESS', () => {
            wrapper.instance().componentWillReceiveProps();
            expect(mockHistory.push).not.toHaveBeenCalled();
        });

        it('componentDidMount redirects to Review Assignment page if status is ASSIGNED', () => {
            wrapper.setProps({status: 'ASSIGNED'});
            wrapper.instance().componentDidMount();
            expect(mockHistory.push).toHaveBeenCalledWith('/next/review');
        });

        it('componentWillReceiveProps redirects to Review Assignment page if status is ASSIGNED', () => {
            wrapper.setProps({status: 'ASSIGNED'});
            wrapper.instance().componentWillReceiveProps();
            expect(mockHistory.push).toHaveBeenCalledWith('/next/review');
        });

        it('componentDidMount redirects to Review Assignment page if status is IN_PROGRESS', () => {
            wrapper.setProps({status: 'IN_PROGRESS'});
            wrapper.instance().componentDidMount();
            expect(mockHistory.push).toHaveBeenCalledWith('/next/review');
        });

        it('componentWillReceiveProps redirects to Review Assignment page if status is IN_PROGRESS', () => {
            wrapper.setProps({status: 'IN_PROGRESS'});
            wrapper.instance().componentWillReceiveProps();
            expect(mockHistory.push).toHaveBeenCalledWith('/next/review');
        });
    });

    it('Renders loon logo', () => {
        expect(wrapper.find('.loon-logo').props().src).toEqual('../images/ic-welcomelogo.svg');
    });

    it('Renders the welcome message', () => {
        expect(wrapper.find('.u-text-insured').text()).toEqual('Welcome to Loon');
    });

    it('Renders the instructions', () => {
        expect(wrapper.find('#loon-instructions').text()).toEqual('Click Get Next Claim to start making your next liability analysis.');
    });

    it('Renders ready message', () => {
        expect(wrapper.find('#readyMessage').text()).toEqual('When you are ready…');
    });

    it('Renders \'Get Next Claim\' text on the button', () => {
        expect(wrapper.find('button').text()).toBe('Get Next Claim');
    });

    it('calls GetNextAssignment action onClick of button ', () => {
        wrapper.find('button').simulate('click');
        expect(mockGetNextAssignmentAction).toBeCalled();
    });

    describe('Connect', () => {
        it('mapStateToProps', () => {
            const result = mapStateToProps({
                claimData: {
                    claimNumber: '123',
                    status: 'STATUS',
                }
            }, {
                history: mockHistory
            });
            expect(result.status).toEqual('STATUS');
            expect(result.history).toEqual(mockHistory);
        });

        it('maps dispatch to props', () => {
            expect(mapDispatchToProps.getNextAssignmentAction).toEqual(getNextAssignmentAction);
        });
    });
});