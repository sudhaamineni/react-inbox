jest.unmock('../../../src/main/components/assignment/ReviewAssignment');
jest.unmock('../../../src/main/helpers/dateTimeHelper');

import React from 'react';
import {shallow} from 'enzyme';
import {
    mapDispatchToProps,
    mapStateToProps,
    ReviewAssignment
} from '../../../src/main/components/assignment/ReviewAssignment';
import {onStartReviewTimeoutAction} from '../../../src/main/actions/assignmentActions';

describe('ReviewAssignment', () => {
    let wrapper;
    const mockOnStartReviewTimeoutAction = jest.fn();

    beforeEach(() => {
        wrapper = shallow(
            <ReviewAssignment
                claimNumber='123'
                lossDate='03/01/2018'
                lossTime='10:00 am'
                lossState='Illinois'
                status='ASSIGNED'
                onStartReviewTimeoutAction={mockOnStartReviewTimeoutAction}
            />
        );
    });

    describe('Lifecycle Events', () => {
        it('sets up a timeout timer in componentDidMount', () => {
            wrapper.instance().componentDidMount();
            expect(setTimeout).toBeCalledWith(wrapper.instance().onTimeout, 900000);
            expect(wrapper.instance().timer).not.toBe(null);
        });

        it('clears the timeout timer in componentWillUnmount', () => {
            wrapper.instance().componentWillUnmount();
            expect(clearTimeout).toBeCalledWith(wrapper.instance().timer);
        });
    });

    it('renders logo', () => {
        expect(wrapper.find('.loon-logo').props().src).toBe('../images/ic-welcomelogo.svg');
    });

    it('renders title', () => {
        expect(wrapper.find('.u-text-insured').text()).toBe('Welcome to Loon');
    });

    it('renders instructions', () => {
        expect(wrapper.find('#loon-instructions').text()).toBe('Please Start Review.');
    });

    it('renders loss detail icon', () => {
        expect(wrapper.find('Icon').props().icon).toBe('intersection-circle');
    });

    it('renders loss detail label', () => {
        expect(wrapper.find('#loss-details-label').text()).toBe('Loss Details');
    });

    it('renders loss detail type', () => {
        expect(wrapper.find('#loss-details-type').text()).toBe('Intersection Accident');
    });

    it('renders loss detail time', () => {
        expect(wrapper.find('#loss-details-time').text()).toBe('Thu, Mar 1, 2018 at 10:00 am in Illinois');
    });

    it('renders Link', () => {
        expect(wrapper.find('Link').props().to).toBe('/investigate');
        expect(wrapper.find('Link').props().children).toBe('Start Review');
        expect(wrapper.find('Link').props().className).toBe('u-text-xs u-text-semibold c-btn c-btn--primary');
    });

    describe('When status is IN_PROGRESS', () => {
        beforeEach(() => {
            wrapper.setProps({status: 'IN_PROGRESS'});
        });

        it('renders instructions', () => {
            expect(wrapper.find('#loon-instructions').text()).toBe('Please Resume Review.');
        });

        it('renders Link label', () => {
            expect(wrapper.find('Link').props().children).toBe('Resume Review');
            expect(wrapper.find('Link').props().className).toBe('u-text-xs u-text-semibold c-btn c-btn--tertiary u-text-active');
        });

        it('should not raise the onStartReviewTimeoutAction when timeout expired', () => {
            wrapper.instance().onTimeout();
            expect(mockOnStartReviewTimeoutAction).not.toBeCalled();
        });
    });

    it('renders instructions when status is IN_PROGRESS', () => {
        wrapper.setProps({status: 'IN_PROGRESS'});
        expect(wrapper.find('#loon-instructions').text()).toBe('Please Resume Review.');
    });

    it('should raise the onStartReviewTimeoutAction with the current claimNumber when timeout expired', () => {
        wrapper.instance().onTimeout();
        expect(mockOnStartReviewTimeoutAction).toBeCalledWith('123');
    });

    describe('Connect', () => {
        it('mapStateToProps', () => {
            const result = mapStateToProps({
                claimData: {
                    claimNumber: '123',
                    lossDate: '03/01/2018',
                    lossTime: '10:00 am',
                    lossState: 'Illinois',
                    status: 'ASSIGNED'
                }
            });
            expect(result.claimNumber).toEqual('123');
            expect(result.lossDate).toEqual('03/01/2018');
            expect(result.lossTime).toEqual('10:00 am');
            expect(result.lossState).toEqual('Illinois');
            expect(result.status).toEqual('ASSIGNED');
        });

        it('mapDispatchToProps', () => {
            expect(mapDispatchToProps).toEqual({
                onStartReviewTimeoutAction
            });
        });
    });
});