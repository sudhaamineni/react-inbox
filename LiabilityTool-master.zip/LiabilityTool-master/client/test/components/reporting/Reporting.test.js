import { shallow } from 'enzyme';
import React from 'react';
import { mapDispatchToProps, mapStateToProps, Reporting } from '../../../src/main/components/reporting/Reporting.js';
import {
    clearReportDataAction,
    getClaimsByCreatedTimeAction,
    getInitialFaultPendingClaimsAction,
    getClaimsByInitialFaultSubmittedAction,
    getReSubmittedClaimsAction,
} from '../../../src/main/actions/reportingActions';
import { exportToCsv } from '../../../src/main/helpers/reportingHelper.js';

jest.unmock('../../../src/main/components/reporting/Reporting.js');
jest.unmock('moment');

describe('Given Reporting Component', () => {
    let wrapper;
    const mockGetSubmittedClaimsAction = jest.fn(),
        mockClearReportDataAction = jest.fn(),
        mockGetClaimsByInitialFaultSubmittedAction = jest.fn(),
        mockGetReSubmittedClaimsAction = jest.fn(),
        mockGetClaimsByCreatedTimeAction = jest.fn(),
        mockGetInitialFaultPendingClaims = jest.fn();

    const expectedErrorMessages = {
        futureDate: 'Cannot enter future date. Please enter current or past date',
        invalidDate: 'Invalid date',
        dateOrderMixup: 'End date must be after begin date'
    };
    const claims = [{
        claimNumber: '123',
        initialFaultSubmitTime: '2019-01-24T15:33:53.771+0000',
        lossDetailType: 'Intersection accident',
        lossState: 'Illinois',
        fnolToSubmittedMins: 129245,
        searchToSubmittedMins: 0,
        participantSize: 3
    }];

    beforeEach(() => {
        wrapper = shallow(
            <Reporting
                reporting={{
                    loading: false,
                    claims,
                    count: 0.77
                }}
                getSubmittedClaimsAction={mockGetSubmittedClaimsAction}
                clearReportDataAction={mockClearReportDataAction}
                getReSubmittedClaimsAction={mockGetReSubmittedClaimsAction}
                getClaimsByCreatedTimeAction={mockGetClaimsByCreatedTimeAction}
                getInitialFaultPendingClaimsAction={mockGetInitialFaultPendingClaims}
                getClaimsByInitialFaultSubmittedAction={mockGetClaimsByInitialFaultSubmittedAction}
            />
        );
    });

    it('should have the title as Loon - Report', () => {
        wrapper.instance().componentDidMount();
        expect(document.title).toEqual('Loon - Report');
    });

    it('should have correct error messages', () => {
        expect(wrapper.instance().errorMessages).toEqual(expectedErrorMessages);
    });

    describe('render function', () => {
        it('should render drop down', () => {
            expect(wrapper.find('select').children.length).toBe(1);
            expect(wrapper.find('select').props().children[0].props.children).toBe('select');
            expect(wrapper.find('select').props().children[0].props.value).toBe('');
            expect(wrapper.find('select').props().children[1].props.children).toBe('Total Number of Re-Submitted Claims');
            expect(wrapper.find('select').props().children[1].props.value).toBe('resubmitted-claims');
            expect(wrapper.find('select').props().children[2].props.children).toBe('Total Claim Searched');
            expect(wrapper.find('select').props().children[2].props.value).toBe('total-claims-searched');
            expect(wrapper.find('select').props().children[3].props.children).toBe('Total Claim Initial Fault Pending');
            expect(wrapper.find('select').props().children[4].props.value).toBe('total-claims-initial-fault-submitted');
            expect(wrapper.find('select').props().children[4].props.children).toBe('Total Claim Initial Fault Submitted');
        });

        it('should render between text', () => {
            expect(wrapper.find('#between-text').text()).toBe('between');
        });

        it('should render date picker for begin date', () => {
            wrapper.setState({ beginDate: { value: 'beginDate', hasError: false, errorMessage: '' } });
            expect(wrapper.find('#begin-date').length).toBe(1);
            expect(wrapper.find('#begin-date').props().value).toEqual('beginDate');
            expect(wrapper.find('#begin-date').props().range[0]).toEqual(new Date('01/01/2019'));
            expect(wrapper.find('#begin-date').props().range[1].toString().substring(0, 15)).toEqual(new Date().toString().substring(0, 15));
            expect(wrapper.find('#begin-date').props().hasError).toEqual(false);
        });

        it('should render and text', () => {
            expect(wrapper.find('#and-text').text()).toBe('and');
        });

        it('should render date picker for end date', () => {
            wrapper.setState({ endDate: { value: 'endDate', hasError: false, errorMessage: '' } });
            expect(wrapper.find('#end-date').length).toBe(1);
            expect(wrapper.find('#end-date').props().value).toEqual('endDate');
            expect(wrapper.find('#end-date').props().range[0]).toEqual(new Date('01/01/2019'));
            expect(wrapper.find('#end-date').props().range[1].toString().substring(0, 15)).toEqual(new Date().toString().substring(0, 15));
            expect(wrapper.find('#end-date').props().hasError).toEqual(false);
        });

        it('should not render date pickers when the category is total-claims-initial-fault-pending', () => {
            wrapper.find('select').simulate('change', { target: { value: 'total-claims-initial-fault-pending' } });
            expect(wrapper.find('#between-text').exists()).toBe(false);
            expect(wrapper.find('#begin-date').exists()).toBe(false);
            expect(wrapper.find('#and-text').exists()).toBe(false);
            expect(wrapper.find('#end-date').exists()).toBe(false);
        });

        it('should render run button', () => {
            expect(wrapper.find('#run-button').text()).toBe('Run');
        });

        it('should render a download csv link', () => {
            expect(wrapper.find('#csv-button').text()).toBe('Download CSV');
        });

        describe('render result', () => {
            it('should render loader when in loading state', () => {
                wrapper.setProps({ reporting: { loading: true, claims: [] } });
                expect(wrapper.find('Loader').exists()).toBe(true);
            });

            it('should render when category is resubmitted-claims', () => {
                const columns = [
                    { key: 'claimNumber', label: 'Claim Number' },
                    { key: 'count', label: 'Number of resubmits with in the given date range' },
                ];
                const reSubmittedClaimsData = [{
                    claimNumber: '123',
                    count: 1
                }];
                const expectedData = {
                    columns,
                    rows: reSubmittedClaimsData
                };
                wrapper.setState({
                    category: 'resubmitted-claims',
                    beginDate: { value: '01/01/2018' },
                    endDate: { value: '01/01/2019' }
                });
                wrapper.setProps({ reporting: { claims: reSubmittedClaimsData } });
                wrapper.setProps({reporting: {claims: reSubmittedClaimsData}});
                wrapper.find('#run-button').simulate('click');
                expect(mockGetReSubmittedClaimsAction).toBeCalledWith('20180101', '20190101');

                const dataTableProps = wrapper.find('#resubmit-datatable').props();
                expect(dataTableProps.data).toEqual(expectedData);
                expect(dataTableProps.sortable).toBe(true);
            });

            it('when category is total-claims-searched', () => {
                const totalClaimsSearchedData = [{
                    count: 1,
                    claimNumber: '123',
                    createdByUserId: 'samin',
                    lastModifiedByUserId: 'abcd',
                    lossState: 'Illinois',
                    comparativeNegligenceRule: 'Mod. Comparative - 51%',
                    lossDetailType: 'Intersection accident',
                    participantSize: 3,
                    createdTime: '2019-01-24T15:33:53.771+0000',
                    createdTimeInCSTStringFormat: 'Wed, Apr 24 2019 at 8:48AM CDT',
                    initialFaultSubmitTime: '2019-01-24T15:33:53.771+0000',
                    initialFaultSubmitTimeInCSTStringFormat: 'Wed, Apr 24 2019 at 8:48AM CDT',
                    settlementSubmitTimeInCSTStringFormat: 'Wed, Apr 24 2019 at 8:48AM CDT',
                    settlementSubmitTime: '2019-01-24T15:33:53.771+0000'
                }];
                wrapper.setState({ category: 'total-claims-searched' });
                wrapper.setProps({ reporting: { claims: totalClaimsSearchedData } });
                wrapper.instance().setState({category: 'total-claims-searched'});
                wrapper.setProps({reporting: {claims: totalClaimsSearchedData}});
                const columns = [
                    { key: 'count', label: 'Id' },
                    { key: 'claimNumber', label: 'Claim Number' },
                    { key: 'createdByUserId', label: 'User (NTID) Created By' },
                    { key: 'lastModifiedByUserId', label: 'User (NTID) Last Modified By' },
                    { key: 'lossDetailType', label: 'Detail Loss Type' },
                    { key: 'lossState', label: 'Loss State' },
                    { key: 'comparativeNegligenceRule', label: 'Comp Neg. Rule' },
                    { key: 'participantSize', label: '# Participant(s) Involved' },
                    { key: 'createdTimeInCSTStringFormat', label: 'Initial Claim Search in Loon Time' },
                    { key: 'initialFaultSubmitTimeInCSTStringFormat', label: 'Initial Fault Submitted Time' },
                    { key: 'settlementSubmitTimeInCSTStringFormat', label: 'Settlement Submitted Time' },
                ];
                const claimsStringFormat = [{
                    count: 1,
                    claimNumber: '123',
                    createdByUserId: 'samin',
                    lastModifiedByUserId: 'abcd',
                    lossDetailType: 'Intersection accident',

                    lossState: 'Illinois',
                    comparativeNegligenceRule: 'Mod. Comparative - 51%',
                    participantSize: 3,
                    createdTime: '2019-01-24T15:33:53.771+0000',
                    createdTimeInCSTStringFormat: 'Wed, Apr 24 2019 at 8:48AM CDT',
                    initialFaultSubmitTime: '2019-01-24T15:33:53.771+0000',
                    initialFaultSubmitTimeInCSTStringFormat: 'Wed, Apr 24 2019 at 8:48AM CDT',
                    settlementSubmitTimeInCSTStringFormat: 'Wed, Apr 24 2019 at 8:48AM CDT',
                    settlementSubmitTime: '2019-01-24T15:33:53.771+0000'
                }];

                const expectedData = {
                    columns,
                    rows: claimsStringFormat
                };

                expect(wrapper.find('#result-total-claims-searched').props().children[0]).toEqual(<b>Total Claim
                    Searched: </b>);
                wrapper.find('#run-button').simulate('click');

                const dataTableProps = wrapper.find('DataTable').props();
                expect(dataTableProps.data).toEqual(expectedData);
                expect(dataTableProps.sortable).toBe(true);
            });

            it('should render results when category is total-claims-initial-fault-pending', () => {
                const initialFaultPendingClaims = [{
                    count: 1,
                    claimNumber: '123',
                    createdByUserId: 'samin',
                    lastModifiedByUserId: 'abcd',
                    lossState: 'Illinois',
                    comparativeNegligenceRule: 'Mod. Comparative - 51%',
                    lossDetailType: 'Intersection accident',
                }];

                wrapper.setState({ category: 'total-claims-initial-fault-pending' });
                wrapper.setProps({ reporting: { claims: initialFaultPendingClaims } });
                const columns = [
                    { key: 'count', label: 'Id' },
                    { key: 'claimNumber', label: 'Claim Number' },
                    { key: 'createdByUserId', label: 'User (NTID) Created By' },
                    { key: 'lastModifiedByUserId', label: 'User (NTID) Last Modified By' },
                    { key: 'lossDetailType', label: 'Detail Loss Type' },
                    { key: 'lossState', label: 'Loss State' },
                    { key: 'comparativeNegligenceRule', label: 'Comp Neg. Rule' },
                ];
                const claimsStringFormat = [{
                    count: 1,
                    claimNumber: '123',
                    createdByUserId: 'samin',
                    lastModifiedByUserId: 'abcd',
                    lossDetailType: 'Intersection accident',
                    lossState: 'Illinois',
                    comparativeNegligenceRule: 'Mod. Comparative - 51%',
                }];

                const expectedData = {
                    columns,
                    rows: claimsStringFormat
                };

                expect(wrapper.find('#result-initial-fault-pending-claims').props().children[0]).toEqual(<b>Total Claim
                    Initial Fault Pending: </b>);
                wrapper.find('#run-button').simulate('click');

                const dataTableProps = wrapper.find('DataTable').props();
                expect(dataTableProps.data).toEqual(expectedData);
                expect(dataTableProps.sortable).toBe(true);

            });
            it('when category is total-claims-initial-falut-submitted', () => {
                const totalClaimsInitialFaultSubmittedData = [{
                    count: 1,
                    claimNumber: '123',
                    createdByUserId: 'samin',
                    lastModifiedByUserId: 'abcd',
                    lossState: 'Illinois',
                    comparativeNegligenceRule: 'Mod. Comparative - 51%',
                    lossDetailType: 'Intersection accident',
                    participantSize: 3,
                    initialFaultSubmitTime: '2019-01-24T15:33:53.771+0000',
                    initialFaultSubmitTimeInCSTStringFormat: 'Wed, Apr 24 2019 at 8:48AM CDT',
                }];
                wrapper.instance().setState({category: 'total-claims-initial-fault-submitted'});
                wrapper.setProps({reporting: {claims: totalClaimsInitialFaultSubmittedData}});
                const columns = [
                    {key: 'count', label: 'Id'},
                    {key: 'claimNumber', label: 'Claim Number'},
                    {key: 'createdByUserId', label: 'User (NTID) Created By'},
                    {key: 'lastModifiedByUserId', label: 'User (NTID) Last Modified By'},
                    {key: 'lossDetailType', label: 'Detail Loss Type'},
                    {key: 'lossState', label: 'Loss State'},
                    {key: 'comparativeNegligenceRule', label: 'Comp Neg. Rule'},
                    {key: 'participantSize', label: '# Participant(s) Involved'},
                    {key: 'initialFaultSubmitTimeInCSTStringFormat', label: 'Initial Fault Submitted Time'},
                ];
                const claimsStringFormat = [{
                    count: 1,
                    claimNumber: '123',
                    createdByUserId: 'samin',
                    lastModifiedByUserId: 'abcd',
                    lossDetailType: 'Intersection accident',
                    lossState: 'Illinois',
                    comparativeNegligenceRule: 'Mod. Comparative - 51%',
                    participantSize: 3,
                    initialFaultSubmitTime: '2019-01-24T15:33:53.771+0000',
                    initialFaultSubmitTimeInCSTStringFormat: 'Wed, Apr 24 2019 at 8:48AM CDT',
                }];

                const expectedData = {
                    columns,
                    rows: claimsStringFormat
                };

                expect(wrapper.find('#result-total-claims-initial-fault-submitted').props().children[0]).toEqual(<b>Total Claim Initial Fault Submitted: </b>);
                wrapper.find('#run-button').simulate('click');

                const dataTableProps = wrapper.find('DataTable').props();
                expect(dataTableProps.data).toEqual(expectedData);
                expect(dataTableProps.sortable).toBe(true);
            });
        });
    });

    it('should change state on changing category', () => {
        const mockEvent = { target: { value: 'new' } };
        wrapper.find('select').simulate('change', mockEvent);
        expect(wrapper.instance().state.category).toBe('new');
    });

    it('should change state on changing begin date through calendar', () => {
        wrapper.find('#begin-date').props().onSubmit({ value: 'newBeginDate' });
        expect(wrapper.instance().state.beginDate.value).toBe('newBeginDate');
    });

    it('should change state on changing end date through calendar', () => {
        wrapper.find('#end-date').props().onSubmit({ value: 'newEndDate' });
        expect(wrapper.instance().state.endDate.value).toBe('newEndDate');
    });

    it('should change state on changing begin date', () => {
        wrapper.find('#begin-date').props().onDateChange({ value: 'newBeginDate' });
        expect(wrapper.instance().state.beginDate.value).toBe('newBeginDate');
    });

    it('should change state on changing end date', () => {
        wrapper.find('#end-date').props().onDateChange({ value: 'newEndDate' });
        expect(wrapper.instance().state.endDate.value).toBe('newEndDate');
    });

    describe('Date validation', () => {
        it('should display error when begin date is in future', () => {
            wrapper.find('#begin-date').props().onDateChange({ value: '01/01/2099' });
            wrapper.find('#end-date').props().onDateChange({ value: '01/01/2016' });
            wrapper.find('#run-button').simulate('click');

            expect(wrapper.find('#begin-date').props().hasError).toBe(true);
            expect(wrapper.find('#end-date').props().hasError).toBe(false);
            expect(wrapper.find('#error-div').text()).toBe(expectedErrorMessages.futureDate);
        });

        it('should display error when end date is in future', () => {
            wrapper.find('#begin-date').props().onDateChange({ value: '01/01/2016' });
            wrapper.find('#end-date').props().onDateChange({ value: '01/01/2099' });
            wrapper.find('#run-button').simulate('click');

            expect(wrapper.find('#begin-date').props().hasError).toBe(false);
            expect(wrapper.find('#end-date').props().hasError).toBe(true);
            expect(wrapper.find('#error-div').text()).toBe(expectedErrorMessages.futureDate);
        });

        it('should display error when end date is invalid', () => {
            wrapper.setState({
                beginDate: {
                    value: '01/01/2016',
                    hasError: false,
                    errorMessage: ''
                },
                endDate: {
                    value: '35/35/2018',
                    hasError: false,
                    errorMessage: ''
                }
            });

            wrapper.find('#run-button').simulate('click');

            expect(wrapper.find('#end-date').props().hasError).toBe(true);
            expect(wrapper.find('#error-div').text()).toBe(expectedErrorMessages.invalidDate);
        });

        it('should remove errors from date pickers when dates change', () => {
            wrapper.setState({ beginDate: { hasError: true } });
            wrapper.setState({ endDate: { hasError: true } });

            expect(wrapper.find('#begin-date').props().hasError).toBe(true);
            expect(wrapper.find('#end-date').props().hasError).toBe(true);

            wrapper.find('#begin-date').props().onDateChange({ value: '01/01/2099' });
            expect(wrapper.find('#begin-date').props().hasError).toBe(false);

            wrapper.find('#end-date').props().onDateChange({ value: '01/01/2099' });
            expect(wrapper.find('#end-date').props().hasError).toBe(false);

            expect(wrapper.find('#error-div').exists()).toBe(false);
        });

        it('should render an error if begin date is after end date', () => {
            wrapper.find('#end-date').props().onDateChange({ value: '01/01/2000' });
            wrapper.find('#begin-date').props().onDateChange({ value: '01/01/2001' });
            wrapper.find('#run-button').simulate('click');

            expect(wrapper.find('#end-date').props().hasError).toBe(true);
            expect(wrapper.find('#begin-date').props().hasError).toBe(true);
            expect(wrapper.find('#error-div').text()).toBe('End date must be after begin date');
        });
    });

    describe('onChange of the category', () => {
        it('should call clearReportDataAction', () => {
            wrapper.find('#category-selection').simulate('change', { target: { value: 'submitted-claims' } });
            expect(mockClearReportDataAction).toBeCalled();
        });

        it('should set state with the selected value', () => {
            wrapper.find('#category-selection').simulate('change', { target: { value: 'submitted-claims' } });
            expect(wrapper.instance().state.category).toBe('submitted-claims');
        });
    });

    describe('onClick of the Run button', () => {
        it('should not call any action with invalid begin date', () => {
            wrapper.setState({
                category: 'any',
                beginDate: '',
                endDate: '01/01/2019'
            });
            wrapper.find('#run-button').simulate('click');
            expect(mockGetSubmittedClaimsAction).not.toBeCalled();
        });

        it('should not call any action with invalid end date', () => {
            wrapper.setState({
                category: 'any',
                beginDate: '01/01/2019',
                endDate: ''
            });
            wrapper.find('#run-button').simulate('click');
            expect(mockGetSubmittedClaimsAction).not.toBeCalled();
        });

        it('should call getClaimsByCreatedTimeAction when category is total-claims-searched with valid dates', () => {
            wrapper.setState({
                category: 'total-claims-searched',
                beginDate: { value: '01/01/2018' },
                endDate: { value: '01/01/2019' }
            });
            wrapper.find('#run-button').simulate('click');
            expect(mockGetClaimsByCreatedTimeAction).toBeCalledWith('20180101', '20190101');
        });

        it('should call getClaimsByInitialFaultSubmittedAction when category is total-claims-initial-fault-submitted with valid dates', () => {
            wrapper.instance().setState({
                category: 'total-claims-initial-fault-submitted',
                beginDate: {value: '01/01/2018'},
                endDate: {value: '01/01/2019'}
            });
            wrapper.find('#run-button').simulate('click');
            expect(mockGetClaimsByInitialFaultSubmittedAction).toBeCalledWith('20180101', '20190101');
        });
        it('should call getReSubmittedClaimsAction when category is resubmitted-claims with valid dates', () => {
            wrapper.find('select').simulate('change', { target: { value: 'resubmitted-claims' } });
            wrapper.find('#begin-date').simulate('dateChange', { value: '01/01/2018' });
            wrapper.find('#end-date').simulate('dateChange', { value: '01/01/2019' });

            wrapper.find('#run-button').simulate('click');

            expect(mockGetReSubmittedClaimsAction).toBeCalledWith('20180101', '20190101');
        });

        it('should call getInitialFaultPendingClaimsAction when category is total-claims-initial-fault-pending', () => {
            wrapper.find('select').simulate('change', { target: { value: 'total-claims-initial-fault-pending' } });
            wrapper.find('#run-button').simulate('click');
            expect(mockGetInitialFaultPendingClaims).toBeCalled();
        });

        it('should not do anything if the category is not selected', () => {
            let expectedState = wrapper.instance().state;
            expectedState.category = 'not a valid category';
            expectedState.beginDate.value = '01/01/2018';
            expectedState.endDate.value = '01/01/2019';

            wrapper.setState({
                category: 'not a valid category',
                beginDate: { value: '01/01/2018' },
                endDate: { value: '01/01/2019' },
            });
            wrapper.find('#run-button').simulate('click');
            expect(wrapper.instance().state.beginDate.value).toBe('01/01/2018');
            expect(wrapper.instance().state.endDate.value).toBe('01/01/2019');
            expect(wrapper.instance().state).toEqual(expectedState);
        });
    });

    describe('onClick of Download CSV button', () => {
        it('should call exportToCsv helper function', () => {
            const expectedData = [
                ['Claim Number', 'Submitted Time', 'Detail Loss Type', 'Loss State', 'Number of Assets', 'FNOL to Submitted (Min)', 'Search to Submitted (Min)'],
                [['123', '2019-01-24T15:33:53.771+0000', 'Intersection accident', 'Illinois', 3, 129245, 0]]
            ];
            wrapper.setState({ category: 'submitted-claims' });
            wrapper.find('#csv-button').simulate('click');
            expect(exportToCsv).toHaveBeenCalledWith('submitted-claims', expectedData);
        });
    });

    describe('when there is no data in reporting', () => {
        it('should have download csv button in disabled mode', () => {
            wrapper.setProps({ reporting: { claims: [] } });
            expect(wrapper.find('#csv-button').props().disabled).toBe(true);

        });
    });

    describe('connect', () => {
        it('mapStateToProps should return store values', () => {
            const store = {
                reporting: {
                    loading: false,
                    claims: [],
                    count: 0
                }
            };
            const result = mapStateToProps(store);
            expect(result.reporting).toEqual(store.reporting);
        });

        it('mapDispatchToProps should return dispatch actions', () => {
            expect(mapDispatchToProps).toEqual({
                clearReportDataAction,
                getReSubmittedClaimsAction,
                getInitialFaultPendingClaimsAction,
                getClaimsByCreatedTimeAction,
                getClaimsByInitialFaultSubmittedAction,
            });
        });
    });
});
