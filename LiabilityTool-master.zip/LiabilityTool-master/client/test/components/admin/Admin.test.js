jest.unmock('../../../src/main/components/admin/Admin');

import React from 'react';
import { shallow } from 'enzyme';
import {Admin, mapDispatchToProps, mapStateToProps} from '../../../src/main/components/admin/Admin';
import {insertAssignmentClaimListAction} from '../../../src/main/actions/adminActions'

describe("Given Admin", () => {
    let tree, mockHistory, mockInsertAssignmentClaimListAction;
    beforeEach(() => {
        mockHistory = {push: jest.fn()};
        mockInsertAssignmentClaimListAction = jest.fn();
        tree = shallow(<Admin
            history={mockHistory}
            insertAssignmentClaimListAction={mockInsertAssignmentClaimListAction}
        />);
    });

    it("sets statusMessage in state to empty string by default", () => {
        expect(tree.instance().state.displayStatusMessage).toBe(false);
    });

    it('Renders loon logo', () => {
        expect(tree.find('.loon-logo').props().src).toEqual('../images/ic-welcomelogo.svg');
    });

    it('Renders the welcome message', () => {
        expect(tree.find('#loon-title').text()).toEqual('Welcome to Loon Admin Page');
    });

    it('Renders the instructions', () => {
        expect(tree.find('#loon-instructions').text()).toEqual('Enter a list of claim numbers to be added in the Assignment Queue.');
    });

    it("Renders successful status when insertAssignmentClaimsState is SUCCESS and displayStatusMessage is true", () => {
        tree.setState({displayStatusMessage: true});
       tree.setProps({insertAssignmentClaimsState: 'SUCCESS'});
        expect(tree.find('#status-message').text()).toBe('Claim list was successfully inserted.');
    });

    it("Renders error status when insertAssignmentClaimsState is ERROR and displayStatusMessage is true", () => {
        tree.setState({displayStatusMessage: true});
        tree.setProps({insertAssignmentClaimsState: 'ERROR'});
        expect(tree.find('#status-message').text()).toBe('An error occurred while processing your request.');
    });

    it("Renders blank when insertAssignmentClaimsState is PROCESSING and displayStatusMessage is true", () => {
        tree.setState({displayStatusMessage: true});
        tree.setProps({insertAssignmentClaimsState: 'PROCESSING'});
        expect(tree.find('#status-message').text()).toBe('');
    });

    it("Does not render status message when displayStatusMessage state is false", () => {
        tree.setState({displayStatusMessage: false});
        tree.setProps({insertAssignmentClaimsState: 'SUCCESS'});
        expect(tree.find('#status-message').text()).toBe('');
    });

    describe("Insert claim list section", () => {
        it("Renders the container for insert claim list section", () => {
            expect(tree.find('#insert-claim-list-container').exists()).toBe(true);
        });

        describe("Use ClearQueue Checkbox", () => {
            it("Renders a FormOption with \"Use Kafka\" as label", () => {
                expect(tree.find('FormOption').at(0).props().label).toBe("Clear Queue")
            });

            it("Renders a FormOption with clearQueue as label", () => {
                expect(tree.find('FormOption').at(0).props().name).toBe("clearQueue")
            });

            it("Renders a FormOption with clearQueue as id", () => {
                expect(tree.find('FormOption').at(0).props().id).toBe("clearQueue")
            });

            it("sets clearQueue in state as false by default", () => {
                expect(tree.instance().state.clearQueue).toBe(false);
            });

            it("sets clearQueue in state as true when the checkbox is checked", () => {
                tree.find('FormOption').at(0).simulate('click');
                expect(tree.instance().state.clearQueue).toBe(true);
            });

            it("sets clearQueue in state as false when it is true and the checkbox is checked", () => {
                tree.setState({clearQueue: true});
                tree.find('FormOption').at(0).simulate('click');
                expect(tree.instance().state.clearQueue).toBe(false);
            });

            it("sets the value prop of FormOption to clearQueue state", () => {
                tree.setState({clearQueue: true});
                expect(tree.find('FormOption').at(0).props().checked).toBe(true);
            });

            it("sets displayStatusMessage to false on click", () => {
                tree.setState({displayStatusMessage: true});
                tree.find('FormOption').at(0).simulate('click');
                expect(tree.instance().state.displayStatusMessage).toBe(false);
            });
        });

        describe("Use Kafka Checkbox", () => {
            it("Renders a FormOption with \"Use Kafka\" as label", () => {
                expect(tree.find('FormOption').at(1).props().label).toBe("Use Kafka")
            });

            it("Renders a FormOption with UseKafka as label", () => {
                expect(tree.find('FormOption').at(1).props().name).toBe("useKafka")
            });

            it("Renders a FormOption with useKafka as id", () => {
                expect(tree.find('FormOption').at(1).props().id).toBe("useKafka")
            });

            it("sets useKafka in state as true by default", () => {
                expect(tree.instance().state.useKafka).toBe(true);
            });

            it("sets useKafka in state as false when the checkbox is checked", () => {
                tree.find('FormOption').at(1).simulate('click');
                expect(tree.instance().state.useKafka).toBe(false);
            });

            it("sets useKafka in state as true when it is false and the checkbox is checked", () => {
                tree.setState({useKafka: false});
                tree.find('FormOption').at(1).simulate('click');
                expect(tree.instance().state.useKafka).toBe(true);
            });

            it("sets the value prop of FormOption to useKafka state", () => {
                tree.setState({useKafka: true});
                expect(tree.find('FormOption').at(1).props().checked).toBe(true);
            });

            it("sets displayStatusMessage to false on click", () => {
                tree.setState({displayStatusMessage: true});
                tree.find('FormOption').at(1).simulate('click');
                expect(tree.instance().state.displayStatusMessage).toBe(false);
            });
        });

        describe("ClaimNumber list FormField", () => {
            it("sets the claimNumberList state to empty string by default", () => {
                expect(tree.instance().state.claimNumberList).toEqual("");
            });

            it("sets the claimNumberList state to FormField value onChange", () => {
                tree.find('FormField').simulate('change', {target: {value: '01234, 55555'}});
                expect(tree.instance().state.claimNumberList).toBe('01234, 55555');
            });

            it("sets the FormField value to claimNumberList state", () => {
                tree.setState({claimNumberList: '111, 222, 333'});
                expect(tree.find('FormField').props().value).toBe('111, 222, 333');
            });

            it("Renders a FormField", () => {
                expect(tree.find('Form').exists()).toBe(true);
            });

            it("Renders a FormField with claimNumberList name", () => {
                expect(tree.find('FormField').props().name).toEqual("claimNumberList");
            });

            it("sets displayStatusMessage to false on click", () => {
                tree.setState({displayStatusMessage: true});
                tree.find('FormField').simulate('click');
                expect(tree.instance().state.displayStatusMessage).toBe(false);
            });
        });

        describe("Submit button", () => {
            it("Renders a Button with InsertClaimList as text", () => {
                expect(tree.find('button').text()).toEqual("Insert Claim List");
            });

            it("Renders a Button with submit as id", () => {
                expect(tree.find('button').props().id).toEqual("submit");
            });

            it("invokes the insertAssignmentClaimListAction when submit button is clicked", () => {
                tree.setState({claimNumberList: '01234', clearQueue: true, useKafka:true});
                tree.find('Form').simulate('submit');
                expect(mockInsertAssignmentClaimListAction).toBeCalledWith('01234', true, true);
            });

            it("sets displayStatusMessage to false", () => {
                tree.setState({displayStatusMessage: false});
                tree.find('Form').simulate('submit');
                expect(tree.instance().state.displayStatusMessage).toBe(true);
            });

        });
    });

    describe('Connect', () => {
        const status = {insertAssignmentClaimsState: 'SUCCESS'};
        const state = {status};

        it('maps required store items to props', () => {
            const result = mapStateToProps(state);
            expect(result.insertAssignmentClaimsState).toEqual('SUCCESS');
        });

        it('maps dispatch to props', () => {
            expect(mapDispatchToProps.insertAssignmentClaimListAction).toEqual(insertAssignmentClaimListAction);
        });
    });
});