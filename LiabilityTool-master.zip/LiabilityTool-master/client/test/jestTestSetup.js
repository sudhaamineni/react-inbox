import 'babel-polyfill';
import React from 'react';
import {configure} from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';

configure({ adapter: new Adapter() });


// this file is needed to get past a "ReferenceError: regeneratorRuntime is not defined" error when running jest
