jest.unmock('../../src/main/reducers/transcriptReducer');

import transcriptReducer from '../../src/main/reducers/transcriptReducer';
import deepFreeze from 'deep-freeze'

describe('Transcript Reducer', () => {
    it('Initial state', () => {
        expect(transcriptReducer(undefined, { type: 'blah' })).toEqual({
            nlp: {},
            success: [],
            errors: []
        });
    });

    it('GET_CLAIMDATA action', () => {
        expect(transcriptReducer({}, { type: 'GET_CLAIMDATA' })).toEqual({
            success: [],
            errors: []
        });
    });

    it('GET_TRANSCRIPT_SUCCESS action', () => {
        const transcriptData = [
            { speaker: 'Speaker 1', startTime: 0, endTime: 10, text: 'Test text for chunk1' },
            { speaker: 'Speaker 1', startTime: 11, endTime: 20, text: 'Test text for chunk2' },
            { speaker: 'Speaker 2', startTime: 21, endTime: 30, text: 'Test text for chunk3' },
            { speaker: 'Speaker 1', startTime: 31, endTime: 40, text: 'Test text for chunk4' },
            { speaker: 'Speaker 1', startTime: 41, endTime: 60, text: 'Test text for chunk5' }
        ];
        const nlpData = [
            {
                categoryName: 'category1',
                categoryIndices: [
                    { startIndex: 0, endIndex: 4 },
                    { startIndex: 47, endIndex: 67 },
                    { startIndex: 68, endIndex: 72 }
                ]
            },
            {
                categoryName: 'category2',
                categoryIndices: [
                    { startIndex: 14, endIndex: 46 }
                ]
            }
        ];
        const highlightEntities = [
            {
                highlightTexts: [
                    { chunkIndex: 1, beginIndex: 5, endIndex: 9 }
                ]
            },
            {
                highlightTexts: [
                    { chunkIndex: 0, beginIndex: 0, endIndex: 20 },
                    { chunkIndex: 1, beginIndex: 0, endIndex: 4 }
                ]
            }
        ];
        const transcript = {
            voiceId: 'voiceId',
            transcriptData,
            nlpData,
            highlightEntities
        };
        const initialState = {
            nlp: {},
            success: [],
        };
        deepFreeze(initialState);
        const expectedState = {
            voiceId: [
                {
                    speaker: 'Speaker 1',
                    beginTime: 0,
                    endTime: 10,
                    beginIndex: 0,
                    endIndex: 20,
                    text: 'Test text for chunk1',
                    highlightTexts: [
                        { entityIndex: 1, beginIndex: 0, endIndex: 20 }
                    ],
                    nlp: {
                        category1: [
                            { categoryIndex: 1, beginIndex: 0, endIndex: 4 }
                        ],
                        category2: [
                            { categoryIndex: 1, beginIndex: 14, endIndex: 20 },
                        ]
                    }
                },
                {
                    speaker: 'Speaker 1',
                    beginTime: 11,
                    endTime: 20,
                    beginIndex: 21,
                    endIndex: 41,
                    text: 'Test text for chunk2',
                    highlightTexts: [
                        { entityIndex: 0, beginIndex: 5, endIndex: 9 },
                        { entityIndex: 1, beginIndex: 0, endIndex: 4 }
                    ],
                    nlp: {
                        category2: [
                            { beginIndex: 0, endIndex: 20 }
                        ]
                    }
                },
                {
                    speaker: 'Speaker 2',
                    beginTime: 21,
                    endTime: 30,
                    beginIndex: 42,
                    endIndex: 62,
                    text: 'Test text for chunk3',
                    highlightTexts: [],
                    nlp: {
                        category1: [
                            { categoryIndex: 2, beginIndex: 5, endIndex: 20 }
                        ],
                        category2: [
                            { beginIndex: 0, endIndex: 4 }
                        ]
                    }
                },
                {
                    speaker: 'Speaker 1',
                    beginTime: 31,
                    endTime: 40,
                    beginIndex: 63,
                    endIndex: 83,
                    text: 'Test text for chunk4',
                    highlightTexts: [],
                    nlp: {
                        category1: [
                            { beginIndex: 0, endIndex: 4 },
                            { categoryIndex: 3, beginIndex: 5, endIndex: 9 }
                        ]
                    }
                },
                {
                    speaker: 'Speaker 1',
                    beginTime: 41,
                    endTime: 60,
                    beginIndex: 84,
                    endIndex: 104,
                    text: 'Test text for chunk5',
                    highlightTexts: [],
                    nlp: {}
                }
            ],
            success: ['voiceId'],
            nlp: {
                voiceId: nlpData
            }
        };
        const action = {
            type: 'GET_TRANSCRIPT_SUCCESS',
            transcript
        };

        expect(transcriptReducer(initialState, action)).toEqual(expectedState);
    });

    it('GET_TRANSCRIPT_FAILURE action', () => {
        const initialState = {
            errors: ['a'],
            tid: ['p']
        };
        deepFreeze(initialState);
        const expectedState = {
            errors: ['a', 'b'],
            tid: ['p']
        };
        const action = {
            type: 'GET_TRANSCRIPT_FAILURE',
            voiceId: 'b'
        };

        expect(transcriptReducer(initialState, action)).toEqual(expectedState);
    });

    describe('SAVE_HIGHLIGHT action', () => {
        describe('No initial highlights', () => {
            it('Add highlight', () => {
                const initialState = {
                    id: [{ beginTime: 1 }, { beginTime: 2 }]
                };
                deepFreeze(initialState);
                const expectedState = {
                    id: [
                        {
                            beginTime: 1,
                            highlightTexts: [{ entityIndex: 0, beginIndex: 8, endIndex: 15 }]
                        },
                        {
                            beginTime: 2,
                            highlightTexts: []
                        }
                    ]
                };
                const action = {
                    type: 'SAVE_HIGHLIGHT',
                    claimNumber: '123',
                    voiceId: 'id',
                    highlightEntities: [{ highlightTexts: [{ chunkIndex: 0, beginIndex: 8, endIndex: 15 }] }]
                };

                expect(transcriptReducer(initialState, action)).toEqual(expectedState);
            });
        });

        describe('With initial highlights', () => {
            it('adds updated highlights not spanning multiple chunks', () => {
                const initialState = {
                    id: [
                        {
                            beginTime: 1,
                            highlightTexts: [{ entityIndex: 0, beginIndex: 8, endIndex: 15 }]
                        },
                        {
                            beginTime: 2,
                            highlightTexts: [{ entityIndex: 1, beginIndex: 8, endIndex: 15 }]
                        }
                    ]
                };
                deepFreeze(initialState);
                const expectedState = {
                    id: [
                        {
                            beginTime: 1,
                            highlightTexts: [{ entityIndex: 0, beginIndex: 8, endIndex: 15 }]
                        },
                        {
                            beginTime: 2,
                            highlightTexts: [{ entityIndex: 1, beginIndex: 8, endIndex: 20 }]
                        }
                    ]
                };
                const action = {
                    type: 'SAVE_HIGHLIGHT',
                    claimNumber: '123',
                    voiceId: 'id',
                    highlightEntities: [
                        { highlightTexts: [{ chunkIndex: 0, beginIndex: 8, endIndex: 15 }] },
                        { highlightTexts: [{ chunkIndex: 1, beginIndex: 8, endIndex: 20 }] },
                    ]
                };

                expect(transcriptReducer(initialState, action)).toEqual(expectedState);
            });

            it('adds updated highlights spanning multiple chunks', () => {
                const initialState = {
                    id: [
                        {
                            beginTime: 1,
                            highlightTexts: [{ entityIndex: 0, beginIndex: 8, endIndex: 15 }]
                        },
                        {
                            beginTime: 2,
                            highlightTexts: [{ entityIndex: 0, beginIndex: 0, endIndex: 15 }]
                        },
                        {
                            beginTime: 3,
                            highlightTexts: [{ entityIndex: 1, beginIndex: 6, endIndex: 15 }]
                        }
                    ]
                };
                deepFreeze(initialState);
                const expectedState = {
                    id: [
                        {
                            beginTime: 1,
                            highlightTexts: [{ entityIndex: 0, beginIndex: 6, endIndex: 15 }]
                        },
                        {
                            beginTime: 2,
                            highlightTexts: [{ entityIndex: 1, beginIndex: 0, endIndex: 20 }]
                        },
                        {
                            beginTime: 3,
                            highlightTexts: [{ entityIndex: 1, beginIndex: 6, endIndex: 15 }]
                        }
                    ]
                };
                const action = {
                    type: 'SAVE_HIGHLIGHT',
                    claimNumber: '123',
                    voiceId: 'id',
                    highlightEntities: [
                        { highlightTexts: [{ chunkIndex: 0, beginIndex: 6, endIndex: 15 }] },
                        {
                            highlightTexts: [{ chunkIndex: 2, beginIndex: 6, endIndex: 15 }, {
                                chunkIndex: 1,
                                beginIndex: 0,
                                endIndex: 20
                            }]
                        },
                    ]
                };

                expect(transcriptReducer(initialState, action)).toEqual(expectedState);
            });
        });
    });

    it('should initialize state upon receiving CLEAR_CLAIMDATA action', () => {
        expect(transcriptReducer(null, { type: 'CLEAR_CLAIMDATA' })).toEqual({
            nlp: {},
            success: [],
            errors: [],
        });
    });
});
