jest.unmock('../../src/main/reducers/rootReducer');
jest.unmock('../../src/main/reducers/claimDataReducer');
jest.unmock('../../src/main/reducers/statusReducer');
jest.unmock('../../src/main/reducers/userReducer');
jest.unmock('../../src/main/reducers/transcriptReducer');
jest.unmock('../../src/main/reducers/featureSwitchesReducer');
jest.unmock('../../src/main/reducers/reportingReducer');

import rootReducer from '../../src/main/reducers/rootReducer';

describe('rootReducer', () => {
    it('calls rootReducer with all the reducers', () => {
        let result = rootReducer({}, []);

        expect(result.claimData).toBeDefined();
        expect(result.status).toBeDefined();
        expect(result.user).toBeDefined();
        expect(result.transcripts).toBeDefined();
        expect(result.featureSwitches).toBeDefined();
        expect(result.reporting).toBeDefined();
        expect(result.diagram).toBeDefined();
        expect(result.dragItem).toBeDefined();
        expect(result.assets).toBeDefined();
        expect(result.template).toBeDefined();
    });
});