jest.unmock('../../src/main/reducers/reportingReducer');

import reportingReducer from '../../src/main/reducers/reportingReducer';

describe('Given reporting reducer', () => {
    it('when unrecognized action received', () => {
        expect(reportingReducer(undefined, { type: 'blah' })).toEqual({
            loading: false,
            claims: [],
            count: 0
        });
    });

    it('when GET_SUBMITTED_CLAIMS action received', () => {
        expect(reportingReducer({ loading: false }, { type: 'GET_SUBMITTED_CLAIMS' })).toEqual({ loading: true });
    });

    it('when GET_SUBMITTED_CLAIMS_SUCCESS action received', () => {
        const initialState = {
            loading: true,
            claims: [
                { claimNumber: '123' }
            ]
        };
        const action = {
            type: 'GET_SUBMITTED_CLAIMS_SUCCESS',
            claims: [
                { claimNumber: '123' },
                { claimNumber: '234' }
            ]
        };
        const expectedState = {
            loading: false,
            claims: [
                { claimNumber: '123' },
                { claimNumber: '234' }
            ]
        };
        expect(reportingReducer(initialState, action)).toEqual(expectedState);
    });

    it('when GET_SUBMITTED_BOOKMARKED_PHOTO_AVERAGE received', () => {
        expect(reportingReducer({ loading: false }, { type: 'GET_SUBMITTED_BOOKMARKED_PHOTO_AVERAGE' })).toEqual({ loading: true });
    });

    it('when GET_SUBMITTED_BOOKMARKED_PHOTO_AVERAGE_SUCCESS action received', () => {
        const action = {
            type: 'GET_SUBMITTED_BOOKMARKED_PHOTO_AVERAGE_SUCCESS',
            count: 0.77
        };
        expect(reportingReducer({ loading: true, count: 0 }, action)).toEqual({ loading: false, count: 0.77 });
    });

    it('when GET_RESUBMITTED_CLAIMS action received', () => {
        expect(reportingReducer({ loading: false }, { type: 'GET_RESUBMITTED_CLAIMS' })).toEqual({ loading: true });
    });

    it('when GET_RESUBMITTED_CLAIMS_SUCCESS action received', () => {
        const initialState = {
            loading: true,
            claims: [
                { claimNumber: '123' }
            ]
        };
        const action = {
            type: 'GET_RESUBMITTED_CLAIMS_SUCCESS',
            claims: [
                { claimNumber: '123' },
                { claimNumber: '234' }
            ]
        };
        const expectedState = {
            loading: false,
            claims: [
                { claimNumber: '123' },
                { claimNumber: '234' }
            ]
        };
        expect(reportingReducer(initialState, action)).toEqual(expectedState);
    });

    it('should return initial state when CLEAR_REPORT_DATA is received', () => {
        const originalState = {
            loading: true,
            claims: [
                { claimNumber: '123' }
            ]
        };

        const expectedState = {
            loading: false,
            claims: [],
            count: 0
        };

        const action = {
            type: 'CLEAR_REPORT_DATA'
        };

        expect(reportingReducer(originalState, action)).toEqual(expectedState);

    });

    it('when GET_CLAIMS_BY_CREATED_TIME action received', () => {
        expect(reportingReducer({ loading: false }, { type: 'GET_CLAIMS_BY_CREATED_TIME' })).toEqual({ loading: true });
    });

    it('when GET_CLAIMS_BY_CREATED_TIME_SUCCESS action received', () => {
        const initialState = {
            loading: true,
            claims: [
                { claimNumber: '123' }
            ]
        };
        const action = {
            type: 'GET_CLAIMS_BY_CREATED_TIME_SUCCESS',
            claims: [
                { claimNumber: '123' },
                { claimNumber: '234' }]
        };
        const expectedState = {
            loading: false,
            claims: [
                { claimNumber: '123' },
                { claimNumber: '234' }
            ]
        };
        expect(reportingReducer(initialState, action)).toEqual(expectedState);
    });

    describe('when GET_INITIAL_FAULT_PENDING_CLAIMS action is received', () => {
        it('should set loading status to true', () => {
            const initialState = {
                loading: false,
                claims: []
            };

            const action = {
                type: 'GET_INITIAL_FAULT_PENDING_CLAIMS',
            };

            const expectedState = {
                loading: true,
                claims: []
            };

            expect(reportingReducer(initialState, action)).toEqual(expectedState);
        });
    });

    describe('when GET_INITIAL_FAULT_PENDING_CLAIMS_SUCCESS action is receieved', () => {
        it('should put the claims from the action into the state and set loading to false', () => {
            const initialState = {
                loading: true,
                claims: [
                    { claimNumber: '123' }
                ]
            };

            const action = {
                type: 'GET_INITIAL_FAULT_PENDING_CLAIMS_SUCCESS',
                claims: [
                    { claimNumber: '123' },
                    { claimNumber: '234' }]
            };

            const expectedState = {
                loading: false,
                claims: [
                    { claimNumber: '123' },
                    { claimNumber: '234' }
                ]
            };

            expect(reportingReducer(initialState, action)).toEqual(expectedState);
        });
    });
    it('when GET_CLAIMS_BY_INITIAL_FAULT_SUBMITTED_TIME action received', () => {
        expect(reportingReducer({loading: false}, {type: 'GET_CLAIMS_BY_INITIAL_FAULT_SUBMITTED_TIME'})).toEqual({loading: true});
    });

    it('when GET_CLAIMS_BY_INITIAL_FAULT_SUBMITTED_TIME_SUCCESS action received', () => {
        const initialState = {
            loading: true,
            claims: [
                {claimNumber: '123'}
            ]
        };
        const action = {
            type: 'GET_CLAIMS_BY_INITIAL_FAULT_SUBMITTED_TIME_SUCCESS',
            claims: [
                {claimNumber: '123'},
                {claimNumber: '234'}]
        };
        const expectedState = {
            loading: false,
            claims: [
                {claimNumber: '123'},
                {claimNumber: '234'}
            ]
        };
        expect(reportingReducer(initialState, action)).toEqual(expectedState);
    });


});
