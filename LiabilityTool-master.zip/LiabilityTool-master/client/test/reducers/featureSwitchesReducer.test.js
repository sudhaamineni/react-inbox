import featureSwitchesReducer from '../../src/main/reducers/featureSwitchesReducer';
import deepFreeze from 'deep-freeze';

jest.unmock('../../src/main/reducers/featureSwitchesReducer');

describe('featureSwitchesReducer', () => {
    it('sets the featureSwitches in store', () => {
        const response = {
            userId: 'something',
            featureSwitches: {
                enableAdmin: false,
                renderSketchTab: true,
            }
        };

        const initialState = {
            enableAdmin: false,
            renderSketchTab: false,
        };
        deepFreeze(initialState);
        const action = {
            type: 'INIT_SUCCESS',
            response
        };

        const expectedState = {
            enableAdmin: false,
            renderSketchTab: true,
        };

        expect(featureSwitchesReducer(initialState, action)).toEqual(expectedState);
    });

    it('does not set the featureSwitches in store when undefined featureSwitches response is returned', () => {
        const response = {
            userId: 'something'
        };

        const initialState = {
            enableAdmin: true,
        };
        deepFreeze(initialState);
        const action = {
            type: 'INIT_SUCCESS',
            response
        };

        const expectedState = initialState;

        expect(featureSwitchesReducer(initialState, action)).toEqual(expectedState);
    });

    it('returns current store when action type other than INIT_SUCCESS received', () => {
        const action = {
            type: 'BLAH_BLAH_BLAH'
        };
        const expectedState = {
            enableAdmin: false,
            renderSketchTab: false,
            enableSettleTab: false
        };
        expect(featureSwitchesReducer(undefined, action)).toEqual(expectedState);
    });
});