jest.unmock('../../src/main/reducers/statusReducer');

import statusReducer from '../../src/main/reducers/statusReducer';
import deepFreeze from 'deep-freeze'
import {createInitialEventValidationArray} from '../../src/main/helpers/eventValidationHelper';

describe('Status Reducer', () => {
    it('returns initial state if no matching action type found', () => {
        expect(statusReducer(undefined, {type: 'blah'})).toEqual({
            retrievingClaimData: false,
            retrievingAttachments: false,
            attachmentsRetrievalFailed: false,
            insertAssignmentClaimsState: 'PROCESSING',
            activeAssignmentRetrieved: false,
            submitState: 'DEFAULT_STATE',
            errorHeader: '',
            errorDescription: '',
            errorButton: '',
            newClaimNumber: '',
            eventsValidation: [],
            updatingDamageApportionment: false,
            showEvidenceModal: false,
            evidenceModalError: false,
        });
    });

    it('GET_CLAIMDATA action', () => {
        const initialState = {retrievingClaimData: false, retrievingAttachments: false};
        deepFreeze(initialState);
        const action = {type: 'GET_CLAIMDATA'};
        const expectedState = {retrievingClaimData: true, retrievingAttachments: true};

        expect(statusReducer(initialState, action)).toEqual(expectedState);
    });

    it('GET_CLAIMDATA_SUCCESS action', () => {
        createInitialEventValidationArray.mockReturnValue('my initial array');
        const initialState = {blah: 'blah', retrievingClaimData: true};
        deepFreeze(initialState);
        const action = {type: 'GET_CLAIMDATA_SUCCESS', claimData: 'my claim data'};
        const expectedState = {
            blah: 'blah',
            eventsValidation: 'my initial array',
            retrievingClaimData: false,
            updatingDamageApportionment: false
        };

        expect(statusReducer(initialState, action)).toEqual(expectedState);
    });

    it('GET_PHOTO_ATTACHMENTS_SUCCESS action', () => {
        const initialState = {retrievingAttachments: true, attachmentsRetrievalFailed: true};
        deepFreeze(initialState);
        const action = {type: 'GET_PHOTO_ATTACHMENTS_SUCCESS'};

        expect(statusReducer(initialState, action)).toEqual({
            retrievingAttachments: false,
            attachmentsRetrievalFailed: false
        });
    });

    it('GET_PHOTO_ATTACHMENTS_FAILURE action', () => {
        const initialState = {retrievingAttachments: true, attachmentsRetrievalFailed: false};
        deepFreeze(initialState);
        const action = {type: 'GET_PHOTO_ATTACHMENTS_FAILURE'};

        expect(statusReducer(initialState, action)).toEqual({
            retrievingAttachments: false,
            attachmentsRetrievalFailed: true
        });
    });

    it('GET_VOICE_ATTACHMENTS_SUCCESS action', () => {
        const initialState = {retrievingAttachments: true, attachmentsRetrievalFailed: true};
        deepFreeze(initialState);
        const action = {type: 'GET_VOICE_ATTACHMENTS_SUCCESS'};

        expect(statusReducer(initialState, action)).toEqual({
            retrievingAttachments: false,
            attachmentsRetrievalFailed: false
        });
    });

    it('GET_VOICE_ATTACHMENTS_FAILURE action', () => {
        const initialState = {retrievingAttachments: true, attachmentsRetrievalFailed: false};
        deepFreeze(initialState);
        const action = {type: 'GET_VOICE_ATTACHMENTS_FAILURE'};

        expect(statusReducer(initialState, action)).toEqual({
            retrievingAttachments: false,
            attachmentsRetrievalFailed: true
        });
    });

    it('INSERT_ASSIGNMENT_ADMIN_SUCCESS action', () => {
        const initialState = {blah: 'blah'};
        deepFreeze(initialState);
        const action = {
            type: 'INSERT_ASSIGNMENT_ADMIN_SUCCESS'
        };
        const expectedState = {blah: 'blah', insertAssignmentClaimsState: 'SUCCESS'};

        expect(statusReducer(initialState, action)).toEqual(expectedState);
    });

    it('INSERT_ASSIGNMENT_ADMIN_ERROR action', () => {
        const initialState = {blah: 'blah'};
        deepFreeze(initialState);
        const action = {
            type: 'INSERT_ASSIGNMENT_ADMIN_ERROR'
        };
        const expectedState = {blah: 'blah', insertAssignmentClaimsState: 'ERROR'};

        expect(statusReducer(initialState, action)).toEqual(expectedState);
    });

    it('INSERT_ASSIGNMENT_CLAIM_LIST action', () => {
        const initialState = {blah: 'blah'};
        deepFreeze(initialState);
        const action = {
            type: 'INSERT_ASSIGNMENT_CLAIM_LIST'
        };
        const expectedState = {blah: 'blah', insertAssignmentClaimsState: 'PROCESSING'};

        expect(statusReducer(initialState, action)).toEqual(expectedState);
    });

    it('SET_ACTIVE_ASSIGNMENT_RETRIEVED action as false', () => {
        const initialState = {blah: 'blah', activeAssignmentRetrieved: false};
        deepFreeze(initialState);
        const action = {
            type: 'SET_ACTIVE_ASSIGNMENT_RETRIEVED',
            assignmentRetrieved: true
        };
        const expectedState = {blah: 'blah', activeAssignmentRetrieved: true};

        expect(statusReducer(initialState, action)).toEqual(expectedState);
    });

    it('SET_ACTIVE_ASSIGNMENT_RETRIEVED action as true', () => {
        const initialState = {blah: 'blah', activeAssignmentRetrieved: true};
        deepFreeze(initialState);
        const action = {
            type: 'SET_ACTIVE_ASSIGNMENT_RETRIEVED',
            assignmentRetrieved: false
        };
        const expectedState = {blah: 'blah', activeAssignmentRetrieved: false};

        expect(statusReducer(initialState, action)).toEqual(expectedState);
    });

    it('SUBMIT_LIABILITY_SUCCESS action', () => {
        const initialState = {submitState: 'SUBMITTING'};
        deepFreeze(initialState);
        const expectedState = {submitState: 'SUBMITTED'};
        const action = {type: 'SUBMIT_LIABILITY_SUCCESS'};

        expect(statusReducer(initialState, action)).toEqual(expectedState);
    });

    it('SUBMIT_LIABILITY action', () => {
        const initialState = {submitState: 'DEFAULT_STATE'};
        deepFreeze(initialState);
        const expectedState = {submitState: 'SUBMITTING'};
        const action = {type: 'SUBMIT_LIABILITY'};

        expect(statusReducer(initialState, action)).toEqual(expectedState);
    });

    it('SUBMIT_LIABILITY_ERROR action', () => {
        const initialState = {submitState: 'SUBMITTING'};
        deepFreeze(initialState);
        const expectedState = {submitState: 'ERROR_SUBMITTING'};
        const action = {type: 'SUBMIT_LIABILITY_ERROR'};

        expect(statusReducer(initialState, action)).toEqual(expectedState);
    });

    it('LIABILITY_SUBMITTED action', () => {
        const initialState = {submitState: 'SUBMITTED'};
        deepFreeze(initialState);
        const expectedState = {submitState: 'DEFAULT_STATE'};
        const action = {type: 'LIABILITY_SUBMITTED'};

        expect(statusReducer(initialState, action)).toEqual(expectedState);
    });

    it('CANCEL_SUBMIT_LIABILITY action', () => {
        const initialState = {submitState: 'ERROR_SUBMITTING'};
        deepFreeze(initialState);
        const expectedState = {submitState: 'DEFAULT_STATE'};
        const action = {type: 'CANCEL_SUBMIT_LIABILITY'};

        expect(statusReducer(initialState, action)).toEqual(expectedState);
    });

    it('SET_EVENTS_VALIDATION action', () => {
        const action = {type: 'SET_EVENTS_VALIDATION', eventsValidation: [{id: '123'}]};
        expect(statusReducer({}, action).eventsValidation).toEqual([{id: '123'}]);
    });

    it('returns current state if no matching action type is found ', () => {
        const currentState = {
            blah: 'blah'
        };
        deepFreeze(currentState);
        const otherAction = {
            type: 'blah'
        };

        expect(statusReducer(currentState, otherAction)).toEqual({blah: 'blah'});
    });

    it('Sets errorHeader and errorDescription pieces of state upon receiving a SET_ERROR_MESSAGES action', () => {
        const initialState = {
            errorHeader: '',
            errorDescription: '',
        };
        deepFreeze(initialState);
        const mockAction = {
            type: 'SET_ERROR_MESSAGES',
            errorHeader: 'Some header',
            errorDescription: 'Corresponding description'
        };

        expect(statusReducer(initialState, mockAction)).toEqual({
            errorHeader: 'Some header',
            errorDescription: 'Corresponding description',
            updatingDamageApportionment: false
        });
    });

    it('Sets errorHeader ,errorDescription and newClaimNumber pieces of state upon receiving a SET_ERROR_MESSAGES_WITH_CLAIM_NUMBER action', () => {
        const initialState = {
            errorHeader: '',
            errorDescription: '',
            newClaimNumber: ''
        };
        deepFreeze(initialState);
        const mockAction = {
            type: 'SET_ERROR_MESSAGES_WITH_CLAIM_NUMBER',
            errorHeader: 'Some header',
            errorDescription: 'Corresponding description',
            newClaimNumber: 'newClaimNumber'
        };

        expect(statusReducer(initialState, mockAction)).toEqual({
            errorHeader: 'Some header',
            errorDescription: 'Corresponding description',
            newClaimNumber: 'newClaimNumber'
        });
    });

    it('clears errorHeader and errorDescription pieces of state upon receiving a CLEAR_ERROR_MESSAGES action', () => {
        const initialState = {
            errorHeader: 'Some header',
            errorDescription: 'Corresponding description'
        };
        deepFreeze(initialState);
        const mockAction = {
            type: 'CLEAR_ERROR_MESSAGES'
        };

        expect(statusReducer(initialState, mockAction)).toEqual({
            errorHeader: '',
            errorDescription: '',
            newClaimNumber: '',
            errorButton: '',
        });
    });

    it('CREATE_EVENT adds new event with no errors to eventsValidation data ', () => {
        const initialState = {
            eventsValidation: [{id: '1'}]
        };
        deepFreeze(initialState);
        const action = {
            type: 'CREATE_EVENT',
            event: {id: '2'}
        };
        const expectedState = {eventsValidation: [{id: '1'}, {error: false, id: '2'}]};

        expect(statusReducer(initialState, action)).toEqual(expectedState);
    });

    it('UPDATE_EVENT returns same state ', () => {
        const initialState = {
            eventsValidation: [{something: '1'}]
        };
        deepFreeze(initialState);
        const action = {
            type: 'UPDATE_EVENT',
        };
        const expectedState = {eventsValidation: [{something: '1'}]};

        expect(statusReducer(initialState, action)).toEqual(expectedState);
    });

    it('REMOVE_EVENT clears eventsValidation data for that event only', () => {
        const initialState = {
            eventsValidation: [{id: 'id1'}, {id: 'id2'}, {id: 'id3'}]
        };
        deepFreeze(initialState);
        const action = {
            type: 'REMOVE_EVENT',
            event: {id: 'id2'}
        };
        const expectedState = {eventsValidation: [{id: 'id1'}, {id: 'id3'}]};

        expect(statusReducer(initialState, action)).toEqual(expectedState);
    });

    it('UPDATE_DAMAGE_APPORTIONMENT set updatingDamageApportionment to true', () => {
        const initialState = {
            updatingDamageApportionment: false
        };
        deepFreeze(initialState);
        const action = {
            type: 'UPDATE_DAMAGE_APPORTIONMENT',
        };
        const expectedState = {updatingDamageApportionment: true};

        expect(statusReducer(initialState, action)).toEqual(expectedState);
    });

    describe('SETTLEMENT actions', () => {
        it('SUBMIT_SETTLEMENT action', () => {
            const initialState = {submitState: 'DEFAULT_STATE'};
            deepFreeze(initialState);
            const expectedState = {submitState: 'SUBMITTING'};
            const action = {type: 'SUBMIT_SETTLEMENT'};

            expect(statusReducer(initialState, action)).toEqual(expectedState);
        });

        it('SUBMIT_SETTLEMENT_SUCCESS action', () => {
            const initialState = {submitState: 'SUBMITTING'};
            deepFreeze(initialState);
            const expectedState = {submitState: 'SUBMITTED'};
            const action = {type: 'SUBMIT_SETTLEMENT_SUCCESS'};

            expect(statusReducer(initialState, action)).toEqual(expectedState);
        });


        it('SUBMIT_SETTLEMENT_ERROR action', () => {
            const initialState = {submitState: 'SUBMITTING'};
            deepFreeze(initialState);
            const expectedState = {submitState: 'ERROR_SUBMITTING'};
            const action = {type: 'SUBMIT_SETTLEMENT_ERROR'};

            expect(statusReducer(initialState, action)).toEqual(expectedState);
        });

        it('SETTLEMENT_SUBMITTED action', () => {
            const initialState = {submitState: 'SUBMITTED'};
            deepFreeze(initialState);
            const expectedState = {submitState: 'DEFAULT_STATE'};
            const action = {type: 'SETTLEMENT_SUBMITTED'};

            expect(statusReducer(initialState, action)).toEqual(expectedState);
        });

        it('SUBMIT_SETTLEMENT_CANCEL action', () => {
            const initialState = {submitState: 'ERROR_SUBMITTING'};
            deepFreeze(initialState);
            const expectedState = {submitState: 'DEFAULT_STATE'};
            const action = {type: 'SUBMIT_SETTLEMENT_CANCEL'};

            expect(statusReducer(initialState, action)).toEqual(expectedState);
        });
    });

    describe('SHOW_EVIDENCE_MODAL actions', () => {
        it('should set showEvidenceModal from the action when initialState is undefined', () => {
            const initialState = {blah: 'blah'};
            deepFreeze(initialState);
            const action = {type: 'SHOW_EVIDENCE_MODAL', showEvidenceModal: false};

            expect(statusReducer(initialState, action)).toEqual({
                blah: 'blah',
                showEvidenceModal: false,
            });
        });

        it('should update showEvidenceModal to the value from the action', () => {
            const initialState = {blah: 'blah', showEvidenceModal: false};
            deepFreeze(initialState);
            const action = {type: 'SHOW_EVIDENCE_MODAL', showEvidenceModal: true};

            expect(statusReducer(initialState, action)).toEqual({
                blah: 'blah',
                showEvidenceModal: true,
            });
        });
    });

    describe('EVIDENCE_MODAL_ERROR', () => {
        it('should set evidenceModalError from the action when initialState is undefined', () => {
            const initialState = {blah: 'blah'};
            deepFreeze(initialState);
            const action = {type: 'EVIDENCE_MODAL_ERROR', evidenceModalError: false};

            expect(statusReducer(initialState, action)).toEqual({
                blah: 'blah',
                evidenceModalError: false,
            });
        });

        it('should update evidenceModalError to the value from the action', () => {
            const initialState = {blah: 'blah', evidenceModalError: false};
            deepFreeze(initialState);
            const action = {type: 'EVIDENCE_MODAL_ERROR', evidenceModalError: true};

            expect(statusReducer(initialState, action)).toEqual({
                blah: 'blah',
                evidenceModalError: true,
            });
        });
    });

    describe('INIT_FAILURE', () => {
        it('should set unavailable error values when status is not 403', () => {
            const initialState = {blah: 'blah'};
            deepFreeze(initialState);
            const action = {type: 'INIT_FAILURE', status: 500};

            expect(statusReducer(initialState, action)).toEqual({
                blah: 'blah',
                errorHeader: 'Unavailable',
                errorDescription: 'Our systems are currently unavailable. Please try again later.',
                errorButton: 'Back to Login'
            });
        });

        it('should set unauthorized error values when status is not 403', () => {
            const initialState = {blah: 'blah'};
            deepFreeze(initialState);
            const action = {type: 'INIT_FAILURE', status: 403};

            expect(statusReducer(initialState, action)).toEqual({
                blah: 'blah',
                errorHeader: 'Unauthorized',
                errorDescription: 'You do not have access to Loon.',
                errorButton: 'Back to Login'
            });
        });
    });
});
