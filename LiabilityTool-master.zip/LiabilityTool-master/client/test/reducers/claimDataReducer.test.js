jest.unmock('../../src/main/reducers/claimDataReducer');
jest.unmock('../../src/main/actions/claimDataActions');
jest.unmock('../../src/main/actions/lossLocationActions');
jest.unmock('../../src/main/actions/assignmentActions');

import claimDataReducer from '../../src/main/reducers/claimDataReducer';
import {
    clearClaimDataAction,
    saveClaimUnlockAction,
    saveReportedPciAction
} from '../../src/main/actions/claimDataActions';
import deepFreeze from 'deep-freeze'
import { lossLocationSaveAction } from '../../src/main/actions/lossLocationActions';
import { updateAssignmentStatusAction } from '../../src/main/actions/assignmentActions';
import { ASSIGNED, IN_PROGRESS } from '../../src/main/constants/loonConstants';

describe('claimDataReducer', () => {
    let involvedParty = {
        participantId: '1',
        participantSourceId: '11',
        assetId: 'asset1',
        damageSections: [
            'front',
            'rear'
        ],
        contributingFactors: [
            {
                category: null,
                reason: 'proper-lookout',
                details: 'saw-other-party',
                evidenceIds: ['evidenceId3', 'evidence5']
            }
        ],
        affectedParties: [
            {
                participantId: '2',
                participantSourceId: '22',
                assetId: 'B9763FCB7D843B1F',
                passengerPartyIds: [],
                affectedPercent: 12,
                beginNegotiatingRange: 7,
                endNegotiatingRange: 17,
                submittedAffectedPercent: 12,
                faultAllocationPercent: 1
            }
        ]
    };
    const event =
        { id: '0', title: 'my first event title', severity: 1, involvedParties: [involvedParty] };
    it('returns initial state if no matching action type found', () => {
        const initialState = { blah: 'blah' };
        deepFreeze(initialState);
        const otherAction = {
            type: 'blah'
        };
        expect(claimDataReducer(initialState, otherAction)).toEqual({ blah: 'blah' });
    });

    describe('CLEAR_CLAIMDATA action', () => {
        it('returns empty object for CLEAR_CLAIMDDATA action type', () => {
            const initialState = { blah: 'blah' };
            const expectedState = {
                id: '',
                claimSourceId: '',
                claimNumber: '',
                lossDetailType: '',
                lossStreet: '',
                lossAddress: '',
                lossCity: '',
                lossState: '',
                lossZip: '',
                lossCountyDescription: '',
                mapAddress: '',
                theoryOfDefenseAdditionalNotes: '',
                createdTime: 0,
                updatedTime: 0,
                initialFaultSubmitTime: null,
                settlementSubmitTime: null,
                lastModifiedByUserId: '',
                noFaultAllocationAgreement: false,
                noFaultAllocationResponse: false,
                locked: false,
                lossDate: '',
                liabilitySubjects: [],
                reportedPciDate: null,
                status: '',
                events: [],
                evidences: []
            };

            const clearClaimData = clearClaimDataAction();
            expect(claimDataReducer(initialState, clearClaimData)).toEqual(expectedState);
        });
    });

    describe('GET_CLAIMDATA_SUCCESS action', () => {
        it('initialized claimData when receivedValidClaimDataAction is received', () => {
            const claimData = {
                claimNumber: '12345',
                lossDetailType: 'Contact with other vehicle/property/other party',
                liabilitySubjects: [
                    {
                        firstName: 'CINDA',
                        lastName: 'HERMAN',
                        phoneNumber: '1234567890',
                        organizationName: null,
                        participantSourceId: 'insuredPartId',
                        liabilityRangeBeginPercent: '10',
                        liabilityRangeEndPercent: '20'
                    },
                    {
                        firstName: 'MELISA',
                        lastName: 'VENTURA',
                        phoneNumber: null,
                        organizationName: null,
                        participantSourceId: 'claimantPartId1',
                        liabilityRangeBeginPercent: '80',
                        liabilityRangeEndPercent: '90'
                    },
                    {
                        firstName: 'SUDHA',
                        lastName: 'AMINENI',
                        phoneNumber: '6789012345',
                        organizationName: null,
                        participantSourceId: 'claimantPartId2',
                        liabilityRangeBeginPercent: '70',
                        liabilityRangeEndPercent: '80'
                    }
                ]
            };
            const initialState = {};
            deepFreeze(initialState);
            const action = {
                type: 'GET_CLAIMDATA_SUCCESS',
                claimData: claimData,
            };
            const expectedState = {
                claimNumber: '12345',
                lossDetailType: 'Contact with other vehicle/property/other party',
                liabilitySubjects: [
                    {
                        firstName: 'CINDA',
                        lastName: 'HERMAN',
                        phoneNumber: '1234567890',
                        organizationName: null,
                        participantSourceId: 'insuredPartId',
                        liabilityRangeBeginPercent: '10',
                        liabilityRangeEndPercent: '20'
                    },
                    {
                        firstName: 'MELISA',
                        lastName: 'VENTURA',
                        phoneNumber: null,
                        organizationName: null,
                        participantSourceId: 'claimantPartId1',
                        liabilityRangeBeginPercent: '80',
                        liabilityRangeEndPercent: '90'
                    },
                    {
                        firstName: 'SUDHA',
                        lastName: 'AMINENI',
                        phoneNumber: '6789012345',
                        organizationName: null,
                        participantSourceId: 'claimantPartId2',
                        liabilityRangeBeginPercent: '70',
                        liabilityRangeEndPercent: '80'
                    }
                ],
            };
            expect(claimDataReducer(initialState, action)).toEqual(expectedState);
        });
    });

    describe('PHOTO_TOGGLE_BOOKMARK action', () => {
        it('updates photo attachments and evidences in the store', () => {
            const claimNumber = '123',
                participantSourceId = 'p1',
                photoAttachments = [
                    { dcfId: '1', url: 'link1' },
                    { dcfId: '2', url: 'link2' }
                ],
                newPhotoAttachments = [
                    { dcfId: '1', url: 'link1' },
                    { dcfId: '2', url: 'link2', bookmarked: true }
                ],
                evidences = [
                    { id: 'e1', sourceId: '1' },
                    { id: 'e2', sourceId: '2' }
                ],
                newEvidences = [
                    { id: 'e1', sourceId: '1' },
                    { id: 'e2', sourceId: '2', type: 'photo' }
                ],
                updatedEvents = [{ id: '0', title: 'better title', severity: 1, involvedParties: [involvedParty] }];
            const initialState = {
                claimNumber,
                liabilitySubjects: [{ participantSourceId, photoAttachments }],
                evidences,
                events: [event]
            };
            deepFreeze(initialState);
            const expectedState = {
                claimNumber,
                liabilitySubjects: [{ participantSourceId, photoAttachments: newPhotoAttachments }],
                evidences: newEvidences,
                events: updatedEvents,
            };

            const action = {
                type: 'PHOTO_TOGGLE_BOOKMARK',
                claimNumber,
                participantSourceId,
                photoAttachments: newPhotoAttachments,
                evidences: newEvidences,
                events: updatedEvents,
            };

            expect(claimDataReducer(initialState, action)).toEqual(expectedState);
        });

        it('should keep events from state if none are passed in the action', () => {
            const claimNumber = '123',
                participantSourceId = 'p1',
                photoAttachments = [
                    { dcfId: '1', url: 'link1' },
                    { dcfId: '2', url: 'link2' }
                ],
                newPhotoAttachments = [
                    { dcfId: '1', url: 'link1' },
                    { dcfId: '2', url: 'link2', bookmarked: true }
                ],
                evidences = [
                    { id: 'e1', sourceId: '1' },
                    { id: 'e2', sourceId: '2' }
                ],
                newEvidences = [
                    { id: 'e1', sourceId: '1' },
                    { id: 'e2', sourceId: '2', type: 'photo' }
                ];
            const initialState = {
                claimNumber,
                liabilitySubjects: [{ participantSourceId, photoAttachments }],
                evidences,
                events: [event]
            };
            deepFreeze(initialState);
            const expectedState = {
                claimNumber,
                liabilitySubjects: [{ participantSourceId, photoAttachments: newPhotoAttachments }],
                evidences: newEvidences,
                events: [event]
            };

            const action = {
                type: 'PHOTO_TOGGLE_BOOKMARK',
                claimNumber,
                participantSourceId,
                photoAttachments: newPhotoAttachments,
                evidences: newEvidences,
            };

            expect(claimDataReducer(initialState, action)).toEqual(expectedState);
        });
    });

    describe('PHOTO_ROTATION action', () => {
        it('updates photo attachments and evidences in the store', () => {
            const claimNumber = '123',
                participantSourceId = 'p1',
                photoAttachments = [
                    { dcfId: '1', url: 'link1' },
                    { dcfId: '2', url: 'link2' }
                ],
                newPhotoAttachments = [
                    { dcfId: '1', url: 'link1' },
                    { dcfId: '2', url: 'link2', bookmarked: true }
                ],
                evidences = [
                    { id: 'e1', sourceId: '1' },
                    { id: 'e2', sourceId: '2' }
                ],
                newEvidences = [
                    { id: 'e1', sourceId: '1' },
                    { id: 'e2', sourceId: '2', type: 'photo' }
                ];
            const initialState = {
                claimNumber,
                liabilitySubjects: [{ participantSourceId, photoAttachments }],
                evidences
            };
            deepFreeze(initialState);
            const expectedState = {
                claimNumber,
                liabilitySubjects: [{ participantSourceId, photoAttachments: newPhotoAttachments }],
                evidences: newEvidences
            };

            const action = {
                type: 'PHOTO_ROTATION',
                claimNumber,
                participantSourceId,
                photoAttachments: newPhotoAttachments,
                evidences: newEvidences
            };

            expect(claimDataReducer(initialState, action)).toEqual(expectedState);
        });
    });

    describe('SAVE_UPDATED_LOSS_LOCATION action', () => {
        it('populates updated loss location', () => {
            const initialState = {
                claimNumber: '012345678',
                latitude: 1,
                longitude: 2,
                updatedLossLocation: 'Location Address'
            };

            const claimNumber = '012345678';
            const latitude = 0;
            const longitude = 0;
            const updatedLossLocation = 'New Location Address';
            deepFreeze(initialState);
            const action = lossLocationSaveAction(claimNumber, latitude, longitude, updatedLossLocation);

            const expectedState = {
                claimNumber: '012345678',
                latitude: 0,
                longitude: 0,
                updatedLossLocation: 'New Location Address'
            };

            expect(claimDataReducer(initialState, action)).toEqual(expectedState);
        });
    });

    describe('SAVE_CLAIM_UNLOCK action', () => {
        it('populates updated unlockReason and unlockDescription', () => {
            const initialState = {
                claimNumber: '123',
                unlockReason: '',
                unlockDescription: ''
            };

            deepFreeze(initialState);
            const action = saveClaimUnlockAction('123', 'other', 'description');

            const expectedState = {
                claimNumber: '123',
                locked: false,
                unlockReason: 'other',
                unlockDescription: 'description'
            };

            expect(claimDataReducer(initialState, action)).toEqual(expectedState);
        });
    });

    describe('SAVE_REPORTED_PCI action', () => {
        it('updates the reportedPciDate for the given voiceAttachment', () => {
            Date.now = jest.fn().mockReturnValue('now');

            const initialState = {
                claimNumber: '123',
                voiceAttachments: [
                    { sourceVoiceId: 'voiceId2' },
                    { sourceVoiceId: 'voiceId' },
                ]
            };

            deepFreeze(initialState);
            const action = saveReportedPciAction('123', 'voiceId', 'transcriptId', ['Credit Card']);

            const expectedState = {
                claimNumber: '123',
                voiceAttachments: [
                    { sourceVoiceId: 'voiceId2' },
                    { sourceVoiceId: 'voiceId', reportedPciDate: 'now' },
                ],
            };
            expect(claimDataReducer(initialState, action)).toEqual(expectedState);
        });
    });

    describe('SUBMIT_LIABILITY_SUCCESS action', () => {
        it('updates Claim Data on Submit Decision', () => {
            const claimData = {
                claimNumber: '12345',
                lossDetailType: 'Contact with other vehicle/property/other party',
            };
            const initialState = {};
            deepFreeze(initialState);
            const action = {
                type: 'SUBMIT_LIABILITY_SUCCESS',
                claimData: claimData,
            };
            const expectedState = {
                claimNumber: '12345',
                lossDetailType: 'Contact with other vehicle/property/other party',
                locked: true
            };
            expect(claimDataReducer(initialState, action)).toEqual(expectedState);
        });
    });

    describe('SUBMIT_LIABILITY_ERROR action', () => {
        it('sets locked to false when submit fails', () => {
            const initialState = { blah: 'blah' };
            deepFreeze(initialState);
            const action = {
                type: 'SUBMIT_LIABILITY_ERROR',
            };
            expect(claimDataReducer(initialState, action)).toEqual({ blah: 'blah', locked: false });
        });
    });

    describe('GET_PHOTO_ATTACHMENTS_SUCCESS action', () => {
        it('adds attachments when get attachments success is received', () => {
            const initialState = {
                claimNumber: '12345',
                lossDetailType: 'Contact with other vehicle/property/other party',
                liabilitySubjects: [
                    {
                        firstName: 'CINDA',
                        lastName: 'HERMAN',
                        organizationName: null,
                        participantSourceId: 'insuredPartId',
                        liabilityRangeBeginPercent: '10',
                        liabilityRangeEndPercent: '20'
                    },
                    {
                        firstName: 'MELISA',
                        lastName: 'VENTURA',
                        organizationName: null,
                        participantSourceId: 'claimantPartId1',
                        liabilityRangeBeginPercent: '80',
                        liabilityRangeEndPercent: '90'
                    },
                    {
                        firstName: 'SUDHA',
                        lastName: 'AMINENI',
                        organizationName: null,
                        participantSourceId: 'claimantPartId2',
                        liabilityRangeBeginPercent: '70',
                        liabilityRangeEndPercent: '80'
                    }
                ]
            };
            deepFreeze(initialState);
            const action = {
                type: 'GET_PHOTO_ATTACHMENTS_SUCCESS',
                liabilitySubjects: [{ firstName: 'name' }]
            };
            const expectedState = {
                claimNumber: '12345',
                lossDetailType: 'Contact with other vehicle/property/other party',
                liabilitySubjects: [{ firstName: 'name' }]
            };
            expect(claimDataReducer(initialState, action)).toEqual(expectedState);
        });
    });

    describe('GET_VOICE_ATTACHMENTS_SUCCESS action', () => {
        it('should append voice attachments to store', () => {
            const initialState = {
                claimNumber: '12345',
                voiceAttachments: [{ sourceVoiceUrl: 'voiceAttachment1' }]
            };
            deepFreeze(initialState);
            const action = {
                type: 'GET_VOICE_ATTACHMENTS_SUCCESS',
                voiceAttachments: [{ sourceVoiceUrl: 'voiceAttachment2' }]
            };
            const expectedState = {
                claimNumber: '12345',
                voiceAttachments: [{ sourceVoiceUrl: 'voiceAttachment2' }]
            };
            expect(claimDataReducer(initialState, action)).toEqual(expectedState);
        });
    });

    describe('SAVE_UPDATED_ASSIGNMENT_STATUS action', () => {
        it('updates assignment status', () => {
            const initialState = {
                claimNumber: '012345678',
                lossDetailType: 'Loss Detail Type Description',
                status: ASSIGNED
            };

            const action = updateAssignmentStatusAction(IN_PROGRESS, initialState);

            const expectedState = {
                claimNumber: '012345678',
                lossDetailType: 'Loss Detail Type Description',
                status: IN_PROGRESS
            };
            expect(claimDataReducer(initialState, action)).toEqual(expectedState);
        });
    });

    describe('GET_ACTIVE_ASSIGNMENT_SUCCESS action', () => {
        it('updates Claim Data on Submit Decision', () => {
            const claimData = {
                claimNumber: '12345',
                lossDetailType: 'Contact with other vehicle/property/other party',
            };
            const initialState = {};
            deepFreeze(initialState);
            const action = {
                type: 'GET_ACTIVE_ASSIGNMENT_SUCCESS',
                claimData: claimData,
            };
            const expectedState = {
                claimNumber: '12345',
                lossDetailType: 'Contact with other vehicle/property/other party',
            };
            expect(claimDataReducer(initialState, action)).toEqual(expectedState);
        });
    });

    describe('SAVE_NO_FAULT_IND action', () => {
        it('updates boolean field in store', () => {
            const initialState = { noFaultAllocationAgreement: false, noFaultAllocationResponse: false };
            deepFreeze(initialState);
            const mockAction = {
                type: 'SAVE_NO_FAULT_IND',
                claimNumber: '123',
                noFaultAllocationAgreement: true,
                noFaultAllocationResponse: true
            };
            const expectedState = { noFaultAllocationAgreement: true, noFaultAllocationResponse: true };
            expect(claimDataReducer(initialState, mockAction)).toEqual(expectedState);
        });
    });

    describe('SAVE_ADD_FOLLOW_UP action', () => {
        it('updates participant add followup request data in store', () => {
            const initialState = {
                claimNumber: '012345678',
                lossDetailType: 'Loss Detail Type Description',
                liabilitySubjects: [
                    {
                        participantSourceId: 'insuredPartId',
                        role: 'INSURED',
                        firstName: 'HOWARD',
                        lastName: 'ELLIOTT',
                        organizationName: null,
                        asset: {
                            vehicleYear: '2002',
                            vehicleMake: 'TOYOTA',
                            vehicleModel: 'COROLLA',
                        },
                        intersectionAccident: false,
                        damagePhotos: false,
                    },
                ]
            };
            deepFreeze(initialState);
            const expectedState = {
                claimNumber: '012345678',
                lossDetailType: 'Loss Detail Type Description',
                liabilitySubjects: [
                    {
                        participantSourceId: 'insuredPartId',
                        role: 'INSURED',
                        firstName: 'HOWARD',
                        lastName: 'ELLIOTT',
                        organizationName: null,
                        asset: {
                            vehicleYear: '2002',
                            vehicleMake: 'TOYOTA',
                            vehicleModel: 'COROLLA',
                        },
                        intersectionAccident: false,
                        damagePhotos: false,
                    }
                ]
            };
            const updatedParticipant = {
                participantSourceId: 'insuredPartId',
                role: 'INSURED',
                firstName: 'HOWARD',
                lastName: 'ELLIOTT',
                organizationName: null,
                asset: {
                    vehicleYear: '2002',
                    vehicleMake: 'TOYOTA',
                    vehicleModel: 'COROLLA',
                },
                intersectionAccident: false,
                damagePhotos: false,
            };

            const action = {
                type: 'SAVE_ADD_FOLLOW_UP',
                updatedParticipant
            };
            expect(claimDataReducer(initialState, action)).toEqual(expectedState);
        });
    });

    describe('INIT_SUCCESS', () => {
        it('returns the data from backend if there is a claim in progress', () => {
            expect(claimDataReducer({ claimNumber: '123' }, {
                type: 'INIT_SUCCESS',
                response: {
                    userId: 'tst-loon',
                    assignedClaimData: {
                        claimNumber: '456'
                    }
                }
            })).toEqual({ claimNumber: '456' });
        });

        it('returns the current state if there is no claim in progress', () => {
            expect(claimDataReducer({ claimNumber: '123' }, {
                type: 'INIT_SUCCESS',
                response: {
                    userId: 'tst-loon'
                }
            })).toEqual({ claimNumber: '123' });
        });
    });

    describe('SAVE_SKETCH', () => {
        it('should set the sketch image and garage to claimData store when sketchGarageSource is not falsy', () => {
            const state = {
                claimNumber: '123'
            };
            const action = {
                type: 'SAVE_SKETCH',
                sketch: {
                    imageSource: 'imageSource',
                    garageSource: 'garageSource'
                }
            };
            const newState = {
                claimNumber: '123',
                sketch: {
                    imageSource: 'imageSource',
                    garageSource: 'garageSource'
                }
            };
            expect(claimDataReducer(state, action)).toEqual(newState);
        });
    });

    describe('SAVE_HIGHLIGHT', () => {
        it('should add the new highlight to the store', () => {
            const state = {
                claimNumber: '123',
                voiceAttachments: [{ sourceVoiceId: 'vid' }],
                evidences: [{ id: 'somephotoid' }],
                events: [event]
            };
            const updatedEvent = { ...event, title: 'better title' };
            const action = {
                type: 'SAVE_HIGHLIGHT',
                voiceId: 'vid',
                highlightEntities: [{ id: 'heid' }],
                evidences: [{ id: 'eid', sourceId: 'heid', type: 'highlight' }, { id: 'somephotoid' }],
                events: [updatedEvent]
            };

            const newState = {
                claimNumber: '123',
                voiceAttachments: [{ sourceVoiceId: 'vid', highlightEntities: [{ id: 'heid' }] }],
                evidences: [{ id: 'eid', sourceId: 'heid', type: 'highlight' }, { id: 'somephotoid' }],
                events: [updatedEvent]
            };
            expect(claimDataReducer(state, action)).toEqual(newState);
        });

        it('should remove the selected highlight and update the store with events and evidences', () => {
            const state = {
                claimNumber: '123',
                voiceAttachments: [{ sourceVoiceId: 'vid' }],
                evidences: [{ id: 'somephotoid' }]
            };

            let newInvolvedParty = {
                participantId: '1',
                participantSourceId: '11',
                assetId: 'asset1',
                damageSections: [
                    'front',
                    'rear'
                ],
                contributingFactors: [
                    {
                        category: null,
                        reason: 'proper-lookout',
                        details: 'saw-other-party',
                        evidenceIds: ['evidenceId3', 'evidence5']
                    }
                ],
                affectedParties: [
                    {
                        participantId: '2',
                        participantSourceId: '22',
                        assetId: 'B9763FCB7D843B1F',
                        passengerPartyIds: [],
                        affectedPercent: 12,
                        beginNegotiatingRange: 7,
                        endNegotiatingRange: 17,
                        submittedAffectedPercent: 12,
                        faultAllocationPercent: 1
                    }
                ]
            };
            const newEvent =
                { id: '0', title: 'my first event title', severity: 1, involvedParties: [newInvolvedParty] };
            const action = {
                type: 'SAVE_HIGHLIGHT',
                voiceId: 'vid',
                highlightEntities: [{ id: 'heid' }],
                evidences: [{ id: 'eid', sourceId: 'heid', type: 'highlight' }],
                events: [event]
            };

            const newState = {
                claimNumber: '123',
                voiceAttachments: [{ sourceVoiceId: 'vid', highlightEntities: [{ id: 'heid' }] }],
                evidences: [{ id: 'eid', sourceId: 'heid', type: 'highlight' }],
                events: [newEvent]
            };
            expect(claimDataReducer(state, action)).toEqual(newState);
        });

        it('should keep events from the state when none are passed in the action', () => {
            const state = {
                claimNumber: '123',
                voiceAttachments: [{ sourceVoiceId: 'vid' }],
                evidences: [{ id: 'somephotoid' }],
                events: [event]
            };
            const action = {
                type: 'SAVE_HIGHLIGHT',
                voiceId: 'vid',
                highlightEntities: [{ id: 'heid' }],
                evidences: [{ id: 'eid', sourceId: 'heid', type: 'highlight' }, { id: 'somephotoid' }],
            };

            const newState = {
                claimNumber: '123',
                voiceAttachments: [{ sourceVoiceId: 'vid', highlightEntities: [{ id: 'heid' }] }],
                evidences: [{ id: 'eid', sourceId: 'heid', type: 'highlight' }, { id: 'somephotoid' }],
                events: [event]
            };
            expect(claimDataReducer(state, action)).toEqual(newState);
        });
    });

    describe('CREATE_EVENT', () => {
        it('should add the event to the claimData in the store', () => {
            const state = {
                claimNumber: '123',
                events: []
            };
            const actual = {
                claimNumber: '123',
                events: [{ id: 1 }]
            };
            const action = {
                type: 'CREATE_EVENT',
                event: { id: 1 }
            };
            expect(claimDataReducer(state, action)).toEqual(actual);
        });
    });

    describe('UPDATE_EVENT', () => {
        it('should update the event in the store', () => {
            const state = {
                claimNumber: '123',
                events: [
                    { id: 1, title: '1' },
                    { id: 2, title: '2' }
                ]
            };
            const actual = {
                claimNumber: '123',
                events: [
                    { id: 1, title: '1' },
                    { id: 2, title: '2 updated' }
                ]
            };
            const action = {
                type: 'UPDATE_EVENT',
                event: { id: 2, title: '2 updated' }
            };
            expect(claimDataReducer(state, action)).toEqual(actual);
        });
    });

    describe('REMOVE_EVENT', () => {
        it('should remove the event from the claimData in the store', () => {
            const state = {
                claimNumber: '123',
                events: [
                    { id: 1, title: '1' },
                    { id: 2, title: '2' },
                    { id: 3, title: '3' }
                ]
            };
            const actual = {
                claimNumber: '123',
                events: [
                    { id: 1, title: '1' },
                    { id: 3, title: '3' }
                ]
            };
            const action = {
                type: 'REMOVE_EVENT',
                event: { id: 2, title: '2' }
            };
            expect(claimDataReducer(state, action)).toEqual(actual);
        });
    });

    describe('SAVE_VOICE_ATTACHMENT_SUCCESS', () => {
        it('should update store with new voice attachments when new attachments are saved', () => {
            const mockVoiceAttachments = [{
                participantSourceId: '',
                participantDisplayName: 'OTHER',
                sourceVoiceId: '50',
            }, {
                participantSourceId: 'xyz',
                participantDisplayName: 'my name',
                sourceVoiceId: '51',
            }, {
                participantSourceId: '',
                participantDisplayName: '',
                sourceVoiceId: '52',
            }];

            const mockEvidences = [{ id: 2, type: 'highlight2' }];

            const expectedVoiceAttachments = [{
                participantSourceId: '',
                participantDisplayName: 'OTHER',
                sourceVoiceId: '50',
            }, {
                participantSourceId: 'abc',
                participantDisplayName: 'org name',
                sourceVoiceId: '51',
            }, {
                participantSourceId: '',
                participantDisplayName: '',
                sourceVoiceId: '52',
            }];

            const expectedEvidences = [{ id: 1, type: 'highlight' }];
            const initialState = {
                voiceAttachments: mockVoiceAttachments,
                evidences: mockEvidences,
            };

            deepFreeze(initialState);

            const expectedState = {
                voiceAttachments: expectedVoiceAttachments,
                evidences: expectedEvidences
            };

            const action = {
                type: 'SAVE_VOICE_PARTICIPANT_SUCCESS',
                voiceAttachments: expectedVoiceAttachments,
                evidences: expectedEvidences
            };

            expect(claimDataReducer(initialState, action)).toEqual(expectedState);
        });
    });

    describe('UPDATE_DAMAGES_ACTION', () => {
        it('should update damages using the new events', () => {
            const state = {
                claimNumber: '123',
                events: [
                    { id: 1, title: '1' },
                    {
                        id: 2, title: '2', involvedParties: [
                            { id: 1, damageSections: [] },
                            { id: 2, damageSections: ['blahblah'] }
                        ]
                    }
                ]
            };

            const expected = {
                claimNumber: '123',
                events: [
                    { id: 1, title: '1' },
                    {
                        id: 2, title: '2', involvedParties: [
                            { id: 1, damageSections: [] },
                            { id: 2, damageSections: ['new', 'damage', 'sections'] }
                        ]
                    }
                ]
            };

            const action = {
                type: 'UPDATE_DAMAGES',
                eventIndex: 1,
                involvedPartyIndex: 1,
                damageSections: ['new', 'damage', 'sections']
            };

            expect(claimDataReducer(state, action)).toEqual(expected);
        });
    });

    describe('SAVE_EVIDENCE', () => {
        it('should update evidences in the store', () => {
            const state = {
                claimNumber: '123',
                evidences: [
                    { id: 1, sourceId: 'highlight1' },
                    { id: 2, sourceId: 'highlight2' },
                ]
            };
            const expected = {
                claimNumber: '123',
                evidences: [
                    { id: 1, sourceId: 'highlight1' },
                    { id: 2, sourceId: 'highlight2', category: 'damages' },
                ]
            };
            const action = {
                type: 'SAVE_EVIDENCE',
                claimNumber: '123',
                evidence: { id: 2, sourceId: 'highlight2', category: 'damages' }
            };

            expect(claimDataReducer(state, action)).toEqual(expected);
        });
    });
});
