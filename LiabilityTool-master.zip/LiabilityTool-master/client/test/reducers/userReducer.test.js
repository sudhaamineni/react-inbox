jest.unmock('../../src/main/reducers/userReducer');

import userReducer from '../../src/main/reducers/userReducer';

describe('userReducer', () => {
    it('default', () => {
        expect(userReducer(undefined, {type: 'blah'})).toEqual({userId: '', userRoles: undefined});
    });

    it('INIT_SUCCESS', () => {
        const response = {
            userId: 'something',
            userRoles: ['role1', 'role2'],
            assignedClaimData: {claimNumber: '123'},
            featureSwitches: {
                enableAdmin: true,
            }
        };
        const action = {type: 'INIT_SUCCESS', response};

        const expectedState = {
            userId: 'something',
            userRoles: ['role1', 'role2']
        };
        expect(userReducer(undefined, action)).toEqual(expectedState);
    });

    it('INIT_FAILURE', () => {
        const action = {type: 'INIT_FAILURE'};

        const expectedState = {
            userId: '',
            userRoles: []
        };
        expect(userReducer(undefined, action)).toEqual(expectedState);
    });
});