jest.unmock('../../src/main/helpers/contributingFactorHelper');
jest.unmock('../../src/main/constants/contributingFactorConstants');

import {getCFLabel, getCFCategory} from "../../src/main/helpers/contributingFactorHelper";


describe('Given a contributingFactorHelper', () => {
    describe('getCFLabel', () => {
        it('should return en empty string when cfReason is null, an empty string or an invalid value', () => {
            const invalidReasons = [null, '', 'my-reason'];

            invalidReasons.forEach(reason => {
                expect(getCFLabel(reason)).toBe('')
            });
        });

        it('should return a valid label for a CFReason', () => {
            expect(getCFLabel('mechanical-failure')).toBe('Mechanical Failure');
        });
    });

    describe('getCFCategory', () => {
        it('should return en empty string when cfReason is null, an empty string or an invalid value', () => {
            const invalidReasons = [null, '', 'my-reason'];

            invalidReasons.forEach(reason => {
                expect(getCFCategory(reason)).toBe('')
            });
        });

        it('should return a valid category for a CFReason', () => {
            expect(getCFCategory('failed-to-obey-traffic-control')).toBe('right-of-way');
        });
    });
});
