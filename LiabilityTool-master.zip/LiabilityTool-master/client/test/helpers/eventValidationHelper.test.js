jest.unmock('../../src/main/helpers/eventValidationHelper');

import {
    createInitialEventValidationArray,
    hasAddFaultParticipantError,
    hasAffectedParticipantNotSelectedError,
    hasInitialFaultPercentError,
    hasDamagesError,
    hasSeverityError, hasSupportingEvidenceError,
    hasTooFewInvolvedPartyError,
    validateEvent,
    revalidateEvent
} from '../../src/main/helpers/eventValidationHelper';

describe('eventValidationHelper', () => {
    let event;
    beforeEach(() => {
        event = {
            severity: 0,
            involvedParties: [
                {
                    damageSections: ['area'],
                    participantId: 1,
                    participantSourceId: '001',
                    contributingFactors: [{reason: 'reason1'}],
                    affectedParties: [
                        {
                            participantId: 2,
                            participantSourceId: '002',
                            initialFaultPercent: 50,
                        }
                    ]
                }, {
                    damageSections: ['front'],
                    participantId: 2,
                    participantSourceId: '002',
                    contributingFactors: [{reason: 'reason2'}],
                    affectedParties: [
                        {
                            participantId: 1,
                            participantSourceId: '001',
                            initialFaultPercent: 50,
                        }
                    ]
                }
            ]
        };
    });

    describe('Severity Error', () => {
        it('should have an error when severity is not set for event of event index 1 or more', () => {
            event.severity = undefined;
            const eventIndex = 1;
            expect(hasSeverityError(event, eventIndex)).toBe(true);
            const validation = validateEvent(event, eventIndex);
            expect(validation.severityError).toBe(true);
            expect(validation.error).toBe(true);
        });

        it('should have an error when severity is null for event of event index 1 or more', () => {
            event.severity = null;
            const eventIndex = 1;

            expect(hasSeverityError(event, eventIndex)).toBe(true);

            const validation = validateEvent(event, eventIndex);
            expect(validation.severityError).toBe(true);
            expect(validation.error).toBe(true);
        });

        it('should not have an error when severity is set for event of event index 1 or more', () => {
            const eventIndex = 1;
            expect(hasSeverityError(event, eventIndex)).toBe(false);

            const validation = validateEvent(event, eventIndex);
            expect(validation.severityError).toBe(false);
            expect(validation.error).toBe(false);
        });

        it('should not have an error when event index is 0', () => {
            const eventIndex = 0;
            expect(hasSeverityError(event, eventIndex)).toBe(false);

            const validation = validateEvent(event, eventIndex);
            expect(validation.severityError).toBe(false);
            expect(validation.error).toBe(false);
        });
    });

    describe('Too Few Involved Parties Error', () => {
        it('should not have an error when involved parties length is 1 but there is only one participant in claim ', () => {
            event.involvedParties = [{
                damageSections: ['area'],
                participantId: 1,
                participantSourceId: '001',
                contributingFactors: [{reason: 'reason'}],
                affectedParties: [
                    {
                        participantId: 2,
                        participantSourceId: '002',
                        initialFaultPercent: 50
                    }
                ]
            }];
            expect(hasTooFewInvolvedPartyError(event, true)).toBe(false);

            const validation = validateEvent(event, 1, true);
            expect(validation.tooFewInvolvedPartyError).toBe(false);
            expect(validation.error).toBe(false);
        });

        it('should have an error when involved parties length is 0', () => {
            event.involvedParties = [];
            expect(hasTooFewInvolvedPartyError(event, false)).toBe(true);

            const validation = validateEvent(event, 1, false);
            expect(validation.tooFewInvolvedPartyError).toBe(true);
            expect(validation.error).toBe(true);
        });

        it('should have an error when involved parties length is 1', () => {
            event.involvedParties = [{contributingFactors: []}];
            expect(hasTooFewInvolvedPartyError(event, false)).toBe(true);

            const validation = validateEvent(event, 1, false);
            expect(validation.tooFewInvolvedPartyError).toBe(true);
            expect(validation.error).toBe(true);
        });

        it('should have an error when involved parties is undefined', () => {
            event.involvedParties = undefined;
            expect(hasTooFewInvolvedPartyError(event, false)).toBe(true);

            const validation = validateEvent(event, 1, false);
            expect(validation.tooFewInvolvedPartyError).toBe(true);
            expect(validation.error).toBe(true);
        });

        it('should not have an error when involved parties is length 2', () => {
            expect(hasTooFewInvolvedPartyError(event, false)).toBe(false);

            const validation = validateEvent(event, 1, false);
            expect(validation.tooFewInvolvedPartyError).toBe(false);
            expect(validation.error).toBe(false);
        });
    });

    describe('Add Fault Participant Error', () => {
        it('should have an error when there is a participant not associated to any party', () => {
            event.involvedParties = [
                {
                    participantId: 1,
                    participantSourceId: '001',
                    contributingFactors: [{id: '1'}],
                    damageSections: ['area'],
                    affectedParties: [{participantId: 2, participantSourceId: '002', initialFaultPercent: 50,}]
                },
                {
                    participantId: 2,
                    participantSourceId: '002',
                    contributingFactors: [{id: '1'}],
                    damageSections: ['area'],
                    affectedParties: []
                },
                {
                    participantId: 3,
                    participantSourceId: '003',
                    contributingFactors: [{id: '1'}],
                    damageSections: ['area'],
                    affectedParties: []
                }
            ];
            expect(hasAddFaultParticipantError(event)).toBe(true);

            const validation = validateEvent(event, 1);
            expect(validation.addFaultParticipantError).toBe(true);
            expect(validation.error).toBe(true);
        });

        it('should have an error when all involved parties do not have affected parties', () => {
            event.involvedParties = [
                {
                    participantId: 1,
                    participantSourceId: '001',
                    contributingFactors: [{id: '1'}],
                    damageSections: ['area'],
                    affectedParties: []
                },
                {
                    participantId: 2,
                    participantSourceId: '002',
                    contributingFactors: [{id: '1'}],
                    damageSections: ['area'],
                    affectedParties: []
                }
            ];
            expect(hasAddFaultParticipantError(event)).toBe(true);

            const validation = validateEvent(event, 1);
            expect(validation.addFaultParticipantError).toBe(true);
            expect(validation.error).toBe(true);
        });

        it('should not have an error when all involved parties are associated - 1st scenario', () => {
            event.involvedParties = [
                {
                    participantId: 1,
                    participantSourceId: '001',
                    contributingFactors: [{reason: 'reason'}],
                    damageSections: ['area'],
                    affectedParties: [{participantId: 2, participantSourceId: '002', initialFaultPercent: 50,}]
                },
                {
                    participantId: 2,
                    participantSourceId: '002',
                    contributingFactors: [{reason: 'reason'}],
                    damageSections: ['area'],
                    affectedParties: []
                },
                {
                    participantId: 3,
                    participantSourceId: '003',
                    contributingFactors: [{reason: 'reason'}],
                    damageSections: ['area'],
                    affectedParties: [{participantId: 2, initialFaultPercent: 50, participantSourceId: '002',}]
                }
            ];
            expect(hasAddFaultParticipantError(event)).toBe(false);

            const validation = validateEvent(event, 1);
            expect(validation.addFaultParticipantError).toBe(false);
            expect(validation.error).toBe(false);
        });

        it('should not have an error when all involved parties are associated - 2nd scenario', () => {
            event.involvedParties = [
                {
                    participantId: 1,
                    participantSourceId: '001',
                    contributingFactors: [{reason: 'reason'}],
                    damageSections: ['area'],
                    affectedParties: [{participantId: 2, participantSourceId: '002', initialFaultPercent: 50}]
                },
                {
                    participantId: 2,
                    participantSourceId: '002',
                    contributingFactors: [{reason: 'reason'}],
                    damageSections: ['area'],
                    affectedParties: [{participantId: 3, participantSourceId: '003', initialFaultPercent: 50}]
                },
                {
                    participantId: 3,
                    participantSourceId: '003',
                    contributingFactors: [{reason: 'reason'}],
                    damageSections: ['area'],
                    affectedParties: []
                }
            ];
            expect(hasAddFaultParticipantError(event)).toBe(false);

            const validation = validateEvent(event, 1);
            expect(validation.addFaultParticipantError).toBe(false);
            expect(validation.error).toBe(false);
        });
    });

    describe('Damage Section Not Selected Error', () => {
        it('should have an error when damage sections is null', () => {
            const involvedParty = {
                ...event.involvedParties[0],
                damageSections: null
            };
            event.involvedParties[0] = involvedParty;

            expect(hasDamagesError(involvedParty)).toBe(true);

            const validation = validateEvent(event, 1);
            expect(validation.involvedParties[0].damagesError).toBe(true);
            expect(validation.involvedParties[1].damagesError).toBe(false);
            expect(validation.error).toBe(true);
        });

        it('should have an error when damage sections is undefined', () => {
            const involvedParty = {
                ...event.involvedParties[0],
                damageSections: undefined,
            };
            event.involvedParties[0] = involvedParty;

            expect(hasDamagesError(involvedParty)).toBe(true);

            const validation = validateEvent(event, 1);
            expect(validation.involvedParties[0].damagesError).toBe(true);
            expect(validation.involvedParties[1].damagesError).toBe(false);
            expect(validation.error).toBe(true);
        });

        it('should have an error when damage sections is empty array', () => {
            const involvedParty = {
                ...event.involvedParties[0],
                damageSections: [],
            };
            event.involvedParties[0] = involvedParty;

            expect(hasDamagesError(involvedParty)).toBe(true);

            const validation = validateEvent(event, 1);
            expect(validation.involvedParties[0].damagesError).toBe(true);
            expect(validation.involvedParties[1].damagesError).toBe(false);
            expect(validation.error).toBe(true);
        });

        it('should not have an error when damage sections has values', () => {
            const involvedParty = {
                ...event.involvedParties[0],
                damageSections: ['area'],
            };
            event.involvedParties[0] = involvedParty;

            expect(hasDamagesError(involvedParty)).toBe(false);

            const validation = validateEvent(event, 1);
            expect(validation.involvedParties[0].damagesError).toBe(false);
            expect(validation.involvedParties[1].damagesError).toBe(false);
            expect(validation.error).toBe(false);
        });
    });

    describe('Affected Participant Not Selected Error', () => {
        it('should not have an error if there is only one participant', () => {
            const affectedParty = {
                participantId: null,
                participantSourceId: null,
                assetId: null,
                initialFaultPercent: 50,
            };
            expect(hasAffectedParticipantNotSelectedError(affectedParty, true)).toBe(false);
            event.involvedParties.pop();
            //should only have participant 1 left
            event.involvedParties[0].affectedParties = [affectedParty];
            const validation = validateEvent(event, 1, true);
            expect(validation.involvedParties[0].affectedParties[0].affectedParticipantNotSelectedError).toBe(false);
            expect(validation.error).toBe(false);

        });

        it('should have an error if an affected party is empty object', () => {
            const affectedParty = {};
            expect(hasAffectedParticipantNotSelectedError(affectedParty, false)).toBe(true);

            event.involvedParties[0].affectedParties = [affectedParty];
            const validation = validateEvent(event, 1);
            expect(validation.involvedParties[0].affectedParties[0].affectedParticipantNotSelectedError).toBe(true);
            expect(validation.error).toBe(true);
        });

        it('should have an error when affected party participant ID is null', () => {
            const affectedParty = {participantId: null, participantSourceId: null, initialFaultPercent: '50',};
            expect(hasAffectedParticipantNotSelectedError(affectedParty, false)).toBe(true);

            event.involvedParties[0].affectedParties = [affectedParty];
            const validation = validateEvent(event, 1);
            expect(validation.involvedParties[0].affectedParties[0].affectedParticipantNotSelectedError).toBe(true);
            expect(validation.error).toBe(true);
        });

        it('should not have an error when affected party participant ID is populated', () => {
            const affectedParty = {participantId: '01', participantSourceId: '001', initialFaultPercent: 50};
            expect(hasAffectedParticipantNotSelectedError(affectedParty, false)).toBe(false);

            event.involvedParties[0].affectedParties = [affectedParty];
            const validation = validateEvent(event, 1);
            expect(validation.involvedParties[0].affectedParties[0].affectedParticipantNotSelectedError).toBe(false);
            expect(validation.error).toBe(false);
        });
    });

    describe('Affected Participant Percent Not Entered Error', () => {
        it('should have an error if affected percent is undefined', () => {
            const affectedParty = {participantId: '01', participantSourceId: '001',};
            expect(hasInitialFaultPercentError(affectedParty)).toBe(true);

            event.involvedParties[0].affectedParties = [affectedParty];
            const validation = validateEvent(event, 1);
            expect(validation.involvedParties[0].affectedParties[0].initialFaultPercentError).toBe(true);
            expect(validation.error).toBe(true);
        });

        it('should have an error if affected percent is null', () => {
            const affectedParty = {participantId: '01', participantSourceId: '001', initialFaultPercent: null};
            expect(hasInitialFaultPercentError(affectedParty)).toBe(true);

            event.involvedParties[0].affectedParties = [affectedParty];
            const validation = validateEvent(event, 1);
            expect(validation.involvedParties[0].affectedParties[0].initialFaultPercentError).toBe(true);
            expect(validation.error).toBe(true);
        });

        it('should have an error if affected percent is empty', () => {
            const affectedParty = {participantId: '01', participantSourceId: '001', initialFaultPercent: ''};
            expect(hasInitialFaultPercentError(affectedParty)).toBe(true);

            event.involvedParties[0].affectedParties = [affectedParty];
            const validation = validateEvent(event, 1);
            expect(validation.involvedParties[0].affectedParties[0].initialFaultPercentError).toBe(true);
            expect(validation.error).toBe(true);
        });

        it('should not have an error if affected percent is 0', () => {
            const affectedParty = {participantId: '01', participantSourceId: '001', initialFaultPercent: 0};
            expect(hasInitialFaultPercentError(affectedParty)).toBe(false);

            event.involvedParties[0].affectedParties = [affectedParty];
            const validation = validateEvent(event, 1);
            expect(validation.involvedParties[0].affectedParties[0].initialFaultPercentError).toBe(false);
            expect(validation.error).toBe(false);
        });

        it('should not have an error when affected percent is populated', () => {
            const affectedParty = {participantId: '01', participantSourceId: '001', initialFaultPercent: '0'};
            expect(hasInitialFaultPercentError(affectedParty)).toBe(false);

            event.involvedParties[0].affectedParties = [affectedParty];
            const validation = validateEvent(event, 1);
            expect(validation.involvedParties[0].affectedParties[0].initialFaultPercentError).toBe(false);
            expect(validation.error).toBe(false);
        });
    });

    describe('Event Validation', () => {
        it('should return a correct eventValidation object if no errors', () => {
            const eventIndex = 1;
            const event = {
                severity: 0,
                involvedParties: [
                    {
                        damageSections: ['area'],
                        participantId: 1,
                        participantSourceId: '001',
                        contributingFactors: [{reason: 'proper-lookout', details: 'dtl',}],
                        affectedParties: [
                            {
                                participantId: 2,
                                participantSourceId: '002',
                                initialFaultPercent: 50
                            }
                        ]
                    },
                    {
                        damageSections: ['front'],
                        participantId: 2,
                        participantSourceId: '002',
                        contributingFactors: [{reason: 'reason'}],
                        affectedParties: [
                            {
                                participantId: 1,
                                participantSourceId: '001',
                                initialFaultPercent: 50
                            }
                        ]
                    }
                ]
            };

            const expectedEventValidation = {
                error: false,
                severityError: false,
                tooFewInvolvedPartyError: false,
                addFaultParticipantError: false,
                tooMuchAssignedFaultError: [],
                involvedParties: [
                    {
                        damagesError: false,
                        minOneCfError: false,
                        minOneMissingSupportingEvidenceError: false,
                        affectedParties: [
                            {
                                affectedParticipantNotSelectedError: false,
                                initialFaultPercentError: false,
                            }],
                        contributingFactors: [
                            {
                                missingCfReasonError: false,
                                missingCfDetailsError: false,
                                missingSupportingEvidenceError: false,
                            },
                        ],
                    },
                    {
                        damagesError: false,
                        minOneCfError: false,
                        minOneMissingSupportingEvidenceError: false,
                        affectedParties: [
                            {
                                affectedParticipantNotSelectedError: false,
                                initialFaultPercentError: false,
                            }],
                        contributingFactors: [
                            {
                                missingCfReasonError: false,
                                missingCfDetailsError: false,
                                missingSupportingEvidenceError: false,
                            },
                        ],
                    }]
            };

            expect(validateEvent(event, eventIndex, false, false)).toEqual(expectedEventValidation);
        });

        it('should return a correct eventValidation object if there is an error', () => {
            const eventIndex = 0;
            const event = {
                severity: null,
                involvedParties: [
                    {
                        damageSections: ['area'],
                        participantId: 1,
                        participantSourceId: '001',
                        contributingFactors: [{}],
                        affectedParties: [
                            {
                                participantId: 2,
                                participantSourceId: '002',
                                initialFaultPercent: 50
                            }
                        ]
                    }, {
                        damageSections: null,
                        participantId: 2,
                        participantSourceId: '002',
                        contributingFactors: [],
                        affectedParties: [
                            {
                                participantId: 1,
                                participantSourceId: '001',
                                initialFaultPercent: 50
                            }
                        ]
                    },
                    {
                        damageSections: [],
                        contributingFactors: [],
                        participantId: 3,
                        affectedParties: []
                    }
                ]
            };

            const expectedEventValidation = {
                error: true,
                severityError: false,
                tooFewInvolvedPartyError: false,
                addFaultParticipantError: true,
                tooMuchAssignedFaultError: [],
                involvedParties: [
                    {
                        damagesError: false,
                        minOneCfError: true,
                        minOneMissingSupportingEvidenceError: false,
                        affectedParties: [
                            {
                                affectedParticipantNotSelectedError: false,
                                initialFaultPercentError: false,
                            }],
                        contributingFactors: [
                            {
                                missingCfReasonError: true,
                                missingCfDetailsError: false,
                                missingSupportingEvidenceError: false,
                            }
                        ],

                    },
                    {
                        damagesError: true,
                        minOneCfError: true,
                        minOneMissingSupportingEvidenceError: false,
                        affectedParties: [
                            {
                                affectedParticipantNotSelectedError: false,
                                initialFaultPercentError: false,
                            }],
                        contributingFactors: [],
                    },
                    {
                        damagesError: true,
                        minOneCfError: false,
                        affectedParties: [],
                        contributingFactors: [],
                        minOneMissingSupportingEvidenceError: false,
                    }]
            };

            expect(validateEvent(event, eventIndex, true, false)).toEqual(expectedEventValidation);
        });
    });

    describe('Revalidate event', () => {
        it('should return a correct eventValidation object if there is an error', () => {
            const eventIndex = 0;
            const mockSetEventsValidationAction = jest.fn();
            const event = {
                severity: null,
                involvedParties: [
                    {
                        damageSections: ['area'],
                        participantId: 1,
                        participantSourceId: '001',
                        contributingFactors: [{}],
                        affectedParties: [
                            {
                                participantId: 2,
                                participantSourceId: '002',
                                initialFaultPercent: 50
                            }
                        ]
                    }, {
                        damageSections: null,
                        participantId: 2,
                        participantSourceId: '002',
                        contributingFactors: [],
                        affectedParties: [
                            {
                                participantId: 1,
                                participantSourceId: '001',
                                initialFaultPercent: 50
                            }
                        ]
                    },
                    {
                        damageSections: [],
                        contributingFactors: [],
                        participantId: 3,
                        affectedParties: []
                    }
                ]
            };
            const evidences =[
                {evidenceId: '123'}
                ];

            const eventValidation = [{
                error: true,
                severityError: false,
                tooFewInvolvedPartyError: false,
                addFaultParticipantError: true,
                tooMuchAssignedFaultError: [],
                involvedParties: [
                    {
                        damagesError: false,
                        minOneCfError: true,
                        minOneMissingSupportingEvidenceError: false,
                        affectedParties: [
                            {
                                affectedParticipantNotSelectedError: false,
                                initialFaultPercentError: false,
                            }],
                        contributingFactors: [
                            {
                                missingCfReasonError: true,
                                missingCfDetailsError: false,
                                missingSupportingEvidenceError: false,
                            }
                        ],

                    },
                    {
                        damagesError: true,
                        minOneCfError: false,
                        affectedParties: [],
                        contributingFactors: [],
                        minOneMissingSupportingEvidenceError: false,
                    }]
            }];

            const expectedEventValidation = [{
                error: true,
                severityError: false,
                tooFewInvolvedPartyError: false,
                addFaultParticipantError: true,
                tooMuchAssignedFaultError: [],
                involvedParties: [
                    {
                        damagesError: false,
                        minOneCfError: true,
                        minOneMissingSupportingEvidenceError: false,
                        affectedParties: [
                            {
                                affectedParticipantNotSelectedError: false,
                                initialFaultPercentError: false,
                            }],
                        contributingFactors: [
                            {
                                missingCfReasonError: true,
                                missingCfDetailsError: false,
                                missingSupportingEvidenceError: false,
                            }
                        ],

                    },
                    {
                        damagesError: true,
                        minOneCfError: true,
                        minOneMissingSupportingEvidenceError: false,
                        affectedParties: [
                            {
                                affectedParticipantNotSelectedError: false,
                                initialFaultPercentError: false,
                            }],
                        contributingFactors: [],
                    },
                    {
                        damagesError: true,
                        minOneCfError: false,
                        affectedParties: [],
                        contributingFactors: [],
                        minOneMissingSupportingEvidenceError: false,
                    }]
            }];

            revalidateEvent(event, mockSetEventsValidationAction, eventIndex, eventValidation, evidences);
            expect(mockSetEventsValidationAction).toHaveBeenCalledWith(expectedEventValidation);
        });
    });

    describe('tooMuchAssignedFaultError', () => {
        it('should not have an error when the all participants have a total initialFaultPercent of 100 or less', () => {
            event.involvedParties = [
                {
                    damageSections: ['area'],
                    participantId: 1,
                    participantSourceId: '001',
                    contributingFactors: [{reason: 'reason1'}],
                    affectedParties: [
                        {
                            participantId: 2,
                            participantSourceId: '002',
                            initialFaultPercent: 25,
                        }
                    ]
                }, {
                    damageSections: ['front'],
                    participantId: 2,
                    participantSourceId: '002',
                    contributingFactors: [{reason: 'reason2'}],
                    affectedParties: [
                        {
                            participantId: 1,
                            participantSourceId: '001',
                            initialFaultPercent: 50,
                        }
                    ]
                }, {
                    damageSections: ['rear'],
                    participantId: 3,
                    participantSourceId: '003',
                    contributingFactors: [{reason: 'reason3'}],
                    affectedParties: [
                        {
                            participantId: 1,
                            participantSourceId: '001',
                            initialFaultPercent: 50,
                        },
                        {
                            participantId: 2,
                            participantSourceId: '002',
                            initialFaultPercent: 25,
                        }
                    ]
                }
            ];

            const validation = validateEvent(event, 1, false);
            expect(validation.involvedParties[0].affectedParties[0].initialFaultPercentError).toBe(false);
            expect(validation.involvedParties[1].affectedParties[0].initialFaultPercentError).toBe(false);
            expect(validation.involvedParties[2].affectedParties[0].initialFaultPercentError).toBe(false);
            expect(validation.involvedParties[2].affectedParties[1].initialFaultPercentError).toBe(false);
            expect(validation.tooMuchAssignedFaultError).toEqual([]);
            expect(validation.error).toBe(false);
        });

        describe('when the sum of a participant initialFaultPercent values is over 100', () => {
            let validation;
            beforeEach(() => {
                event.involvedParties = [
                    {
                        damageSections: ['area'],
                        participantId: 1,
                        participantSourceId: '001',
                        contributingFactors: [{reason: 'reason1'}],
                        affectedParties: [
                            {
                                participantId: 2,
                                participantSourceId: '002',
                                initialFaultPercent: 100,
                            },
                            {
                                participantId: 3,
                                participantSourceId: '003',
                                initialFaultPercent: 25,
                            }
                        ]
                    }, {
                        damageSections: ['front'],
                        participantId: 2,
                        participantSourceId: '002',
                        contributingFactors: [{reason: 'reason2'}],
                        affectedParties: [
                            {
                                participantId: 1,
                                participantSourceId: '001',
                                initialFaultPercent: 50,
                            },
                            {
                                participantId: 3,
                                participantSourceId: '003',
                                initialFaultPercent: 25,
                            }
                        ]
                    }, {
                        damageSections: ['rear'],
                        participantId: 3,
                        participantSourceId: '003',
                        contributingFactors: [{reason: 'reason3'}],
                        affectedParties: [
                            {
                                participantId: 1,
                                participantSourceId: '001',
                                initialFaultPercent: 60,
                            },
                            {
                                participantId: 2,
                                participantSourceId: '002',
                                initialFaultPercent: 1,
                            }
                        ]
                    }
                ];

                validation = validateEvent(event, 1, false);
            });

            it('should have an overall error', () => {
                expect(validation.error).toBe(true);
            });

            it('should list the participantSourceId in the tooMuchAssignedFaultError array', () => {
                expect(validation.tooMuchAssignedFaultError).toEqual(['001', '002']);
            });

            it('should set initialFaultPercentError to true for each affectedParty with that participantId', () => {
                expect(validation.involvedParties[0].affectedParties[0].initialFaultPercentError).toBe(true);
                expect(validation.involvedParties[0].affectedParties[1].initialFaultPercentError).toBe(false);
                expect(validation.involvedParties[1].affectedParties[0].initialFaultPercentError).toBe(true);
                expect(validation.involvedParties[1].affectedParties[1].initialFaultPercentError).toBe(false);
                expect(validation.involvedParties[2].affectedParties[0].initialFaultPercentError).toBe(true);
                expect(validation.involvedParties[2].affectedParties[1].initialFaultPercentError).toBe(true);
            });
        });
    });

    describe('Create Initial Events Validation array', () => {
        it('should create a new event validation array based on an event', () => {
            const events = [{
                id: 1,
                title: '',
                severity: 0,
                involvedParties: [
                    {
                        participantId: 1,
                        participantSourceId: '001',
                        affectedParties: [
                            {
                                participantId: 2,
                                participantSourceId: '002',
                            },
                            {
                                participantId: 3,
                                participantSourceId: '003',
                            }
                        ],
                        contributingFactors: [
                            {
                                reason: 'reason',
                            }
                        ],
                    },
                    {
                        participantId: 2,
                        participantSourceId: '002',
                        affectedParties: [
                            {
                                participantId: 1,
                                participantSourceId: '001',
                            }
                        ],
                        contributingFactors: [],
                    }
                ]
            }];

            const expectedEventValidation = [{
                error: false,
                severityError: false,
                tooFewInvolvedPartyError: false,
                addFaultParticipantError: false,
                tooMuchAssignedFaultError: [],
                involvedParties: [
                    {
                        damagesError: false,
                        minOneCfError: false,
                        minOneMissingSupportingEvidenceError: false,
                        affectedParties: [
                            {
                                affectedParticipantNotSelectedError: false,
                                initialFaultPercentError: false,
                            },
                            {
                                affectedParticipantNotSelectedError: false,
                                initialFaultPercentError: false,
                            }
                        ],
                        contributingFactors: [
                            {
                                missingCfReasonError: false,
                                missingCfDetailsError: false,
                                missingSupportingEvidenceError: false,
                            },
                        ],
                    },
                    {
                        damagesError: false,
                        minOneCfError: false,
                        minOneMissingSupportingEvidenceError: false,
                        affectedParties: [
                            {
                                affectedParticipantNotSelectedError: false,
                                initialFaultPercentError: false,
                            }
                        ],
                        contributingFactors: [],
                    }
                ]
            }];

            expect(createInitialEventValidationArray(events)).toEqual(expectedEventValidation);
        });
    });

    describe('Contributing factor validation', () => {
        describe('Missing Supporting Evidence Error', () => {
            it('should not have an error for supporting evidence if the validateContributingFactorEvidence feature switch is off', () => {
                const contributingFactors = {reason: 'reason1', evidenceIds: []};
                event.involvedParties[0].contributingFactors[0] = contributingFactors;
                const validation = validateEvent(event, 0, false, true, false);

                expect(validation.error).toBe(false);
                expect(validation.involvedParties[0].contributingFactors[0].missingSupportingEvidenceError).toBe(false);
                expect(validation.involvedParties[0].minOneMissingSupportingEvidenceError).toBe(false)
            });
            
            it('should not have an error when no supporting evidence is added and if there does not exist an evidence', () => {
                const contributingFactors = {reason: 'reason1', evidenceIds: []};
                event.involvedParties[0].contributingFactors[0] = contributingFactors;

                expect(hasSupportingEvidenceError(contributingFactors, false, false)).toBe(false);

                const validation = validateEvent(event, 0, false, false);

                expect(validation.error).toBe(false);
                expect(validation.involvedParties[0].contributingFactors[0].missingSupportingEvidenceError).toBe(false);

            });

            it('should have an error when no supporting evidence is added and if there exist an evidence', () => {
                const contributingFactors = {reason: 'reason1', evidenceIds: []};
                event.involvedParties[0].contributingFactors[0] = contributingFactors;

                expect(hasSupportingEvidenceError(contributingFactors, true, true)).toBe(true);

                const validation = validateEvent(event, 0, false, true);

                expect(validation.error).toBe(true);
                expect(validation.involvedParties[0].contributingFactors[0].missingSupportingEvidenceError).toBe(true);
                expect(validation.involvedParties[0].minOneMissingSupportingEvidenceError).toBe(true)

            });

            it('should have an error when no supporting evidence is added and if there exist an evidence', () => {
                const contributingFactors = {reason: 'reason1', evidenceIds: ['evidenceId']};
                event.involvedParties[0].contributingFactors[0] = contributingFactors;

                expect(hasSupportingEvidenceError(contributingFactors, true, true)).toBe(false);

                const validation = validateEvent(event, 0, false, true);

                expect(validation.error).toBe(false);
                expect(validation.involvedParties[0].contributingFactors[0].missingSupportingEvidenceError).toBe(false);

            });

            it('should set minOneMissingSupportingEvidenceError for multiple contributing factors', () => {
                const contributingFactors1 = {reason: 'reason1', evidenceIds: ['evidenceId']};
                const contributingFactors2 = {reason: 'reason2', evidenceIds: []};
                event.involvedParties[0].contributingFactors = [contributingFactors1, contributingFactors2]


                expect(hasSupportingEvidenceError(contributingFactors1, true, true)).toBe(false);
                expect(hasSupportingEvidenceError(contributingFactors2, true, true)).toBe(true);

                const validation = validateEvent(event, 0, false, true);

                expect(validation.error).toBe(true);
                expect(validation.involvedParties[0].contributingFactors[0].missingSupportingEvidenceError).toBe(false);
                expect(validation.involvedParties[0].contributingFactors[1].missingSupportingEvidenceError).toBe(true);
                expect(validation.involvedParties[0].minOneMissingSupportingEvidenceError).toBe(true)

            });
        });

        it('should not have an error if there are no affected parties', () => {
            event.involvedParties[0].contributingFactors = [];
            event.involvedParties[0].affectedParties = [];

            const result = validateEvent(event);
            expect(result.involvedParties[0].minOneCfError).toBe(false);
            expect(result.error).toBe(false);
        });

        it('should have an error if there is not at least one contributing factor per involved party', () => {
            event.involvedParties[0].contributingFactors = [{category: null, reason: null, details: null},];
            event.involvedParties[1].contributingFactors = [];
            event.involvedParties[2] = {
                ...event.involvedParties[1],
                participantId: '3',
                participantSourceId: '003',
                contributingFactors: [{reason: 'a reason'}]
            };

            const result = validateEvent(event);
            expect(result.involvedParties[0].minOneCfError).toBe(true);
            expect(result.involvedParties[1].minOneCfError).toBe(true);
            expect(result.involvedParties[2].minOneCfError).toBe(false);
            expect(result.error).toBe(true);
        });

        it('should have an error if a contributing factor does not have a reason', () => {
            event.involvedParties[0].contributingFactors = [{reason: undefined}, {reason: 'a reason'}];

            const result = validateEvent(event, 1);
            expect(result.involvedParties[0].contributingFactors[0].missingCfReasonError).toBe(true);
            expect(result.involvedParties[0].contributingFactors[1].missingCfReasonError).toBe(false);
            expect(result.involvedParties[1].contributingFactors[0].missingCfReasonError).toBe(false);
            expect(result.error).toBe(true);

        });

        it('should have an error if a contributing factor with a reason that can have details does not have a detail chosen', () => {
            const reasonsWithDetailOptions = [
                'failed-to-obey-traffic-control',
                'proper-lookout',
                'improper-lookout',
                'improper-maneuver',
                'unsafe-speed-for-circumstances',
                'took-evasive-action',
                'driver-compromised',
            ];
            reasonsWithDetailOptions.forEach(reason => {
                event.involvedParties[0].contributingFactors = [{reason: reason, details: undefined},];
                event.involvedParties[1].contributingFactors = [{reason: reason, details: 'detail'},];
                const result = validateEvent(event, 1);
                expect(result.involvedParties[0].contributingFactors[0].missingCfDetailsError).toBe(true);
                expect(result.involvedParties[1].contributingFactors[0].missingCfDetailsError).toBe(false);
                expect(result.error).toBe(true);
            });
        });

        it('should not have an error if a contributing factor with a reason that cannot have details does not have a detail chosen', () => {
            event.involvedParties[0].contributingFactors = [{reason: 'reasonWithoutFurtherDetails'},];
            const result = validateEvent(event, 1);
            expect(result.involvedParties[0].contributingFactors[0].missingCfDetailsError).toBe(false);
            expect(result.error).toBe(false);
        });

        it('should not have a missing detail error if the contributing factor has no reason', () => {
            event.involvedParties[0].contributingFactors = [{reason: undefined}, {reason: 'a reason'}];

            const result = validateEvent(event, 1);
            expect(result.involvedParties[0].contributingFactors[0].missingCfReasonError).toBe(true);
            expect(result.involvedParties[0].contributingFactors[0].missingCfDetailsError).toBe(false);
        });

        it('should have an error if other is selected and the detail is empty', () => {
            const otherReasons = ['additional-factors-other', 'timely-recognition-other', 'evasive-action-other'];
            otherReasons.forEach(reason => {
                event.involvedParties[0].contributingFactors = [{reason: reason, details: ''}];
                const result = validateEvent(event, 1);
                expect(result.involvedParties[0].contributingFactors[0].missingCfDetailsError).toBe(true);
                expect(result.error).toBe(true);
            });
        });
    });
});
