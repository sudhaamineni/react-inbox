jest.unmock('../../src/main/helpers/claimDataHelper');
jest.unmock('../../src/main/constants/detailLossTypeIconConstants');
jest.unmock('../../src/main/constants/loonConstants');

import {
    createId,
    getAssetTypeShortName,
    getDamageOptions,
    getIconLabel,
    getParticipantName,
    getCallTypeLabel,
    getQueryStringValue,
    getSketchTemplateType,
    getVehicleInfo,
    isInsured,
    isReadOnly,
    isReadOnlyUser,
    padClaimNumber
} from '../../src/main/helpers/claimDataHelper';

describe('Given a claimDataHelper', () => {
    describe('padClaimNumber', () => {
        it('should pad with zeros on left side if claimnumber is less than 12 digits', () => {
            let needsPadding = '123456789';
            expect(padClaimNumber(needsPadding)).toEqual('000123456789');
        });

        it('should not pad with zeros on left side if claimnumber is 12 digits', () => {
            let needsNoPadding = '123456789123';
            expect(padClaimNumber(needsNoPadding)).toEqual('123456789123');
        });
    });

    describe('getQueryStringValue', () => {
        const location = {
            search: '?a=b&c=d'
        };

        it('Returns null if location input is null', () => {
            expect(getQueryStringValue(null, 'a')).toEqual(null);
        });

        it('Returns null if location input is empty', () => {
            expect(getQueryStringValue({}, 'a')).toEqual(null);
        });

        it('Returns null if location input contains search as null', () => {
            expect(getQueryStringValue({ search: null }, 'a')).toEqual(null);
        });

        it('Returns null if location input contains search as empty', () => {
            expect(getQueryStringValue({ search: '' }, 'a')).toEqual(null);
        });

        it('Returns null if name input is null', () => {
            expect(getQueryStringValue(location, null)).toEqual(null);
        });

        it('Returns null if name input is empty', () => {
            expect(getQueryStringValue(location, '')).toEqual(null);
        });

        it('Returns null if location does not match name input', () => {
            expect(getQueryStringValue(location, 'e')).toEqual(null);
        });

        it('Returns true if location matches name, value input', () => {
            expect(getQueryStringValue(location, 'a')).toEqual('b');
        });
    });

    describe('getParticipantName', () => {
        it('When organization name is available', () => {
            const participant = {
                organizationName: 'Organization',
                firstName: 'First',
                lastName: 'Last',
                name: 'Organization',
            };
            expect(getParticipantName(participant)).toBe('Organization');
        });

        describe('When organization name is not available', () => {
            it('returns concatenated first and last name when both are available', () => {
                const participant = {
                    firstName: 'First',
                    lastName: 'Last',
                    name: 'First Last',
                };
                expect(getParticipantName(participant)).toBe('First Last');
            });

            it('returns last name when first name is not available', () => {
                const participant = {
                    lastName: 'Last',
                    name: 'Last',
                };
                expect(getParticipantName(participant)).toBe('Last');
            });

            it('returns first name when first name is not available', () => {
                const participant = {
                    firstName: 'First',
                    name: 'First',
                };
                expect(getParticipantName(participant)).toBe('First');
            });

            it('returns UNKNOWN when first name and last name are not available', () => {
                expect(getParticipantName({
                    name: 'UNKNOWN',
                })).toBe('UNKNOWN');
            });
        });
    });

    describe('getVehicleInfo', () => {
        describe('When vehicle year, make and model is available', () => {
            it('should display year make model', () => {
                const participant = {
                    firstName: 'HOWARD',
                    lastName: 'ELLIOTT',
                    organizationName: null,
                    name: 'HOWARD ELLIOTT',
                    asset: {
                        vehicleYear: '2002 ',
                        vehicleMake: 'TOYOTA ',
                        vehicleModel: 'COROLLA ',
                        assetYearMakeModel: '2002 TOYOTA COROLLA',
                    },
                    participantSourceId: 'insuredId',
                    liabilityRangeBeginPercent: 10,
                    liabilityRangeEndPercent: 20,
                    liabilityRangeError: false,
                    role: 'INSURED',
                    contributingFactors: [],
                    isDriver: true,
                    photoAttachments: [],
                    voiceAttachments: []
                };
                expect(getVehicleInfo(participant)).toBe('2002 TOYOTA COROLLA');
            });
        });

        describe('When vehicle year, make and model is not available', () => {
            it('should display UNKNOWN', () => {
                const participant = {
                    firstName: 'HOWARD',
                    lastName: 'ELLIOTT',
                    organizationName: null,
                    name: 'HOWARD ELLIOTT',
                    asset: {
                        vehicleYear: '',
                        vehicleMake: '',
                        vehicleModel: '',
                        assetYearMakeModel: 'UNKNOWN ASSET',
                    },
                    participantSourceId: 'insuredId',
                    liabilityRangeBeginPercent: 10,
                    liabilityRangeEndPercent: 20,
                    liabilityRangeError: false,
                    role: 'INSURED',
                    contributingFactors: [],
                    isDriver: true,
                    photoAttachments: [],
                    voiceAttachments: []
                };
                expect(getVehicleInfo(participant)).toBe('UNKNOWN ASSET');
            });

            describe('When vehicle year, make or model is null or undefined', () => {
                it('should display UNKNOWN ASSET', () => {
                    const participant = {
                        firstName: 'HOWARD',
                        lastName: 'ELLIOTT',
                        organizationName: null,
                        name: 'HOWARD ELLIOTT',
                        asset: {
                            vehicleYear: null,
                            vehicleMake: '',
                            vehicleModel: '',
                            assetYearMakeModel: 'UNKNOWN ASSET',
                        },
                        participantSourceId: 'insuredId',
                        liabilityRangeBeginPercent: 10,
                        liabilityRangeEndPercent: 20,
                        liabilityRangeError: false,
                        role: 'INSURED',
                        contributingFactors: [],
                        isDriver: true,
                        photoAttachments: [],
                        voiceAttachments: []
                    };
                    expect(getVehicleInfo(participant)).toBe('UNKNOWN ASSET');
                });
            });

            it('should display Pedestrian/Bicyclist when the role is PEDESTRIAN/BICYCLIST', () => {
                const participant = {
                    role: 'PEDESTRIAN/BICYCLIST',
                    asset: {
                        vehicleYear: '',
                        vehicleMake: '',
                        vehicleModel: '',
                        assetYearMakeModel: 'UNKNOWN ASSET',
                    },
                };
                expect(getVehicleInfo(participant)).toBe('PEDESTRIAN/BICYCLIST');
            });
        });
    });

    describe('isInsured', () => {
        it('returns true when participant role is insured', () => {
            const participant = {
                role: 'INSURED'
            };
            expect(isInsured(participant)).toBe(true);
        });

        it('returns false when participant role is not insured', () => {
            const participant = {
                role: 'NOT_INSURED'
            };
            expect(isInsured(participant)).toBe(false);
        });
    });

    describe('getIconLabel', () => {
        it('should return INSURED when the role of the participamt is Insured', () => {
            const participant = {
                role: 'INSURED'
            };
            expect(getIconLabel(participant)).toBe('Insured Owner');
        });

        it('should return PEDESTRIAN/BICYCLIST when the role of the participant is PEDESTRIAN/BICYCLIST', () => {
            const participant = {
                role: 'PEDESTRIAN/BICYCLIST'
            };
            expect(getIconLabel(participant)).toBe('Claimant');
        });

        it('should return CLAIMANTOWNER when the role of the participant is not Insured or PEDESTRIAN/BICYCLIST', () => {
            const participant = {
                role: 'CLAIMANT'
            };
            expect(getIconLabel(participant)).toBe('Claimant Owner');
        });
    });

    describe('isReadOnly', () => {
        it('should return true when userRoles only contain role = LOON Read Only User', () => {
            expect(isReadOnly(['LOON Read Only User'], false)).toBe(true);
        });

        it('should return true when userRoles only contain role = LOON Read Only User and claim is locked', () => {
            expect(isReadOnly(['LOON Read Only User'], true)).toBe(true);
        });

        it('should return false when userRoles is undefined', () => {
            expect(isReadOnly(undefined, false)).toBe(false);
        });

        it('should return false when userRoles is empty', () => {
            expect(isReadOnly([], false)).toBe(false);
        });

        it('should return true when userRoles is undefined and locked', () => {
            expect(isReadOnly(undefined, true)).toBe(true);
        });

        it('should return true when userRoles is empty and locked', () => {
            expect(isReadOnly([], true)).toBe(true);
        });

        it('should return false when userRoles contain more than 1 roles', () => {
            expect(isReadOnly(['LOON User', 'LOON Read Only User'], false)).toBe(false);
        });

        it('should return false when userRoles = NOT LOON Read Only User (e.g. LOON User)', () => {
            expect(isReadOnly(['LOON User'], false)).toBe(false);
        });

        it('should return true when userRoles = NOT LOON Read Only User (e.g. LOON User) and claim is locked', () => {
            expect(isReadOnly(['LOON User'], true)).toBe(true);
        });
    });

    describe('isReadOnlyUser', () => {
        it('should return true when userRoles only contain role = LOON Read Only User', () => {
            expect(isReadOnlyUser(['LOON Read Only User'])).toBe(true);
        });

        it('should return false when userRoles is undefined', () => {
            expect(isReadOnlyUser(undefined)).toBe(false);
        });

        it('should return false when userRoles is empty', () => {
            expect(isReadOnlyUser([])).toBe(false);
        });

        it('should return false when userRoles contain more than 1 roles', () => {
            expect(isReadOnlyUser(['LOON User', 'LOON Read Only User'])).toBe(false);
        });

        it('should return false when userRoles = NOT LOON Read Only User (e.g. LOON User)', () => {
            expect(isReadOnlyUser(['LOON User'])).toBe(false);
        });
    });

    describe('getAssetTypeShortName', () => {
        it('should return auto when participant assetType description is Auto', () => {
            expect(getAssetTypeShortName('Auto')).toEqual('auto');
        });

        it('should return truck when participant assetType description is Pick Up Truck', () => {
            expect(getAssetTypeShortName('Pick Up Truck')).toEqual('truck');
        });

        it('should return motorcycle when participant assetType description is Motorcycle', () => {
            expect(getAssetTypeShortName('Motorcycle')).toEqual('motorcycle');
        });

        it('should return motorcycle when participant assetType description is Motorcycle', () => {
            expect(getAssetTypeShortName('Boat')).toEqual('boat');
        });

        it('should return motorcycle when participant assetType description is Motorcycle', () => {
            expect(getAssetTypeShortName('RV')).toEqual('rv');
        });

        it('should return empty string when participant assetType description is UTIL/CAMPER', () => {
            expect(getAssetTypeShortName('UTIL/CAMPER')).toEqual('');
        });

        it('should return empty string when participant assetType description is PICK/CAMPER', () => {
            expect(getAssetTypeShortName('PICK/CAMPER')).toEqual('');
        });
        it('should return empty string when participant assetType description falls under default', () => {
            expect(getAssetTypeShortName('blah')).toEqual('');
        });
    });

    describe('getSketchTemplateType', () => {
        it('should return parkingLot when Detail Loss Type Code is 6(Backing accident - both parties moving)', () => {
            expect(getSketchTemplateType('06')).toEqual('parkingLot');
        });

        it('should return parkingLot when Detail Loss Type Code is 07(Intersection accident)', () => {
            expect(getSketchTemplateType('07')).toEqual('fourWayIntersection');
        });

        it('should return StraightAway when Detail Loss Type Code is 08(Insured drove into standing water)', () => {
            expect(getSketchTemplateType('08')).toEqual('straightAway');
        });

        it('should return StraightAway when Detail Loss Type Code is 09(Changing lanes)', () => {
            expect(getSketchTemplateType('09')).toEqual('straightAway');
        });

        it('should return StraightAway when Detail Loss Type Code is 09(Changing lanes)', () => {
            expect(getSketchTemplateType('09')).toEqual('straightAway');
        });

        it('should return StraightAway when Detail Loss Type Code is 11(Head-on collision)', () => {
            expect(getSketchTemplateType('11')).toEqual('tIntersection');
        });

        it('should return StraightAway when Detail Loss Type Code is 14(Insured hit fixed object)', () => {
            expect(getSketchTemplateType('14')).toEqual('straightAway');
        });

        it('should return StraightAway when Detail Loss Type Code is 15(Insured Hit a Pedestrian/Bicycle)', () => {
            expect(getSketchTemplateType('15')).toEqual('tIntersection');
        });

        it('should return StraightAway when Detail Loss Type Code is 17(Making a turn)', () => {
            expect(getSketchTemplateType('17')).toEqual('tIntersection');
        });

        it('should return StraightAway when Detail Loss Type Code is 19(Parked Vehicle - insured hit parked vehicle.)', () => {
            expect(getSketchTemplateType('19')).toEqual('parkingLot');
        });

        it('should return StraightAway when Detail Loss Type Code is 20(Parked Vehicle - Other Party hit parked Insured)', () => {
            expect(getSketchTemplateType('20')).toEqual('parkingLot');
        });

        it('should return StraightAway when Detail Loss Type Code is 21(Rear-end accident - insured rear-ended other party)', () => {
            expect(getSketchTemplateType('21')).toEqual('fourWayIntersection');
        });

        it('should return StraightAway when Detail Loss Type Code is 22(Rear-end accident - multiple cars)', () => {
            expect(getSketchTemplateType('22')).toEqual('fourWayIntersection');
        });

        it('should return StraightAway when Detail Loss Type Code is 23(Rear-end accident - Other party rear-ended insured)', () => {
            expect(getSketchTemplateType('23')).toEqual('fourWayIntersection');
        });

        it('should return StraightAway when Detail Loss Type Code is 24(Sideswipe accident)', () => {
            expect(getSketchTemplateType('24')).toEqual('straightAway');
        });

        it('should return null when Detail Loss Type Code is not found', () => {
            expect(getSketchTemplateType('999')).toBeNull();
        });
    });

    describe('getDamageOptions', () => {
        it('should get damage options for a truck', () => {
            const assetType = 'Pick Up Truck';
            const options = ['front', 'rear', 'driver'];

            const expectedOptions = [{
                value: 'front',
                label: 'Front',
                checked: true,
            }, {
                value: 'rear',
                label: 'Rear',
                checked: true,
            }, {
                value: 'driver',
                label: 'Driver Side',
                checked: true,
            }, {
                value: 'passenger',
                label: 'Passenger Side',
                checked: false,
            }, {
                value: 'noDamages',
                label: 'No Damages',
                checked: false,
            }];

            expect(getDamageOptions(assetType, options)).toEqual(expectedOptions);
        });

        it('should get damage options for a RV', () => {
            const assetType = 'RV';
            const options = ['front', 'rear', 'driver'];

            const expectedOptions = [{
                value: 'front',
                label: 'Front',
                checked: true,
            }, {
                value: 'rear',
                label: 'Rear',
                checked: true,
            }, {
                value: 'driver',
                label: 'Driver Side',
                checked: true,
            }, {
                value: 'passenger',
                label: 'Passenger Side',
                checked: false,
            }, {
                value: 'noDamages',
                label: 'No Damages',
                checked: false,
            }];

            expect(getDamageOptions(assetType, options)).toEqual(expectedOptions);
        });

        it('should get damage options for a Motorcycle', () => {
            const assetType = 'Motorcycle';
            const options = ['front'];

            const expectedOptions = [{
                value: 'front',
                label: 'Front',
                checked: true,
            }, {
                value: 'rear',
                label: 'Rear',
                checked: false,
            }, {
                value: 'noDamages',
                label: 'No Damages',
                checked: false,
            }];

            expect(getDamageOptions(assetType, options)).toEqual(expectedOptions);
        });

        it('should get damage options for a PICK/CAMPER', () => {
            const assetType = 'PICK/CAMPER';
            const options = ['hasDamage'];

            const expectedOptions = [{
                value: 'hasDamage',
                label: 'Has Damage',
                checked: true,
            }, {
                value: 'noDamages',
                label: 'No Damages',
                checked: false,
            }];

            expect(getDamageOptions(assetType, options)).toEqual(expectedOptions);
        });

        it('should get damage options for a UTIL/CAMPER', () => {
            const assetType = 'UTIL/CAMPER';
            const options = [];

            const expectedOptions = [{
                value: 'hasDamage',
                label: 'Has Damage',
                checked: false,
            }, {
                value: 'noDamages',
                label: 'No Damages',
                checked: false,
            }];

            expect(getDamageOptions(assetType, options)).toEqual(expectedOptions);
        });

        it('should get damage options for a Boat', () => {
            const assetType = 'Boat';
            const options = ['hasDamage'];

            const expectedOptions = [{
                value: 'hasDamage',
                label: 'Has Damage',
                checked: true,
            }, {
                value: 'noDamages',
                label: 'No Damages',
                checked: false,
            }];

            expect(getDamageOptions(assetType, options)).toEqual(expectedOptions);
        });
    });

    describe('getCallTypeLabel', () => {
        it('should return the correct call type label if the call type exists in the map', () => {
            const callType = 'FNOL';
            expect(getCallTypeLabel(callType)).toBe('FNOL');
        });

        it('should return the call type label of Other if the call type does not exist in the map', () => {
            const callType = 'something else';
            expect(getCallTypeLabel(callType)).toBe('Other');
        });
    });

    describe('createId', () => {
        it('should return an id composed of the type and timestamp', () => {
            const now = Number(new Date());
            const result = createId('myType');
            const theNumberPart = Number(result.replace('myType', ''));
            expect(result).toEqual(expect.stringContaining('myType'));
            expect(theNumberPart).not.toBeLessThan(now);
        });
    });
});
