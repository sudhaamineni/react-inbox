jest.unmock('../../src/main/helpers/analyticsHelper');

import AnalyticsHelper from '../../src/main/helpers/analyticsHelper';
const host = "oursite.com";

describe('AnalyticsHelper', () => {
    beforeEach(() => {

        global._satellite = {track: jest.fn()};
        AnalyticsHelper.initialize();
    });

    describe('#initialize', () => {
        it('initializing the digitalData on the window object should have proper properties', () => {
            expect(global.digitalData).toBeTruthy();
            expect(global.digitalData.Page.isitOverlay).toBeFalsy();
            expect(global.digitalData.CtaResponse).toEqual({});
            expect(global.digitalData.Transaction).toEqual({claimNumber: null});
            expect(global._satellite.track).toHaveBeenCalledTimes(0);
        });
    });

    describe('#trackEvent', () => {
        it('digitalData CtaResponse object is updated when _satellite exists', () => {
            const CtaResponse = {
                message: "Success",
                eventAction: "login",
                eventSource: "button",
                errorCode: "",
            };

            const customer = {
                customer: {
                    membershipNumber: "123456789"
                }
            };
            window.digitalData = {
                Page: {
                    server: host,
                    channel: 'claims/loon/',
                    isitOverlay: false
                },
                CtaResponse: CtaResponse
            };
            AnalyticsHelper.trackEvent(CtaResponse, customer);

            expect(global.digitalData).toBeTruthy();
            expect(global.digitalData.Page.pageId).toBeUndefined();
            expect(global.digitalData.Page.server).toBe(host);
            expect(global.digitalData.Page.channel).toBe('claims/loon/');
            expect(global.digitalData.Page.isitOverlay).toBeFalsy();
            expect(global.digitalData.CtaResponse).toEqual(CtaResponse);
            expect(global._satellite.track).toHaveBeenCalledTimes(1);
            expect(global._satellite.track).toHaveBeenCalledWith('wl_continue');
        });

        it('digitalData CtaResponse object is undefined when _satellite is missing and track is not called', () => {
            global._satellite = undefined;

            const CtaResponse = {
                message: "Success",
                eventAction: "login",
                eventSource: "button",
                errorCode: "",
            };
            window.digitalData = {
                Page: {
                    server: host,
                    channel: 'claims/loon/',
                    isitOverlay: false
                },
                CtaResponse: CtaResponse
            };
            const customer = {
                customer: {
                    membershipNumber: "123456789"
                }
            };
            AnalyticsHelper.trackEvent(CtaResponse, customer);

            expect(global.digitalData).toBeTruthy();
            expect(global.digitalData.Page.pageId).toBeUndefined();
            expect(global.digitalData.Page.server).toBe(host);
            expect(global.digitalData.Page.isitOverlay).toBeFalsy();
            expect(global.digitalData.CtaResponse).toEqual(CtaResponse);
            expect(global._satellite).toBeUndefined();
        });
    });

    describe('#trackTransction', () => {
        it('digitalData Transaction object is updated when _satellite exists', () => {
            const Transaction = {
                claimNumber: "123456"
            };

            window.digitalData = {
                Page: {
                    server: host,
                    channel: 'claims/loon/',
                    isitOverlay: false
                },
                CtaResponse: {},
                Transaction: Transaction
            };
            AnalyticsHelper.trackTransaction(Transaction);

            expect(global.digitalData).toBeTruthy();
            expect(global.digitalData.Page.pageId).toBeUndefined();
            expect(global.digitalData.Page.server).toBe(host);
            expect(global.digitalData.Page.channel).toBe('claims/loon/');
            expect(global.digitalData.Page.isitOverlay).toBeFalsy();
            expect(global.digitalData.Transaction).toEqual(Transaction);
            expect(global._satellite.track).toHaveBeenCalledTimes(1);
            expect(global._satellite.track).toHaveBeenCalledWith('wl_continue');
        });

        it('digitalData Transaction object is undefined when _satellite is missing and track is not called', () => {
            global._satellite = undefined;

            const Transaction = {
                claimNumber: "123456"
            };

            window.digitalData = {
                Page: {
                    server: host,
                    channel: 'claims/loon/',
                    isitOverlay: false
                },
                CtaResponse: {},
                Transaction: Transaction
            };
            AnalyticsHelper.trackTransaction(Transaction);

            expect(global.digitalData).toBeTruthy();
            expect(global.digitalData.Page.pageId).toBeUndefined();
            expect(global.digitalData.Page.server).toBe(host);
            expect(global.digitalData.Page.isitOverlay).toBeFalsy();
            expect(global.digitalData.Transaction).toEqual(Transaction);
            expect(global._satellite).toBeUndefined();
        });
    });

    describe('#trackPage', () => {
        it('digitalData page id updated when _satellite exists', () => {
            const pageId = "testPage";
            window.digitalData = {
                Page: {
                    server: host,
                    channel: 'claims/loon/',
                    isitOverlay: false
                },
                CtaResponse: {}
            };
            AnalyticsHelper.trackPage(pageId);

            expect(global.digitalData).toBeTruthy();
            expect(global.digitalData.Page.pageId).toBe(pageId);
            expect(global.digitalData.Page.server).toBe(host);
            expect(global.digitalData.Page.isitOverlay).toBeFalsy();
            expect(global.digitalData.CtaResponse).toEqual({});
            expect(global._satellite.track).toHaveBeenCalledTimes(1);
            expect(global._satellite.track).toHaveBeenCalledWith('warmup');
        });

        it('digitalData page id is undefined when _satellite is non-existent', () => {
            global._satellite = undefined;
            window.digitalData = {
                Page: {
                    server: host,
                },
                CtaResponse: {}
            };
            const pageId = "testPage";
            AnalyticsHelper.trackPage(pageId);

            expect(global.digitalData).toBeTruthy();
            expect(global.digitalData.Page.pageId).toBe(pageId);
            expect(global.digitalData.Page.server).toBe(host);
            expect(global.digitalData.Page.isitOverlay).toBeFalsy();
            expect(global.digitalData.CtaResponse).toEqual({});
            expect(global._satellite).toBeUndefined();
        });
    });

    describe('#clickLink', () => {
        it('track event will be called with default button event and passed in id', () => {

            AnalyticsHelper.clickLink('testbutton');

            expect(global.digitalData).toBeTruthy();
            expect(global.digitalData.CtaResponse.eventAction).toEqual('testbutton');
            expect(global.digitalData.CtaResponse.errorCode).toEqual('');
            expect(global.digitalData.CtaResponse.eventSource).toEqual('button');
            expect(global.digitalData.CtaResponse.message).toEqual('success');
            expect(global._satellite.track).toHaveBeenCalledTimes(1);
            expect(global._satellite.track).toHaveBeenCalledWith('wl_continue');
        });

        it('track event will be called with default button event and will handle undefined id', () => {

            AnalyticsHelper.clickLink();

            expect(global.digitalData).toBeTruthy();
            expect(global.digitalData.CtaResponse.eventAction).toEqual(undefined);
            expect(global.digitalData.CtaResponse.errorCode).toEqual('');
            expect(global.digitalData.CtaResponse.eventSource).toEqual('button');
            expect(global.digitalData.CtaResponse.message).toEqual('success');
            expect(global._satellite.track).toHaveBeenCalledTimes(1);
            expect(global._satellite.track).toHaveBeenCalledWith('wl_continue');
        });
    });
});