jest.unmock('../../src/main/helpers/decisionErrorHelper');

import {allowThreeDigitNumbers} from '../../src/main/helpers/decisionErrorHelper';

describe('Given allowThreeDigitNumbers helper', () => {
    window.getSelection = jest.fn().mockReturnValue({
        toString: jest.fn().mockReturnValue('')
    });

    it('Should allow numbers upto 100 entered through number top of the keyboard', () => {
        const mockEvent = {
            ctrlKey: false,
            metaKey: false,
            keyCode: 48,
            preventDefault: jest.fn(),
            target: {
                value: '99'
            }
        };
        allowThreeDigitNumbers(mockEvent);
        expect(mockEvent.preventDefault).not.toBeCalled();
    });

    it('Should allow numbers upto 100 entered through number keypad', () => {
        const mockEvent = {
            ctrlKey: false,
            metaKey: false,
            keyCode: 96,
            preventDefault: jest.fn(),
            target: {
                value: '99'
            }
        };
        allowThreeDigitNumbers(mockEvent);
        expect(mockEvent.preventDefault).not.toBeCalled();
    });

    it('Should not allow more than 100', () => {
        const mockEvent = {
            ctrlKey: false,
            metaKey: false,
            keyCode: 49,
            preventDefault: jest.fn(),
            target: {
                value: '101'
            }
        };
        allowThreeDigitNumbers(mockEvent);
        expect(mockEvent.preventDefault).toBeCalled();
    });

    it('Should not allow other than numbers and special functions', () => {
        const mockEvent = {
            ctrlKey: false,
            metaKey: true,
            keyCode: 11,
            preventDefault: jest.fn(),
            target: {
                value: '99'
            }
        };
        allowThreeDigitNumbers(mockEvent);
        expect(mockEvent.preventDefault).toBeCalled();
    });

    it('Should allow numbers when selected text is not empty', () => {
        window.getSelection = jest.fn().mockReturnValue({
            toString: jest.fn().mockReturnValue('33')
        });
        const mockEvent = {
            ctrlKey: false,
            metaKey: false,
            keyCode: 48,
            preventDefault: jest.fn(),
            target: {
                value: '101'
            }
        };
        allowThreeDigitNumbers(mockEvent);
        expect(mockEvent.preventDefault).not.toBeCalled();
    });

    it('Should allow numbers when selected text is not empty - IE workaround', () => {
        const mockEvent = {
            ctrlKey: false,
            metaKey: false,
            keyCode: 48,
            preventDefault: jest.fn(),
            target: {
                value: '101',
                selectionStart: 0,
                selectionEnd: 3
            }
        };
        allowThreeDigitNumbers(mockEvent);
        expect(mockEvent.preventDefault).not.toBeCalled();
    });

    it('Should allow ctrl + A', () => {
        const mockEvent = {
            ctrlKey: true,
            metaKey: false,
            keyCode: 65,
            preventDefault: jest.fn(),
            target: {
                value: '99'
            }
        };
        allowThreeDigitNumbers(mockEvent);
        expect(mockEvent.preventDefault).not.toBeCalled();
    });

    it('Should allow cmd + A', () => {
        const mockEvent = {
            ctrlKey: false,
            metaKey: true,
            keyCode: 65,
            preventDefault: jest.fn(),
            target: {
                value: '99'
            }
        };
        allowThreeDigitNumbers(mockEvent);
        expect(mockEvent.preventDefault).not.toBeCalled();
    });

    it('Should allow ctrl + C', () => {
        const mockEvent = {
            ctrlKey: true,
            metaKey: false,
            keyCode: 67,
            preventDefault: jest.fn(),
            target: {
                value: '99'
            }
        };
        allowThreeDigitNumbers(mockEvent);
        expect(mockEvent.preventDefault).not.toBeCalled();
    });

    it('Should allow cmd + C', () => {
        const mockEvent = {
            ctrlKey: false,
            metaKey: true,
            keyCode: 67,
            preventDefault: jest.fn(),
            target: {
                value: '99'
            }
        };
        allowThreeDigitNumbers(mockEvent);
        expect(mockEvent.preventDefault).not.toBeCalled();
    });

    it('Should allow ctrl + C', () => {
        const mockEvent = {
            ctrlKey: true,
            metaKey: false,
            keyCode: 86,
            preventDefault: jest.fn(),
            target: {
                value: '99'
            }
        };
        allowThreeDigitNumbers(mockEvent);
        expect(mockEvent.preventDefault).not.toBeCalled();
    });

    it('Should allow cmd + C', () => {
        const mockEvent = {
            ctrlKey: false,
            metaKey: true,
            keyCode: 86,
            preventDefault: jest.fn(),
            target: {
                value: '99'
            }
        };
        allowThreeDigitNumbers(mockEvent);
        expect(mockEvent.preventDefault).not.toBeCalled();
    });

    it('Should allow backspace key', () => {
        const mockEvent = {
            ctrlKey: false,
            metaKey: true,
            keyCode: 8,
            preventDefault: jest.fn(),
            target: {
                value: '99'
            }
        };
        allowThreeDigitNumbers(mockEvent);
        expect(mockEvent.preventDefault).not.toBeCalled();
    });

    it('Should allow tab key', () => {
        const mockEvent = {
            ctrlKey: false,
            metaKey: true,
            keyCode: 9,
            preventDefault: jest.fn(),
            target: {
                value: '99'
            }
        };
        allowThreeDigitNumbers(mockEvent);
        expect(mockEvent.preventDefault).not.toBeCalled();
    });

    it('Should allow left arrow key', () => {
        const mockEvent = {
            ctrlKey: false,
            metaKey: true,
            keyCode: 37,
            preventDefault: jest.fn(),
            target: {
                value: '99'
            }
        };
        allowThreeDigitNumbers(mockEvent);
        expect(mockEvent.preventDefault).not.toBeCalled();
    });

    it('Should allow right arrow key', () => {
        const mockEvent = {
            ctrlKey: false,
            metaKey: true,
            keyCode: 39,
            preventDefault: jest.fn(),
            target: {
                value: '99'
            }
        };
        allowThreeDigitNumbers(mockEvent);
        expect(mockEvent.preventDefault).not.toBeCalled();
    });

    it('Should allow delete key', () => {
        const mockEvent = {
            ctrlKey: false,
            metaKey: true,
            keyCode: 46,
            preventDefault: jest.fn(),
            target: {
                value: '99'
            }
        };
        allowThreeDigitNumbers(mockEvent);
        expect(mockEvent.preventDefault).not.toBeCalled();
    });

    it('Should not allow numbers with alt key', () => {
        const mockEvent = {
            altKey: true,
            keyCode: 49,
            preventDefault: jest.fn(),
            target: {
                value: '99'
            }
        };
        allowThreeDigitNumbers(mockEvent);
        expect(mockEvent.preventDefault).toBeCalled();
    });

    it('Should not allow numbers with shift alt key', () => {
        const mockEvent = {
            shiftKey: true,
            keyCode: 49,
            preventDefault: jest.fn(),
            target: {
                value: '99'
            }
        };
        allowThreeDigitNumbers(mockEvent);
        expect(mockEvent.preventDefault).toBeCalled();
    });
});
