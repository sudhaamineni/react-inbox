jest.unmock('../../src/main/helpers/dateTimeHelper');
jest.unmock('dateformat');

import dateFormat from 'dateformat';

import {
    convertZuluTimeToLocalTime,
    formatLossDateString,
    formatVoiceDateTimeString,
    getCurrentTime
} from '../../src/main/helpers/dateTimeHelper'

describe('Given dateTimeHelper', () => {
    describe('convertZuluTimeToLocalTime', () => {
        it('converts a date in the form 2018-10-22T14:24:29.392+0000 to local time', () => {
            const result = convertZuluTimeToLocalTime('2018-07-19T20:14:37.421+0000');
            expect(result).toEqual(dateFormat(new Date('2018-07-19T15:14:37.421'), 'ddd, mmm d, yyyy \'at\' h:MMTT Z'));
        });

        it('returns UNKNOWN the passed in date is not a valid date', () => {
            const result = convertZuluTimeToLocalTime('');
            expect(result).toEqual('UNKNOWN');
        });
    });

    describe('formatLossDateString', () => {
        it('takes a loss date and returns with proper formatting', () => {
            const result = formatLossDateString('2018-07-23');
            expect(result).toEqual(dateFormat(new Date('2018-07-23'), 'ddd, mmm d, yyyy'));
        });

        it('returns UNKNOWN when loss date is not a valid date string', () => {
            const result = formatLossDateString('');
            expect(result).toEqual('UNKNOWN');
        });
    });

    describe('formatVoiceDateTimeString', () => {
        it('should convert a date time in format 2019-02-06T16:08:30.802 to Wed, Feb 6, 2019 at 4:08PM CST', () => {
            const result = formatVoiceDateTimeString('2019-02-06T16:08:30.802');
            expect(result).toEqual(dateFormat(new Date('2019-02-06T16:08:30.802'), 'ddd, mmm d, yyyy \'at\' h:MMTT'));
        });

        it('should return UNKNOWN when input is not a valid date', () => {
            const result = formatVoiceDateTimeString('')
            expect(result).toEqual('UNKNOWN')
        });
    });

    describe('getCurrentTime', () => {
        expect(getCurrentTime()).not.toBe(undefined);
    });
});