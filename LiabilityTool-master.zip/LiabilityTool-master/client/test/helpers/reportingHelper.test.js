jest.unmock('../../src/main/helpers/reportingHelper');
import {exportToCsv} from '../../src/main/helpers/reportingHelper';

describe('Reporting helper', () => {

    it('should return exportToCsv', () => {
        const rows = [
            ["Claim Number", "Submitted Time", "Loss Type", "Empty Col", "Date Col"],
            [["123", ',2019-01-24T15:33:53.771+0000', "werwer", "", new Date()]]];
        URL.createObjectURL = jest.fn();
        URL.createObjectURL.mockReturnValueOnce("blob:http://localhost:3000/345f3188-e069-4976-8902-256ecea9b3bd").mockReturnValue("test");
        document.createElement = jest.fn().mockReturnValue({
            'href': 'blob:http://localhost:3000/345f3188-e069-4976-8902-256ecea9b3bd',
            'download': 'submitted-claims',
            'style': 'visibility:hidden'
        });
        document.createElement('a').setAttribute = jest.fn();
        document.createElement('a').click = jest.fn();
        document.createElement('a').removeChild = jest.fn();
        document.body.appendChild = jest.fn();
        document.body.removeChild = jest.fn();
        exportToCsv('submit', rows);

        expect(document.createElement('a').setAttribute).toHaveBeenCalledWith('href', 'blob:http://localhost:3000/345f3188-e069-4976-8902-256ecea9b3bd');
        expect(document.createElement('a').setAttribute).toHaveBeenCalledWith('download', 'submit');
    });
});
