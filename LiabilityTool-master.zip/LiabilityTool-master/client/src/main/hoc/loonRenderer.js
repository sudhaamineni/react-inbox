import {connect} from 'react-redux';
import React, {Component} from 'react';
import NavigationHeader from '../components/common/NavigationHeader';
import ErrorPage from '../components/common/ErrorPage';
import {LOON_WIP_CLAIM_NUMBER} from '../constants/loonConstants';
import {getClaimDataAction} from '../actions/claimDataActions';
import LossDetailsHeader from '../components/common/LossDetailsHeader';

export const LoonRenderer = WrappedComponent => {
    const renderLoonComponent = (props) => {
        // eslint-disable-next-line react/prop-types
        const {userRoles, claimNumber, errorHeader, match, history, getClaimDataAction} = props;
        const isHomePage = match.path === '/';
        const isRptPage = match.path === '/rpt';
        const hasError = errorHeader !== '';

        if (userRoles === undefined) {
            return hasError ? <ErrorPage/> : null;
        } else if (userRoles.length === 0) {
            return <ErrorPage/>;
        } else if (isRptPage) {
            return <WrappedComponent/>;
        } else if (!isHomePage && !claimNumber) {
            const loonWipClaimNumber = window.sessionStorage.getItem(LOON_WIP_CLAIM_NUMBER);
            if (loonWipClaimNumber) {
                getClaimDataAction(loonWipClaimNumber);
                return null;
            } else {
                history.push('/');
                return null;
            }
        } else if (!isHomePage && hasError) {
            return <ErrorPage/>;
        }
        return <WrappedComponent/>;
    };

    return (
        connect(mapStateToProps, mapDispatchToProps)(
            class extends Component {
                render() {
                    // eslint-disable-next-line react/prop-types
                    const {errorHeader, match, claimNumber} = this.props;
                    const isHomePage = match.path === '/';
                    const hasError = errorHeader !== '';
                    const isRptPage = match.path === '/rpt';
                    const isInitialFault = match.path === '/initial-fault';
                    return (
                        <div
                            className={`l-shell l-shell--masthead ${isInitialFault ? 'l-shell--1024-overflow' : 'l-shell--1024'} ${hasError ? 'l-shell--status-bar' : ''}`}>
                            <NavigationHeader showTabs={!isHomePage && !hasError && !isRptPage}/>
                            {!isHomePage && !hasError && !isRptPage && claimNumber && <LossDetailsHeader/>}
                            {renderLoonComponent(this.props)}
                        </div>
                    );
                }
            }
        )
    );
};

export const mapStateToProps = ({user, claimData, status}, {history, match}) => {
    return {
        userRoles: user.userRoles,
        claimNumber: claimData.claimNumber,
        locked: claimData.locked,
        initialFaultSubmitTime: claimData.initialFaultSubmitTime,
        errorHeader: status.errorHeader,
        match,
        history
    };
};

export const mapDispatchToProps = {
    getClaimDataAction,
};
