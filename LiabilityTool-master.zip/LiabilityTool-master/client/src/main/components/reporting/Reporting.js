import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { DataTable, DatePicker, Loader } from 'loon-pattern-library';
import {
    clearReportDataAction,
    getClaimsByCreatedTimeAction,
    getInitialFaultPendingClaimsAction,
    getClaimsByInitialFaultSubmittedAction,
    getReSubmittedClaimsAction,
} from '../../actions/reportingActions';
import moment from 'moment';
import { connect } from 'react-redux';
import { exportToCsv } from '../../helpers/reportingHelper';

export class Reporting extends Component {
    constructor(props) {
        super(props);
        this.state = {
            category: '',
            beginDate: { value: '', hasError: false, errorMessage: '' },
            endDate: { value: '', hasError: false, errorMessage: '' },
        };

        this.errorMessages = {
            futureDate: 'Cannot enter future date. Please enter current or past date',
            invalidDate: 'Invalid date',
            dateOrderMixup: 'End date must be after begin date'
        };
    }

    componentDidMount() {
        document.title = 'Loon - Report';
    }

    onRun = () => {
        if (this.state.category === 'total-claims-initial-fault-pending') {
            this.props.getInitialFaultPendingClaimsAction();
        } else {
        const dates = this.validateDate();
        if (!dates) {
            return;
        }
        const {beginDate, endDate} = dates;
        switch (this.state.category) {
            case 'resubmitted-claims':
                this.props.getReSubmittedClaimsAction(beginDate, endDate);
                break;
            case 'total-claims-searched':
                this.props.getClaimsByCreatedTimeAction(beginDate , endDate);
                break;
            case 'total-claims-initial-fault-submitted':
                this.props.getClaimsByInitialFaultSubmittedAction(dates.beginDate, dates.endDate);
                break;
            default:
                break;
        }
        }

        this.setState({
            beginDate: {
                value: this.state.beginDate.value,
                hasError: false,
                errorMessage: ''
            },
            endDate: {
                value: this.state.endDate.value,
                hasError: false,
                errorMessage: ''
            }
        });
    };

    categoryChange = (e) => {
        this.props.clearReportDataAction();
        this.setState({ category: e.target.value });
    };

    validateDate = () => {
        const beginDate = moment(this.state.beginDate.value, 'MM/DD/YYYY').format('YYYYMMDD');
        const endDate = moment(this.state.endDate.value, 'MM/DD/YYYY').format('YYYYMMDD');
        if (beginDate === 'Invalid date') {
            this.setState({
                beginDate: {
                    value: this.state.beginDate.value,
                    hasError: true,
                    errorMessage: this.errorMessages.invalidDate
                }
            });
            return null;
        }
        if (endDate === 'Invalid date') {
            this.setState({
                endDate: {
                    value: this.state.endDate.value,
                    hasError: true,
                    errorMessage: this.errorMessages.invalidDate
                }
            });
            return null;
        }
        if (this.isDateInFuture(this.state.beginDate.value)) {
            this.setState({
                beginDate: {
                    value: this.state.beginDate.value,
                    hasError: true,
                    errorMessage: this.errorMessages.futureDate
                }
            });
            return null;
        }
        if (this.isDateInFuture(this.state.endDate.value)) {
            this.setState({
                endDate: {
                    value: this.state.endDate.value,
                    hasError: true,
                    errorMessage: this.errorMessages.futureDate
                }
            });
            return null;
        }
        if (beginDate > endDate) {
            this.setState({
                endDate: {
                    value: this.state.endDate.value,
                    hasError: true,
                    errorMessage: this.errorMessages.dateOrderMixup
                },
                beginDate: {
                    value: this.state.beginDate.value,
                    hasError: true,
                    errorMessage: this.errorMessages.dateOrderMixup
                }
            });
            return null;
        }
        return { beginDate, endDate };
    };

    isDateInFuture = date => moment(date, 'MM/DD/YYYY') > new Date();

    getSubmittedClaimsHeader = () => {
        return [
            { key: 'claimNumber', label: 'Claim Number' },
            { key: 'initialFaultSubmitTime', label: 'Submitted Time' },
            { key: 'lossDetailType', label: 'Detail Loss Type' },
            { key: 'lossState', label: 'Loss State' },
            { key: 'participantSize', label: 'Number of Assets' },
            { key: 'fnolToSubmittedMins', label: 'FNOL to Submitted (Min)' },
            { key: 'searchToSubmittedMins', label: 'Search to Submitted (Min)' },
        ];
    };

    getClaimsByCreatedTimeHeader = () => {
        return [
            { key: 'count', label: 'Id' },
            { key: 'claimNumber', label: 'Claim Number' },
            { key: 'createdByUserId', label: 'User (NTID) Created By' },
            { key: 'lastModifiedByUserId', label: 'User (NTID) Last Modified By' },
            { key: 'lossDetailType', label: 'Detail Loss Type' },
            { key: 'lossState', label: 'Loss State' },
            { key: 'comparativeNegligenceRule', label: 'Comp Neg. Rule' },
            { key: 'participantSize', label: '# Participant(s) Involved' },
            { key: 'createdTimeInCSTStringFormat', label: 'Initial Claim Search in Loon Time' },
            { key: 'initialFaultSubmitTimeInCSTStringFormat', label: 'Initial Fault Submitted Time' },
            { key: 'settlementSubmitTimeInCSTStringFormat', label: 'Settlement Submitted Time' },
        ];
    };

    getClaimsByInitialFaultSubmitted = () => {
        return [
            {key: 'count', label: 'Id'},
            {key: 'claimNumber', label: 'Claim Number'},
            {key: 'createdByUserId', label: 'User (NTID) Created By'},
            {key: 'lastModifiedByUserId', label: 'User (NTID) Last Modified By'},
            {key: 'lossDetailType', label: 'Detail Loss Type'},
            {key: 'lossState', label: 'Loss State'},
            {key: 'comparativeNegligenceRule', label: 'Comp Neg. Rule'},
            {key: 'participantSize', label: '# Participant(s) Involved'},
            {key: 'initialFaultSubmitTimeInCSTStringFormat', label: 'Initial Fault Submitted Time'},
        ];
    };
    getInitialFaultPendingHeader = () => {
        return [
            { key: 'count', label: 'Id' },
            { key: 'claimNumber', label: 'Claim Number' },
            { key: 'createdByUserId', label: 'User (NTID) Created By' },
            { key: 'lastModifiedByUserId', label: 'User (NTID) Last Modified By' },
            { key: 'lossDetailType', label: 'Detail Loss Type' },
            { key: 'lossState', label: 'Loss State' },
            { key: 'comparativeNegligenceRule', label: 'Comp Neg. Rule' },
        ];
    };

    getResubmittedClaimsHeader = () => {
        return [
            { key: 'claimNumber', label: 'Claim Number' },
            { key: 'count', label: 'Number of resubmits with in the given date range' },
        ];
    };

    getHeader = () => {
        switch (this.state.category) {
            case 'submitted-claims':
                return this.getSubmittedClaimsHeader();
            case 'resubmitted-claims':
                return this.getResubmittedClaimsHeader();
            case 'total-claims-searched':
                return this.getClaimsByCreatedTimeHeader();
            case 'total-claims-initial-fault-pending':
                return this.getInitialFaultPendingHeader();
            case 'total-claims-initial-fault-submitted':
                return this.getClaimsByInitialFaultSubmitted();
            default:
                return [];
        }
    };

    getReportingClaimsData = () => {
        return {
            columns: this.getHeader(),
            rows: this.props.reporting.claims
        };
    };

    renderResult = () => {
        if (this.props.reporting.loading) {
            return <Loader className="c-loader--lg u-vr-top" />;
        } else {
            switch (this.state.category) {
                case'resubmitted-claims':
                    return (
                        this.props.reporting.claims && <div id="result-container" className="u-vr-top">
                            <div><b>Number of Resubmitted claims: </b>{this.props.reporting.claims.length}</div>
                            <DataTable id="resubmit-datatable" data={this.getReportingClaimsData()}
                                       sortable={true} />
                        </div>
                    );

                case'total-claims-searched':
                    return (
                        this.props.reporting.claims && <div id="result-total-claims-searched" className="u-vr-top">
                            <b>Total Claim Searched: </b>
                            <DataTable id="total-claims-datatable" data={this.getReportingClaimsData()}
                                       sortable={true} />
                        </div>
                    );
                case 'total-claims-initial-fault-pending':
                    return (
                        this.props.reporting.claims &&
                        <div id="result-initial-fault-pending-claims" className="u-vr-top">
                            <b>Total Claim Initial Fault Pending: </b>
                            <DataTable id="initial-fault-pending-datatable" data={this.getReportingClaimsData()}
                                       sortable={true} />
                        </div>
                    );

                case 'total-claims-initial-fault-submitted':
                    return (
                        this.props.reporting.claims && <div id="result-total-claims-initial-fault-submitted" className="u-vr-top">
                            <b>Total Claim Initial Fault Submitted: </b>
                            <DataTable id="total-claims-initial-fault-submitted-datatable" data={this.getReportingClaimsData()} sortable={true}/>
                        </div>
                    );
                default:
                    return (
                        <div id="result-container" className="u-vr-top" />
                    );
            }
        }
    };

    downloadCsv = () => {
        const rows = [];
        rows.push(this.getHeader().map(h => h.label));
        rows.push(this.props.reporting.claims.map(r => this.getHeader().map(h => r[h.key])));
        exportToCsv(this.state.category, rows);
    };

    render() {
        const { beginDate, endDate, category } = this.state;
        const csvDisabled = this.props.reporting.claims.length > 0;
        return (
            <div id="reporting-container" className="u-vr-8-top u-hr-4-left">
                {(beginDate.hasError || endDate.hasError) &&
                <div id="error-div" style={{ color: 'red' }}>
                    {beginDate.errorMessage || endDate.errorMessage}
                </div>}
                <div className="u-flex u-flex--middle u-vr-top">
                    <select id="category-selection" onChange={(evt) => this.categoryChange(evt)}>
                        <option value="">select</option>
                        <option value="resubmitted-claims">Total Number of Re-Submitted Claims</option>
                        <option value="total-claims-searched">Total Claim Searched</option>
                        <option value="total-claims-initial-fault-pending">Total Claim Initial Fault Pending</option>
                        <option value="total-claims-initial-fault-submitted">Total Claim Initial Fault Submitted</option>
                    </select>
                    {category !== 'total-claims-initial-fault-pending' &&
                    <div className="u-flex u-flex--middle">
                        <div id="between-text" className="u-hr-left u-hr">between</div>
                        <DatePicker
                            id="begin-date"
                            value={this.state.beginDate.value}
                            range={[new Date('01/01/2019'), new Date()]}
                            onDateChange={date => this.setState({
                                beginDate: {
                                    value: date.value,
                                    hasError: false,
                                    errorMessage: ''
                                }
                            })}
                            onSubmit={date => this.setState({
                                beginDate: {
                                    value: date.value,
                                    hasError: false,
                                    errorMessage: ''
                                }
                            })}
                            hasError={this.state.beginDate.hasError}
                        />
                        <div id="and-text" className="u-hr-left u-hr">and</div>
                        <DatePicker
                            id="end-date"
                            value={this.state.endDate.value}
                            range={[new Date('01/01/2019'), new Date()]}
                            onDateChange={date => this.setState({
                                endDate: {
                                    value: date.value,
                                    hasError: false,
                                    errorMessage: ''
                                }
                            })}
                            onSubmit={date => this.setState({
                                endDate: {
                                    value: date.value,
                                    hasError: false,
                                    errorMessage: ''
                                }
                            })}
                            hasError={this.state.endDate.hasError}
                        />
                    </div>}
                    <button id="run-button" className="c-btn c-btn--primary u-hr-left" onClick={this.onRun}>Run
                    </button>
                    <button id="csv-button" className="c-btn c-btn--primary u-hr-left"
                            disabled={!csvDisabled}
                            onClick={this.downloadCsv}>Download CSV
                    </button>
                </div>
                {this.renderResult()}
            </div>
        );
    }
}

export const mapStateToProps = ({ reporting }) => {
    return {
        reporting
    };
};

export const mapDispatchToProps = {
    getReSubmittedClaimsAction,
    clearReportDataAction,
    getInitialFaultPendingClaimsAction,
    getClaimsByCreatedTimeAction,
    getClaimsByInitialFaultSubmittedAction,
};

export default connect(mapStateToProps, mapDispatchToProps)(Reporting);

Reporting.propTypes = {
    reporting: PropTypes.object.isRequired,
    getReSubmittedClaimsAction: PropTypes.func.isRequired,
    clearReportDataAction: PropTypes.func.isRequired,
    getInitialFaultPendingClaimsAction: PropTypes.func.isRequired,
    getClaimsByCreatedTimeAction: PropTypes.func.isRequired,
    getClaimsByInitialFaultSubmittedAction: PropTypes.func.isRequired
};
