import React from 'react';
import _ from 'lodash';
import {CustomDropdown, FormField, Icon, MegaMenu} from 'loon-pattern-library';
import {MEGA_MENU_ITEMS, OTHER_REASONS_SET, REASON_TO_DETAILS_MAP} from '../../constants/contributingFactorConstants';
import PropTypes from 'prop-types';
import {getCFCategory, getCFLabel} from '../../helpers/contributingFactorHelper';
import {revalidateEvent} from '../../helpers/eventValidationHelper';
import {setEventsValidationAction, updateEventAction} from '../../actions/eventActions';
import {connect} from 'react-redux';
import SupportingEvidenceModal from '../liability/SupportingEvidenceModal';
import {createId} from '../../helpers/claimDataHelper';
import analyticsHelper from '../../helpers/analyticsHelper';

export class ContributingFactor extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            showSupportingEvidenceModal: false,
        };
    }

    renderSubDetailSection = () => {
        const {readOnly, contributingFactor, cfIndex, eventsValidation, eventIndex, involvedPartyIndex} = this.props;
        const hasMissingDetailsError = _.get(eventsValidation,
            `[${eventIndex}].involvedParties[${involvedPartyIndex}].contributingFactors[${cfIndex}].missingCfDetailsError`,
            false);

        if (REASON_TO_DETAILS_MAP[contributingFactor.reason]) {
            return (
                <CustomDropdown
                    id={`contributing-factor-qualifier-${cfIndex}`}
                    hasError={hasMissingDetailsError}
                    className="contributing-factor-qualifier"
                    items={REASON_TO_DETAILS_MAP[contributingFactor.reason]}
                    placeHolder="Select"
                    readonly={readOnly}
                    initialSelectedItem={{
                        value: contributingFactor.details,
                        label: (contributingFactor.details && REASON_TO_DETAILS_MAP[contributingFactor.reason].find(q => q.value === contributingFactor.details).label)
                    }}
                    onSelect={(option) => this.handleQualifierChange(option.value, cfIndex)}
                />
            );
        } else if (OTHER_REASONS_SET.has(contributingFactor.reason)) {
            return (
                <FormField className="c-form-field__sm c-form-field__sm--fixed"
                           id={`comments-field-${cfIndex}`}
                           maxLength={50}
                           value={contributingFactor.details}
                           onBlur={e => this.saveComments(e.target.value)}
                           autoFocus
                           hasError={hasMissingDetailsError}
                           disabled={readOnly}
                           autoComplete={false}
                />
            );
        } else if (!_.isEmpty(contributingFactor)) {
            return this.renderAddEvidenceSection();
        }
        return null;
    };

    handleAddEvidenceClick = () => {
        analyticsHelper.trackEvent({
            message: 'success',
            eventAction: 'LiabilityPage_AddEvidence_LinkClicked',
            eventSource: 'link',
            errorCode: '',
        });
        this.setState({showSupportingEvidenceModal: true});
    };

    renderAddEvidenceSection = () => {
        const {cfIndex, contributingFactor, eventsValidation, eventIndex, involvedPartyIndex} = this.props;
        const supportingEvidenceCfError = _.get(eventsValidation,
            `[${eventIndex}].involvedParties[${involvedPartyIndex}].contributingFactors[${cfIndex}].missingSupportingEvidenceError`,
            false);
        const supportingEvidencesCount = (contributingFactor.evidenceIds && contributingFactor.evidenceIds.length) || 0;
        const evidenceText = supportingEvidencesCount === 0 ? 'Add Evidence' : `Evidence Added (${supportingEvidencesCount})`;
        return (
            <button
                id={`cf-add-evidence-link-${cfIndex}`}
                className={`align-items-center c-btn c-btn--icon c-btn--evidence ${supportingEvidenceCfError && 'error-link'}`}
                onClick={this.handleAddEvidenceClick}
            >
                <Icon id={`add-evidence-icon-${cfIndex}`} icon="plus" size={0.875}
                      color={supportingEvidenceCfError ? 'magenta' : 'action'}/>
                <Icon className="c-btn--evidence-star" icon="star" color="bookmark" size={0.8125}/>
                <span id={`cf-evidence-text-${cfIndex}`} className="u-text-semibold u-hr-left">{evidenceText}</span>
            </button>
        );
    };

    handleMegaMenuSelect = (option) => {
        const {event, involvedParty, involvedPartyIndex, updateEventAction, claimNumber, cfIndex,
            setEventsValidationAction, eventIndex, eventsValidation, evidences, validateContributingFactorEvidence} = this.props;
        const updatedInvolvedParty = _.cloneDeep(involvedParty);
        const updatedEvent = _.cloneDeep(event);
        let updatedFactor = updatedInvolvedParty.contributingFactors[cfIndex];
        const category = MEGA_MENU_ITEMS.find(item => item.options.find(o => o.value === option.value)).value;

        if (updatedFactor.reason !== option.value) {
            updatedFactor.id = createId('cf');
            updatedFactor.category = category;
            updatedFactor.reason = option.value;
            updatedFactor.details = null;
            updatedEvent.involvedParties[involvedPartyIndex] = updatedInvolvedParty;
            updatedFactor.evidenceIds = [];
            revalidateEvent(updatedEvent, setEventsValidationAction, eventIndex, eventsValidation, evidences, validateContributingFactorEvidence);
            updateEventAction(claimNumber, updatedEvent);
        }
    };

    handleContributingFactorRemoveClick = () => {
        const {event, involvedParty, involvedPartyIndex, updateEventAction, claimNumber, cfIndex,
            setEventsValidationAction, eventIndex, eventsValidation, evidences, validateContributingFactorEvidence} = this.props;
        const updatedInvolvedParty = _.cloneDeep(involvedParty);
        const updatedEvent = _.cloneDeep(event);
        updatedInvolvedParty.contributingFactors.splice(cfIndex, 1);

        updatedEvent.involvedParties[involvedPartyIndex] = updatedInvolvedParty;
        revalidateEvent(updatedEvent, setEventsValidationAction, eventIndex, eventsValidation, evidences, validateContributingFactorEvidence);
        updateEventAction(claimNumber, updatedEvent);
    };

    saveComments = (comments) => {
        const {event, involvedParty, involvedPartyIndex, updateEventAction, claimNumber, cfIndex,
            setEventsValidationAction, eventIndex, eventsValidation, evidences, validateContributingFactorEvidence} = this.props;
        const updatedInvolvedParty = _.cloneDeep(involvedParty);
        const updatedEvent = _.cloneDeep(event);
        updatedInvolvedParty.contributingFactors[cfIndex].details = comments;
        updatedEvent.involvedParties[involvedPartyIndex] = updatedInvolvedParty;

        revalidateEvent(updatedEvent, setEventsValidationAction, eventIndex, eventsValidation, evidences, validateContributingFactorEvidence);

        updateEventAction(claimNumber, updatedEvent);
    };

    handleQualifierChange = (value) => {
        const {event, involvedParty, involvedPartyIndex, updateEventAction, claimNumber, cfIndex,
            setEventsValidationAction, eventIndex, eventsValidation, evidences, validateContributingFactorEvidence} = this.props;
        const updatedInvolvedParty = _.cloneDeep(involvedParty);
        const clonedEvent = _.cloneDeep(event);
        updatedInvolvedParty.contributingFactors[cfIndex].details = value;
        clonedEvent.involvedParties[involvedPartyIndex] = updatedInvolvedParty;

        revalidateEvent(clonedEvent, setEventsValidationAction, eventIndex, eventsValidation, evidences, validateContributingFactorEvidence);
        updateEventAction(claimNumber, clonedEvent);
    };

    onCloseSupportingEvidenceModal = () => {
        this.setState({showSupportingEvidenceModal: false});
    };

    render() {
        const {readOnly, cfIndex, contributingFactor, involvedParty, involvedPartyIndex, event, eventsValidation, eventIndex} = this.props;
        const {showSupportingEvidenceModal} = this.state;
        const hasMissingCfReasonError = _.get(eventsValidation,
            `[${eventIndex}].involvedParties[${involvedPartyIndex}].contributingFactors[${cfIndex}].missingCfReasonError`,
            false);

        return (
            <div key={cfIndex} className="u-flex u-flex--middle u-vr-top padding-bottom-12">
                <div id={`cf-column1-${cfIndex}`} className="u-flex u-flex--middle">
                    <Icon id={`contributing-factor-icon-x-${cfIndex}`}
                          className={`factor-x-icon u-hr ${readOnly ? 'cursor-not-allowed' : 'pointer'}`}
                          icon="cross"
                          color="button"
                          size={0.6}
                          disabled={readOnly}
                          onClick={() => !readOnly && this.handleContributingFactorRemoveClick()}
                    />
                    <MegaMenu
                        key={contributingFactor.reason}
                        placeHolder="Select..."
                        items={MEGA_MENU_ITEMS}
                        isDefaultOpen={contributingFactor.reason === undefined}
                        onSelect={(option) => this.handleMegaMenuSelect(option)}
                        readonly={readOnly}
                        initialSelectedItem={{
                            value: contributingFactor.reason,
                            label: getCFLabel(contributingFactor.reason)
                        }}
                        hasError={hasMissingCfReasonError}
                        initialSelectedIcon={getCFCategory(contributingFactor.reason)}
                    />
                </div>
                <div id={`cf-column2-${cfIndex}`}>
                    {this.renderSubDetailSection()}
                </div>
                <div id={`cf-column3-${cfIndex}`} className="u-hr-left">
                    {(contributingFactor.details
                        && (REASON_TO_DETAILS_MAP[contributingFactor.reason]
                            || OTHER_REASONS_SET.has(contributingFactor.reason))
                    )
                    && this.renderAddEvidenceSection()}
                </div>
                {showSupportingEvidenceModal &&
                <SupportingEvidenceModal
                    isActive={true}
                    onClose={this.onCloseSupportingEvidenceModal}
                    cfIndex={cfIndex}
                    involvedParty={involvedParty}
                    involvedPartyIndex={involvedPartyIndex}
                    event={event}
                    eventIndex={eventIndex}
                    eventsValidation={eventsValidation}
                />}
            </div>
        );
    }
}

export const mapDispatchToProps = {
    updateEventAction,
    setEventsValidationAction,
};

export const mapStateToProps = ({claimData, featureSwitches}) => {
    return {
        evidences: claimData.evidences,
        validateContributingFactorEvidence: featureSwitches.validateContributingFactorEvidence,
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(ContributingFactor);

ContributingFactor.propTypes = {
    readOnly: PropTypes.bool.isRequired,
    cfIndex: PropTypes.number.isRequired,
    contributingFactor: PropTypes.object.isRequired,
    validateContributingFactorEvidence: PropTypes.bool.isRequired,
    event: PropTypes.object.isRequired,
    eventIndex: PropTypes.number.isRequired,
    involvedParty: PropTypes.object.isRequired,
    involvedPartyIndex: PropTypes.number.isRequired,
    claimNumber: PropTypes.string.isRequired,
    updateEventAction: PropTypes.func.isRequired,
    eventsValidation: PropTypes.array.isRequired,
    setEventsValidationAction: PropTypes.func.isRequired,
    evidences: PropTypes.array.isRequired
};
