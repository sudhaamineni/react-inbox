import {Alert} from 'loon-pattern-library';
import React from 'react';
import PropTypes from 'prop-types';

export const ErrorBanner = ({error, children}) => (
    <Alert type={error ? 'error' : 'info'}
           className={`u-text-gray-dark u-text-xs ${!error && 'info-height'}  ${error && 'error-border'}`}>
        {children}
    </Alert>
);

export default ErrorBanner;

ErrorBanner.propTypes = {
    error: PropTypes.bool.isRequired,
    children: PropTypes.array.isRequired,
};
