import React, {Component} from 'react';
import {CustomDropdown, FormField, ModalDialog} from 'loon-pattern-library';
import PropTypes from 'prop-types';
import {connect} from 'react-redux';
import {saveClaimUnlockAction} from '../../actions/claimDataActions';

export class UnlockClaimModal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            dropdownValue: 'select',
            dropdownError: false,
            textareaValue: '',
            textareaError: false
        };
    }

    handleSaveClick = () => {
        const {claimNumber, saveClaimUnlockAction, toggleShowUnlockClaimModal} = this.props;
        const {dropdownValue, textareaValue} = this.state;
        if (dropdownValue === 'select') {
            this.setState({dropdownError: true});
        } else if (dropdownValue === 'other' && textareaValue === '') {
            this.setState({textareaError: true});
        } else {
            saveClaimUnlockAction(claimNumber, dropdownValue, textareaValue);
            toggleShowUnlockClaimModal();

        }
    };

    handleDropdownSelect = item => {
        if (item.value === 'other') {
            this.setState({dropdownValue: item.value, dropdownError: false});
        } else {
            this.setState({dropdownValue: item.value, dropdownError: false, textareaError: false});
        }
    };

    render = () => {
        const {isActive} = this.props;
        const {dropdownError, dropdownValue, textareaError, textareaValue} = this.state;
        const optionsToUnlock = [
            {label: 'Received additional loss information', value: 'info'},
            {label: 'Correction/Error', value: 'error'},
            {label: 'Other', value: 'other'},
        ];

        return (
            <ModalDialog
                id="unlock-modal"
                title={<span className="u-text-loon-title">Unlock Claim</span>}
                hideTrigger
                isActive={isActive}
                footer={
                    <ul className="l-h-list">
                        <li>
                            <button className="c-btn c-btn--primary c-btn--sm"
                                    onClick={this.handleSaveClick}
                            >
                                Unlock
                            </button>
                        </li>
                    </ul>
                }
            >
                <div className="u-vr-2 u-text-md loon-color-gray-404040 u-text-normal">
                    Please provide your reason for unlocking this claim.
                </div>
                <CustomDropdown
                    placeHolder="Select Reason..."
                    items={optionsToUnlock}
                    hasError={dropdownError}
                    errorText="Please choose a reason"
                    initialSelectedItem={{value: dropdownValue}}
                    onSelect={this.handleDropdownSelect}
                />
                {dropdownValue === 'other' &&
                <div>
                    <div className="u-vr-3-top u-vr-2 u-text-md loon-color-gray-404040 u-text-normal">
                        If other, please provide an explanation.
                    </div>
                    <FormField
                        type="textarea"
                        placeholder="Please provide an explanation"
                        rows={4}
                        maxLength={160}
                        hasError={textareaError}
                        errorText="Please provide an explanation"
                        value={textareaValue}
                        onBlur={e => this.setState({textareaValue: e.target.value})}
                        autoComplete={false}
                    />
                </div>
                }
            </ModalDialog>
        );
    };
}

export const mapDispatchToProps = {
    saveClaimUnlockAction
};

export const mapStateToProps = ({claimData}) => {
    return {
        claimNumber: claimData.claimNumber
    };
};
export default connect(mapStateToProps, mapDispatchToProps)(UnlockClaimModal);

UnlockClaimModal.propTypes = {
    claimNumber: PropTypes.string.isRequired,
    isActive: PropTypes.bool.isRequired,
    toggleShowUnlockClaimModal: PropTypes.func.isRequired,
    saveClaimUnlockAction: PropTypes.func.isRequired
};
