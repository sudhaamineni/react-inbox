import React from 'react';
import PropTypes from 'prop-types';
import {Icon} from 'loon-pattern-library';
import EvidenceModalPhotoSection from './EvidenceModalPhotoSection';
import EvidenceModalHighlightSection from './EvidenceModalHighlightSection';
import {EVIDENCE_LABEL_MAP} from '../../constants/loonConstants';

const EvidenceModalSection = ({category, evidences, readOnly}) => {
    const number = evidences.length;
    const isUntagged = category === 'untagged';
    const highlights = evidences.filter(evidence => evidence.type === 'highlight');
    const photoEvidences = evidences.filter(evidence => evidence.type === 'photo');
    return (
        <div className={`evidence-modal-section ${isUntagged ? 'background-very-light-gray' : ''}`}>
            <div className="u-h4 u-text-loon-title u-flex u-flex--middle">
                <Icon className="u-hr" icon="tag" color={isUntagged ? 'magenta' : 'loon-gray-light'} size={1.0}/>
                <div id="category-section__header__text">{EVIDENCE_LABEL_MAP[category]} ({number})</div>
            </div>
            {isUntagged &&
            <div id="untagged-section__subheader" className="u-text-sm u-text-loon-title">
                Tag the following evidence type before assigning fault.
            </div>}
            {photoEvidences.length > 0 &&
            <EvidenceModalPhotoSection photoEvidences={photoEvidences} category={category} readOnly={readOnly}/>}
            {highlights.length > 0 &&
            <EvidenceModalHighlightSection highlights={highlights} category={category} readOnly={readOnly}/>}
        </div>
    );
};

export default EvidenceModalSection;

EvidenceModalSection.propTypes = {
    category: PropTypes.string.isRequired,
    evidences: PropTypes.array.isRequired,
    readOnly: PropTypes.bool.isRequired
};
