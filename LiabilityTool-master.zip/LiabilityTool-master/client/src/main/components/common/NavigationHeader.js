import React, {Component} from 'react';
import {connect} from 'react-redux';
import {withRouter} from 'react-router-dom';
import {Header} from 'loon-pattern-library';
import {signOutAction} from '../../actions/signOutActions';
import {clearErrorMessagesAction} from '../../actions/errorActions';
import PropTypes from 'prop-types';
import ErrorBanner from './ErrorBanner';
import {isReadOnlyUser} from '../../helpers/claimDataHelper';
import UnlockClaimModal from './UnlockClaimModal';
import EvidenceModal from './EvidenceModal';
import {evidenceModalErrorAction, showEvidenceModalAction} from '../../actions/evidenceActions';
import analyticsHelper from '../../helpers/analyticsHelper';

export class NavigationHeader extends Component {
    constructor(props) {
        super(props);
        this.transitionTimer = null;
        this.evidenceTriggerTime = null;
        this.state = {
            showUnlockClaimModal: false,
            evidenceTriggered: false
        };
    }

    componentWillUnmount() {
        this.transitionTimer && clearTimeout(this.transitionTimer);
    };

    componentDidUpdate(prevProps) {
        if (prevProps.evidences.length !== this.props.evidences.length && prevProps.claimNumber) {
            this.evidenceTriggerTime = Number(new Date());
            setTimeout(this.clearEvidenceTriggered, 2000);
            this.setEvidenceTriggered(true);
        }
    }

    setEvidenceTriggered = evidenceTriggered => this.setState({evidenceTriggered});

    clearEvidenceTriggered = () => Number(new Date()) - this.evidenceTriggerTime >= 1900 && this.setEvidenceTriggered(false);

    onEvidenceClickCallback = () => {
        analyticsHelper.trackEvent({
            message: 'Evidence count = ' + this.props.evidences.length,
            eventAction: 'NavigationHeader_Evidence_ButtonClicked',
            eventSource: 'button',
            errorCode: '',
        });
        this.props.showEvidenceModalAction(true);
    };

    onLogoClickCallback = () => {
        this.props.clearErrorMessagesAction();
        this.props.history.push('/');
        window.sessionStorage.clear();
    };

    getCurrentTab = () => {
        const curTab = window.location.hash.substring(2);
        return curTab === '' ? 'investigate' : curTab.replace('-', ' ');
    };

    getTabs = () => {
        const {renderSketchTab, enableSettleTab, locked} = this.props;

        const tabs = ['investigate'];
        renderSketchTab && tabs.push('sketch');
        tabs.push('initial fault');
        enableSettleTab && locked && tabs.push('settlement');
        return tabs;
    };

    renderBanner = () => {
        const {showTabs, locked, readOnlyUser} = this.props;
        if (!showTabs) {
            return null;
        }
        if (readOnlyUser || (locked && this.getCurrentTab() !== 'settlement')) {
            const firstSpan = <span className="u-text-sm u-text-semibold">Read Only Mode</span>;
            let secondSpan = <span className="u-text-xs u-hr-left">You are unable to edit this claim.</span>;
            if (locked && this.getCurrentTab() !== 'settlement') {
                secondSpan = <span className="u-text-xs u-hr-left">
                            Initial Fault for this claim has been submitted.
                            <a id="unlock-claim-link" className="u-hr-left u-text-semibold"
                               onClick={this.toggleShowUnlockClaimModal}>
                                Unlock to make changes
                            </a>
                        </span>;
            }
            return (
                <div className="c-alert--info">
                    <div className="centered-content l-body__content l-body__main--1280">
                        <ErrorBanner error={false} id="read-only-banner">
                            {firstSpan}
                            {secondSpan}
                        </ErrorBanner>
                    </div>
                </div>
            );
        }
        return null;
    };

    toggleShowUnlockClaimModal = () => {
        this.setState({showUnlockClaimModal: !this.state.showUnlockClaimModal});
    };

    renderUnlockClaimModal = () => (
        <UnlockClaimModal
            isActive={this.state.showUnlockClaimModal}
            toggleShowUnlockClaimModal={this.toggleShowUnlockClaimModal}
        />
    );

    continueToFaultCallback = () => {
        const {history, showEvidenceModalAction} = this.props;
        if (history.location.pathname !== '/initial-fault') {
            // Set a timer to allow some time for modal dismal animation before routing to Initial Fault
            this.transitionTimer = setTimeout(() => history.push('/initial-fault'), 400);
        }
        showEvidenceModalAction(false);
        this.props.evidenceModalErrorAction(false);
    };

    renderEvidenceModal = () => (
        <EvidenceModal
            isActive={this.props.showEvidenceModal}
            onClose={this.closeEvidenceModalCallback}
            onContinueToFault={this.continueToFaultCallback}
        />
    );

    closeEvidenceModalCallback = () => {
        this.props.showEvidenceModalAction(false);
        this.props.evidenceModalErrorAction(false);
    };

    render() {
        const {userId, showTabs, history, signOutAction, evidences} = this.props;

        return (
            <div id="navigation-header" className="primary-bg-color">
                <Header
                    className="l-shell--1024"
                    user={userId}
                    showTabs={showTabs}
                    tabs={this.getTabs()}
                    activeTab={this.getCurrentTab()}
                    showEvidence={showTabs}
                    badgeContent={evidences.length}
                    triggerEvidence={this.state.evidenceTriggered}
                    onLogoClick={this.onLogoClickCallback}
                    onEvidenceClick={this.onEvidenceClickCallback}
                    onTabChange={tab => history.push(`/${tab.replace(' ', '-')}`)}
                    onMenuItemClick={signOutAction}
                />
                {this.renderBanner()}
                {this.renderUnlockClaimModal()}
                {this.renderEvidenceModal()}
            </div>
        );
    };
}

export const mapStateToProps = ({user, featureSwitches, claimData, status}, {history}) => {
    return {
        userId: user.userId,
        history,
        isClaimSubmitted: claimData.initialFaultSubmitTime !== null,
        claimNumber: claimData.claimNumber,
        locked: claimData.locked,
        renderSketchTab: featureSwitches.renderSketchTab,
        enableSettleTab: featureSwitches.enableSettleTab,
        readOnlyUser: isReadOnlyUser(user.userRoles),
        evidences: claimData.evidences,
        showEvidenceModal: status.showEvidenceModal
    };
};

export const mapDispatchToProps = {
    signOutAction,
    clearErrorMessagesAction,
    showEvidenceModalAction,
    evidenceModalErrorAction
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(NavigationHeader));

NavigationHeader.propTypes = {
    showTabs: PropTypes.bool.isRequired,
    userId: PropTypes.string.isRequired,
    history: PropTypes.object.isRequired,
    isClaimSubmitted: PropTypes.bool.isRequired,
    claimNumber: PropTypes.string.isRequired,
    renderSketchTab: PropTypes.bool.isRequired,
    enableSettleTab: PropTypes.bool.isRequired,
    readOnlyUser: PropTypes.bool.isRequired,
    locked: PropTypes.bool.isRequired,
    signOutAction: PropTypes.func.isRequired,
    clearErrorMessagesAction: PropTypes.func.isRequired,
    evidences: PropTypes.array.isRequired,
    showEvidenceModal: PropTypes.bool.isRequired,
    showEvidenceModalAction: PropTypes.func.isRequired,
    evidenceModalErrorAction: PropTypes.func.isRequired
};
