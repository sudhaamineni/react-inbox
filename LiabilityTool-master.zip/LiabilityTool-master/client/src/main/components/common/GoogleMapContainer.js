import {GoogleMap} from 'loon-pattern-library';
import React, {Component} from 'react';
import {lossLocationSaveAction} from '../../actions/lossLocationActions';
import {connect} from 'react-redux';
import PropTypes from 'prop-types';
import {isReadOnly} from '../../helpers/claimDataHelper';
import ErrorBanner from './ErrorBanner';

export class GoogleMapContainer extends Component {
    onAddressChangeConfirm = (updatedLossLocation, coordinates) => {
        const {claimData, lossLocationSaveAction} = this.props;
        if (!updatedLossLocation || updatedLossLocation === claimData.updatedLossLocation) {
            return;
        }
        lossLocationSaveAction(claimData.claimNumber, coordinates.lat, coordinates.lng, updatedLossLocation);
    };

    onMapChange = mapOptions => {
        const {claimData, readOnly, lossLocationSaveAction} = this.props;
        if (!claimData.longitude || !claimData.latitude) {
            if (!mapOptions || (mapOptions.center.lng === claimData.longitude && mapOptions.center.lat === claimData.latitude)) {
                return;
            }
            if (!readOnly) {
                lossLocationSaveAction(claimData.claimNumber, mapOptions.center.lat, mapOptions.center.lng, claimData.updatedLossLocation);
            }
        }
    };

    render = () => {
        const {claimData, readOnly} = this.props;
        const {
            mapAddress,
            updatedLossLocation
        } = claimData;

        // Fixes google maps issue since the map will try to load even if we render it conditionally.
        // We need to give it an initial value while the actual address is loaded or it will bomb out and not recover - even when we give it the new valid address later
        const initialAddress = updatedLossLocation ? updatedLossLocation : (mapAddress || '');
        const renderError = !updatedLossLocation &&
            (!claimData.lossZip && !claimData.lossCity && !claimData.lossAddress && !claimData.lossStreet);
        const latLng = claimData.latitude && claimData.longitude && {lat: claimData.latitude, lng: claimData.longitude};
        return (
            <div id="google-map" className="background-very-light-gray">
                {renderError &&
                <ErrorBanner error={true}>
                    <span>Missing Information: </span>Please provide the most precise loss location available
                </ErrorBanner>
                }
                {(typeof window.google === 'object' && typeof window.google.maps === 'object') &&
                <GoogleMap
                    isClickToActivate
                    minHeight="366px"
                    address={initialAddress}
                    readOnly={readOnly}
                    latLng={latLng}
                    onConfirmAddress={(address, coordinates) => this.onAddressChangeConfirm(address, coordinates)}
                    onMapChange={mapOptions => this.onMapChange(mapOptions)}
                    mapOptions={
                        {
                            zoom: 18,
                            scrollwheel: true,
                            draggable: true,
                            mapTypeId: 'hybrid',
                            styles: [
                                {
                                    featureType: 'road',
                                    stylers: [
                                        {visibility: 'on'}
                                    ]
                                }
                            ],
                            streetViewControl: true,
                            mapTypeControl: false,
                            zoomControlOptions: {
                                position: window.google.maps.ControlPosition.RIGHT_CENTER
                            },
                            streetViewControlOptions: {
                                position: window.google.maps.ControlPosition.RIGHT_CENTER
                            }
                        }
                    }
                />}
            </div>
        );
    };
}

export const mapStateToProps = ({claimData, user}) => {
    return {
        claimData,
        readOnly: isReadOnly(user.userRoles, claimData.locked)
    };
};

export const mapDispatchToProps = {
    lossLocationSaveAction
};

export default connect(mapStateToProps, mapDispatchToProps)(GoogleMapContainer);

GoogleMapContainer.propTypes = {
    claimData: PropTypes.object.isRequired,
    lossLocationSaveAction: PropTypes.func.isRequired,
    readOnly: PropTypes.bool.isRequired,
};
