import React from 'react';
import {connect} from 'react-redux';
import PropTypes from 'prop-types';
import {ErrorMessage, Icon} from 'loon-pattern-library';
import {signOutAction} from '../../actions/signOutActions';

export const ErrorPage = ({errorHeader, errorDescription, errorButton, signOutAction}) => {
    const getButtonClickAction = () => {
        if (errorButton === 'Back to Login') {
            return signOutAction;
        }
        return undefined;
    };

    return (
        <div className="error-card">
            <div className="c-box">
                <ErrorMessage
                    icon={<Icon className="c-icon u-hr-3-left" color="loon-pink-dark" icon="alert-octagon"/>}
                    errorText={<div className="u-text-bold">{errorHeader}</div>}
                    helpText={<span className="u-hr-6-left">{errorDescription}</span>}
                    buttonText={<span className="u-text-bold">{errorButton}</span>}
                    hideBtn={errorButton === ''}
                    onButtonClick={getButtonClickAction()}
                />
            </div>
        </div>
    );
};

export const mapStateToProps = ({status}) => {
    return {
        errorHeader: status.errorHeader,
        errorDescription: status.errorDescription,
        errorButton: status.errorButton,
    };
};

export const mapDispatchToProps = {
    signOutAction
};

export default connect(mapStateToProps, mapDispatchToProps)(ErrorPage);

ErrorPage.propTypes = {
    errorHeader: PropTypes.string.isRequired,
    errorDescription: PropTypes.string.isRequired,
    errorButton: PropTypes.string.isRequired,
    signOutAction: PropTypes.func.isRequired,
};
