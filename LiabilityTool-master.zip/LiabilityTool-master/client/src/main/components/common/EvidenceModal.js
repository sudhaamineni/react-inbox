import React from 'react';
import PropTypes from 'prop-types';
import {Icon, ModalDialog} from 'loon-pattern-library';
import {connect} from 'react-redux';
import {Link} from 'react-router-dom';
import EvidenceModalSection from './EvidenceModalSection';
import ErrorBanner from './ErrorBanner';
import {showEvidenceModalAction} from '../../actions/evidenceActions';
import {isReadOnly} from '../../helpers/claimDataHelper';

const getCategorySections = (evidences) => {
    let categorySections = {};
    for (let i = 0; i < evidences.length; i++) {
        let category = evidences[i].category;
        if (!category) category = 'untagged';
        if (categorySections[category] === undefined) {
            categorySections[category] = [{...evidences[i]}];
        } else {
            categorySections[category].push({...evidences[i]});
        }
    }
    return categorySections;
};

const getSortedCategories = (categorySections) => {
    const categorySectionsArray = Object.keys(categorySections);
    categorySectionsArray.sort((a, b) => {
        if (a === 'untagged') {
            return -1;
        }
        if (b === 'untagged') {
            return 1;
        }
        return a > b ? 1 : -1;
    });
    return categorySectionsArray;
};

export const EvidenceModal = ({isActive, evidences, onClose, onContinueToFault, evidenceModalError, showEvidenceModalAction, readOnly}) => {
    const untaggedCount = evidences.filter(e => !e.category).length;

    const evidenceCount = evidences.length;

    const headerIconColor = evidenceCount > 0 ? 'bookmark' : 'gray-lighter';

    const categorySections = getCategorySections(evidences);
    const categorySectionsArray = getSortedCategories(categorySections);

    const onInvestigateClick = () => {
        showEvidenceModalAction(false);
    };

    const header =
        <div className="u-flex u-flex--middle u-vr-top u-vr-2">
            <Icon icon="star" color={headerIconColor} size={1.5}/>
            {`Evidence (${evidences.length})`}
        </div>;

    const footer =
        <ul className="l-h-list">
            <li>
                <button className="c-btn c-btn--primary c-btn--sm"
                        disabled={untaggedCount > 0}
                        onClick={onContinueToFault}>
                    Continue to Fault
                </button>
            </li>
        </ul>;

    const emptyStateBody =
        <div className={'evidence-modal__body-container u-flex u-flex--center u-flex--middle'}>
            <div className="evidence-modal__empty u-flex u-flex--center u-flex--column">
                <div className="u-text-error u-text-large">You haven't added any evidence</div>
                <div className="u-text-smaller">Photos and transcript highlights can be added as evidence on <Link
                    to={'/investigate'}
                    className="u-text-semibold"
                    onClick={onInvestigateClick}>
                    Investigate
                </Link>.
                </div>
            </div>
        </div>;

    return (
        <div id="evidence-modal-container" className="evidence-modal-container">
            <ModalDialog
                id="evidence-modal"
                isActive={isActive}
                hideTrigger={true}
                header={header}
                footer={footer}
                onClose={onClose}
            >
                {evidenceCount === 0 && emptyStateBody}
                {evidenceModalError && <ErrorBanner id="fault-event" className="fault-event" error="error">
                    <span>Missing Information.</span> Complete evidence tagging to continue to Assign Fault.
                </ErrorBanner>}
                {categorySectionsArray.map((category, index) =>
                    <div id="evidence-modal-section" key={category}>
                        <EvidenceModalSection
                            category={category}
                            evidences={categorySections[category]}
                            readOnly={readOnly}
                        />
                        {index < categorySectionsArray.length - 1 &&
                        <hr className="participant-section-header-border"/>}
                    </div>
                )}
            </ModalDialog>
        </div>
    );
};

EvidenceModal.propTypes = {
    isActive: PropTypes.bool.isRequired,
    evidences: PropTypes.array.isRequired,
    onClose: PropTypes.func.isRequired,
    onContinueToFault: PropTypes.func.isRequired,
    evidenceModalError: PropTypes.bool.isRequired,
    showEvidenceModalAction: PropTypes.func.isRequired,
    readOnly: PropTypes.bool.isRequired,
};

export const mapStateToProps = ({claimData, status, user}) => ({
    evidences: claimData.evidences,
    evidenceModalError: status.evidenceModalError,
    readOnly: isReadOnly(user.userRoles, claimData.locked)
});


export const mapDispatchToProps = {
    showEvidenceModalAction,
};

export default connect(mapStateToProps, mapDispatchToProps)(EvidenceModal);
