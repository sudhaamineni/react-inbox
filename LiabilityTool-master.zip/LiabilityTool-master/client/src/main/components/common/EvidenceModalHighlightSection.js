import React, {Component} from 'react';
import PropTypes from 'prop-types';
import '../../assets/images/tag-icon.svg';
import {EvidenceMenu, Icon} from 'loon-pattern-library';
import {transcriptEvidenceMenuOptions} from '../../constants/loonConstants';
import {saveEvidenceAction} from '../../actions/attachmentsActions';
import {connect} from 'react-redux';
import {saveHighlightAction} from '../../actions/transcriptActions';
import {evidenceModalErrorAction} from '../../actions/evidenceActions';

export class EvidenceModalHighlightSection extends Component {
    constructor(props) {
        super(props);
        this.state = {
            evidenceMenuRefId: '',
            evidenceMenuPosition: 'top'
        };
    }

    sortHighlights = () => {
        const sortedHighlights = [...this.props.highlights];
        return sortedHighlights.sort((a, b) => {
            let aDate = new Date(a.transcriptCreatedDate);
            let bDate = new Date(b.transcriptCreatedDate);
            if (aDate > bDate) return 1;
            if (aDate < bDate) return -1;

            return a.highlightTexts[0].chunkIndex - b.highlightTexts[0].chunkIndex;
        });
    };

    handleTagButtonClick = evidenceMenuRefId => {
        const bodyRect = document.getElementById('evidence-modal_content').children[1].getBoundingClientRect();
        const targetIconRect = document.getElementById(evidenceMenuRefId).getBoundingClientRect();

        this.setState({
            evidenceMenuRefId,
            evidenceMenuPosition: targetIconRect.y - bodyRect.y < 225 ? 'bottom' : 'top'
        });
    };

    handleEvidenceMenuSelect = categorySelected => {
        const {claimNumber, category, highlights, saveEvidenceAction, evidenceModalErrorAction} = this.props;
        if (category !== categorySelected) {
            const targetHighlightEvidence = JSON.parse(JSON.stringify(highlights)).find(e => e.id === this.state.evidenceMenuRefId);
            targetHighlightEvidence.category = categorySelected;
            saveEvidenceAction(claimNumber, targetHighlightEvidence);

            category === 'untagged' && highlights.length === 1 && evidenceModalErrorAction(false);
            this.setState({evidenceMenuRefId: ''});
        }
    };

    handleEvidenceMenuRemove = () => {
        const targetEvidence = this.props.highlights.find(e => e.id === this.state.evidenceMenuRefId);
        const targetVoiceAttachment = this.props.voiceAttachments.find(va => va.sourceVoiceId === targetEvidence.sourceVoiceId);
        let updatedHighlightEntities = JSON.parse(JSON.stringify(targetVoiceAttachment.highlightEntities));
        updatedHighlightEntities = updatedHighlightEntities.filter(he => he.id !== targetEvidence.sourceId);
        let updatedEvidences = JSON.parse(JSON.stringify(this.props.evidences));
        updatedEvidences = updatedEvidences.filter(e => e.id !== targetEvidence.id);

        this.props.saveHighlightAction(this.props.claimNumber, targetEvidence.sourceVoiceId, updatedHighlightEntities, updatedEvidences);
        this.setState({evidenceMenuRefId: ''});
    };

    render = () => {
        return (
            <div className="position-relative">
                {this.sortHighlights().map(highlight => {
                    let previousSpeaker = null;
                    let currentSpeaker = null;
                    return (
                        <div key={highlight.id} className="highlight-section">
                            <button id={highlight.id}
                                    className="c-btn c-btn--tag--pill"
                                    onClick={() => this.handleTagButtonClick(highlight.id)}
                                /*disabled={readOnly}*/>
                                <Icon icon="tag" size={1}/>
                                <span className="c-btn--tag--pill__text">
                                    {highlight.callType} from {highlight.participantDisplayName || 'Unknown'}
                                    </span>
                            </button>
                            <span className="highlight-review">
                            {highlight.highlightTexts.map(highlightText => {
                                previousSpeaker = currentSpeaker;
                                currentSpeaker = highlightText.speaker;
                                return (
                                    <span key={highlightText.chunkIndex}
                                          className="u-text-small evidence-transcript-chunk">
                                            {previousSpeaker !== currentSpeaker &&
                                            <span
                                                className="u-text-xs u-text-semibold u-text-hint-gray u-hr evidence-transcript-speaker-label">
                                                {currentSpeaker}
                                            </span>
                                            }
                                        {(previousSpeaker === currentSpeaker ? ' ' : '') + highlightText.text}
                                    </span>
                                );
                            })}
                            </span>
                        </div>
                    );
                })}
                <EvidenceMenu
                    align="left"
                    columns={2}
                    options={transcriptEvidenceMenuOptions}
                    position={this.state.evidenceMenuPosition}
                    isActive={this.state.evidenceMenuRefId !== ''}
                    forwardRef={document.getElementById(this.state.evidenceMenuRefId)}
                    selected={this.props.category}
                    onClose={() => this.setState({evidenceMenuRefId: ''})}
                    onSelect={this.handleEvidenceMenuSelect}
                    onRemoveClick={this.handleEvidenceMenuRemove}
                    readOnly={this.props.readOnly}
                />
            </div>
        );
    }
}

export const mapStateToProps = ({claimData}) => ({
    claimNumber: claimData.claimNumber,
    voiceAttachments: claimData.voiceAttachments,
    evidences: claimData.evidences,
});

export const mapDispatchToProps = {
    saveEvidenceAction,
    saveHighlightAction,
    evidenceModalErrorAction
};

EvidenceModalHighlightSection.propTypes = {
    highlights: PropTypes.array.isRequired,
    category: PropTypes.string.isRequired,
    claimNumber: PropTypes.string.isRequired,
    voiceAttachments: PropTypes.array.isRequired,
    evidences: PropTypes.array.isRequired,
    saveEvidenceAction: PropTypes.func.isRequired,
    saveHighlightAction: PropTypes.func.isRequired,
    evidenceModalErrorAction: PropTypes.func.isRequired,
    readOnly: PropTypes.bool.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(EvidenceModalHighlightSection);
