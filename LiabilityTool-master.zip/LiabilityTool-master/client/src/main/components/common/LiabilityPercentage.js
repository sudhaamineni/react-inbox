import React, {Component} from 'react';
import PropTypes from 'prop-types';
import {FormField} from 'loon-pattern-library';
import {allowThreeDigitNumbers} from '../../helpers/decisionErrorHelper';

export default class LiabilityPercentage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            hasValidationError: false,
            percentValue: undefined,
        };
    }

    componentWillReceiveProps(nextProps) {
        const updatedErrorState = ((nextProps.value === this.props.value) && this.state.hasValidationError);
        this.setState({hasValidationError: updatedErrorState});
    }

    onBlurHandler = newValue => {
        let newValueNum = null;
        if (newValue.trim() !== '') {
            newValueNum = Number(newValue.trim());
        }
        if (newValueNum > 100 || newValueNum < 0) {
            this.setState({hasValidationError: true, percentValue: newValueNum});
        } else if (this.props.value !== newValueNum) {
            this.props.onBlurCallback(newValueNum);
            this.setState({hasValidationError: false, percentValue: undefined});
        } else {
            this.setState({hasValidationError: false, percentValue: undefined});
        }
    };

    renderErrorBorder = () => (this.props.hasError || this.state.hasValidationError);

    getValue = () => {
        let value = this.props.value;

        if (this.state.hasValidationError) {
            value = this.state.percentValue;
        }
        return value === 0 ? '0' : value;
    };

    invalidPercentageError = () => {
        const {hasValidationError} = this.state;
        const value = this.getValue();
        return hasValidationError && (value > 100 || value < 0);
    };

    render = () => (
        <div>
            <div
                className={`liability-range u-flex u-flex--center l-grid--middle
                ${this.renderErrorBorder() && 'liability-range-error'}`
                }>
                <FormField
                    value={this.getValue()}
                    disabled={this.props.readOnly}
                    onKeyDown={allowThreeDigitNumbers}
                    onBlur={e => this.onBlurHandler(e.target.value)}
                    autoComplete={false}
                />
                <span id="percentage"
                      className={`u-align-center u-text-sm ${this.state.hasValidationError ? 'u-text-error' : 'color-bright-blue'}`}
                > % </span>
            </div>
            <div id="validation-error" className="u-text-error u-text-tiny text-align-right height-12">
                {this.invalidPercentageError() ? 'Must be 0-100%' : ''}
            </div>
        </div>
    );
}

LiabilityPercentage.propTypes = {
    value: PropTypes.number,
    readOnly: PropTypes.bool.isRequired,
    onBlurCallback: PropTypes.func.isRequired,
    hasError: PropTypes.bool.isRequired,
};
