import React from 'react';
import {Icon} from 'loon-pattern-library';
import {getAssetTypeShortName, getIconLabel} from '../../helpers/claimDataHelper';
import PropTypes from 'prop-types';
import {INSURED, PEDESTRIAN_BICYCLIST} from '../../constants/loonConstants';

const isInsured = liabilitySubject => liabilitySubject.role === INSURED;
const isPed = liabilitySubject => liabilitySubject.role === PEDESTRIAN_BICYCLIST;

const getIconProp = (liabilitySubject) => {
    if (isPed(liabilitySubject)) {
        return 'pedestrian';
    }
    return liabilitySubject.asset && getAssetTypeShortName(liabilitySubject.asset.assetTypeDescription);
};

const getIconSize = liabilitySubject => {
    if (isPed(liabilitySubject)) {
        return 0.875;
    }
    return 1.625;
};

const ParticipantPill = ({liabilitySubject}) => (
    <span id="participant-pill"
          className={`c-badge c-badge--pill c-badge--pill__icon ${isInsured(liabilitySubject) ? 'c-badge--pill--insured' : ''}`}>
        <span
            className={`c-badge--pill__icon__container u-hr-half ${isPed(liabilitySubject) ? 'c-badge--pill__icon__container--vertical' : ''}`}>
            <Icon
                icon={getIconProp(liabilitySubject)}
                color={isInsured(liabilitySubject) ? 'insured' : 'claimant'}
                size={getIconSize(liabilitySubject)}
            />
        </span>
        {getIconLabel(liabilitySubject)}
    </span>
);

export default ParticipantPill;

ParticipantPill.propTypes = {
    liabilitySubject: PropTypes.object.isRequired,
};
