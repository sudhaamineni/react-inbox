import React, {Component} from 'react';
import PropTypes from 'prop-types';
import {EvidenceMenu, Icon} from 'loon-pattern-library';
import {connect} from 'react-redux';
import {photoEvidenceMenuOptions} from '../../constants/loonConstants';
import {saveEvidenceAction} from '../../actions/attachmentsActions';
import {photoToggleBookmarkAction} from '../../actions/photoActions';
import {evidenceModalErrorAction} from '../../actions/evidenceActions';

export class EvidenceModalPhotoSection extends Component {
    constructor(props) {
        super(props);
        this.state = {
            evidenceMenuRefId: '',
            evidenceMenuPosition: 'bottom'
        };
    }

    sortPhotos() {
        return JSON.parse(JSON.stringify(this.props.photoEvidences)).sort((a, b) => {
            if (a.role === 'INSURED') {
                return -1;
            } else if (b.role === 'INSURED') {
                return 1;
            } else if (a.role === b.role) return 0;
            return 1;
        });
    }

    handleTagIconClick = evidenceMenuRefId => {
        const footerRect = document.getElementById('evidence-modal_content').children[2].getBoundingClientRect();
        const targetIconRect = document.getElementById(evidenceMenuRefId).getBoundingClientRect();

        this.setState({
            evidenceMenuRefId,
            evidenceMenuPosition: footerRect.y - targetIconRect.y < 225 ? 'top' : 'bottom'
        });
    };

    handleEvidenceMenuSelect = categorySelected => {
        const {claimNumber, category, photoEvidences, saveEvidenceAction, evidenceModalErrorAction} = this.props;
        if (category !== categorySelected) {
            const targetPhotoEvidence = JSON.parse(JSON.stringify(photoEvidences)).find(e => e.id === this.state.evidenceMenuRefId);
            targetPhotoEvidence.category = categorySelected;
            saveEvidenceAction(claimNumber, targetPhotoEvidence);

            category === 'untagged' && photoEvidences.length === 1 && evidenceModalErrorAction(false);
            this.setState({evidenceMenuRefId: ''});
        }
    };

    handleEvidenceMenuRemove = () => {
        const {claimNumber, liabilitySubjects, evidences, photoToggleBookmarkAction, photoEvidences} = this.props;
        const targetPhotoEvidence = photoEvidences.find(e => e.id === this.state.evidenceMenuRefId);
        const targetLiabilitySubject = liabilitySubjects.find(ls => ls.participantSourceId === targetPhotoEvidence.participantSourceId);
        const updatedPhotoAttachments = JSON.parse(JSON.stringify(targetLiabilitySubject.photoAttachments));
        let updatedEvidences = JSON.parse(JSON.stringify(evidences));

        updatedPhotoAttachments.forEach(pa => {
            if (targetPhotoEvidence.sourceId === pa.dcfId) {
                pa.bookmarked = false;
                updatedEvidences = updatedEvidences.filter(e => e.sourceId !== pa.dcfId);
            }
        });
        photoToggleBookmarkAction(claimNumber, targetPhotoEvidence.participantSourceId, updatedPhotoAttachments, updatedEvidences);
        this.setState({evidenceMenuRefId: ''});
    };

    render = () => (
        <div id="photo-evidence-by-category" className="l-grid l-grid__col photo-evidence-by-category">
            {this.sortPhotos().map(e => (
                <div key={e.id} className="photo-container u-hr-3 u-vr-3-top">
                    <img
                        className="photo-thumbnail"
                        src={e.photoUrl}
                        style={{transform: `rotate(${e.rotation}deg)`}}
                    />
                    <button id={e.id}
                            className="c-btn c-btn__gallery-icon c-btn__gallery-icon--tag photo-gallery-icon"
                            disabled={this.props.readOnly}
                            onClick={() => this.handleTagIconClick(e.id)}>
                        <Icon icon="tag" size={1}/>
                    </button>
                </div>
            ))}
            <EvidenceMenu
                align="right"
                columns={1}
                options={photoEvidenceMenuOptions}
                position={this.state.evidenceMenuPosition}
                isActive={this.state.evidenceMenuRefId !== ''}
                forwardRef={document.getElementById(this.state.evidenceMenuRefId)}
                selected={this.props.category}
                onClose={() => this.setState({evidenceMenuRefId: ''})}
                onSelect={this.handleEvidenceMenuSelect}
                onRemoveClick={this.handleEvidenceMenuRemove}
                readOnly={this.props.readOnly}
            />
        </div>
    );
}

export const mapStateToProps = ({claimData}) => {
    return {
        claimNumber: claimData.claimNumber,
        liabilitySubjects: claimData.liabilitySubjects,
        evidences: claimData.evidences,
    };
};

export const mapDispatchToProps = {
    saveEvidenceAction,
    photoToggleBookmarkAction,
    evidenceModalErrorAction
};

export default connect(mapStateToProps, mapDispatchToProps)(EvidenceModalPhotoSection);

EvidenceModalPhotoSection.propTypes = {
    claimNumber: PropTypes.string.isRequired,
    liabilitySubjects: PropTypes.array.isRequired,
    evidences: PropTypes.array.isRequired,
    photoEvidences: PropTypes.array.isRequired,
    category: PropTypes.string.isRequired,
    saveEvidenceAction: PropTypes.func.isRequired,
    photoToggleBookmarkAction: PropTypes.func.isRequired,
    readOnly: PropTypes.bool.isRequired,
    evidenceModalErrorAction: PropTypes.func.isRequired,
};
