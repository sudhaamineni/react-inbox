import React, {Component} from 'react';
import PropTypes from 'prop-types';
import {convertZuluTimeToLocalTime, formatLossDateString} from '../../helpers/dateTimeHelper';
import {detailLossTypesAndIcons} from '../../constants/detailLossTypeIconConstants';
import {Icon} from 'loon-pattern-library';
import {connect} from 'react-redux';
import ParticipantHeader from './ParticipantHeader';
import {isReadOnlyUser} from '../../helpers/claimDataHelper';

export class LossDetailsHeader extends Component {
    constructor(props) {
        super(props);
        this.state = {
            expanded: false,
        };
    }

    getCurrentTab = () => {
        const curTab = window.location.hash.substring(2);
        return curTab === '' ? 'investigate' : curTab.replace('-', ' ');
    };

    render() {
        const {lossDetailType, liabilitySubjects, initialFaultSubmitTime, claimNumber, lossDate, lossTime, lossState, lossDetailTypeCode, locked} = this.props.claimData;
        const {readOnly} = this.props;
        const foundLossDetail = detailLossTypesAndIcons.find(ea => {
            return ea.lossDetailTypeCode === lossDetailTypeCode;
        });
        const {expanded} = this.state;

        const submittedOrNotProps = initialFaultSubmitTime ?
            {
                icon: 'check-circle',
                color: 'button',
                submitStatusText: 'last',
                submitStatusPunctuation: ':',
            }
            :
            {
                icon: 'update',
                color: 'hot-pink',
                submitStatusText: 'not',
                submitStatusPunctuation: '',
            };

        const headerClassName = readOnly || (locked && this.getCurrentTab() !== 'settlement') ? 'margin-top-6rem' : 'u-vr-9-top';

        return (<div className="l-body background-very-light-gray">
                <div id="liability-analysis--container" className="l-body__content l-body__main--1280">
                    <div id="liability-analysis--scene"
                         className={headerClassName}>
                        <div className="u-flex u-vr-2">
                            <div className="u-flex u-flex--middle">
                                <Icon id="loss-detail-type-icon"
                                      icon={(foundLossDetail && foundLossDetail.icon) || 'default-car-circle'}
                                      color="loon-gray-dark"
                                      size={3}
                                />
                                <div className="u-hr-3-left">
                                    <div id="loss-details-label" className="u-text-xsmall">Loss Details</div>
                                    <div id="loss-detail-type-value" className="u-text-larger">{lossDetailType}</div>
                                    <div id="loss-date-state-value" className="u-text-xsmall">
                                        {formatLossDateString(lossDate) + ' at ' + lossTime.toUpperCase() + ' in ' + lossState}
                                    </div>
                                </div>
                            </div>
                            <div className="loss-details-header-margin"/>
                            <div>
                                <div id="loss-details-status" className="u-text-xsmall u-hr-3-left">Status</div>
                                <div className="u-flex u-flex--middle">
                                    <Icon
                                        id="submit-status-icon"
                                        icon={submittedOrNotProps.icon}
                                        color={submittedOrNotProps.color}
                                        size={1}
                                    />
                                    <div id="claim-submit-status" className="u-text-medium u-hr-left">
                                        {`Claim #${claimNumber} initial fault ${submittedOrNotProps.submitStatusText} submitted${submittedOrNotProps.submitStatusPunctuation}`}
                                    </div>
                                </div>
                                {initialFaultSubmitTime
                                && <div id="claim-submit-time" className="u-text-xsmall u-hr-3-left">
                                    {convertZuluTimeToLocalTime(initialFaultSubmitTime)}
                                </div>}
                            </div>
                        </div>
                        <div className="u-hr-9-left u-text-xs u-vr-top" id="participants-label">
                            {`Participants (${liabilitySubjects.length})`}
                        </div>
                        <div className="u-vr-2 u-vr u-hr-9-left">
                            <ParticipantHeader liabilitySubjects={liabilitySubjects}
                                               expanded={expanded}/>
                        </div>
                        {liabilitySubjects.length > 4 &&
                        <div className="participant-expand-button u-vr-2">
                            <button id="show-more-btn" className="c-btn c-btn--highlighter"
                                    onClick={() => this.setState({expanded: !expanded})}>
                                <Icon icon="chevron" size={1} viewBox="0 0 22 28"
                                      className={`c-btn--rotate-${expanded ? 90 : 270}`}/>
                                <span className="c-btn--highlighter__text">{expanded ? 'Show Less' : 'Show More'}</span>
                            </button>
                        </div>}
                    </div>
                </div>
            </div>
        );
    };
}

export const mapStateToProps = ({claimData, user}) => {
    return {
        claimData,
        readOnly: isReadOnlyUser(user.userRoles)
    };
};

LossDetailsHeader.propTypes = {
    claimData: PropTypes.object.isRequired,
    readOnly: PropTypes.bool.isRequired,
};

export default connect(mapStateToProps)(LossDetailsHeader);
