import React from 'react';
import PropTypes from 'prop-types';
import {
    getParticipantName,
    getVehicleInfo,
} from '../../helpers/claimDataHelper';
import ParticipantPill from './ParticipantPill';

export const ParticipantHeader = ({liabilitySubjects, expanded}) => {

    const renderParticipantsHeader = (liabilitySubjects) => {
        const colSize = 3;

        return liabilitySubjects.map((participant, index) => {
            return (
                <div key={index} className={`u-vr-2 l-grid__col--${colSize}`}>
                    <ParticipantPill liabilitySubject={participant}/>
                    <div id={`participant-name${index}`}
                         className="u-text-hint-gray u-text-md u-wrap u-hr-2">{getParticipantName(participant)}</div>
                    <div id={`participant-vehicle${index}`}
                         className="u-text-gray-darker u-text-xs u-wrap u-hr-2">{getVehicleInfo(participant)}</div>
                </div>
            );
        });
    };

    return (
        <div>
            <div className="l-grid l-grid__col u-text-sm u-text-gray-dark u-flex--wrap">
                {liabilitySubjects.length === 0 && <div id="noParticipants">Participants are not available.</div>}
                {(liabilitySubjects.length > 4 && !expanded) ?
                    renderParticipantsHeader(liabilitySubjects.slice(0, 4)) :
                    renderParticipantsHeader(liabilitySubjects)}
            </div>

        </div>
    );
};

export default ParticipantHeader;

ParticipantHeader.propTypes = {
    liabilitySubjects: PropTypes.array.isRequired,
    expanded: PropTypes.bool.isRequired,
};
