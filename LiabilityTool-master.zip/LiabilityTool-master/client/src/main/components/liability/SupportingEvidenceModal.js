import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import {Icon, ModalDialog} from 'loon-pattern-library';
import {connect} from 'react-redux';
import {Link} from 'react-router-dom';
import {getParticipantName, isReadOnly} from '../../helpers/claimDataHelper';
import ParticipantPill from '../common/ParticipantPill';
import {MEGA_MENU_ITEMS_REVERSE_MAPPING, REASON_TO_DETAILS_MAP} from '../../constants/contributingFactorConstants';
import SupportingEvidenceModalSection from './SupportingEvidenceModalSection';
import {updateEventAction, setEventsValidationAction} from '../../actions/eventActions';
import {revalidateEvent} from '../../helpers/eventValidationHelper';

export class SupportingEvidenceModal extends React.Component {
    constructor(props) {
        super(props);
        const {liabilitySubjects, involvedParty} = this.props;
        const mainParticipant = liabilitySubjects
            && liabilitySubjects.find(p =>
                p.participantSourceId === involvedParty.participantSourceId
                && p.asset.vehicleItemId === involvedParty.assetId);

        this.state = {
            mainParticipant,
            evidenceIds: _.isArray(props.involvedParty.contributingFactors[props.cfIndex].evidenceIds) ? props.involvedParty.contributingFactors[props.cfIndex].evidenceIds : []
        };
    }

    onEvidenceClick = (evidenceId) => {
        const newEvidenceIds = [...this.state.evidenceIds];
        const index = this.state.evidenceIds.indexOf(evidenceId);

        if (index === -1) {
            newEvidenceIds.push(evidenceId);
        }
        else {
            newEvidenceIds.splice(index, 1);
        }
        this.setState({evidenceIds: newEvidenceIds});
    };

    handleAddEvidenceClick = () => {
        const {
            claimNumber,
            event,
            involvedPartyIndex,
            updateEventAction,
            cfIndex,
            onClose,
            setEventsValidationAction,
            eventIndex,
            eventsValidation,
            evidences,
            validateContributingFactorEvidence,
        } = this.props;
        const updatedEvent = _.cloneDeep(event);
        updatedEvent.involvedParties[involvedPartyIndex].contributingFactors[cfIndex].evidenceIds = this.state.evidenceIds;
        updateEventAction(claimNumber, updatedEvent);
        revalidateEvent(updatedEvent, setEventsValidationAction, eventIndex, eventsValidation, evidences, validateContributingFactorEvidence);
        onClose();
    };

    render() {
        const {isActive, onClose, evidences} = this.props;
        const {mainParticipant, evidenceIds} = this.state;
        const {contributingFactorDetails, label} = this.getHeaderLabel();

        const evidenceCount = evidences.length;

        const header =
            <div>
                <div className="u-flex u-flex--middle u-vr-top u-vr">
                    <Icon icon="star" color="bookmark" size={1.5}/>
                    Add Supporting Evidence ({evidenceIds.length})
                </div>
                {mainParticipant &&
                <div className="u-flex u-flex--middle u-vr-2">
                    <ParticipantPill id="supporting-participantLabel" liabilitySubject={mainParticipant}/>
                    <span id="supporting-participantName" className="u-text-small u-hr-15-left">
                        {getParticipantName(mainParticipant)}
                    </span>
                    <span id="supporting-contributingFactor" className="u-text-small u-hr-4-left">
                        <Icon className="supporting-evidence-cf-icon"
                              size={1.0}
                              icon={contributingFactorDetails && contributingFactorDetails.icon}
                              color="action"
                        />
                        {label}
                    </span>
                </div>
                }
            </div>;

        const footer =
            <ul className="l-h-list">
                <li>
                    <button className="c-btn c-btn--primary c-btn--sm"
                            onClick={this.handleAddEvidenceClick}
                            disabled={this.props.readOnly}>
                        Add Evidence
                    </button>
                </li>
            </ul>;

        const emptyStateBody =
            <div className={'evidence-modal__body-container u-flex u-flex--center u-flex--middle'}>
                <div className="evidence-modal__empty u-flex u-flex--center u-flex--column">
                    <div className="u-text-error u-text-large">You haven't added any evidence</div>
                    <div className="u-text-smaller">Photos and transcript highlights can be added as evidence on <Link
                        to={'/investigate'}
                        className="u-text-semibold"
                    >
                        Investigate
                    </Link>.
                    </div>
                    <div className="u-text-smaller">You must add at least one piece of evidence for this contributing
                        factor.
                    </div>
                </div>
            </div>;

        // create category sections map, excluding untagged evidence
        const taggedEvidence = evidences.filter((evidence) => evidence.category);
        let categorySections = {};
        for (let i = 0; i < taggedEvidence.length; i++) {
            let category = taggedEvidence[i].category;

            if (categorySections[category] === undefined) {
                categorySections[category] = [{...taggedEvidence[i]}];
            } else {
                categorySections[category].push({...taggedEvidence[i]});
            }
        }

        // sort the categorySections into an array
        const categorySectionsArray = Object.keys(categorySections);
        categorySectionsArray.sort((a, b) => {
            return a > b ? 1 : -1;
        });

        return (
            <div id="supporting-evidence-modal-container" className="evidence-modal-container supporting-evidence-modal">
                <ModalDialog
                    id="supporting-evidence-modal"
                    isActive={isActive}
                    hideTrigger={true}
                    header={header}
                    footer={footer}
                    onClose={onClose}
                >
                    {evidenceCount === 0 && emptyStateBody}
                    {categorySectionsArray.map((category, index) =>
                        <div key={category} id="supporting-evidence-modal-section">
                            <SupportingEvidenceModalSection
                                category={category}
                                evidences={categorySections[category]}
                                evidenceIds={this.state.evidenceIds}
                                onEvidenceClick={this.onEvidenceClick}
                            />
                            {index < categorySectionsArray.length - 1 &&
                            <hr className="participant-section-header-border"/>}
                        </div>
                    )}
                </ModalDialog>
            </div>
        );
    }

    getHeaderLabel = () => {
        const {cfIndex, involvedParty} = this.props;

        const contributingFactorDetails = MEGA_MENU_ITEMS_REVERSE_MAPPING.find(options => options.value === involvedParty.contributingFactors[cfIndex].reason);

        const detailedReason = involvedParty.contributingFactors[cfIndex].reason &&
            REASON_TO_DETAILS_MAP[involvedParty.contributingFactors[cfIndex].reason] &&
            REASON_TO_DETAILS_MAP[involvedParty.contributingFactors[cfIndex].reason].find(d => d.value === involvedParty.contributingFactors[cfIndex].details);

        let detailedReasonLabel = '';
        if (detailedReason) {
            detailedReasonLabel = ': ' + detailedReason.label;
        } else if (involvedParty.contributingFactors[cfIndex].reason
            && involvedParty.contributingFactors[cfIndex].reason.includes('-other')) {
            detailedReasonLabel = ': ' + involvedParty.contributingFactors[cfIndex].details;
        }

        const label = (contributingFactorDetails ? contributingFactorDetails.label : '') + (detailedReasonLabel);
        return {contributingFactorDetails, label};
    }
}

export const mapStateToProps = ({claimData, user, featureSwitches}) => {
    return {
        claimNumber: claimData.claimNumber,
        validateContributingFactorEvidence: featureSwitches.validateContributingFactorEvidence,
        liabilitySubjects: claimData.liabilitySubjects,
        evidences: claimData.evidences,
        readOnly: isReadOnly(user.userRoles, claimData.locked)
    };
};

export const mapDispatchToProps = {
    updateEventAction,
    setEventsValidationAction
};

export default connect(mapStateToProps, mapDispatchToProps)(SupportingEvidenceModal);

SupportingEvidenceModal.propTypes = {
    isActive: PropTypes.bool.isRequired,
    claimNumber: PropTypes.string.isRequired,
    onClose: PropTypes.func.isRequired,
    validateContributingFactorEvidence: PropTypes.bool.isRequired,
    involvedParty: PropTypes.object.isRequired,
    event: PropTypes.object.isRequired,
    cfIndex: PropTypes.number.isRequired,
    liabilitySubjects: PropTypes.array.isRequired,
    evidences: PropTypes.array.isRequired,
    involvedPartyIndex: PropTypes.number.isRequired,
    updateEventAction: PropTypes.func.isRequired,
    readOnly: PropTypes.bool.isRequired,
    eventsValidation: PropTypes.array.isRequired,
    setEventsValidationAction: PropTypes.func.isRequired,
    eventIndex: PropTypes.number.isRequired
};
