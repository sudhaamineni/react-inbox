import React from 'react';
import PropTypes from 'prop-types';
import {Icon} from 'loon-pattern-library';
import SupportingEvidenceModalPhotoSection from './SupportingEvidenceModalPhotoSection';
import SupportingEvidenceModalHighlightSection from './SupportingEvidenceModalHighlightSection';
import {EVIDENCE_LABEL_MAP} from '../../constants/loonConstants';

const SupportingEvidenceModalSection = ({category, evidences, evidenceIds, onEvidenceClick}) => {
    const number = evidences.length;
    const highlightEvidences = evidences.filter(evidence => evidence.type === 'highlight');
    const photoEvidences = evidences.filter(evidence => evidence.type === 'photo');
    return (
        <div className="evidence-modal-section">
            <div className="u-h4 u-text-loon-title u-flex u-flex--middle">
                <Icon className="u-hr" icon="tag" color="loon-gray-light" size={1.0}/>
                <div id="supporting-category-section__header__text">{EVIDENCE_LABEL_MAP[category]} ({number})</div>
            </div>
            {photoEvidences.length > 0 && <SupportingEvidenceModalPhotoSection photoEvidences={photoEvidences}
                                                                               evidenceIds={evidenceIds}
                                                                               onEvidenceClick={onEvidenceClick}
            />}
            {highlightEvidences.length > 0 &&
            <SupportingEvidenceModalHighlightSection highlightEvidences={highlightEvidences}
                                                     evidenceIds={evidenceIds}
                                                     onEvidenceClick={onEvidenceClick}
            />}
        </div>
    );
};

export default SupportingEvidenceModalSection;

SupportingEvidenceModalSection.propTypes = {
    category: PropTypes.string.isRequired,
    evidences: PropTypes.array.isRequired,
    evidenceIds: PropTypes.array,
    onEvidenceClick: PropTypes.func.isRequired,
};
