import React, {Component} from 'react';
import _ from 'lodash';
import {
    getDamageOptions,
    getParticipantName,
    getVehicleInfo,
    isInsured,
    isReadOnly
} from '../../helpers/claimDataHelper';
import {CustomDropdown, Icon} from 'loon-pattern-library';
import PropTypes from 'prop-types';
import {setEventsValidationAction, updateEventAction} from '../../actions/eventActions';
import {connect} from 'react-redux';
import analyticsHelper from '../../helpers/analyticsHelper';
import LiabilityPercentage from '../common/LiabilityPercentage';
import ParticipantPill from '../common/ParticipantPill';
import Damages from './Damages';
import {AUTO, damageAreaAssetTypes} from '../../constants/loonConstants';
import DamagesSection from './DamagesSection';
import {revalidateEvent} from '../../helpers/eventValidationHelper';
import ContributingFactor from '../common/ContributingFactor';

export class ParticipantFault extends Component {
    constructor(props) {
        super(props);
        const {liabilitySubjects, involvedParty} = props;
        const mainParticipant = liabilitySubjects.find(p => p.participantSourceId === involvedParty.participantSourceId && p.asset.vehicleItemId === involvedParty.assetId);
        const insured = isInsured(mainParticipant);
        const affectedParticipants = [];
        if (involvedParty.affectedParties) {
            involvedParty.affectedParties.forEach(ap => {
                    affectedParticipants.push(liabilitySubjects.find(p => p.participantSourceId === ap.participantSourceId
                        && p.asset.vehicleItemId === ap.assetId));
                }
            );
        }
        this.state = {
            mainParticipant,
            insured,
            affectedParticipants,
        };
    }

    componentDidUpdate(prevProps) {
        const {liabilitySubjects, involvedParty} = this.props;
        const mainParticipant = liabilitySubjects.find(p => p.participantSourceId === involvedParty.participantSourceId && p.asset.vehicleItemId === involvedParty.assetId);
        const insured = isInsured(mainParticipant);
        const affectedParticipants = [];
        if (involvedParty.affectedParties) {
            involvedParty.affectedParties.forEach(ap => {
                    affectedParticipants.push(liabilitySubjects.find(p => p.participantSourceId === ap.participantSourceId
                        && p.asset.vehicleItemId === ap.assetId));
                }
            );
        }
        if (this.props !== prevProps) {
            // eslint-disable-next-line react/no-did-update-set-state
            this.setState({
                mainParticipant,
                insured,
                affectedParticipants,
            });
        }
    }

    isDisabled = () => {
        const {readOnly, events, eventIndex} = this.props;
        const {affectedParticipants} = this.state;
        return (readOnly || affectedParticipants.length === events[eventIndex].involvedParties.length - 1);
    };

    damagesError = () => {
        const {eventsValidation, eventIndex, involvedPartyIndex} = this.props;
        return _.get(eventsValidation, `[${eventIndex}].involvedParties[${involvedPartyIndex}].damagesError`, false);
    };

    renderInvolvedPartyAndDamageAreas = () => {
        const {mainParticipant} = this.state;
        const {involvedParty, events, eventIndex, involvedPartyIndex} = this.props;
        return (
            <div className="l-grid l-grid__col u-hr-left u-vr-2-top">
                <div className="l-grid__col--7 u-flex l-grid--top">
                    <ParticipantPill liabilitySubject={mainParticipant}/>
                    <div id={'mainParticipant-name'}
                         className="u-hr-left u-text-sm">
                        {getParticipantName(mainParticipant)}
                    </div>
                </div>
                {damageAreaAssetTypes.includes(mainParticipant.asset.assetTypeDescription) &&
                <div className="l-grid__col--5 u-flex"
                     id={`involvedPartyDamageArea-${mainParticipant.participantSourceId}`}>
                    {this.damagesError() &&
                    <Icon className="c-hint__icon u-vr-top-half" size={1.0} icon="error-circle"
                          color="loon-pink-dark"/>}
                    <div className="l-grid__col--5">
                        <div className={`u-text-xs u-text-semibold ${this.damagesError() && 'u-text-magenta'}`}
                             id="damage-areas-label">
                            Select Damage Areas
                        </div>
                        <div id="vehicle-make-model-year"
                             className={`u-text-tiny u-text-normal u-vr-top-half ${this.damagesError() ? 'u-text-magenta' : 'u-text-hint-gray '}`}>
                            {getVehicleInfo(mainParticipant)}
                        </div>
                    </div>
                    {mainParticipant.asset.assetTypeDescription === AUTO &&
                    <DamagesSection
                        isInsured={isInsured(mainParticipant)}
                        options={involvedParty.damageSections}
                        event={events[eventIndex]}
                        eventIndex={eventIndex}
                        involvedPartyIndex={involvedPartyIndex}
                    />
                    }
                    {mainParticipant.asset.assetTypeDescription !== AUTO &&
                    <div className="l-grid__col--7">
                        <Damages
                            options={getDamageOptions(mainParticipant.asset.assetTypeDescription, involvedParty.damageSections)}
                            eventIndex={eventIndex}
                            involvedPartyIndex={involvedPartyIndex}
                            event={events[eventIndex]}
                        />
                    </div>
                    }
                </div>
                }
            </div>
        );
    };

    revalidateEvent = (event) => {
        const {setEventsValidationAction, eventIndex, eventsValidation, evidences, validateContributingFactorEvidence } = this.props;
        revalidateEvent(event, setEventsValidationAction, eventIndex, eventsValidation, evidences, validateContributingFactorEvidence);
    };

    renderContributingFactors = () => {
        const {
            readOnly,
            involvedParty,
            eventsValidation,
            involvedPartyIndex,
            eventIndex,
            events,
            claimNumber
        } = this.props;
        const minOneCfError = _.get(eventsValidation, `[${eventIndex}].involvedParties[${involvedPartyIndex}].minOneCfError`, false);

        return (
            <div id="contributing-factors-container" className="contributing-factors-container l-grid__col--7">
                <a id="add-contributing-link"
                   className={`align-items-center ${readOnly && 'cursor-not-allowed'} ${minOneCfError && 'u-text-error'}`}
                   disabled={readOnly} onClick={!readOnly ? this.handleContributingFactorClick : undefined}>
                    <Icon id="add-contributing-icon" icon="plus" color={minOneCfError ? 'magenta' : 'action'}
                          size={0.875}/>
                    <span id="add-contributing-label" className="u-hr-left u-text-semibold">
                        Add a Contributing Factor
                    </span>
                </a>
                {minOneCfError &&
                <div id="min-one-cf-error-text"
                     className="u-flex u-flex--middle eventErrorText align-items-center u-vr-top">
                    <div className="u-hr-2-left u-hr-2 u-vr u-vr-top">Add at least one contributing factor to support
                        the fault decision.
                    </div>
                </div>
                }
                {involvedParty.contributingFactors && involvedParty.contributingFactors.map((cf, index) => {
                    return (
                        <ContributingFactor
                            key={index}
                            readOnly={readOnly}
                            cfIndex={index}
                            contributingFactor={cf}
                            event={events[eventIndex]}
                            eventIndex={eventIndex}
                            involvedParty={involvedParty}
                            involvedPartyIndex={involvedPartyIndex}
                            claimNumber={claimNumber}
                            eventsValidation={eventsValidation}
                        />
                    );
                })}
            </div>
        );
    };

    renderFaultInputForTwoParty = () => {
        const {involvedParty} = this.props;
        const {insured} = this.state;
        return (
            <div>
                <div id="initial-fault" className="u-text-semibold">Initial Fault</div>
                {this.renderFaultInput(involvedParty.affectedParties[0], 0)}
                <div className="l-grid l-grid__col l-body__content">
                    <div className="l-grid__col--8"/>
                    <div id={`score-updated-${insured ? '0' : '1'}`} style={{visibility: 'hidden'}}
                         className="l-grid__col--2 u-hr-5-left range-updated-badge u-text-inverse">
                        Score Updated
                    </div>
                </div>
            </div>
        );
    };

    renderFaultInputForMoreThanTwoParty = () => {
        const {involvedParty} = this.props;
        return (
            <div>
                <a id="add-fault-link"
                   className={`align-items-center ${this.isDisabled() ? 'cursor-not-allowed' : ''}`}
                   disabled={this.isDisabled()}
                   onClick={!this.isDisabled() ? this.handleAddFaultClick : undefined}>
                    <Icon id="add-fault-icon" icon="plus" color="action" size={0.875}/>
                    <span className="u-hr-left u-align-top  u-text-semibold" id="add-fault-label">Add Fault</span>
                </a>
                {involvedParty.affectedParties && involvedParty.affectedParties.map((ap, index) => this.renderFaultInput(ap, index))}
            </div>
        );
    };

    renderParticipantNameForLessThanThreeParties = () => {
        const {liabilitySubjects} = this.props;
        const {affectedParticipants} = this.state;
        return (
            <div id="fault-party-name" className="u-hr-left u-hr-3">
                {liabilitySubjects.length === 2 ? getParticipantName(affectedParticipants[0]) : 'UNKNOWN'}
            </div>
        );
    };

    getInitialSelectedItem = (affectedParty) => {
        return affectedParty.participantSourceId ?
            {
                value: JSON.stringify({
                    participantSourceId: affectedParty.participantSourceId,
                    assetId: affectedParty.assetId
                }),
                label: this.getDropdownOption(affectedParty.participantSourceId, affectedParty.assetId).label
            }
            : undefined;
    };

    renderFaultInput = (affectedParty, index) => {
        const {liabilitySubjects, events, eventIndex, involvedParty, involvedPartyIndex, eventsValidation, readOnly} = this.props;
        let participantOptions;
        if (liabilitySubjects.length > 2) {
            participantOptions = events[eventIndex].involvedParties.map(ip => this.getDropdownOption(ip.participantSourceId, ip.assetId));
            participantOptions = participantOptions.filter(o => {
                const values = JSON.parse(o.value);
                return !(values.participantSourceId === involvedParty.participantSourceId && values.assetId === involvedParty.assetId);
            });

            involvedParty.affectedParties.map(ap => {
                    if (ap.participantSourceId !== affectedParty.participantSourceId || ap.assetId !== affectedParty.assetId) {
                        participantOptions = participantOptions.filter(o =>
                            JSON.parse(o.value).participantSourceId !== ap.participantSourceId
                            || JSON.parse(o.value).assetId !== ap.assetId);
                    }
            });
        }

        const liabilityPercentageHasError = () => {
            return _.get(eventsValidation, `[${eventIndex}].involvedParties[${involvedPartyIndex}].affectedParties[${index}].initialFaultPercentError`, false);
        };

        const affectedParticipantNotSelectedError = () => {
            return _.get(eventsValidation, `[${eventIndex}].involvedParties[${involvedPartyIndex}].affectedParties[${index}].affectedParticipantNotSelectedError`, false);
        };

        return (
            <div key={index} className="u-text-gray u-flex u-flex--middle u-vr-top" id="fault-input-section">
                <div className="u-flex u-flex--middle padding-bottom-12">
                    {liabilitySubjects.length > 2
                    &&
                    <Icon id={`fault-icon-x-${index}`}
                          className={`u-hr factor-x-icon ${readOnly ? 'cursor-not-allowed' : 'pointer'}`}
                          icon="cross" color="button" size={0.6} disabled={readOnly}
                          onClick={() => !readOnly && this.handleParticipantRemoveClick(index)}
                    />
                    }
                    <div id="initial-fault-to">TO</div>
                    <Icon id="arrow-icon"
                          icon="line-arrow"
                          color="loon-gray-light"
                          size={1.5}
                          className="u-hr-left factor-x-icon"
                    />
                    {liabilitySubjects.length < 3
                        ? this.renderParticipantNameForLessThanThreeParties()
                        : <div className="u-hr-left two-participant-fault-container">
                            <CustomDropdown
                                id={`participant-dropdown-${index}`}
                                placeHolder="Select a Participant"
                                readonly={readOnly}
                                initialSelectedItem={this.getInitialSelectedItem(affectedParty)}
                                items={participantOptions}
                                hasError={affectedParticipantNotSelectedError()}
                                onSelect={o => this.handleAffectedPartyChange(o, index)}
                            />
                        </div>
                    }
                </div>
                <div className="u-flex u-flex--middle">
                    <LiabilityPercentage
                        value={affectedParty.initialFaultPercent}
                        readOnly={readOnly}
                        hasError={liabilityPercentageHasError()}
                        onBlurCallback={val => this.handleScoreOnBlur(val, index)}
                    />
                </div>
            </div>
        );
    };

    handleScoreOnBlur = (val, index) => {
        const {liabilitySubjects, events, eventIndex, updateEventAction, claimNumber, involvedParty} = this.props;
        const {insured} = this.state;
        const event = events.slice(0)[eventIndex];
        if (liabilitySubjects.length === 1) {
            event.involvedParties[0].affectedParties[0].initialFaultPercent = val;
        } else if (liabilitySubjects.length === 2) {
            let tooltipId = 'score-updated-0';
            const firstVal = val;
            const secondVal = val === null ? null : 100 - val;
            if (insured) {
                event.involvedParties[0].affectedParties[0].initialFaultPercent = firstVal;
                event.involvedParties[1].affectedParties[0].initialFaultPercent = secondVal;
                tooltipId = 'score-updated-1';
            } else {
                event.involvedParties[0].affectedParties[0].initialFaultPercent = secondVal;
                event.involvedParties[1].affectedParties[0].initialFaultPercent = firstVal;
            }

            document.getElementById(tooltipId).style.visibility = 'visible';
            setTimeout(() => {
                document.getElementById(tooltipId).style.visibility = 'hidden';
            }, 2000);
        } else {
            event.involvedParties.forEach(p => {
                if (p.participantSourceId === involvedParty.participantSourceId) {
                    p.affectedParties[index] = {
                        ...p.affectedParties[index],
                        initialFaultPercent: val
                    };
                }

            });
        }

        this.revalidateEvent(event);
        updateEventAction(claimNumber, event);
    };

    handleAddFaultClick = () => {
        const {involvedParty, events, eventIndex, updateEventAction, claimNumber} = this.props;
        const event = events.slice(0)[eventIndex];
        event.involvedParties.forEach(p => {
            if (p.participantSourceId === involvedParty.participantSourceId && p.assetId === involvedParty.assetId) {
                if (p.affectedParties) {
                    p.affectedParties.push({});
                } else {
                    p.affectedParties = [{}];
                }
            }
        });
        updateEventAction(claimNumber, event);
    };

    handleParticipantRemoveClick = index => {
        const {events, eventIndex, involvedParty, updateEventAction, claimNumber} = this.props;
        const event = events.slice(0)[eventIndex];
        event.involvedParties.forEach(p => {
            if (p.participantSourceId === involvedParty.participantSourceId && p.assetId === involvedParty.assetId) {
                p.affectedParties.splice(index, 1);
            }
        });
        this.revalidateEvent(event);

        updateEventAction(claimNumber, event);
    };

    getDropdownOption = (participantSourceId, assetId) => {
        const {liabilitySubjects, readOnly} = this.props;
        const participant = liabilitySubjects.find(p => p.participantSourceId === participantSourceId && p.asset.vehicleItemId === assetId);
        return {
            value: JSON.stringify({participantSourceId, assetId}),
            label: getParticipantName(participant),
            disabled: readOnly,
        };
    };

    handleAffectedPartyChange = (option, index) => {
        const {involvedParty, liabilitySubjects, eventIndex, events, claimNumber, updateEventAction,} = this.props;
        const event = JSON.parse(JSON.stringify(events))[eventIndex];
        const values = JSON.parse(option.value);
        event.involvedParties.forEach(ip => {
            if (ip.participantSourceId === involvedParty.participantSourceId && ip.assetId === involvedParty.assetId) {
                const involvedLiabilitySubject = liabilitySubjects.find(ls => ls.participantSourceId === ip.participantSourceId && ls.asset.vehicleItemId === ip.assetId);
                const affectedLiabilitySubject = liabilitySubjects.find(ls => ls.participantSourceId === values.participantSourceId && ls.asset.vehicleItemId === values.assetId);
                ip.passengerPartyIds = this.getPassengerPartyIds(involvedLiabilitySubject);
                ip.affectedParties[index] = {
                    ...ip.affectedParties[index],
                    participantId: affectedLiabilitySubject.participantPartyId,
                    participantSourceId: values.participantSourceId,
                    assetId: values.assetId,
                    passengerPartyIds: this.getPassengerPartyIds(affectedLiabilitySubject)
                };
            }
        });

        this.revalidateEvent(event);

        updateEventAction(claimNumber, event);
    };

    getPassengerPartyIds = liabilitySubject => {
        const ret = [];
        liabilitySubject.relatedParticipants.filter(rp => rp.role === 'PASSENGER').forEach(passenger => ret.push(passenger.participantPartyId));
        return ret;
    };

    handleContributingFactorClick = () => {
        const {events, eventIndex, involvedParty, updateEventAction, claimNumber} = this.props;
        analyticsHelper.trackEvent({
            message: 'success',
            eventAction: 'LiabilityPage_AddContributingFactor_LinkClicked',
            eventSource: 'link',
            errorCode: '',
        });

        const event = events.slice(0)[eventIndex];
        event.involvedParties.forEach(ip => {
            if (ip.participantSourceId === involvedParty.participantSourceId) {
                if (!ip.contributingFactors) {
                    ip.contributingFactors = [];
                }
                ip.contributingFactors.push({});
            }
        });
        updateEventAction(claimNumber, event);
    };

    minMissingSupportingEvidenceError = () => {
       const {eventIndex,involvedPartyIndex, eventsValidation} = this.props;
       return _.get(eventsValidation, `[${eventIndex}].involvedParties[${involvedPartyIndex}].minOneMissingSupportingEvidenceError`,false);
    };

    render() {
        const {liabilitySubjects} = this.props;
        return (
            <div>
                <hr className="participant-section-header-border"/>
                {this.renderInvolvedPartyAndDamageAreas()}
                {this.minMissingSupportingEvidenceError() &&
                <div className="u-flex u-flex--middle eventErrorText align-items-center u-vr-top u-hr-2-left">
                    <div id ="evidence-error-text" className="u-hr-2-left u-hr-2 who-involved-error-text">
                        You must add evidence for each contributing factor.
                    </div>
                </div>
                }
                <div id="affected-parties-section" className="l-grid l-grid__col u-hr-left u-text-xs u-vr">
                    {this.renderContributingFactors()}
                    <div className="l-grid__col--5 u-text-black">
                        {liabilitySubjects.length < 3 && this.renderFaultInputForTwoParty()}
                        {liabilitySubjects.length > 2 && this.renderFaultInputForMoreThanTwoParty()}
                    </div>
                </div>
            </div>
        );
    }
}

export const mapStateToProps = ({claimData, user, status, featureSwitches}) => {
    return {
        claimNumber: claimData.claimNumber,
        validateContributingFactorEvidence: featureSwitches.validateContributingFactorEvidence,
        liabilitySubjects: claimData.liabilitySubjects,
        events: claimData.events,
        readOnly: isReadOnly(user.userRoles, claimData.locked),
        eventsValidation: status.eventsValidation,
        evidences: claimData.evidences
    };
};

export const mapDispatchToProps = {
    updateEventAction,
    setEventsValidationAction,
};

export default connect(mapStateToProps, mapDispatchToProps)(ParticipantFault);

ParticipantFault.propTypes = {
    eventIndex: PropTypes.number.isRequired,
    involvedParty: PropTypes.object.isRequired,
    validateContributingFactorEvidence: PropTypes.bool.isRequired,
    involvedPartyIndex: PropTypes.number.isRequired,
    claimNumber: PropTypes.string.isRequired,
    liabilitySubjects: PropTypes.array.isRequired,
    events: PropTypes.array.isRequired,
    readOnly: PropTypes.bool.isRequired,
    eventsValidation: PropTypes.array.isRequired,
    updateEventAction: PropTypes.func.isRequired,
    setEventsValidationAction: PropTypes.func.isRequired,
    evidences: PropTypes.array.isRequired
};
