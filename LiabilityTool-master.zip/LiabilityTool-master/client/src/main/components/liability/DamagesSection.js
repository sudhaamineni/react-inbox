import React from 'react';
import PropTypes from 'prop-types';
import {connect} from 'react-redux';
import {DamageArea, FormOption} from 'loon-pattern-library';
import {setEventsValidationAction, updateDamagesAction} from '../../actions/eventActions';
import {validateEvent} from '../../helpers/eventValidationHelper';
import {isReadOnly} from '../../helpers/claimDataHelper';
import _ from 'lodash';

const NO_DAMAGES = 'noDamages';

export const DamagesSection = ({isInsured, options, updateDamages, eventsValidation, event, eventIndex, setEventsValidation, involvedPartyIndex, readOnly, evidences}) => {

    const updateEventsValidation = (updatedEventsValidation, updatedEvent) => {
        updatedEventsValidation[eventIndex] = validateEvent(updatedEvent, eventIndex, false,evidences.length > 0 );
        setEventsValidation(updatedEventsValidation);
    };

    const handleDamageAreaClick = (selectedDamages) => {
        if (_.get(eventsValidation, `[${eventIndex}].error`, false)) {
            let updatedEventsValidation = [...eventsValidation];
            let updatedEvent = {...event};

            updatedEvent.involvedParties[involvedPartyIndex].damageSections = selectedDamages;

            updateEventsValidation(updatedEventsValidation, updatedEvent);
        }

        updateDamages(eventIndex, involvedPartyIndex, selectedDamages);
    };

    const handleNoDamagesClick = (e) => {
        const damageSections = e.target.checked ? [NO_DAMAGES] : [];
        handleDamageAreaClick(damageSections);
    };

    const isNoDamageChecked = options.includes(NO_DAMAGES);
    const damageAreaOptions = isNoDamageChecked ? [] : options;
    const readOnlyClassName = readOnly ? 'c-option__label__text-read-only' : '';

    return (
        <div id="damages-area" className="l-grid l-grid__col l-grid__col--7">
            <div className="l-grid__col--6">
                <DamageArea isInsured={isInsured}
                            selectedDamages={damageAreaOptions}
                            onClick={selectedDamages => handleDamageAreaClick(selectedDamages)}
                            readOnly={readOnly}
                />
            </div>
            <div className="l-grid__col--6 u-text-xs u-text-normal u-text-hint-gray u-flex u-flex--middle"
                 id="no-damages">
                <FormOption value="noDamages"
                            name="noDamages"
                            disabled={readOnly}
                            readOnly={readOnly}
                            checked={isNoDamageChecked}
                            className={readOnlyClassName}
                            onChange={handleNoDamagesClick}>
                    No Damages
                </FormOption>
            </div>
        </div>
    );
};

DamagesSection.propTypes = {
    isInsured: PropTypes.bool.isRequired,
    options: PropTypes.array.isRequired,
    updateDamages: PropTypes.func.isRequired,
    setEventsValidation: PropTypes.func.isRequired,
    eventsValidation: PropTypes.array.isRequired,
    eventIndex: PropTypes.number.isRequired,
    event: PropTypes.object.isRequired,
    involvedPartyIndex: PropTypes.number.isRequired,
    readOnly: PropTypes.bool.isRequired,
    evidences: PropTypes.array.isRequired
};

export const mapStateToProps = ({claimData, user, status}) => {
    return {
        readOnly: isReadOnly(user.userRoles, claimData.locked),
        eventsValidation: status.eventsValidation,
        evidences: claimData.evidences
    };
};

export const mapDispatchToProps = {
    updateDamages: updateDamagesAction,
    setEventsValidation: setEventsValidationAction
};

export default connect(mapStateToProps, mapDispatchToProps)(DamagesSection);
