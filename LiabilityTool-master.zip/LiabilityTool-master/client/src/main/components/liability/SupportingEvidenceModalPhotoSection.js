import React, {Component} from 'react';
import PropTypes from 'prop-types';
import {Icon} from 'loon-pattern-library';
import {connect} from 'react-redux';
import {saveEvidenceAction} from '../../actions/attachmentsActions';
import {photoToggleBookmarkAction} from '../../actions/photoActions';
import {updateEventAction} from '../../actions/eventActions';
import {isReadOnly} from '../../helpers/claimDataHelper';

export class SupportingEvidenceModalPhotoSection extends Component {
    sortPhotos() {
        return JSON.parse(JSON.stringify(this.props.photoEvidences)).sort((a, b) => {
            if (a.role === 'INSURED') {
                return -1;
            } else if (b.role === 'INSURED') {
                return 1;
            }
            return 0;
        });
    }

    render() {
        const {readOnly, evidenceIds, onEvidenceClick} = this.props;
        return (
            <div id="supporting-photo-evidence-by-category" className="l-grid l-grid__col">
                {this.sortPhotos().map(e => (
                    <div key={e.id} className="photo-container u-hr-3 u-vr-3-top">
                        <img
                            className="photo-thumbnail"
                            src={e.photoUrl}
                            style={{transform: `rotate(${e.rotation}deg)`}}
                        />
                        <button
                            className={`c-btn c-btn__gallery-icon c-btn__gallery-icon--check${evidenceIds && evidenceIds.includes(e.id) ? '--active' : ''} photo-gallery-icon`}
                            disabled={readOnly}
                            onClick={() => onEvidenceClick(e.id)}>
                            <Icon icon="check" size={1}/>
                        </button>
                    </div>
                ))}
            </div>
        );
    }
}

export const mapStateToProps = ({claimData, user}) => {
    return {
        claimNumber: claimData.claimNumber,
        liabilitySubjects: claimData.liabilitySubjects,
        evidences: claimData.evidences,
        events: claimData.events,
        readOnly: isReadOnly(user.userRoles, claimData.locked)
    };
};

export const mapDispatchToProps = {
    saveEvidenceAction,
    updateEventAction, // what does this action take as a payload?
    photoToggleBookmarkAction
};

export default connect(mapStateToProps, mapDispatchToProps)(SupportingEvidenceModalPhotoSection);

SupportingEvidenceModalPhotoSection.propTypes = {
    claimNumber: PropTypes.string.isRequired,
    liabilitySubjects: PropTypes.array.isRequired,
    evidences: PropTypes.array.isRequired,
    evidenceIds: PropTypes.array,
    photoEvidences: PropTypes.array.isRequired,
    saveEvidenceAction: PropTypes.func.isRequired,
    updateEventAction: PropTypes.func.isRequired,
    onEvidenceClick: PropTypes.func.isRequired,
    photoToggleBookmarkAction: PropTypes.func.isRequired,
    readOnly: PropTypes.bool.isRequired
};
