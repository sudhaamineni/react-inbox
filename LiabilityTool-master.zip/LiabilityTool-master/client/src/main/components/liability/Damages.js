import React from 'react';
import PropTypes from 'prop-types';
import {connect} from 'react-redux';
import {FormOption} from 'loon-pattern-library';
import {isReadOnly} from '../../helpers/claimDataHelper';
import {setEventsValidationAction, updateDamagesAction} from '../../actions/eventActions';
import {validateEvent} from '../../helpers/eventValidationHelper';

const NO_DAMAGES = 'noDamages';

const getUpdatedDamages = (e, options) => {
    if (e.target.value === NO_DAMAGES) {
        return e.target.checked ? [NO_DAMAGES] : [];
    }

    let result = [];
    const damageOptions = options.filter(o => o.value !== NO_DAMAGES);
    damageOptions.forEach(option => {
        if (option.value === e.target.value) {
            if (e.target.checked) {
                result.push(option.value);
            }
        } else if (option.checked) {
            result.push(option.value);
        }
    });
    return result;
};

export const Damages = ({options, updateDamages, event, eventIndex, involvedPartyIndex, eventsValidation, setEventsValidation, isSingleParty, readOnly, evidences}) => {
    const readOnlyClassName = readOnly ? 'c-option__label__text-read-only' : '';

    const handleOnChange = (e) => {
        let result = getUpdatedDamages(e, options);

        if (eventsValidation[eventIndex] && eventsValidation[eventIndex].error) {
            let updatedEventsValidation = [...eventsValidation];
            let updatedEvent = {...event};

            updatedEvent.involvedParties[involvedPartyIndex].damageSections = result;

            updatedEventsValidation[eventIndex] = validateEvent(updatedEvent, eventIndex, isSingleParty, evidences.length > 0);
            setEventsValidation(updatedEventsValidation);
        }

        updateDamages(eventIndex, involvedPartyIndex, result);
    };

    const renderOptions = (options) => {
        return options.map((option) =>
            <FormOption key={option.value}
                        value={option.value}
                        name={option.value}
                        disabled={readOnly}
                        readOnly={readOnly}
                        checked={option.checked}
                        onChange={handleOnChange}
                        className={`u-vr ${readOnlyClassName}`}
            >
                {option.label}
            </FormOption>
        );
    };

    const cut = Math.floor((options.length + 1) / 2);

    return (
        <div className="l-grid l-grid__col u-text-xs u-text-normal u-text-hint-gray">
            <div className="l-grid__col--6">
                {renderOptions(options.slice(0, cut))}
            </div>
            <div className="l-grid__col--6">
                {renderOptions(options.slice(cut))}
            </div>
        </div>);
};

Damages.propTypes = {
    options: PropTypes.array.isRequired,
    updateDamages: PropTypes.func.isRequired,
    eventIndex: PropTypes.number.isRequired,
    involvedPartyIndex: PropTypes.number.isRequired,
    event: PropTypes.object.isRequired,
    setEventsValidation: PropTypes.func.isRequired,
    eventsValidation: PropTypes.array.isRequired,
    isSingleParty: PropTypes.bool,
    readOnly: PropTypes.bool.isRequired,
    evidences: PropTypes.array.isRequired

};

Damages.defaultProps = {
    isSingleParty: false
};

export const mapStateToProps = ({status, claimData, user}) => {
    return {
        eventsValidation: status.eventsValidation,
        isSingleParty: claimData.liabilitySubjects.length === 1,
        readOnly: isReadOnly(user.userRoles, claimData.locked),
        evidences: claimData.evidences
    };
};

export const mapDispatchToProps = {
    updateDamages: updateDamagesAction,
    setEventsValidation: setEventsValidationAction,
};

export default connect(mapStateToProps, mapDispatchToProps)(Damages);
