import React from 'react';
import {ButtonGroup, FormOption, Icon} from 'loon-pattern-library';
import {connect} from 'react-redux';
import PropTypes from 'prop-types';
import {getParticipantName, isReadOnly} from '../../helpers/claimDataHelper';
import {removeEventAction, setEventsValidationAction, updateEventAction} from '../../actions/eventActions';
import ParticipantFault from './ParticipantFault';
import {damageAreaAssetTypes} from '../../constants/loonConstants';
import ErrorBanner from '../common/ErrorBanner';
import {validateEvent} from '../../helpers/eventValidationHelper';
import _ from 'lodash';

const HAS_DAMAGE = 'hasDamage';

const sortInvolvedParties = (participant1, participant2) => {
    if (participant1.participantId > participant2.participantId) {
        return 1;
    }
    if (participant1.participantId < participant2.participantId) {
        return -1;
    }
    return participant1.assetId > participant2.assetId ? 1 : -1;
};

const tooMuchAssignedFaultErrorText = (eventsValidation, eventIndex, liabilitySubjects) => {
    const ids = eventsValidation[eventIndex].tooMuchAssignedFaultError;
    let nameText = getParticipantName(liabilitySubjects.find(s => s.participantSourceId === ids[0]));
    if (ids.length > 1) {
        for (let i = 1; i < ids.length; i++) {
            const liabilitySubject = liabilitySubjects.find(s => s.participantSourceId === ids[i]);
            const name = getParticipantName(liabilitySubject);
            nameText += `, ${name}`;
        }
    }
    return `Cannot assign more than 100% fault to ${nameText} in an event.`;
};

const renderInvolvedParticipantValidationError = () => {
    return (
        <div className="u-flex u-flex--middle eventErrorText align-items-center u-vr-top">
            <div className="u-hr-2-left u-hr-2 who-involved-error-text">
                You must add at least 2 participants to Who’s Involved for this event.
            </div>
        </div>
    );
};

const renderNoFaultValidationError = () => {
    return (
        <div className="u-flex u-flex--middle eventErrorText align-items-center u-vr-top">
            <div className="u-hr-2-left u-hr-2 who-involved-error-text">
                Involved participants must be included in at least one fault decision pair.
            </div>
        </div>
    );
};

const renderHasTooMuchAssignedFaultValidationError = (eventsValidation, eventIndex, liabilitySubjects) => {
    return (
        <div className="u-flex u-flex--middle eventErrorText align-items-center u-vr-top">
            <div className="u-hr-2-left u-hr-2 who-involved-error-text">
                {tooMuchAssignedFaultErrorText(eventsValidation, eventIndex, liabilitySubjects)}
            </div>
        </div>
    );
};

const hasTooMuchAssignedFaultValidationError = (eventsValidation, eventIndex) => {
    const errorLength = _.get(eventsValidation, `[${eventIndex}].tooMuchAssignedFaultError.length`, 0);
    return errorLength !== 0;
};

const noFaultValidationError = (eventsValidation, eventIndex) => {
    return _.get(eventsValidation, `[${eventIndex}].addFaultParticipantError`, false);
};

const renderParticipantCheckBoxes = (event, participant, index, handleCheckboxChange, readOnly) => {
    const involvedParty = event.involvedParties
        && event.involvedParties.find(ip => ip.participantSourceId === participant.participantSourceId && ip.assetId === participant.asset.vehicleItemId);
    const checkboxClassName = involvedParty ? 'c-option--blue l-grid__col--3 u-vr-top-2' : 'l-grid__col--3 u-vr-top-2';
    return (
        <FormOption key={index}
                    value={participant.participantSourceId}
                    className={checkboxClassName}
                    checked={!!involvedParty}
                    readOnly={readOnly}
                    onChange={e => handleCheckboxChange(e.target.checked, participant, index)}>
                                <span
                                    className={`${readOnly && 'cursor-not-allowed'}`}>{participant.role} - {getParticipantName(participant)}</span>
        </FormOption>
    );
};
const handleCheck = (updatedEvent, participant, mainParticipant) => {
    if (!updatedEvent.involvedParties) {
        updatedEvent.involvedParties = [];
    }
    let damages = [];
    if (participant.asset && !damageAreaAssetTypes.includes(participant.asset.assetTypeDescription)) {
        damages.push(HAS_DAMAGE);
    }
    const involvedParty = {
        participantId: mainParticipant.participantPartyId,
        participantSourceId: mainParticipant.participantSourceId,
        affectedParties: [],
        assetId: mainParticipant.asset.vehicleItemId,
        damageSections: damages,
        contributingFactors: [],
    };
    updatedEvent.involvedParties.push(involvedParty);
};

const handleUncheck = (updatedEvent, participant) => {
    const {participantSourceId, asset} = participant;
    const index = updatedEvent.involvedParties.findIndex(
        involvedParty => involvedParty.participantSourceId === participantSourceId
            && involvedParty.assetId === asset.vehicleItemId
    );
    updatedEvent.involvedParties.splice(index, 1);

    updatedEvent.involvedParties.forEach(ip => {
        if (ip.affectedParties) {
            const apIndex = ip.affectedParties.findIndex(
                affectedParty => affectedParty.participantSourceId === participantSourceId
                    && affectedParty.assetId === asset.vehicleItemId
            );
            if (apIndex >= 0) {
                ip.affectedParties.splice(apIndex, 1);
            }
        }
    });
};

const updateEventOnCheckboxChange = (event, isChecked, participant, pIndex, mainParticipant) => {

    const updatedEvent = {...event};

    if (isChecked) {
        handleCheck(updatedEvent, participant, mainParticipant);
    } else {
        handleUncheck(updatedEvent, participant);
    }
    return updatedEvent;
};

const getCursor = (readOnly) => {
    return readOnly ? 'cursor-not-allowed' : '';
};

const getEventTitle = (length, eventIndex, lossDetailType) => {
    return length > 2 ? `Event ${eventIndex + 1}` : lossDetailType;
};

const getClassIfDisabled = (readOnly) => {
    return readOnly ? 'div-disabled' : '';
};

export const Event = (({
                           claimNumber,
                           lossDetailType,
                           liabilitySubjects,
                           event,
                           eventIndex,
                           numberOfEvents,
                           readOnly,
                           eventsValidation,
                           updateEventAction,
                           removeEventAction,
                           setEventsValidationAction,
                           evidences,
                       }) => {
    let sortedInvolvedParties = event.involvedParties && event.involvedParties.sort(sortInvolvedParties);

    const involvedParticipantValidationError = _.get(eventsValidation, `[${eventIndex}].tooFewInvolvedPartyError`, false);

    const updateEventsValidation = (updatedEvent) => {
        const eventValidation = validateEvent(updatedEvent, eventIndex, false, evidences.length > 0);
        const newEventsValidation = [...eventsValidation];
        newEventsValidation[eventIndex] = eventValidation;
        setEventsValidationAction(newEventsValidation);
    };

    const updateSeverity = (e) => {
        const updatedEvent = {...event};
        updatedEvent.severity = parseInt(e.target.value, 10);
        if (eventsValidation[eventIndex].error) {
            updateEventsValidation(updatedEvent);
        }
        updateEventAction(claimNumber, updatedEvent);
    };

    const handleCheckboxChange = (isChecked, p, pIndex) => {
        const updatedEvent = updateEventOnCheckboxChange(event, isChecked, p, pIndex, liabilitySubjects[pIndex]);

        if (eventsValidation[eventIndex].error) {
            updateEventsValidation(updatedEvent);
        }
        updateEventAction(claimNumber, updatedEvent);
    };

    const updateEventName = title => {
        event.title !== title && updateEventAction(claimNumber, {...event, title});
    };

    const renderWhosInvolved = () => {
        return (
            <div
                className="u-text-xs u-vr-2-top u-vr-2 u-hr-2-left">
                <div className="u-flex u-flex--middle">
                    {involvedParticipantValidationError &&
                    <Icon className="c-hint__icon" size={0.75} icon="alert-octagon" color="loon-pink-dark"/>}
                    <div id="who-involved"
                         className={`u-text-semibold ${involvedParticipantValidationError ? 'u-text-magenta' : ''}`}>
                        Who's Involved?
                    </div>
                </div>
                <div className="u-flex l-grid l-grid__col">
                    {liabilitySubjects.map((p, pIndex) => {
                        return renderParticipantCheckBoxes(event, p, pIndex, handleCheckboxChange, readOnly);
                    })}
                </div>
                {involvedParticipantValidationError && renderInvolvedParticipantValidationError()}
                {noFaultValidationError(eventsValidation, eventIndex) && renderNoFaultValidationError()}
                {hasTooMuchAssignedFaultValidationError(eventsValidation, eventIndex)
                && renderHasTooMuchAssignedFaultValidationError(eventsValidation, eventIndex, liabilitySubjects)}
            </div>
        );
    };

    return (
        <div className="u-color-white-background">
            <div className="centered-content l-body__content l-body__main--1280 ">
                <div id={`fault-event-${eventIndex}`} className="fault-event participant-section-border u-vr-5-top">
                    <div
                        className="background-very-light-gray u-text-large u-padding-top-1 u-padding-bottom-1 u-padding-left-2 u-flex c-accordion__hd__bd border-top-radius-6">
                        <span id="event-name-label">
                            {getEventTitle(liabilitySubjects.length, eventIndex, lossDetailType)} -
                            <input
                                className={`background-very-light-gray event-name u-hr-left ${getCursor(readOnly)}`}
                                key={event.title}
                                defaultValue={event.title}
                                maxLength={50}
                                placeholder="Name This Event"
                                disabled={readOnly}
                                onBlur={e => updateEventName(e.target.value)}
                                autoFocus={!event.title && eventIndex + 1 === numberOfEvents}
                                autoComplete={false}
                            />
                        </span>
                        {eventIndex > 0 &&
                        <span>
                            <Icon icon="cross"
                                  size={0.75}
                                  color="button"
                                  className={`u-hr-3 pointer ${getClassIfDisabled(readOnly)}`}
                                  disabled={readOnly}
                                  onClick={() => removeEventAction(claimNumber, event)}
                            />
                        </span>
                        }
                    </div>
                    <hr className="participant-section-header-border"/>
                    {_.get(eventsValidation, `[${eventIndex}].error`) &&
                    <ErrorBanner error={true}>
                        <span>Missing Information: </span>See details below
                    </ErrorBanner>
                    }
                    {eventIndex > 0 &&
                    <div className="u-flex u-flex--middle u-vr-2-top u-text-smaller u-text-semibold">
                        <span id="severity-label" className="u-hr-2-left u-hr-2">Severity Compared to Event 1:</span>
                        <ButtonGroup
                            type="radio"
                            name={`decision${eventIndex}`}
                            disabled={readOnly}
                            hasError={_.get(eventsValidation, `[${eventIndex}].severityError`, false)}
                            options={[
                                {
                                    text: 'Less',
                                    value: -1,
                                    defaultChecked: event.severity === -1
                                },
                                {
                                    text: 'Same',
                                    value: 0,
                                    defaultChecked: event.severity === 0
                                },
                                {
                                    text: 'More',
                                    value: 1,
                                    defaultChecked: event.severity === 1
                                },
                            ]}
                            onChange={updateSeverity}/>
                    </div>}
                    {liabilitySubjects.length > 2 && renderWhosInvolved()}
                    {sortedInvolvedParties && sortedInvolvedParties.map((p, i) => (
                        <ParticipantFault
                            key={i}
                            eventIndex={eventIndex}
                            involvedPartyIndex={i}
                            involvedParty={p}
                        />
                    ))}
                </div>
            </div>
        </div>
    );
});

export const mapStateToProps = ({claimData, user, status}) => {
    return {
        claimNumber: claimData.claimNumber,
        lossDetailType: claimData.lossDetailType,
        liabilitySubjects: claimData.liabilitySubjects,
        numberOfEvents: claimData.events ? claimData.events.length : 0,
        readOnly: isReadOnly(user.userRoles, claimData.locked),
        eventsValidation: status.eventsValidation,
        evidences: claimData.evidences
    };
};

export const mapDispatchToProps = {
    updateEventAction,
    removeEventAction,
    setEventsValidationAction,
};

Event.propTypes = {
    claimNumber: PropTypes.string.isRequired,
    lossDetailType: PropTypes.string,
    liabilitySubjects: PropTypes.array.isRequired,
    numberOfEvents: PropTypes.number.isRequired,
    event: PropTypes.object.isRequired,
    eventIndex: PropTypes.number.isRequired,
    eventsValidation: PropTypes.array.isRequired,
    updateEventAction: PropTypes.func.isRequired,
    removeEventAction: PropTypes.func.isRequired,
    setEventsValidationAction: PropTypes.func.isRequired,
    readOnly: PropTypes.bool.isRequired,
    evidences: PropTypes.array.isRequired
};

export default connect(mapStateToProps, mapDispatchToProps)(Event);
