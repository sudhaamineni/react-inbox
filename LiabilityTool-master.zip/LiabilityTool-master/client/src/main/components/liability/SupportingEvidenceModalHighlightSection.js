import React, {Component} from 'react';
import PropTypes from 'prop-types';
import '../../assets/images/tag-icon.svg';
import {connect} from 'react-redux';
import {Icon} from 'loon-pattern-library';
import {isReadOnly} from '../../helpers/claimDataHelper';

export class SupportingEvidenceModalHighlightSection extends Component {
    sortHighlights = () => {
        const sortedHighlights = [...this.props.highlightEvidences];
        return sortedHighlights.sort((a, b) => {
            let aDate = new Date(a.transcriptCreatedDate);
            let bDate = new Date(b.transcriptCreatedDate);
            if (aDate > bDate) return 1;
            if (aDate < bDate) return -1;

            return a.highlightTexts[0].chunkIndex - b.highlightTexts[0].chunkIndex;
        });
    };

    render = () => {
        let previousSpeaker = null;
        let currentSpeaker = null;
        const {readOnly, onEvidenceClick, evidenceIds} = this.props;
        return (
            <div className="position-relative">
                {this.sortHighlights().map((highlight, index) => (<div key={highlight.id} className="highlight-section">
                    <button id={`highlight-pill-${index}`}
                            className={`c-btn
                            c-btn--recorded-statement-pill${evidenceIds.includes(highlight.id) ? '--active' : ''}
                            u-vr-half`}
                            disabled={readOnly}
                            onClick={!readOnly && (() => onEvidenceClick(highlight.id))}>
                        <Icon strokeLinecap="round" icon="check-solid" size={1}/>
                        <span className="c-btn--recorded-statement-pill__text">
                                {highlight.callType} from {highlight.participantDisplayName || 'Unknown'}
                            </span>
                    </button>
                    <span className="highlight-review">
                            {highlight.highlightTexts.map(highlightText => {
                                previousSpeaker = currentSpeaker;
                                currentSpeaker = highlightText.speaker;
                                return (
                                    <span key={highlightText.chunkIndex}
                                          className="u-text-small evidence-transcript-chunk">
                                            {previousSpeaker !== currentSpeaker &&
                                            <span
                                                className="u-text-xs u-text-semibold u-text-hint-gray u-hr evidence-transcript-speaker-label">
                                                {currentSpeaker}
                                            </span>}
                                        {(previousSpeaker === currentSpeaker ? ' ' : '') + highlightText.text}
                                    </span>
                                );
                            })}
                        </span>
                </div>))}
            </div>
        );
    }
}

export const mapStateToProps = ({claimData, user}) => ({
    readOnly: isReadOnly(user.userRoles, claimData.locked)
});

SupportingEvidenceModalHighlightSection.propTypes = {
    highlightEvidences: PropTypes.array.isRequired,
    evidenceIds: PropTypes.array.isRequired,
    onEvidenceClick: PropTypes.func.isRequired,
    readOnly: PropTypes.bool.isRequired
};

export default connect(mapStateToProps)(SupportingEvidenceModalHighlightSection);
