import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import analyticsHelper from '../../helpers/analyticsHelper';
import PropTypes from 'prop-types';
import { FormField, Icon } from 'loon-pattern-library';
import Event from './Event';
import { isReadOnly } from '../../helpers/claimDataHelper';
import { validateEvent } from '../../helpers/eventValidationHelper';
import { createEventAction, setEventsValidationAction } from '../../actions/eventActions';
import { SubmitModal } from './SubmitModal';
import { ERROR_SUBMITTING, SUBMITTED, SUBMITTING } from '../../constants/loonConstants';
import {
    liabilitySubmittedAction,
    submitLiabilityAction,
    submitLiabilityCancelAction
} from '../../actions/submitActions';
import ErrorBanner from '../common/ErrorBanner';
import { saveSketchAction } from '../../actions/claimDataActions';

export class Liability extends Component {
    constructor(props) {
        super(props);
        this.shouldScroll = false;
        this.mapDataUrl = '';
        this.state = {
            openConfirmModal: false
        };
    };

    componentDidMount() {
        const { claimNumber } = this.props.claimData;
        analyticsHelper.trackPage('claims/loon/liabilityPage');
        const claimNumberNoLeadingZero = claimNumber !== '' ? parseInt(claimNumber, 10) : '';
        document.title = 'Loon - ' + claimNumberNoLeadingZero;
    }

    componentDidUpdate() {
        if (this.shouldScroll) {
            const top = document.getElementById('submit-initial-fault').getBoundingClientRect().top + window.pageYOffset - 55;
            if (this.scrollBehaviorSupported()) {
                window.scrollTo({ top: top, behavior: 'smooth' });
            } else {
                window.scrollTo(0, top);
            }
            this.shouldScroll = false;
        }
    }

    addEvent = () => {
        const { createEventAction, claimData } = this.props;
        let newEvent = {
            involvedParties: []
        };
        createEventAction(claimData.claimNumber, newEvent);
        this.shouldScroll = true;
    };

    scrollBehaviorSupported = () => {
        return 'scrollBehavior' in document.documentElement.style;
    };

    launchConfirmSubmitModal = () => {
        const sketchValidated = this.props.claimData.sketch &&
            (this.props.claimData.sketch.completed || this.props.claimData.sketch.notCompletedReason);
        const firstErrorIndex = this.validateEvents();
        if (firstErrorIndex === -1 && sketchValidated) {
            this.setState({ openConfirmModal: true });
        } else if (!sketchValidated) {
            window.scrollTo(0, 0);
        } else {
            const firstEventWithError = document.getElementById(`fault-event-${firstErrorIndex}`);
            firstEventWithError.scrollIntoView({ block: 'center' });
        }
    };

    validateEvents = () => {
        const { liabilitySubjects, evidences } = this.props.claimData;
        const { validateContributingFactorEvidence } = this.props;
        const validation = [];
        const isSingleParty = liabilitySubjects.length === 1;
        const hasEvidences = evidences ? evidences.length > 0 : false;
        let firstErrorIndex = -1;
        this.props.claimData.events.forEach((event, eventIndex) => {
            const eventValidation = validateEvent(event, eventIndex, isSingleParty, hasEvidences,
                validateContributingFactorEvidence);
            validation.push(eventValidation);
            if (eventValidation.error) {
                if (firstErrorIndex === -1) {
                    firstErrorIndex = eventIndex;
                }
            }
        });

        this.props.setEventsValidationAction(validation);
        return firstErrorIndex;
    };

    closeModal = () => {
        this.setState({ openConfirmModal: false });
    };

    onSubmitConfirmClick = () => {
        const { submitLiabilityAction, claimData } = this.props;
        submitLiabilityAction(claimData, this.mapDataUrl);
        this.setState({ openConfirmModal: false });
    };

    getGoogleMapImageData = (latitude, longitude) => {
        const googleStaticMapBaseUrl = 'https://maps.googleapis.com/maps/api/staticmap?key=AIzaSyBK3Q55JaYi4jO6AuDzU6sp_qwgLD2FI9Y';
        const center = `&center=${latitude},${longitude}`;
        const mapUrl = `${googleStaticMapBaseUrl}${center}&zoom=17&size=744x261&markers=color:red|${latitude},${longitude}&maptype=hybrid`;
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        const image = new Image();
        image.crossOrigin = 'crossOrigin';
        image.onload = () => {
            canvas.width = image.width;
            canvas.height = image.height;
            context.drawImage(image, 0, 0, image.width, image.height);
            this.mapDataUrl = canvas.toDataURL();
        };
        image.src = mapUrl;
    };

    redirectToHomePage = () => {
        const { liabilitySubmittedAction, history } = this.props;
        liabilitySubmittedAction();
        history.push('/');
    };

    redirectToSettlementPage = () => {
        const { liabilitySubmittedAction, history } = this.props;
        liabilitySubmittedAction();
        history.push('/settlement');
    };

    isConfirmModalActive = () => {
        return this.state.openConfirmModal || this.props.submitState === SUBMITTING;
    };

    renderSketchNotDoneSection = () => (
        <div id="sketch-not-completed-section">
            <div className="u-flex u-flex--middle u-vr-4-top">
                {this.showSketchExplanationError() &&
                <Icon id="sketch-error-icon" icon="error-circle" color="magenta" size={0.875} className="u-hr" />}
                <div id="sketch-explanation"
                     className={`u-text-xs u-text-semibold ${this.showSketchExplanationError() && 'u-text-error'}`}>
                    You haven’t added a sketch. Please add a sketch or provide an explanation before submitting.
                </div>
            </div>
            <div id="sketch-question" className="u-text-xs u-text-semibold u-vr-2-top">
                Why isn’t a sketch required?
            </div>
            <div className="u-flex u-flex--middle u-vr-top-half">
                <div id="sketch-not-done-reason" className="sketch-not-done-reason">
                    <FormField
                        value={this.props.claimData.sketch ? this.props.claimData.sketch.notCompletedReason : null}
                        maxLength={75}
                        hasError={this.showSketchExplanationError()}
                        disabled={this.props.readOnly}
                        onBlur={e => this.handleSketchNotCompletedReasonBlur(e.target.value)}
                        autoComplete={false}
                    />
                </div>
                <a className="u-hr-4-left" onClick={() => this.props.history.push('/sketch')}>
                    <Icon id="add-sketch-icon" icon="plus" color="action" size={0.75} />
                    <span id="add-sketch-label" className="u-hr-left u-text-xs u-text-semibold">Add Sketch</span>
                </a>
            </div>
        </div>
    );

    handleSketchNotCompletedReasonBlur = notCompletedReason => {
        const updatedSketch = { ...this.props.claimData.sketch };
        updatedSketch.notCompletedReason = notCompletedReason;
        this.props.saveSketchAction(updatedSketch);
    };

    renderEvents = () => {
        const { liabilitySubjects, events, sketch } = this.props.claimData;
        return (
            <div className="u-color-white-background">
                <div id="liability-analysis--container" className="l-body__content l-body__main--1280">
                    <div id="liability-analysis--scene">
                        {!this.sketchCompleted() && this.renderSketchNotDoneSection(sketch)}
                        <div id="fault-header" className="u-text-large u-vr-4-top">
                            {liabilitySubjects.length < 3 ? 'Initial Fault' : 'Determine Initial Fault Using Events'}
                        </div>
                        {liabilitySubjects.length > 2 &&
                        <div id="fault-event-text" className="u-text-medium u-vr-2-top">
                            Your analysis can be separated into events.
                            <div className="u-vr-top" />
                            An event typically starts with an proximate cause of loss. This is a distinct act of
                            negligence resulting in 1 or more impacts.
                        </div>}
                        {events.map((e, i) => <Event key={i} event={e} eventIndex={i} />)}
                    </div>
                </div>
            </div>
        );
    };

    sketchCompleted = () => {
        return this.props.claimData.sketch && this.props.claimData.sketch.completed;
    };

    showSketchExplanationError = () => {
        if (this.props.claimData.sketch) {
            return !this.props.claimData.sketch.notCompletedReason;
        }
        return true;
    };

    render = () => {
        const { claimData, readOnly, submitLiabilityCancelAction, liabilitySubmittedAction } = this.props;
        const { liabilitySubjects, events } = this.props.claimData;
        claimData.latitude && claimData.longitude && this.getGoogleMapImageData(claimData.latitude, claimData.longitude);

        return (
            <div>
                {!this.sketchCompleted() && this.showSketchExplanationError() &&
                <div id="liability-error-banner">
                    <ErrorBanner error={true}>
                        <span>Missing Information: </span>See details below
                    </ErrorBanner>
                </div>}
                <div id="liability-page" className="l-body background-very-light-gray">
                    {this.renderEvents()}
                </div>
                <div className="l-body u-color-white-background">
                    <div id="liability-analysis--container"
                         className="l-body__content l-body__main--1280">
                        <div id="liability-analysis--scene">
                            <div id="button-section" className="u-text-large u-vr-5">
                                {liabilitySubjects.length > 2 && events.length < 5 &&
                                <span className="u-hr">
                                    <button id="create-event-button"
                                            disabled={readOnly}
                                            onClick={() => this.addEvent()}
                                            className="u-vr-5-top u-vr c-btn c-btn--tertiary">
                                        <Icon id="add-event-icon" icon="plus" color="blue" size={0.7} />
                                        Create an Event
                                    </button>
                                </span>}
                                {events && events.length > 0 &&
                                <button id="submit-initial-fault"
                                        disabled={readOnly}
                                        onClick={this.launchConfirmSubmitModal}
                                        className="u-vr-5-top u-vr c-btn c-btn--primary">
                                    Submit Initial Fault
                                </button>}
                            </div>
                        </div>
                    </div>
                    <div id="footer-padding-for-cf-menu" className="u-color-white-background" />
                    <SubmitModal
                        id="confirm-modal"
                        activeModal="Confirm"
                        isActive={this.isConfirmModalActive()}
                        firstButtonCallback={() => this.onSubmitConfirmClick()}
                        onClose={this.closeModal}
                        spinner={this.props.submitState === SUBMITTING}
                        modalText="Are you sure you want to submit your initial fault?"
                    />
                    <SubmitModal
                        id="success-modal"
                        activeModal="Success"
                        isActive={this.props.submitState === SUBMITTED}
                        firstButtonCallback={this.redirectToHomePage}
                        secondButtonCallback={this.redirectToSettlementPage}
                        onClose={liabilitySubmittedAction}
                        spinner={false}
                        modalText="Your claim has been successfully submitted."
                    />
                    <SubmitModal
                        id="error-modal"
                        activeModal="Error"
                        promptType="error"
                        isActive={this.props.submitState === ERROR_SUBMITTING}
                        firstButtonCallback={() => this.onSubmitConfirmClick()}
                        onCloseCallback={submitLiabilityCancelAction}
                        spinner={this.props.submitState === SUBMITTING}
                        modalText="We are unable to submit your initial fault analysis. Would you like to try submitting this initial fault analysis again?"
                    />
                </div>
            </div>
        );
    };
}

export const mapStateToProps = ({ claimData, user, status, featureSwitches }, { history }) => {
    return {
        claimData,
        history,
        readOnly: isReadOnly(user.userRoles, claimData.locked),
        submitState: status.submitState,
        validateContributingFactorEvidence: featureSwitches.validateContributingFactorEvidence,
    };
};

export const mapDispatchToProps = {
    createEventAction,
    submitLiabilityAction,
    submitLiabilityCancelAction,
    liabilitySubmittedAction,
    setEventsValidationAction,
    saveSketchAction,
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Liability));

Liability.propTypes = {
    claimData: PropTypes.object.isRequired,
    validateContributingFactorEvidence: PropTypes.bool.isRequired,
    history: PropTypes.object.isRequired,
    readOnly: PropTypes.bool.isRequired,
    submitState: PropTypes.string.isRequired,
    createEventAction: PropTypes.func.isRequired,
    submitLiabilityAction: PropTypes.func.isRequired,
    submitLiabilityCancelAction: PropTypes.func.isRequired,
    liabilitySubmittedAction: PropTypes.func.isRequired,
    setEventsValidationAction: PropTypes.func.isRequired,
    saveSketchAction: PropTypes.func.isRequired,
};
