import React from 'react';
import {Loader, ModalDialog} from 'loon-pattern-library';
import PropTypes from 'prop-types';

export const SubmitModal = ({
                                activeModal,
                                modalText,
                                isActive,
                                firstButtonLabel,
                                secondButtonLabel,
                                firstButtonCallback,
                                secondButtonCallback,
                                spinner,
                                onClose,
                                onCloseCallback,
                            }) => {
    let modalId, firstButtonText, secondButtonText, modalTitle, isError;

    switch (activeModal) {
        case 'Confirm' : {
            modalId = 'confirmModalDialog';
            modalTitle = 'Confirm';
            firstButtonText = firstButtonLabel || 'Yes, Submit';
            isError = false;
            break;
        }
        case 'Success': {
            modalId = 'confirmSuccessModalDialog';
            modalTitle = 'Successfully Submitted';
            firstButtonText = firstButtonLabel || 'Start a New Claim';
            secondButtonText = secondButtonLabel || 'Go to Settlement';
            isError = false;
            break;
        }
        case 'Error': {
            modalId = 'errorModalDialog';
            modalTitle = 'Unable to Submit';
            firstButtonText = firstButtonLabel || 'Try Again';
            isError = true;
            break;
        }
        default: {
            break;
        }
    }

    const getFooter = () => {
        return (<div>
                {spinner && <div className="c-overlay has-loader">
                    <Loader id="spinloader" className="c-loader--xl"/>
                </div>}
                <button
                    className="c-btn c-btn--primary c-btn--sm u-hr u-hr-2 u-text-bold "
                    id="YesButton"
                    onClick={firstButtonCallback}
                >{firstButtonText}
                </button>
                {secondButtonText && <button
                    className="c-btn c-btn--tertiary c-btn--sm u-text-bold"
                    id="NoButton"
                    onClick={secondButtonCallback}
                >{secondButtonText}
                </button>}
            </div>
        );
    };
    return (
        <ModalDialog
            id={modalId}
            isActive={isActive}
            staticModal
            title={modalTitle}
            onClose={onClose}
            onCloseCallback={onCloseCallback}
            hideTrigger={true}
            className="c-modal-dialog"
            promptType={`${isError && 'error'}`}
            footer={getFooter()}>
            <div className="l-grid">
                <div className="l-grid__col l-grid__col--12">
                    <p id="modal-text">{modalText}</p>
                </div>
            </div>
        </ModalDialog>
    );
};

SubmitModal.propTypes = {
    activeModal: PropTypes.string,
    isActive: PropTypes.bool,
    firstButtonCallback: PropTypes.func,
    secondButtonCallback: PropTypes.func,
    onClose: PropTypes.func,
    onCloseCallback: PropTypes.func,
    spinner: PropTypes.bool.isRequired,
    modalText: PropTypes.string,
    firstButtonLabel: PropTypes.string,
    secondButtonLabel: PropTypes.string,
};
