import React, {Component} from 'react';
import {connect} from 'react-redux';
import {getNextAssignmentAction} from '../../actions/assignmentActions';
import {withRouter} from 'react-router-dom';
import {ASSIGNED, IN_PROGRESS} from '../../constants/loonConstants';
import PropTypes from 'prop-types';

export class NextAssignment extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        if (this.props.status === ASSIGNED || this.props.status === IN_PROGRESS) {
            this.props.history.push('/next/review');
        }
    }

    componentWillReceiveProps() {
        if (this.props.status === ASSIGNED || this.props.status === IN_PROGRESS) {
            this.props.history.push('/next/review');
        }
    }

    render() {
        return (
            <div className="l-body">
                <div className="l-body__section">
                    <div className="l-grid l-grid--center u-vr-10-top">
                        <div className="l-grid__col u-vr-12-top">
                            <img className="loon-logo u-vr" src="../images/ic-welcomelogo.svg" alt="Loon logo"/>
                            <div className="u-text-insured u-text-thin u-text-xlarge">Welcome to Loon</div>
                            <h4 className="u-align-center u-text-gray u-vr-2-top u-text-md" id="loon-instructions">
                                Click <b>Get Next Claim</b> to start making your next liability analysis.
                            </h4>
                        </div>
                        <div id="get-next-container" className="l-tile u-vr-3-top">
                            <div className="u-vr-3 u-vr-3-top u-hr-6-left u-flex">
                                <h3 className="u-text-larger u-text-gray" id="readyMessage">
                                    When you are ready…
                                </h3>
                                <button
                                    onClick={this.props.getNextAssignmentAction}
                                    id="get-next-claim-btn"
                                    className="c-btn c-btn--primary u-text-xs u-text-semibold u-hr-7-left">
                                    Get Next Claim
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export const mapStateToProps = ({claimData: {status}}, {history}) => {
    return ({
        status,
        history
    });
};

export const mapDispatchToProps = {
    getNextAssignmentAction
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(NextAssignment));

NextAssignment.propTypes = {
    status: PropTypes.string.isRequired,
    history: PropTypes.object.isRequired,
    getNextAssignmentAction: PropTypes.func.isRequired
};
