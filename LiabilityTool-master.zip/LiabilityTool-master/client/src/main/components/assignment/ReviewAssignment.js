import React, {Component} from 'react';
import {Icon} from 'loon-pattern-library';
import {formatLossDateString} from '../../helpers/dateTimeHelper';
import {Link} from 'react-router-dom';
import {onStartReviewTimeoutAction} from '../../actions/assignmentActions';
import {connect} from 'react-redux';
import {ASSIGNED} from '../../constants/loonConstants';
import PropTypes from 'prop-types';

export class ReviewAssignment extends Component {
    constructor(props) {
        super(props);
        this.timer = null;
    }

    componentDidMount() {
        this.timer = setTimeout(this.onTimeout, 1000 * 60 * 15);
    }

    componentWillUnmount() {
        clearTimeout(this.timer);
    }

    onTimeout = () => {
        if (this.props.status === ASSIGNED) {
            this.props.onStartReviewTimeoutAction(this.props.claimNumber);
        }
    };

    render() {
        const {lossDate, lossTime, lossState, status} = this.props;
        const label = (status === ASSIGNED && 'Start Review') || 'Resume Review';
        const buttonClass = (status === ASSIGNED && 'c-btn--primary') || 'c-btn--tertiary u-text-active';
        return (
            <div className="l-body">
                <div className="l-body__section">
                    <div className="l-grid u-vr-10-top">
                        <div className="l-grid__col l-grid--center u-vr-12-top">
                            <img className="loon-logo u-vr" src="../images/ic-welcomelogo.svg" alt="Loon logo"/>
                            <div className="u-text-insured u-text-thin u-text-xlarge">Welcome to Loon</div>
                            <h4 className="u-align-center u-text-gray u-vr-3-top u-text-md" id="loon-instructions">
                                Please <b>{label}</b>.
                            </h4>
                        </div>
                        <div id="review-next-container" className="l-tile u-vr-3-top">
                            <div className="u-vr-3 u-vr-3-top u-hr-6-left u-hr-6 l-grid">
                                <div className="l-grid__col--9">
                                    <div className="u-flex">
                                        <Icon icon="intersection-circle" color="loon-grayscale" size={5}/>
                                        <div className="u-hr-8-left">
                                            <div id="loss-details-label" className="u-text-gray">Loss Details</div>
                                            <h3 id="loss-details-type">Intersection Accident</h3>
                                            <div id="loss-details-time" className="u-h1 u-text-xs">
                                                {formatLossDateString(lossDate)} at {lossTime} in {lossState}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="l-grid__col--3 l-grid--middle u-flex--end u-flex">
                                    <Link className={`u-text-xs u-text-semibold c-btn ${buttonClass}`}
                                          to={'/investigate'}>
                                        {label}
                                    </Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    };
}

export const mapStateToProps = ({claimData: {claimNumber, lossDate, lossTime, lossState, status}}) => {
    return ({
        claimNumber,
        lossDate,
        lossTime,
        lossState,
        status
    });
};

export const mapDispatchToProps = {
    onStartReviewTimeoutAction
};

export default connect(mapStateToProps, mapDispatchToProps)(ReviewAssignment);

ReviewAssignment.propTypes = {
    claimNumber: PropTypes.string.isRequired,
    lossDate: PropTypes.string.isRequired,
    lossTime: PropTypes.string.isRequired,
    lossState: PropTypes.string.isRequired,
    status: PropTypes.string.isRequired,
    onStartReviewTimeoutAction: PropTypes.func.isRequired
};
