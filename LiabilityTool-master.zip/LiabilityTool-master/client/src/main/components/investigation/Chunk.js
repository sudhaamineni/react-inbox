import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { isEmpty } from 'lodash';
import { Icon } from 'loon-pattern-library';

export class Chunk extends Component {
    constructor(props) {
        super(props);
        this.state = {
            hovering: false
        };
    }

    shouldComponentUpdate(nextProps, nextState) {
        const { chunk, elapsedTime } = this.props;
        const audioPlayAlong = this.audioPlayAlong(chunk.beginTime, chunk.endTime, elapsedTime);
        const audioPlayAlongNext = this.audioPlayAlong(nextProps.chunk.beginTime, nextProps.chunk.endTime, nextProps.elapsedTime);
        if (nextProps.autoScroll && !audioPlayAlong && audioPlayAlongNext) {
            this.setScroll();
        }
        const nlpForCategory = this.getNlpForCategory(nextProps.nlpCategory);
        if (nlpForCategory && nlpForCategory.filter(n => n.categoryIndex === nextProps.nlpCategoryIndex)[0]) {
            this.setScroll();
        }
        return this.shouldUpdate(nextProps, nextState, audioPlayAlong, audioPlayAlongNext);
    };

    audioPlayAlong = (beginTime, endTime, elapsedTime) => {
        return elapsedTime >= beginTime && elapsedTime <= endTime;
    };

    shouldUpdate = (nextProps, nextState, audioPlayAlong, audioPlayAlongNext) => {
        const { hovering } = this.state;
        const { chunk, highlightMode, nlpCategory } = this.props;
        const { highlightTexts } = chunk;
        if (audioPlayAlong !== audioPlayAlongNext) {
            return true;
        }
        if (highlightMode !== nextProps.highlightMode) {
            return true;
        }
        if (highlightTexts !== nextProps.chunk.highlightTexts) {
            return true;
        }
        if (nlpCategory !== nextProps.nlpCategory) {
            if (!isEmpty(nlpCategory) && !isEmpty(nextProps.nlpCategory)
                && !this.getNlpForCategory(nlpCategory) && !this.getNlpForCategory(nextProps.nlpCategory)) {
                return false;
            }
            return true;
        }
        if (hovering !== nextState.hovering) {
            return true;
        }
        return false;
    };

    setScroll = () => {
        const chunk0 = document.getElementById('chunk0');
        const chunk = document.getElementById(`chunk${this.props.id}`);
        const summary = document.getElementById('transcript-content');

        summary.scrollTop = chunk.offsetTop - chunk0.offsetTop - 100;
    };

    getNlpForCategory = nlpCategory => {
        const { chunk } = this.props;
        if (isEmpty(nlpCategory) || !chunk.nlp[nlpCategory] || chunk.nlp[nlpCategory].length === 0) {
            return undefined;
        }
        return chunk.nlp[nlpCategory];
    };

    isHighlight = (hIndex, highlights, i) => {
        return hIndex < highlights.length && i >= highlights[hIndex].beginIndex && i < highlights[hIndex].endIndex;
    };

    isNlp = (nIndex, nlps, i) => {
        return nIndex < nlps.length && i >= nlps[nIndex].beginIndex && i < nlps[nIndex].endIndex;
    };

    getSpanClass = (isHighlight, isNlp, isActive) => {
        let spanClass = '';
        if (isHighlight) {
            spanClass = 'chunk-highlight';
        }
        if (isNlp) {
            spanClass = spanClass + ' chunk-nlp ' + (isActive ? 'u-text-active' : 'u-text-gray-dark');
        }
        return spanClass;
    };

    getNlps = () => {
        const { nlpCategory, chunk } = this.props;
        const { nlp } = chunk;
        return nlp && !isEmpty(nlpCategory) && nlp[nlpCategory] ? nlp[nlpCategory] : [];
    };

    getHighlights = () => {
        const { chunk } = this.props;
        return chunk.highlightTexts ? chunk.highlightTexts.sort((a, b) => a.beginIndex - b.beginIndex) : [];
    };

    // Marking here means either highlight or NLP categorization
    isEndOfMarking = (index, markings, i) => {
        return index < markings.length && i === markings[index].endIndex;
    };

    renderSpans = audioPlayAlong => {
        const { hovering } = this.state;
        const { text } = this.props.chunk;
        const highlights = this.getHighlights();
        const nlps = this.getNlps();
        const spans = [], addedNlpIndices = [];
        let bIndex = 0, hIndex = 0, nIndex = 0, prevClass = '';
        for (let i = 0; i < text.length; i++) {
            const isHighlight = this.isHighlight(hIndex, highlights, i);
            const isNlp = this.isNlp(nIndex, nlps, i);
            const isActive = audioPlayAlong || hovering;
            const spanClass = this.getSpanClass(isHighlight, isNlp, isActive);
            if (i > 0 && prevClass !== spanClass) {
                spans.push(this.addNlpLocationIndicator(spans, prevClass, nIndex, nlps, addedNlpIndices));
                spans.push(this.getSpan(bIndex, i, prevClass, highlights, hIndex));
                bIndex = i;
                if (this.isEndOfMarking(hIndex, highlights, i)) {
                    hIndex++;
                }
                if (this.isEndOfMarking(nIndex, nlps, i)) {
                    nIndex++;
                }
            }
            prevClass = spanClass;
        }
        spans.push(this.addNlpLocationIndicator(spans, prevClass, nIndex, nlps, addedNlpIndices));
        spans.push(this.getSpan(bIndex, undefined, prevClass, highlights, hIndex));
        return spans;
    };

    addNlpLocationIndicator = (spans, spanClass, nIndex, nlps, addedNlpIndices) => {
        let nlpCategoryIndex;
        if (spanClass.includes('chunk-nlp')) {
            nlpCategoryIndex = nIndex === 0 ? nlps[0].categoryIndex : nlps[nIndex - 1].categoryIndex;
        }
        if (!nlpCategoryIndex || addedNlpIndices.includes(nlpCategoryIndex)) {
            return;
        }
        addedNlpIndices.push(nlpCategoryIndex);
        spans.push(
            <span key={`nlp-loc-ind-${nIndex}`} className="c-badge c-badge--icon-pin">
                <Icon icon="pin-drop" color="magenta" size={1} />
                <span className="u-text-x-tiny u-text-semibold">{nlpCategoryIndex}</span>
            </span>
        );
    };

    getSpan = (bIndex, eIndex, className, highlights, hIndex) => {
        const { id, chunk, handleHighlightClick } = this.props;
        const { text } = chunk;
        let spanId = `chunk${id}-text${bIndex}`;
        if (className.includes('chunk-highlight')) {
            spanId = `${spanId}-highlight${highlights[hIndex].entityIndex}`;
        }
        return (
            <span key={spanId} id={spanId} className={className}
                  onClick={className.includes('chunk-highlight') ? e => handleHighlightClick(e) : undefined}>
                {eIndex ? text.substring(bIndex, eIndex) : text.substring(bIndex)}
            </span>
        );
    };

    getChunkClass = audioPlayAlong => {
        const { highlightMode, nlpCategory } = this.props;
        let inactiveClassName;

        if (highlightMode) {
            inactiveClassName = !isEmpty(nlpCategory) ? ' chunk-highlight-nlp-nosel' : '';
            return 'chunk-highlight-default' + (audioPlayAlong ? ' u-text-active' : inactiveClassName);
        }
        inactiveClassName = !isEmpty(nlpCategory) ? 'chunk-nlp-nosel' : 'chunk-default';
        return audioPlayAlong ? 'chunk-play u-text-active' : inactiveClassName;
    };

    render() {
        const { id, chunk, elapsedTime, onSetSeekTo, highlightMode, nlpCategory } = this.props;
        const { beginTime, endTime } = chunk;
        const audioPlayAlong = this.audioPlayAlong(beginTime, endTime, elapsedTime);
        return (
            <div key={`chunk${id}`} id={`chunk${id}`} className={this.getChunkClass(audioPlayAlong)}
                 onClick={(!highlightMode && (() => onSetSeekTo(chunk.beginTime))) || undefined}
                 onMouseOver={(!highlightMode && !isEmpty(nlpCategory) && !audioPlayAlong && (() => this.setState({ hovering: true }))) || undefined}
                 onMouseOut={(!highlightMode && !isEmpty(nlpCategory) && !audioPlayAlong && (() => this.setState({ hovering: false }))) || undefined}>
                {this.renderSpans(audioPlayAlong)}
            </div>
        );
    }
}

Chunk.propTypes = {
    id: PropTypes.number.isRequired,
    chunk: PropTypes.object.isRequired,
    elapsedTime: PropTypes.number.isRequired,
    onSetSeekTo: PropTypes.func.isRequired,
    autoScroll: PropTypes.bool.isRequired,
    highlightMode: PropTypes.bool.isRequired,
    handleHighlightClick: PropTypes.func.isRequired,
    nlpCategory: PropTypes.string.isRequired,
    nlpCategoryIndex: PropTypes.number.isRequired
};

export default Chunk;
