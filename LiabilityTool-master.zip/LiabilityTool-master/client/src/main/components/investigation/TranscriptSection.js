import React, {Component} from 'react';
import PropTypes from 'prop-types';
import {connect} from 'react-redux';
import {FilterList, Icon, Loader} from 'loon-pattern-library';
import {Link, withRouter} from 'react-router-dom';
import Highlighter from './Highlighter';
import Transcript from './Transcript';
import {getQueryStringValue} from '../../helpers/claimDataHelper';
import {saveReportedPciAction} from '../../actions/claimDataActions';
import {convertZuluTimeToLocalTime} from '../../helpers/dateTimeHelper';
import PCIModal from './PCIModal';

export class TranscriptSection extends Component {
    constructor(props) {
        super(props);
        this.state = {
            autoScroll: true,
            highlightMode: props.highlightMode,
            nlpCategory: '',
            nlpCategoryIndex: 0,
            filterMode: true,
            showSensitiveModal: false
        };
    }

    handleReportSensitiveClick = () => {
        this.setState({...this.state, showSensitiveModal: true});
    };

    handleReportSensitiveModalClose = () => {
        this.setState({...this.state, showSensitiveModal: false});
    };

    handleReportClick = (voiceId, transcriptId, pciCategories) => {
        const {saveReportedPciAction, claimNumber} = this.props;
        saveReportedPciAction(claimNumber, voiceId, transcriptId, pciCategories);
        this.setState({...this.state, showSensitiveModal: false});
    };

    getTranscriptStatus = (voiceAttachment) => {
        const {retrievingAttachments, transcripts} = this.props;
        const {success, errors} = transcripts;
        if (retrievingAttachments) {
            return 'LOADING';
        } else {
            if (voiceAttachment && voiceAttachment.sourceVoiceId) {
                if (errors.includes(voiceAttachment.sourceVoiceId)) {
                    return 'ERROR';
                } else if (success.includes(voiceAttachment.sourceVoiceId)) {
                    return 'SUCCESS';
                } else {
                    return 'LOADING';
                }
            } else {
                return 'NO DATA';
            }
        }
    };

    renderLoadingTranscriptSection = () => {
        return (
            <div>
                <div className="u-text-large u-hr-3-left u-vr-2-top u-text-normal l-grid__col--3 u-vr-2">
                    Transcript
                </div>
                <hr className="participant-section-header-border"/>
                <div className="u-vr-4-top u-vr-4">
                    <Loader className="c-loader--lg"/>
                </div>
            </div>
        );
    };

    renderNoDataTranscriptSection = () => {
        return (
            <div>
                <div id="empty-transcript-title"
                     className="u-text-large u-hr-3-left u-vr-2-top u-text-normal l-grid__col--3 u-vr-2">
                    Transcript
                </div>
                <hr className="participant-section-header-border"/>
                <div className="u-vr-4-top u-vr-4 u-hr-6-left">
                    <span id="empty-transcript" className="u-text-sm">No transcripts available</span>
                    <span className="u-display--block u-vr-top u-anchor u-text-sm" style={{lineHeight: 1}}>
                        <a className="c-link" role="button">
                            <Icon icon="request" color="active" size={1}/>
                            <span id="empty-transcript-req-info" className="u-hr-left u-text-semibold">
                                Request Information
                            </span>
                        </a>
                    </span>
                </div>
            </div>
        );
    };

    renderErrorTranscriptSection = () => {
        return (
            <div>
                <div className="l-grid l-grid-col">
                    <div id="transcript-error-title"
                         className="u-text-large u-hr-3-left u-vr-2-top u-text-normal l-grid__col--3 u-vr-2">Transcript
                    </div>
                </div>
                <hr className="participant-section-header-border"/>
                <div className="u-vr-4-top u-vr-4 u-hr-2-left l-grid">
                    <Icon id="transcript-file-alert"
                          className="c-icon l-grid__col--1\@xsmall"
                          color="loon-pink"
                          icon="file-alert"
                          size={1}
                    />
                    <div className="l-grid__col--11 u-hr-15-left">
                        <div id="unable-to-load" className="u-text-sm u-text-error u-align-super">
                            Unable to load transcript
                        </div>
                        <span id="try-again" className="u-text-sm dark-gray">Try again later or </span>
                        <Link id="transcript-refresh"
                              className="c-link u-text-semibold"
                              to={'/investigate?scrollTo=investigation-page--participants'}>
                            Refresh
                        </Link>
                    </div>
                </div>
            </div>
        );
    };

    renderSuccessTranscriptSection = (voiceAttachment) => {
        const {autoScroll, highlightMode, nlpCategory, nlpCategoryIndex, filterMode, showSensitiveModal} = this.state;
        const {claimNumber, audioPlaying, audioIndex, elapsedTime, togglePlayPause, onSetSeekTo, transcriptContentStyle, readOnly} = this.props;
        const transcriptUrl = voiceAttachment.sourceTranscriptUrl;
        const transcriptId = transcriptUrl.substring(transcriptUrl.lastIndexOf('/') + 1);
        return (
            <div id="transcript">
                <div id="transcript-header">
                    <div className="l-grid l-grid__col">
                        <div className="l-grid__col--8">
                            <div className="u-flex u-flex--middle transcript-header-left u-vr u-vr-top u-hr-3-left">
                                <div className="u-text-large" id="transcriptLabel">Transcript</div>
                                <div id="miniAudioPlayerImage"
                                     className={`u-hr-3-left u-flex__item--middle ${audioPlaying ? 'pause-icon' : 'play-icon'}`}
                                     onClick={() => togglePlayPause()}
                                />
                                <div className="highlight-toolbar u-hr-3-left u-align-center">
                                    <Highlighter highlightMode={highlightMode} toggleHighlight={this.toggleHighlight}/>
                                </div>
                                <div className="u-hr-3-left">
                                    <button
                                        id="filterTranscriptLabel"
                                        onClick={this.onToggleFilter}
                                        className={`c-btn animated ${filterMode ? 'c-btn--show-transcript-filters--active' : 'c-btn--show-transcript-filters'}`}>
                                        <Icon strokeLinecap="round" icon="filter" strokeWidth={2} size={1.25}/>
                                        <span
                                            className="c-btn--show-transcript-filters__text">Filter Transcript</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                        {!voiceAttachment.reportedPciDate ?
                            <div className="l-grid__col--4 u-flex u-flex--middle u-flex--end">
                                <a id="reportSensitiveInfoLabel" className="u-flex u-flex--middle u-hr-3"
                                   onClick={this.handleReportSensitiveClick}
                                >
                                    <Icon id="add-contributing-icon" icon="danger-recognition" color="action"
                                          size={1.25}/>
                                    <span id="add-contributing-label" className="u-hr-left u-text-xs">
                                    Report sensitive information
                                </span>
                                </a>
                            </div>
                            :
                            <div className="l-grid__col--4 u-flex u-flex--middle u-flex--end">
                                <span>
                                    <Icon id="reported-sensitive-icon" icon="danger-recognition" color="loon-gray-dark"
                                          size={1}/>
                                    <span id="reported-sensitive-label"
                                          className="u-hr-left u-hr-2 u-text-xs u-align-top">
                                        Sensitive Information Reported
                                    </span>
                                    <br/>
                                        <p>
                                            <span id="reported-sensitive-date-label"
                                                  className="u-text-xs u-hr-left u-hr-2">
                                                {convertZuluTimeToLocalTime(voiceAttachment.reportedPciDate)}
                                            </span>
                                        </p>
                                </span>
                            </div>}
                    </div>

                </div>
                {filterMode
                && <FilterList
                    items={this.buildFilterListItems(voiceAttachment)}
                    onSelect={(nlpCategory, nlpCategoryIndex) => this.setNlpCategory(nlpCategory, nlpCategoryIndex)}
                    onClose={() => this.setNlpCategory('', 0)}
                    onNextClick={nlpCategoryIndex => this.setNlpCategory(nlpCategory, nlpCategoryIndex)}
                    onPrevClick={nlpCategoryIndex => this.setNlpCategory(nlpCategory, nlpCategoryIndex)}
                />
                }
                <div
                    id="transcript-content"
                    style={transcriptContentStyle}
                    className="u-text-gray-dark">
                    <Transcript
                        claimNumber={claimNumber}
                        audioPlaying={audioPlaying}
                        audioIndex={audioIndex}
                        elapsedTime={elapsedTime}
                        togglePlayPause={togglePlayPause}
                        onSetSeekTo={time => onSetSeekTo(time)}
                        autoScroll={autoScroll}
                        highlightMode={highlightMode}
                        nlpCategory={nlpCategory}
                        nlpCategoryIndex={nlpCategoryIndex}
                    />
                    {showSensitiveModal &&
                    <PCIModal
                        onSubmit={(pciCategories) => this.handleReportClick(voiceAttachment.sourceVoiceId, transcriptId, pciCategories)}
                        onClose={() => this.handleReportSensitiveModalClose()}
                        readOnly={readOnly}
                    />}

                </div>
            </div>
        );
    };

    toggleHighlight = () => {
        this.setState({
            autoScroll: false,
            highlightMode: !this.state.highlightMode
        });
    };

    onToggleFilter = () => {
        this.setState({
            filterMode: !this.state.filterMode,
            nlpCategory: ''
        });
    };

    setNlpCategory = (nlpCategory, nlpCategoryIndex) => {
        this.setState({
            autoScroll: false,
            nlpCategory,
            nlpCategoryIndex
        });
    };

    buildFilterListItems = (voiceAttachment) => {
        const {transcripts} = this.props;
        const items = [];
        const categories = transcripts.nlp[voiceAttachment.sourceVoiceId];
        categories.map(c => c.categoryName).sort().forEach(categoryName => {
            const category = categories.filter(c => c.categoryName === categoryName)[0];
            items.push({
                label: categoryName,
                value: categoryName,
                matches: category.categoryIndices ? category.categoryIndices.length : 0
            });
        });
        return items;
    };

    render() {
        const {voiceAttachments, audioIndex} = this.props;
        const voiceAttachment = (voiceAttachments && voiceAttachments.length > 0
            && voiceAttachments[audioIndex]) || undefined;
        const transcriptStatus = this.getTranscriptStatus(voiceAttachment);
        if (transcriptStatus === 'LOADING') {
            return this.renderLoadingTranscriptSection();
        } else if (transcriptStatus === 'NO DATA') {
            return this.renderNoDataTranscriptSection();
        } else if (transcriptStatus === 'ERROR') {
            return this.renderErrorTranscriptSection();
        } else if (transcriptStatus === 'SUCCESS') {
            return this.renderSuccessTranscriptSection(voiceAttachment);
        }
        return null;
    }
}

export const mapStateToProps = ({claimData, transcripts, status}, {location}) => {
    return {
        retrievingAttachments: status.retrievingAttachments,
        voiceAttachments: claimData.voiceAttachments,
        transcripts,
        highlightMode: getQueryStringValue(location, 'highlightMode') === 'on'
    };
};

export const mapDispatchToProps = {
    saveReportedPciAction: saveReportedPciAction
};
export default withRouter(connect(mapStateToProps, mapDispatchToProps)(TranscriptSection));

TranscriptSection.propTypes = {
    claimNumber: PropTypes.string.isRequired,
    audioPlaying: PropTypes.bool.isRequired,
    audioIndex: PropTypes.number.isRequired,
    elapsedTime: PropTypes.number.isRequired,
    togglePlayPause: PropTypes.func.isRequired,
    onSetSeekTo: PropTypes.func.isRequired,
    transcriptContentStyle: PropTypes.object.isRequired,
    retrievingAttachments: PropTypes.bool.isRequired,
    voiceAttachments: PropTypes.array.isRequired,
    transcripts: PropTypes.object.isRequired,
    highlightMode: PropTypes.bool.isRequired,
    readOnly: PropTypes.bool.isRequired,
    saveReportedPciAction: PropTypes.func.isRequired
};
