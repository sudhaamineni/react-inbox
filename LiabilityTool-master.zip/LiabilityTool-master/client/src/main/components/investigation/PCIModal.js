import React, { Component } from 'react';
import { FormOption, Icon, ModalDialog } from 'loon-pattern-library';
import { PCI_OPTIONS } from '../../constants/loonConstants';
import PropTypes from 'prop-types';

export default class PCIModal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            checkedValues: [],
        };
    };

    handleCheckboxChange = (value) => {
        let {checkedValues} = this.state;
        let updatedValues = [...checkedValues];
        if (checkedValues.includes(value)) {
            this.setState({ checkedValues: updatedValues.filter(val => val !== value) });
        } else {
            updatedValues.push(value);
            this.setState({ checkedValues: updatedValues });
        }
    };

    render() {
        const { checkedValues } = this.state;
        const { onSubmit, onClose, readOnly } = this.props;
        return (
            <ModalDialog
                showCloseBtn={true}
                staticModal
                title={
                    <div id="reportSensitiveInformationModalHeader" className="u-flex u-flex--middle">
                        <Icon icon="danger-recognition" color="action" size={1.75} />
                        <span className="u-hr-left">Report Sensitive Information</span>
                    </div>
                }
                hideTrigger
                isActive={true}
                isPrompt={false}
                onClose={onClose}
                footer={
                    <ul className="l-h-list">
                        <li>
                            <button
                                id="report-sensitive-information-button"
                                className="c-btn c-btn--primary c-btn--sm"
                                disabled={checkedValues.length === 0}
                                onClick={() => onSubmit(checkedValues)}>
                                Report
                            </button>
                        </li>
                    </ul>
                }
            >
                <div className="u-text-small u-text-color-gray-333333 u-text-weight-300">
                    <div className="u-vr-2">
                        Transcripts that contain the following sensitive information must be reported immediately:
                    </div>
                    {PCI_OPTIONS.map(option =>
                        <div className="u-vr-top" key={option.value}>
                            <FormOption onChange={() => this.handleCheckboxChange(option.value)} readOnly={readOnly}>
                                <span className="u-text-xs u-text-color-gray-4a4a4a">{option.displayText}</span>
                            </FormOption>
                        </div>
                    )}
                    <div className="u-vr-5-top">
                        Once reported, any sensitive information will be removed from the transcript.
                    </div>
                </div>
            </ModalDialog>
        );
    };
}

PCIModal.propTypes = {
    readOnly: PropTypes.bool.isRequired,
    onSubmit: PropTypes.func.isRequired,
    onClose: PropTypes.func.isRequired,
};
