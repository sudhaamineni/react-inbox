import React, {Component} from 'react';
import PropTypes from 'prop-types';
import {
    createId,
    getAssetTypeShortName,
    getParticipantName,
    getQueryStringValue,
    getVehicleInfo,
    isInsured,
    isReadOnly
} from '../../helpers/claimDataHelper';
import {Gallery, ParticipantListItem} from 'loon-pattern-library';
import AssetDamages from './AssetDamages';
import {photoRotationAction, photoToggleBookmarkAction} from '../../actions/photoActions';
import {withRouter} from 'react-router-dom';
import {connect} from 'react-redux';
import analyticsHelper from '../../helpers/analyticsHelper';
import {isEmpty} from 'lodash';
import {PEDESTRIAN_BICYCLIST} from '../../constants/loonConstants';
import {saveEvidenceAction} from '../../actions/attachmentsActions';

export class ParticipantAssetDamages extends Component {
    constructor(props) {
        super(props);
        this.state = {
            participantIndex: 0
        };
    }

    trackGalleryOpen = () => {
        const galleryOpenEvent = {
            message: 'success',
            eventAction: 'InvestigationPage_Gallery_GalleryOpen',
            eventSource: 'link',
            errorCode: '',
        };
        analyticsHelper.trackEvent(galleryOpenEvent);
    };

    getPhotosForGallery = () => {
        const {liabilitySubjects, evidences} = this.props;

        const photos = [];
        liabilitySubjects[this.state.participantIndex].photoAttachments.forEach(photoAttachment => {
            const evidence = evidences.find(e => e.sourceId === photoAttachment.dcfId);

            photos.push({
                url: photoAttachment.url,
                isBookmarked: photoAttachment.bookmarked,
                rotation: photoAttachment.rotation,
                hasError: false,
                evidence: evidence && evidence.category
            });
        });
        return photos;
    };

    isNewBookmark = (updatedPhoto, photoAttachment) => {
        return updatedPhoto.isBookmarked && !photoAttachment.bookmarked;
    };

    isRemovingBookmark = (updatedPhoto, photoAttachment) => {
        return !updatedPhoto.isBookmarked && photoAttachment.bookmarked;
    };

    isCategoryUpdate = (updatedPhoto, photoAttachment) => {
        return updatedPhoto.isBookmarked && photoAttachment.bookmarked;
    };

    handleBookmarksChange = (updatedPhotoIndex, updatedPhoto) => {
        const {claimNumber, liabilitySubjects, evidences, photoToggleBookmarkAction, saveEvidenceAction, events} = this.props;
        const {participantIndex} = this.state;
        const participant = liabilitySubjects[participantIndex];
        const updatedPhotoAttachments = JSON.parse(JSON.stringify(liabilitySubjects[participantIndex])).photoAttachments;
        let updatedEvidences = JSON.parse(JSON.stringify(evidences));
        const updatedEvents = JSON.parse(JSON.stringify(events));
        let isToggle = true;
        const updatedPhotoAttachment = updatedPhotoAttachments.find(p => p.url === updatedPhoto.url);
        if (this.isNewBookmark(updatedPhoto, updatedPhotoAttachment)) {
            updatedPhotoAttachment.bookmarked = true;
            updatedEvidences.push({
                id: createId('photo'),
                type: 'photo',
                sourceId: updatedPhotoAttachment.dcfId,
                photoUrl: updatedPhotoAttachment.url,
                rotation: updatedPhotoAttachment.rotation,
                role: participant.role,
                participantPartyId: participant.participantPartyId,
                participantSourceId: participant.participantSourceId,
            });
        } else if (this.isRemovingBookmark(updatedPhoto, updatedPhotoAttachment)) {
            updatedPhotoAttachment.bookmarked = false;
            updatedEvidences = updatedEvidences.filter(e => e.sourceId !== updatedPhotoAttachment.dcfId);
            const removeEvidenceId = evidences.filter(e => e.sourceId === updatedPhotoAttachment.dcfId)[0].id;

            updatedEvents.forEach(event => {
                event.involvedParties.forEach(ip => {
                    ip.contributingFactors.forEach(cF => {
                            if (cF.evidenceIds) {
                                cF.evidenceIds = cF.evidenceIds.filter(id => id !== removeEvidenceId);
                            }
                        }
                    );
                });
            });
        } else if (this.isCategoryUpdate(updatedPhoto, updatedPhotoAttachment)) {
            const updatedEvidence = updatedEvidences.find(e => e.sourceId === updatedPhotoAttachment.dcfId);
            if (updatedPhoto.evidence !== updatedEvidence.category) {
                updatedEvidence.category = updatedPhoto.evidence;
                isToggle = false;
                saveEvidenceAction(claimNumber, updatedEvidence);
            }
        }

        if (isToggle) {
            photoToggleBookmarkAction(claimNumber, liabilitySubjects[participantIndex].participantSourceId, updatedPhotoAttachments, updatedEvidences, updatedEvents);
        }
    };

    handleRotationChange = (updatedPhotoIndex, updatedPhoto) => {
        const {claimNumber, liabilitySubjects, evidences, photoRotationAction} = this.props;
        const updatedPhotoAttachments = JSON.parse(JSON.stringify(liabilitySubjects[this.state.participantIndex])).photoAttachments;
        const updatedEvidences = JSON.parse(JSON.stringify(evidences));
        updatedPhotoAttachments.forEach(pa => {
            if (updatedPhoto.url === pa.url) {
                pa.rotation = updatedPhoto.rotation;
            }
        });
        updatedEvidences.forEach(e => {
            if (updatedPhoto.url === e.photoUrl) {
                e.rotation = updatedPhoto.rotation;
            }
        });

        photoRotationAction(claimNumber, liabilitySubjects[this.state.participantIndex].participantSourceId, updatedPhotoAttachments, updatedEvidences);
    };

    getDriverName = (participant) => {
        return (isEmpty(participant.driverName) ? 'UNKNOWN' : participant.driverName.toUpperCase());
    };

    render = () => {
        const {
            readOnly,
            liabilitySubjects,
            attachmentsRetrievalFailed,
            isGalleryActive,
        } = this.props;
        const liabilitySubjectSelected = liabilitySubjects[this.state.participantIndex];
        return (
            <div id="participant-asset-damages-container" className="participant-asset-damages-container u-vr-5-top">
                <div className="u-flex u-hr-3-left u-vr-3-top">
                    <div id="title" className="u-text-large u-flex__item--baseline">Asset Damages
                        ({liabilitySubjects.length})
                    </div>
                </div>
                <hr className="participant-asset-hr u-vr-3-top"/>
                {liabilitySubjects.map((p, i) =>
                    <ParticipantListItem
                        key={i}
                        isActive={i === this.state.participantIndex}
                        isInsured={isInsured(p)}
                        icon={p.role === PEDESTRIAN_BICYCLIST ? 'pedestrian' : getAssetTypeShortName(p.asset.assetTypeDescription)}
                        vehicle={getVehicleInfo(p)}
                        name={getParticipantName(p).toUpperCase() + (p.isDriver ? ' (DRIVER)' : '')}
                        driver={p.isDriver ? '' : this.getDriverName(p)}
                        onClick={() => this.setState({participantIndex: i})}
                    />
                )}
                <hr className="participant-asset-hr"/>
                <div className="u-hr-3-left u-vr-2-top u-text-xs">{getVehicleInfo(liabilitySubjectSelected)}</div>
                <hr className="participant-asset-hr u-vr-2-top"/>
                <div className="participant-asset-damages u-flex">
                    <div className="u-vr-3-top u-hr-3-left">
                        <Gallery
                            isActive={isGalleryActive}
                            name={getParticipantName(liabilitySubjectSelected)}
                            isInsured={isInsured(liabilitySubjectSelected)}
                            vehicle={getVehicleInfo(liabilitySubjectSelected)}
                            photos={this.getPhotosForGallery()}
                            assetDamages={liabilitySubjectSelected.asset.damages}
                            hasError={attachmentsRetrievalFailed}
                            readOnly={readOnly}
                            onOpen={this.trackGalleryOpen}
                            onBookmarksChange={this.handleBookmarksChange}
                            onPhotoRotationChange={this.handleRotationChange}
                        />
                    </div>
                    <AssetDamages damages={liabilitySubjectSelected.asset.damages}/>
                </div>
            </div>
        );
    };
}

export const mapStateToProps = ({user, claimData, status}, {location}) => {
    return {
        claimNumber: claimData.claimNumber,
        liabilitySubjects: claimData.liabilitySubjects,
        evidences: claimData.evidences,
        attachmentsRetrievalFailed: status.attachmentsRetrievalFailed,
        retrievingAttachments: status.retrievingAttachments,
        isGalleryActive: 'Gallery' === getQueryStringValue(location, 'activeComponent'),
        readOnly: isReadOnly(user.userRoles, claimData.locked),
        events: claimData.events
    };
};

export const mapDispatchToProps = {
    photoToggleBookmarkAction,
    photoRotationAction,
    saveEvidenceAction
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(ParticipantAssetDamages));

ParticipantAssetDamages.propTypes = {
    claimNumber: PropTypes.string.isRequired,
    liabilitySubjects: PropTypes.array.isRequired,
    evidences: PropTypes.array.isRequired,
    events: PropTypes.array.isRequired,
    attachmentsRetrievalFailed: PropTypes.bool.isRequired,
    retrievingAttachments: PropTypes.bool.isRequired,
    isGalleryActive: PropTypes.bool.isRequired,
    readOnly: PropTypes.bool.isRequired,
    photoToggleBookmarkAction: PropTypes.func.isRequired,
    photoRotationAction: PropTypes.func.isRequired,
    saveEvidenceAction: PropTypes.func.isRequired
};
