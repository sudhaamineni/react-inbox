import React, {Component} from 'react';
import Chunk from './Chunk';
import {saveHighlightAction} from '../../actions/transcriptActions';
import {connect} from 'react-redux';
import PropTypes from 'prop-types';
import {Bars, EvidenceMenu} from 'loon-pattern-library';
import {transcriptEvidenceMenuOptions} from '../../constants/loonConstants';
import {createId, getCallTypeLabel} from '../../helpers/claimDataHelper';
import {saveEvidenceAction} from '../../actions/attachmentsActions';

export class Transcript extends Component {
    constructor(props) {
        super(props);
        this.lastProcessId = 0;
        this.state = {evidenceMenu: {}};
    }

    componentDidMount() {
        window.addEventListener('mousemove', this.positionEditEvidenceTooltip);
    };

    componentWillUnmount() {
        window.removeEventListener('mousemove', this.positionEditEvidenceTooltip);
    };

    renderChunks = () => {
        const {
            audioPlaying,
            audioIndex,
            elapsedTime,
            togglePlayPause,
            onSetSeekTo,
            autoScroll,
            highlightMode,
            nlpCategory,
            nlpCategoryIndex,
            voiceAttachments,
            transcripts
        } = this.props;
        const paragraphs = [];

        transcripts[voiceAttachments[audioIndex].sourceVoiceId].forEach((c, i) => {
            const followAlongTextStyle = this.getFollowAlongTextStyle(c, elapsedTime);
            const cursorClassName = highlightMode ? 'chunk-highlight-default' : '';

            paragraphs.push(
                <div id={`paragraph${i}`} key={`paragraph${i}`} className="l-grid u-vr-2-top u-hr">
                    <div className="l-grid__col--3">
                        <div className="l-grid ">
                            <div
                                className={`speaker l-grid__col--8 u-align-right ${followAlongTextStyle} ${cursorClassName}`}
                                id={`chunk${i}-speaker`}>
                                {c.speaker.length > 14 ? c.speaker.substr(0, 12) + '..' : c.speaker}
                            </div>
                            <div id={`chunk${i}-begin-time`}
                                 className={`l-grid__col--2 u-align-center ${followAlongTextStyle}`}>
                                {this.formatStartTime(c.beginTime)}
                            </div>
                            <div className="l-grid__col--2">
                                {this.shouldRenderBars(c, elapsedTime)
                                && <Bars isPlaying={audioPlaying} onClicked={togglePlayPause}/>}
                            </div>
                        </div>
                    </div>
                    <div className="u-text-small l-grid__col--9">
                        <Chunk
                            id={i}
                            chunk={c}
                            elapsedTime={elapsedTime}
                            onSetSeekTo={time => onSetSeekTo(time)}
                            autoScroll={autoScroll}
                            highlightMode={highlightMode}
                            handleHighlightClick={this.handleHighlightClick}
                            nlpCategory={nlpCategory}
                            nlpCategoryIndex={nlpCategoryIndex}
                        />
                    </div>
                </div>
            );
        });
        return paragraphs;
    };

    getFollowAlongTextStyle = (chunk, elapsedTime) => {
        if (chunk.beginTime <= elapsedTime && chunk.endTime > elapsedTime) {
            return 'u-text-xs u-text-bold u-text-light-blue';
        }
        return 'u-text-xs u-text-semibold u-text-gray-lighter';
    };

    formatStartTime = beginTime => {
        let seconds = beginTime.toString().split('.')[0];
        let minutes = '' + Math.floor(seconds / 60);
        seconds = Math.round(seconds % 60);
        if (seconds < 10) {
            seconds = '0' + seconds;
        }
        return minutes + ':' + seconds;
    };

    shouldRenderBars = (chunk, elapsedTime) => {
        return elapsedTime !== 0.00 && chunk.beginTime <= elapsedTime && chunk.endTime > elapsedTime;
    };

    handleHighlightClick = e => {
        if (this.props.highlightMode) {
            const category = this.getEvidenceFromHighlightId(e.target.id).category;
            this.setEvidenceMenuState(e, e.target.id, category ? category : '');
            document.getElementById('edit-evidence-tooltip').style.visibility = 'hidden';
        }
    };

    handleMouseUp = e => {
        const selection = window.getSelection();
        const anchorNodeId = selection.anchorNode.parentNode.id;
        const focusNodeId = selection.focusNode.parentNode.id;
        this.props.highlightMode
        && selection.toString() !== ''
        && anchorNodeId.startsWith('chunk')
        && focusNodeId.startsWith('chunk')
        && !((anchorNodeId.endsWith('-speaker') || anchorNodeId.endsWith('-begin-time')) && anchorNodeId.split('-')[0] === focusNodeId.split('-')[0])
        && this.addHighlight(e);
        window.getSelection().removeAllRanges();
    };

    addHighlight = e => {
        const {claimNumber, voiceAttachments, audioIndex, saveHighlightAction,events} = this.props;
        const newHighlightEntity = this.createHighlightEntity();
        if (newHighlightEntity) {
            const highlight = this.mergedHighlightEntities(newHighlightEntity);
            saveHighlightAction(claimNumber, voiceAttachments[audioIndex].sourceVoiceId, highlight.newHighlights, highlight.newEvidences, events);
            this.setEvidenceMenuState(e, this.getEvidenceMenuRefId(highlight.newHighlights), undefined);
        }
    };

    createHighlightEntity = () => {
        const highlighted = this.getHighlighted();
        if (highlighted) {
            const {voiceAttachments, audioIndex, transcripts} = this.props;
            const chunks = transcripts[voiceAttachments[audioIndex].sourceVoiceId];
            const beginChunk = chunks[highlighted.beginChunkIndex];
            const endChunk = chunks[highlighted.endChunkIndex];
            const highlightTexts = [];
            const audioHighlightTimeStart =
                this.calculateAudioHighlightTimeStart(
                    beginChunk.beginTime,
                    beginChunk.endTime,
                    beginChunk.text.length,
                    highlighted.beginTextIndex
                );
            if (highlighted.beginChunkIndex === highlighted.endChunkIndex) {
                // highlight is within the same chunk
                highlightTexts.push({
                    chunkIndex: highlighted.beginChunkIndex,
                    beginIndex: highlighted.beginTextIndex,
                    endIndex: highlighted.endTextIndex,
                    text: beginChunk.text.substring(highlighted.beginTextIndex, highlighted.endTextIndex),
                    speaker: beginChunk.speaker
                });
            } else {
                // highlight spans across adjacent chunks
                highlightTexts.push({
                    chunkIndex: highlighted.beginChunkIndex,
                    beginIndex: highlighted.beginTextIndex,
                    endIndex: beginChunk.text.length,
                    text: beginChunk.text.substring(highlighted.beginTextIndex, beginChunk.text.length),
                    speaker: beginChunk.speaker
                });
                if (highlighted.endChunkIndex - highlighted.beginChunkIndex > 1) {
                    // highlight spans across 3 or more adjacent chunks - push all inner texts into final array
                    for (let i = highlighted.beginChunkIndex + 1; i < highlighted.endChunkIndex; i++) {
                        highlightTexts.push({
                            chunkIndex: i,
                            beginIndex: 0,
                            endIndex: chunks[i].text.length,
                            text: chunks[i].text.substring(0, chunks[i].text.length),
                            speaker: chunks[i].speaker
                        });
                    }
                }
                highlightTexts.push({
                    chunkIndex: highlighted.endChunkIndex,
                    beginIndex: 0,
                    endIndex: highlighted.endTextIndex,
                    text: endChunk.text.substring(0, highlighted.endTextIndex),
                    speaker: endChunk.speaker
                });
            }
            return {
                id: createId('highlight'),
                highlightTexts,
                audioHighlightTimeStart,
            };
        }
        return null;
    };

    getHighlighted = () => {
        const selection = this.getWindowSelection();
        if (selection.beginNodeId === selection.endNodeId && selection.beginNodeId.includes('highlight')) {
            return null;
        }
        // textBlock ids are of the form:
        // chunk{chunkIndex}-text{textBlock"sStartingPositionWithinTheChunk}-highlight(ifHighlighted){highlightEntityIndex}
        // e.g. chunk0-text12-highlight4 (if highlighted), chunk0-text12 (if not highlighted)
        const beginChunkIndex = Number(selection.beginNodeId.split('-')[0].replace('chunk', ''));
        const endChunkIndex = Number(selection.endNodeId.split('-')[0].replace('chunk', ''));
        const beginChunkTextIndex = Number(selection.beginNodeId.split('-')[1].replace('text', ''));
        const endChunkTextIndex = Number(selection.endNodeId.split('-')[1].replace('text', ''));
        const endNodeTextLength = document.getElementById(selection.endNodeId).innerText.length;
        const previousNodeId = this.getPreviousNodeId(selection.beginNodeId);
        const nextNodeId = this.getNextNodeId(selection.endNodeId);

        let highlighted = {};
        const {voiceAttachments, audioIndex} = this.props;
        const existingHighlightEntities = voiceAttachments[audioIndex].highlightEntities;
        if (selection.beginNodeId.includes('highlight')) {
            // new highlight begins within existing highlight
            const entityIndex = selection.beginNodeId.split('-')[2].replace('highlight', '');
            highlighted.beginChunkIndex = existingHighlightEntities[entityIndex].highlightTexts[0].chunkIndex;
            highlighted.beginTextIndex = existingHighlightEntities[entityIndex].highlightTexts[0].beginIndex;
        } else if (selection.beginTextIndex === 0 && previousNodeId.includes('highlight')) {
            // new highlight begins adjacent to existing highlight
            const entityIndex = previousNodeId.split('-')[2].replace('highlight', '');
            highlighted.beginChunkIndex = existingHighlightEntities[entityIndex].highlightTexts[0].chunkIndex;
            highlighted.beginTextIndex = existingHighlightEntities[entityIndex].highlightTexts[0].beginIndex;
        } else {
            highlighted.beginChunkIndex = beginChunkIndex;
            highlighted.beginTextIndex = beginChunkTextIndex + selection.beginTextIndex;
        }
        if (selection.endNodeId.includes('highlight')) {
            // new highlight ends within existing highlight
            const entityIndex = selection.endNodeId.split('-')[2].replace('highlight', '');
            const existingHighlightEntity = existingHighlightEntities[entityIndex].highlightTexts[existingHighlightEntities[entityIndex].highlightTexts.length - 1];
            highlighted.endChunkIndex = existingHighlightEntity.chunkIndex;
            highlighted.endTextIndex = existingHighlightEntity.endIndex;
        } else if (selection.endTextIndex === endNodeTextLength && nextNodeId.includes('highlight')) {
            // new highlight ends adjacent to existing highlight
            const entityIndex = nextNodeId.split('-')[2].replace('highlight', '');
            const existingHighlightEntity = existingHighlightEntities[entityIndex].highlightTexts[existingHighlightEntities[entityIndex].highlightTexts.length - 1];
            highlighted.endChunkIndex = existingHighlightEntity.chunkIndex;
            highlighted.endTextIndex = existingHighlightEntity.endIndex;
        } else {
            highlighted.endChunkIndex = endChunkIndex;
            highlighted.endTextIndex = endChunkTextIndex + selection.endTextIndex;
        }
        return highlighted;
    };

    getWindowSelection = () => {
        const selection = window.getSelection();
        let beginNodeId, endNodeId, beginTextIndex, endTextIndex;
        if (this.isRightToLeft()) {
            beginNodeId = selection.focusNode.parentNode.id;
            endNodeId = selection.anchorNode.parentNode.id;
            beginTextIndex = selection.focusOffset;
            endTextIndex = selection.anchorOffset;
        } else {
            beginNodeId = selection.anchorNode.parentNode.id;
            beginTextIndex = selection.anchorOffset;
            endNodeId = selection.focusNode.parentNode.id;
            endTextIndex = selection.focusOffset;
        }
        if (beginNodeId.endsWith('-speaker') || beginNodeId.endsWith('-begin-time')) {
            beginNodeId = this.getNextNodeId(beginNodeId);
            beginTextIndex = 0;
        }
        if (endNodeId.endsWith('-speaker') || endNodeId.endsWith('-begin-time')) {
            endNodeId = this.getPreviousNodeId(endNodeId);
            endTextIndex = document.getElementById(endNodeId).innerHTML.length;
        }
        return {
            beginNodeId,
            endNodeId,
            beginTextIndex,
            endTextIndex
        };
    };

    isRightToLeft = () => {
        const selection = window.getSelection();
        const position = selection.anchorNode.compareDocumentPosition(selection.focusNode);
        return (!position && selection.anchorOffset > selection.focusOffset || position === Node.DOCUMENT_POSITION_PRECEDING);
    };

    getNextNodeId = nodeId => {
        const chunkSpans = Array.from(document.getElementById(nodeId.split('-')[0]).children);
        if (nodeId.endsWith('-speaker') || nodeId.endsWith('-begin-time')) {
            return chunkSpans[0].id;
        }
        let nextNodeId = '';
        const chunkIndex = nodeId.split('-')[0].replace('chunk', '');
        let nodeIndex = 0;
        chunkSpans.forEach((span, index) => {
            if (span.id === nodeId) {
                nodeIndex = index;
            }
        });
        if (nodeIndex === chunkSpans.length - 1 && document.getElementById('chunk' + (chunkIndex + 1))) {
            const nextChunkSpans = Array.from(document.getElementById('chunk' + (chunkIndex + 1)).children);
            nextNodeId = nextChunkSpans[0].id;
        } else if (nodeIndex < chunkSpans.length - 1) {
            nextNodeId = chunkSpans[nodeIndex + 1].id;
        }
        return nextNodeId;
    };

    getPreviousNodeId = nodeId => {
        const chunkSpans = Array.from(document.getElementById(nodeId.split('-')[0]).children);
        let nodeIndex = 0;
        chunkSpans.forEach((span, index) => {
            if (span.id === nodeId) {
                nodeIndex = index;
            }
        });
        const chunkIndex = nodeId.split('-')[0].replace('chunk', '');
        if (nodeIndex === 0 && chunkIndex > 0) {
            const previousChunkSpans = Array.from(document.getElementById('chunk' + (chunkIndex - 1)).children);
            return previousChunkSpans[previousChunkSpans.length - 1].id;
        } else if (nodeIndex !== 0) {
            return chunkSpans[nodeIndex - 1].id;
        }
        return '';
    };

    calculateAudioHighlightTimeStart = (beginTime, endTime, length, index) => {
        return beginTime + ((endTime - beginTime) / length) * index;
    };

    mergedHighlightEntities = newHighlightEntity => {
        const newHighlights = [];
        const {voiceAttachments, audioIndex, evidences} = this.props;
        let newEvidences = evidences.slice(0);
        voiceAttachments[audioIndex].highlightEntities.forEach(oldHighlightEntity => {
            let addExisting = true;
            oldHighlightEntity.highlightTexts.forEach(oldHighlightText => {
                addExisting = this.shouldAddExistingHighlight(oldHighlightText,
                    newHighlightEntity.highlightTexts[0],
                    newHighlightEntity.highlightTexts[newHighlightEntity.highlightTexts.length - 1]);
            });
            if (addExisting) {
                newHighlights.push(oldHighlightEntity);
            } else {
                newEvidences = newEvidences.filter(e => e.sourceId !== oldHighlightEntity.id);
            }
        });
        newHighlights.push(newHighlightEntity);
        newEvidences.push({
            id: createId('evidence'),
            sourceId: newHighlightEntity.id,
            type: 'highlight',
            sourceVoiceId: voiceAttachments[audioIndex].sourceVoiceId,
            highlightTexts: newHighlightEntity.highlightTexts,
            transcriptCreatedDate: voiceAttachments[audioIndex].createdDate,
            participantDisplayName: voiceAttachments[audioIndex].participantDisplayName,
            participantSourceId: voiceAttachments[audioIndex].participantSourceId,
            callType: getCallTypeLabel(voiceAttachments[audioIndex].sourceVoiceTitle)
        });
        return {
            newHighlights,
            newEvidences
        };
    };

    shouldAddExistingHighlight = (oldHighlightText, newHighlightTextBegin, newHighlightTextEnd) => {
        if (oldHighlightText.chunkIndex === newHighlightTextBegin.chunkIndex && oldHighlightText.chunkIndex === newHighlightTextEnd.chunkIndex) {
            if (oldHighlightText.beginIndex >= newHighlightTextBegin.beginIndex && oldHighlightText.endIndex <= newHighlightTextEnd.endIndex) {
                return false;
            }
        } else if (oldHighlightText.chunkIndex === newHighlightTextBegin.chunkIndex && oldHighlightText.beginIndex >= newHighlightTextBegin.beginIndex) {
            return false;
        } else if (oldHighlightText.chunkIndex === newHighlightTextEnd.chunkIndex && oldHighlightText.endIndex <= newHighlightTextEnd.endIndex) {
            return false;
        } else if (oldHighlightText.chunkIndex > newHighlightTextBegin.chunkIndex && oldHighlightText.chunkIndex < newHighlightTextEnd.chunkIndex) {
            return false;
        }
        return true;
    };

    setEvidenceMenuState = (e, refId, category) => {
        const liabilityAnalysisHeight = document.getElementById('liability-analysis--container').clientHeight;
        const googleMapHeight = document.getElementById('google-map').clientHeight;
        const contentRectLeft = document.getElementById('transcript-content').getBoundingClientRect().x;
        const contentRectRight = document.getElementById('transcript-content').getBoundingClientRect().right;

        const top = (e.pageY - liabilityAnalysisHeight - googleMapHeight - 240) + 'px'; // 240 for the height of the evidence menu
        let left = (e.pageX - contentRectLeft - 175) + 'px'; // 175 is half the width of evidence menu
        let align = 'center';
        if (contentRectRight - e.pageX - contentRectLeft < 350) {
            left = (e.pageX - contentRectLeft - 300) + 'px'; // 350 is the width of evidence menu
            align = 'right';
        }

        this.setState({
            evidenceMenu: {
                ...this.state.evidenceMenu,
                positioning: {top, left, align},
                refId,
                category
            }
        });
    };

    getEvidenceMenuRefId = highlightEntities => {
        const lastHighlightEntity = highlightEntities[highlightEntities.length - 1];
        const lastHighlightText = lastHighlightEntity.highlightTexts[lastHighlightEntity.highlightTexts.length - 1];
        return `chunk${lastHighlightText.chunkIndex}-text${lastHighlightText.beginIndex}-highlight${highlightEntities.length - 1}`;
    };

    getEvidenceFromHighlightId = highlightId => {
        const {voiceAttachments, audioIndex, evidences} = this.props;
        const entityIndex = highlightId.split('-')[2].replace('highlight', '');
        const highlightEntity = voiceAttachments[audioIndex].highlightEntities[entityIndex];
        return evidences.find(e => e.sourceId === highlightEntity.id);
    };

    handleEvidenceMenuSelect = category => {
        if (this.state.evidenceMenu.category !== category) {
            const {saveEvidenceAction, claimNumber} = this.props;
            const evidence = this.getEvidenceFromHighlightId(this.state.evidenceMenu.refId);
            let updatedEvidence = {...evidence, category};
            saveEvidenceAction(claimNumber, updatedEvidence);
            this.positionEvidenceConfirmationTooltip(this.state.evidenceMenu.category !== undefined ? 'Evidence Tagged' : 'Evidence Added and Tagged');
        }
        this.setState({evidenceMenu: {}});
    };

    handleEvidenceMenuRemove = () => {
        const {claimNumber, voiceAttachments, audioIndex, evidences, saveHighlightAction, events} = this.props;
        const voiceAttachment = voiceAttachments[audioIndex];
        const highlightEntities = JSON.parse(JSON.stringify(voiceAttachment.highlightEntities));
        const entityIndex = this.state.evidenceMenu.refId.split('-')[2].replace('highlight', '');
        const highlightEntity = voiceAttachment.highlightEntities[entityIndex];
        highlightEntities.splice(entityIndex, 1);

        let updatedEvidences = JSON.parse(JSON.stringify(evidences));
        updatedEvidences = updatedEvidences.filter(e => e.sourceId !== highlightEntity.id);

        const removeEvidenceId = evidences.filter(e => e.sourceId === highlightEntity.id)[0].id;
        const updatedEvents = JSON.parse(JSON.stringify(events));
        updatedEvents.forEach(event => {
            event.involvedParties.forEach(ip => {
                ip.contributingFactors.forEach(cF => {
                    if (cF.evidenceIds) {
                            cF.evidenceIds = cF.evidenceIds.filter(id => id !== removeEvidenceId);
                        }
                    }
                );
            });
        });
        saveHighlightAction(claimNumber, voiceAttachment.sourceVoiceId, highlightEntities, updatedEvidences, updatedEvents);
        this.positionEvidenceConfirmationTooltip('Evidence Removed');
        this.setState({evidenceMenu: {}});
    };

    positionEvidenceConfirmationTooltip = text => {
        const evidenceMenuTop = Number(this.state.evidenceMenu.positioning.top.replace('px', ''));
        const evidenceMenuLeft = Number(this.state.evidenceMenu.positioning.left.replace('px', ''));
        const tooltip = document.getElementById('evidence-confirmation-tooltip');
        tooltip.style.top = (evidenceMenuTop + 200) + 'px';
        tooltip.style.left = (evidenceMenuLeft + 175) + 'px';
        tooltip.style.visibility = 'visible';
        tooltip.innerText = text;

        this.lastProcessId++;
        const processVal = this.lastProcessId;
        setTimeout(() => {
            if (processVal === this.lastProcessId) {
                tooltip.style.visibility = 'hidden';
            }
        }, 2000);
    };

    positionEditEvidenceTooltip = e => {
        const tooltip = document.getElementById('edit-evidence-tooltip');
        tooltip.style.visibility = 'hidden';
        if (this.props.highlightMode
            && this.state.evidenceMenu.positioning === undefined
            && e.target.classList && e.target.classList.contains('chunk-highlight')) {

            const evidenceCategory = this.getEvidenceFromHighlightId(e.target.id).category;
            if (this.state.evidenceMenu.category !== evidenceCategory) {
                this.setState({evidenceMenu: {...this.state.evidenceMenu, category: evidenceCategory}});
            }

            const liabilityAnalysisContainerHeight = document.getElementById('liability-analysis--container').clientHeight;
            const googleMapHeight = document.getElementById('google-map').clientHeight;
            const tooltipTop = e.pageY - (liabilityAnalysisContainerHeight + googleMapHeight) - (this.state.evidenceMenu.category ? 60 : 45);

            const contentRect = document.getElementById('transcript-content').getBoundingClientRect();
            const tooltipLeft = e.pageX - contentRect.left - 20;

            tooltip.style.top = tooltipTop + 'px';
            tooltip.style.left = tooltipLeft + 'px';
            tooltip.style.visibility = 'visible';
        }
    };

    render = () => (
        <div>
            <div id="transcript-container" onMouseUp={e => this.handleMouseUp(e)}>
                {this.renderChunks()}
            </div>
            <EvidenceMenu
                columns={2}
                options={transcriptEvidenceMenuOptions}
                isActive={this.state.evidenceMenu.positioning !== undefined}
                align={this.state.evidenceMenu.positioning && this.state.evidenceMenu.positioning.align}
                position="top"
                positioning={this.state.evidenceMenu.positioning}
                selected={this.state.evidenceMenu.category}
                onClose={() => this.setState({evidenceMenu: {}})}
                onSelect={this.handleEvidenceMenuSelect}
                onRemoveClick={this.handleEvidenceMenuRemove}
            />
            <span id="evidence-confirmation-tooltip" className="confirmation-tooltip"/>
            <span id="edit-evidence-tooltip" className="edit-evidence-tooltip">
                <div>
                    <div id="evidence-category-tooltip" className="u-text-weight-300 u-text-x-tiny">
                        {this.state.evidenceMenu.category
                        && transcriptEvidenceMenuOptions.find(e => e.value === this.state.evidenceMenu.category).label}
                    </div>
                    <div>Edit Evidence</div>
                    <span className="tooltip-arrow"/>
                </div>
            </span>
        </div>
    );
}

Transcript.propTypes = {
    claimNumber: PropTypes.string.isRequired,
    audioPlaying: PropTypes.bool.isRequired,
    audioIndex: PropTypes.number.isRequired,
    elapsedTime: PropTypes.number.isRequired,
    togglePlayPause: PropTypes.func.isRequired,
    onSetSeekTo: PropTypes.func.isRequired,
    autoScroll: PropTypes.bool.isRequired,
    highlightMode: PropTypes.bool.isRequired,
    nlpCategory: PropTypes.string.isRequired,
    nlpCategoryIndex: PropTypes.number.isRequired,
    voiceAttachments: PropTypes.array.isRequired,
    evidences: PropTypes.array.isRequired,
    events: PropTypes.array.isRequired,
    transcripts: PropTypes.object.isRequired,
    saveHighlightAction: PropTypes.func.isRequired,
    saveEvidenceAction: PropTypes.func.isRequired,
};

export const mapStateToProps = ({claimData, transcripts}) => {
    return {
        voiceAttachments: claimData.voiceAttachments,
        evidences: claimData.evidences,
        events: claimData.events,
        transcripts
    };
};

export const mapDispatchToProps = {
    saveHighlightAction,
    saveEvidenceAction,
};

export default connect(mapStateToProps, mapDispatchToProps)(Transcript);
