import React from 'react';
import PropTypes from 'prop-types';

const AssetDamages = ({damages}) => {
    const renderDamages = () => {
        return damages.map((damage, di) => {
            return (
                <div id={`damage${di}`} key={`damage${di}`} className={'l-grid__col l-grid__col--3'}>
                    <div id={`damage-area${di}`}
                         className="u-text-semibold u-vr-2 u-hr-left">{damage.damageArea}</div>
                    {damage.damageParts.map((part, pi) => {
                        return (
                            <div id={`damage-area${di}-part${pi}`} key={`damage-area${di}-part${pi}`}
                                 className="u-hr-left">
                                {part}
                            </div>
                        );
                    })}
                </div>
            );
        });
    };

    return (
        <div className="l-grid u-vr-2-top u-hr-6-left asset-damages-container u-text-sm u-text-gray-dark">
            {damages.length === 0 && <div id="noAssetDamages">No damages available.</div>}
            {damages.length > 0 && renderDamages()}
        </div>
    );
};

export default AssetDamages;

AssetDamages.propTypes = {
    damages: PropTypes.array.isRequired
};
