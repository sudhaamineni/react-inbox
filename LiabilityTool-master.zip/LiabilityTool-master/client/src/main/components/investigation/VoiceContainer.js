import React, {Component} from 'react';
import {connect} from 'react-redux';
import PropTypes from 'prop-types';
import {AudioPlayer, CustomDropdown, Icon, Loader, ModalDialog} from 'loon-pattern-library';
import TranscriptSection from './TranscriptSection';
import {getCallTypeLabel, getParticipantName, isReadOnly} from '../../helpers/claimDataHelper';
import {saveVoiceParticipantAction} from '../../actions/transcriptActions';
import {formatVoiceDateTimeString} from '../../helpers/dateTimeHelper';
import analyticsHelper from '../../helpers/analyticsHelper';

export class VoiceContainer extends Component {
    constructor(props) {
        super(props);
        this.state = {
            audioIndex: 0,
            elapsedTime: 0.00,
            seekTo: {
                track: 0,
                time: 0.00
            },
            transcriptContentStyle: {
                maxHeight: '800px',
                overflowY: 'auto',
                scrollBehavior: 'smooth',
                borderTop: 'solid 1px #d6d6d6'
            },
            audioPlaying: false,
            showEditModal: false,
            hasErrorDropdown: false,
            selectedParticipantId: 'SELECT',
            selectedCallType: 'Other',
        };
    };

    componentDidMount() {
        window.addEventListener('scroll', this.adjustTranscriptContainerHeight);
        window.addEventListener('resize', this.adjustTranscriptContainerHeight);
    }

    componentWillUnmount() {
        window.removeEventListener('scroll', this.adjustTranscriptContainerHeight);
        window.removeEventListener('resize', this.adjustTranscriptContainerHeight);
    }

    setElapsedTime = elapsedTime => {
        this.setState({elapsedTime});
    };

    setSeekTo = time => {
        this.setState((prevState) => ({seekTo: {track: prevState.audioIndex, time: time}, audioPlaying: true}));
    };

    triggerPlayPauseCallback = triggerPlayPauseRef => {
        this.triggerPlayPause = triggerPlayPauseRef;
    };

    onPlayChangeCallback = (audioIndex, audioPlaying) => {
        this.setState({audioIndex, audioPlaying});
    };

    onTrackChangeCallback = (audioIndex) => {
        this.setState({audioIndex});
    };

    togglePlayPause = () => {
        this.triggerPlayPause(this.state.audioIndex);
    };

    getAudioBookmarks = (audioIndex, voiceAttachments) => {
        let bookmarks = [];
        voiceAttachments && voiceAttachments.map(attachment => {
            attachment.highlightEntities && attachment.highlightEntities.map((highlightEntity) => bookmarks.push({
                track: audioIndex,
                time: highlightEntity.audioHighlightTimeStart
            }));
        });
        return bookmarks;
    };

    adjustTranscriptContainerHeight = () => {
        if (document.getElementById('transcript')) {
            const currentHeight = document.getElementById('transcript').getBoundingClientRect().height;
            const heightToSet = this.getTranscriptContainerHeight();
            const yPositionFromHeader = this.getTranscriptContainerPosition();

            if (currentHeight !== heightToSet && yPositionFromHeader <= 5) {
                this.setState({
                    transcriptContentStyle: {...this.state.transcriptContentStyle, maxHeight: heightToSet}
                });
            } else if (currentHeight < 800 && yPositionFromHeader > 10) {
                this.setState({
                    transcriptContentStyle: {...this.state.transcriptContentStyle, maxHeight: '800px'}
                });
            }
        }
    };

    getTranscriptContainerPosition = () => {
        const headerHeight = document.getElementById('navigation-header').getBoundingClientRect().height;
        const transcriptTop = document.getElementById('transcript').getBoundingClientRect().top;
        return transcriptTop - headerHeight;
    };

    getTranscriptContainerHeight = () => {
        const totalHeight = document.body.getBoundingClientRect().height;
        const headerHeight = document.getElementById('navigation-header').getBoundingClientRect().height;
        const transcriptHeaderHeight = document.getElementById('transcript-header').getBoundingClientRect().height;
        const transcriptContainerHeight = totalHeight - headerHeight - transcriptHeaderHeight - 32; // 32 for the bottom margin/padding
        return transcriptContainerHeight + 'px';
    };

    updateVoiceParticipant = option => {
        if (this.state.hasErrorDropdown) {
            this.setState({selectedParticipantId: option, hasErrorDropdown: option === 'SELECT'});
        } else {
            this.setState({selectedParticipantId: option});
        }
    };

    updateCallType = option => {
        this.setState({selectedCallType: option});
    };

    saveVoiceParticipant = () => {
        const {claimData, saveVoiceParticipant} = this.props;
        const {audioIndex, selectedParticipantId, selectedCallType} = this.state;
        if (selectedParticipantId === 'SELECT') {
            this.setState({hasErrorDropdown: true});
        } else {
            saveVoiceParticipant(claimData.claimNumber, audioIndex, selectedParticipantId, selectedCallType);
            this.setState({
                showEditModal: false,
                hasErrorDropdown: false,
                selectedParticipantId: 'SELECT',
                selectedCallType: 'Other',
            });
        }
    };

    handleCancelClick = () => {
        this.setState({
            showEditModal: false,
            hasErrorDropdown: false,
            selectedParticipantId: 'SELECT',
            selectedCallType: 'Other',
        });
    };

    handlePencilClick = index => {
        const {claimData} = this.props;
        const {voiceAttachments} = claimData;
        const event = {
            message: 'success',
            eventAction: 'Investigation_VoiceContainer_EditVoice_Clicked',
            eventSource: 'button',
            errorCode: '',
        };
        analyticsHelper.trackEvent(event);
        this.setState({
            showEditModal: true,
            audioIndex: index,
            selectedCallType: getCallTypeLabel(voiceAttachments[index].sourceVoiceTitle),
            selectedParticipantId: this.getNewSelectedParticipantId(claimData, index),
        });
    };

    getNewSelectedParticipantId = (claimData, index) => {
        const {participantDisplayName, participantSourceId} = claimData.voiceAttachments[index];
        if (participantDisplayName === 'Other') {
            return 'OTHER';
        }
        if (participantDisplayName) {
            return participantSourceId;
        }
        return 'SELECT';
    };

    render() {
        const {claimData, retrievingAttachments, attachmentsRetrievalFailed, readOnly} = this.props;
        const {
            seekTo,
            audioIndex,
            transcriptContentStyle,
            audioPlaying,
            elapsedTime,
            selectedCallType,
            hasErrorDropdown,
            showEditModal,
            selectedParticipantId,
        } = this.state;
        const {participants, claimNumber, voiceAttachments} = claimData;
        const waveForms = [];
        const trackDetails = voiceAttachments ? voiceAttachments.map(attachment => {
            const title = attachment.participantDisplayName
                ? `${getCallTypeLabel(attachment.sourceVoiceTitle)} from ${attachment.participantDisplayName}`
                : getCallTypeLabel(attachment.sourceVoiceTitle);
            return {
                src: attachment.sourceVoiceUrl,
                title,
                timestamp: formatVoiceDateTimeString(attachment.createdDate),
                bookmarks: this.getAudioBookmarks(audioIndex, [attachment]),
            };
        }) : [];
        // At present Loon Pattern Library requires us to send waveforms of the same length as trackDetails
        trackDetails.forEach(() => waveForms.push([]));
        const calTypeOptions = [
            {label: 'FNOL', value: 'FNOL', disabled: this.props.readOnly},
            {label: 'Inquiry', value: 'Inquiry', disabled: this.props.readOnly},
            {label: 'Loss Investigation', value: 'Loss Investigation', disabled: this.props.readOnly},
            {label: 'Attempted Contact', value: 'Attempted Contact', disabled: this.props.readOnly},
            {label: 'Settlement', value: 'Settlement', disabled: this.props.readOnly},
            {label: 'Vendor/Provider Contact', value: 'Vendor/Provider Contact', disabled: this.props.readOnly},
            {label: 'Other', value: 'Other', disabled: this.props.readOnly},
        ];

        return (
            <div className="participant-section-border u-vr-4 u-vr-4-top">
                <div id="voice" className="u-vr-3-top u-vr-3 u-flex c-accordion__hd__bd">
                    <div
                        className="u-text-large u-hr-3-left">Voice{trackDetails.length > 0 && ` (${trackDetails.length})`}</div>
                    <div id="voice-transcription-message" className="u-flex">
                        <Icon id="voice-info-icon" icon="info-circle" color="gray-light" size={1}
                              className="u-flex__item--middle"/>
                        <div className="u-hr-left u-text-xs u-text-gray-dark u-hr-4">Calls recorded in the last 30
                            minutes may still be processing.
                        </div>
                    </div>
                </div>
                <hr className="participant-section-header-border"/>
                {(retrievingAttachments
                    && !attachmentsRetrievalFailed
                    && <div id="audio-player-loader" className="u-vr-4-top u-vr-4">
                        <Loader className="c-loader--lg"/>
                    </div>)
                || <AudioPlayer
                    onTimeChange={(idx, track) => this.setElapsedTime(track.time)}
                    seekTo={seekTo}
                    onSeekTimeline={(idx, track) => this.setElapsedTime(track.time)}
                    tracks={trackDetails}
                    onPlayChange={this.onPlayChangeCallback}
                    onTrackChange={this.onTrackChangeCallback}
                    triggerPlayPause={this.triggerPlayPauseCallback}
                    bookmarks={this.getAudioBookmarks(audioIndex, voiceAttachments)}
                    hasError={attachmentsRetrievalFailed}
                    waveforms={waveForms}
                    onEditClick={(index) => {
                        this.handlePencilClick(index);
                    }}
                />
                }
                <hr className="participant-section-header-border"/>
                <TranscriptSection
                    claimNumber={claimNumber}
                    audioPlaying={audioPlaying}
                    audioIndex={audioIndex}
                    elapsedTime={elapsedTime}
                    togglePlayPause={this.togglePlayPause}
                    onSetSeekTo={time => this.setSeekTo(time)}
                    transcriptContentStyle={transcriptContentStyle}
                    readOnly={readOnly}
                />
                <ModalDialog
                    id="voice-modal"
                    staticModal
                    title="Edit Recording Details"
                    hideTrigger
                    isPrompt={false}
                    isActive={showEditModal}
                    footer={
                        <ul className="l-h-list">
                            <li>
                                <button
                                    disabled={readOnly}
                                    onClick={this.saveVoiceParticipant}
                                    className="c-btn c-btn--primary c-btn--sm">
                                    Save
                                </button>
                            </li>
                            <li>
                                <button
                                    onClick={this.handleCancelClick}
                                    className="c-btn c-btn--tertiary c-btn--sm">
                                    Cancel
                                </button>
                            </li>
                        </ul>
                    }
                >
                    <div className="u-vr-3">
                        <div id="callType-dropdown-label"
                             className="u-text-color-gray-333333 u-text-sm u-text-semibold">
                            Call Type
                        </div>
                        <CustomDropdown
                            id="callTypeDropdown"
                            items={calTypeOptions}
                            readonly={readOnly}
                            onSelect={option => this.updateCallType(option.value)}
                            initialSelectedItem={{
                                value: selectedCallType,
                                label: selectedCallType,
                            }}
                        />
                    </div>
                    <div>
                        <div id="recording-participant-label"
                             className="u-text-color-gray-333333 u-text-sm u-text-semibold">
                            Recording Participant
                        </div>
                        <CustomDropdown
                            id="recordingParticipantDropdown"
                            hasError={hasErrorDropdown}
                            errorText="Please choose a participant"
                            readonly={readOnly}
                            items={[...participants.map(c => {
                                return {
                                    value: c.participantSourceId,
                                    label: getParticipantName(c),
                                    disabled: readOnly,
                                };
                            }), {value: 'OTHER', label: 'Other', disabled: readOnly}]}
                            onSelect={option => this.updateVoiceParticipant(option.value)}
                            initialSelectedItem={{
                                value: selectedParticipantId,
                                label: voiceAttachments && voiceAttachments.length > 0 && voiceAttachments[audioIndex].participantDisplayName
                            }}
                        />
                    </div>
                </ModalDialog>
            </div>
        );
    }
}

export const mapStateToProps = ({claimData, status, user}) => {
    return {
        claimData,
        retrievingAttachments: status.retrievingAttachments,
        attachmentsRetrievalFailed: status.attachmentsRetrievalFailed,
        readOnly: isReadOnly(user.userRoles, claimData.locked),
    };
};

export const mapDispatchToProps = {
    saveVoiceParticipant: saveVoiceParticipantAction,
};

export default connect(mapStateToProps, mapDispatchToProps)(VoiceContainer);

VoiceContainer.propTypes = {
    claimData: PropTypes.object.isRequired,
    retrievingAttachments: PropTypes.bool.isRequired,
    attachmentsRetrievalFailed: PropTypes.bool.isRequired,
    readOnly: PropTypes.bool.isRequired,
    saveVoiceParticipant: PropTypes.func.isRequired,
};
