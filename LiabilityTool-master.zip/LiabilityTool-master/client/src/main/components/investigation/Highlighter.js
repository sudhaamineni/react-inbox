import React from 'react';
import PropTypes from 'prop-types';
import {connect} from 'react-redux';
import {Icon} from 'loon-pattern-library';
import {isReadOnly} from '../../helpers/claimDataHelper';

export const Highlighter = ({isReadOnly, highlightMode, toggleHighlight}) => {
    return (
        <button id="highlight-evidence-button"
                className={`c-btn ${highlightMode ? 'c-btn--highlighter--active' : 'c-btn--highlighter'}`}
                disabled={isReadOnly}
                onClick={toggleHighlight}>
            <Icon icon="star" size={1.25} viewBox="0 0 22 28"/>
            <span className="c-btn--highlighter__text">Highlight Evidence</span>
        </button>
    );
};

export const mapStateToProps = ({user, claimData}) => {
    return {
        isReadOnly: isReadOnly(user.userRoles, claimData.locked)
    };
};

export default connect(mapStateToProps)(Highlighter);

Highlighter.propTypes = {
    highlightMode: PropTypes.bool.isRequired,
    toggleHighlight: PropTypes.func.isRequired,
    isReadOnly: PropTypes.bool.isRequired,
};
