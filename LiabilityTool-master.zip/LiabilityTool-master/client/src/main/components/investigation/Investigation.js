import React, {Component} from 'react';
import {connect} from 'react-redux';
import {getQueryStringValue} from '../../helpers/claimDataHelper';
import analyticsHelper from '../../helpers/analyticsHelper';
import PropTypes from 'prop-types';
import GoogleMapContainer from '../common/GoogleMapContainer';
import ParticipantAssetDamages from './ParticipantAssetDamages';
import VoiceContainer from './VoiceContainer';
import {withRouter} from 'react-router-dom';
import {evidenceModalErrorAction, showEvidenceModalAction} from '../../actions/evidenceActions';

export class Investigation extends Component {
    constructor(props) {
        super(props);
        this.shouldScroll = true;
    };

    componentDidMount() {
        analyticsHelper.trackPage('claims/loon/investigationPage');

        const claimNumberNoLeadingZero = this.props.claimNumber !== '' ? parseInt(this.props.claimNumber, 10) : '';
        document.title = 'Loon - ' + claimNumberNoLeadingZero;

        this.unblock = this.props.history.block(this.historyBlockCallback);
    }

    historyBlockCallback = (targetLocation) => {
        if (targetLocation.pathname === '/initial-fault' && this.props.evidences.filter(e => !e.category).length > 0) {
            this.props.showEvidenceModalAction(true);
            this.props.evidenceModalErrorAction(true);
            return false;
        }
        return true;
    };

    componentWillUnmount() {
        this.unblock();
    }

    componentDidUpdate() {
        const {scrollTo} = this.props;
        if (this.shouldScroll && scrollTo && document.getElementById(scrollTo)) {
            const top = document.getElementById(scrollTo).getBoundingClientRect().top + window.pageYOffset - 55;
            if (this.scrollBehaviorSupported()) {
                window.scrollTo({top: top, behavior: 'smooth'});
            } else {
                window.scrollTo(0, top);
            }
            this.shouldScroll = false;
        }
    }

    scrollBehaviorSupported = () => {
        return 'scrollBehavior' in document.documentElement.style;
    };

    render() {
        return (
            <div id="investigation-page" className="l-body background-very-light-gray u-vr-5">
                <div className="l-body primary-bg-color">
                    <GoogleMapContainer/>
                    <div id="liability-analysis--container" className="l-body__content l-body__main--1280">
                        <div id="liability-analysis--scene">
                            <div id="investigation-page--participants" className="l-body__content">
                                <div id="participant-owner" className="u-vr-4-top">
                                    <ParticipantAssetDamages/>
                                </div>
                            </div>
                            <VoiceContainer/>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export const mapStateToProps = ({claimData}, {location}) => {
    return {
        claimNumber: claimData.claimNumber,
        scrollTo: getQueryStringValue(location, 'scrollTo'),
        evidences: claimData.evidences
    };
};

export const mapDispatchToProps = {
    showEvidenceModalAction,
    evidenceModalErrorAction
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Investigation));

Investigation.propTypes = {
    claimNumber: PropTypes.string.isRequired,
    evidences: PropTypes.array.isRequired,
    scrollTo: PropTypes.string,
    history: PropTypes.object.isRequired,
    showEvidenceModalAction: PropTypes.func.isRequired,
    evidenceModalErrorAction: PropTypes.func.isRequired,
};
