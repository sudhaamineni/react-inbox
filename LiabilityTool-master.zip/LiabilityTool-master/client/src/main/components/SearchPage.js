import React, {Component} from 'react';
import {connect} from 'react-redux';
import {Icon, ModalDialog, SearchField} from 'loon-pattern-library';
import {clearClaimDataAction, getClaimDataAction} from '../actions/claimDataActions';
import '../assets/images/ic-welcomelogo.svg';
import analyticsHelper from '../helpers/analyticsHelper';
import PropTypes from 'prop-types';
import {padClaimNumber} from '../helpers/claimDataHelper';
import {clearNewClaimNumberAction} from '../actions/errorActions';
import {LOON_WIP_CLAIM_NUMBER} from '../constants/loonConstants';

export class SearchPage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            claimNumber: window.sessionStorage.getItem(LOON_WIP_CLAIM_NUMBER)
        };
    }

    componentDidMount() {
        analyticsHelper.trackPage('claims/loon/searchPage');
        document.title = 'Loon - Search';
    };

    onSubmit = () => {
        const {getClaimDataAction, clearClaimDataAction} = this.props;
        const {claimNumber} = this.state;
        if (claimNumber.trim().length > 0) {
            analyticsHelper.trackEvent({
                message: 'success',
                eventAction: 'SearchPage_FindClaims_ButtonClicked',
                eventSource: 'button',
                errorCode: '',
            });
            analyticsHelper.trackTransaction({claimNumber: padClaimNumber(claimNumber.trim())});
            getClaimDataAction(claimNumber.trim());
        } else {
            clearClaimDataAction();
        }
    };

    renderClaimResetModal = () => {
        const oldClaimNumber = this.state.claimNumber;
        const {newClaimNumber, errorDescription, retrievingClaimData, getClaimDataAction, clearNewClaimNumberAction} = this.props;

        if (!newClaimNumber || errorDescription !== 'This claim has been reset.') {
            return null;
        }
        return (
            <div className="u-vr">
                <ModalDialog
                    isActive
                    title="This claim has been reset"
                    promptType="error"
                    isPrompt={false}
                    onClose={() => clearNewClaimNumberAction()}
                    hideTrigger
                    isLoading={retrievingClaimData}
                    footer={
                        <ul className="l-h-list">
                            <li>
                                <button
                                    className="c-btn c-btn--primary c-btn--sm"
                                    onClick={() => getClaimDataAction(newClaimNumber)}
                                >
                                    Continue
                                </button>
                            </li>
                        </ul>
                    }
                >
                    <div className="u-align-left">
                        {'Please note claim '}<b>#{oldClaimNumber}</b>{' has been reset to '}<b>#{newClaimNumber}.</b>
                    </div>
                    <div className="u-align-left">
                        You will be redirected to this new claim.
                    </div>
                </ModalDialog>
            </div>
        );
    };

    buildErrorText = () => {
        const {errorHeader, errorDescription} = this.props;
        return (
            <div className="u-flex u-flex--middle">
                <Icon className="c-hint__icon" size={0.75} icon="alert-octagon"/>
                <p className="u-text-hint-gray u-text-xs u-text-thin">
                    <span className="u-text-magenta u-text-semibold u-hr">
                        {errorHeader === 'Unauthorized' && <b>{errorHeader} </b>}
                        {errorDescription}
                    </span>
                </p>
            </div>
        );
    };

    render() {
        const {errorDescription, retrievingClaimData} = this.props;
        return (
            <div className="l-body u-vr-5">
                <div className="l-body__section">
                    <div className="l-grid l-grid--center u-vr-10-top">
                        <div className="l-grid__col u-vr-12-top">
                            <img className="loon-logo u-vr" src="../images/ic-welcomelogo.svg"
                                 alt="Loon logo"/>
                            <div className="u-text-insured u-text-xlarge u-text-thin u-align-center u-vr-top">
                                Welcome to Loon
                            </div>
                            <h4 className="u-align-center u-text-gray u-vr-top u-text-md"
                                id="search-instructions">
                                Search for a claim number to begin a liability analysis
                            </h4>
                            <div id="search-container" className="u-vr-3-top u-vr-2 u-flex--center">
                                <SearchField
                                    type="text"
                                    placeholder="Enter a claim number"
                                    maxLength={50}
                                    loading={retrievingClaimData}
                                    hasError={errorDescription !== ''}
                                    errorText={this.buildErrorText()}
                                    defaultValue={window.sessionStorage.getItem(LOON_WIP_CLAIM_NUMBER)}
                                    onChange={claimNumber => this.setState({claimNumber})}
                                    onSubmit={this.onSubmit}
                                    autoComplete={false}
                                />
                            </div>
                            {this.renderClaimResetModal()}
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export const mapStateToProps = ({status}) => {
    return {
        errorHeader: status.errorHeader,
        errorDescription: status.errorDescription,
        newClaimNumber: status.newClaimNumber,
        retrievingClaimData: status.retrievingClaimData
    };
};

export const mapDispatchToProps = {
    getClaimDataAction,
    clearClaimDataAction,
    clearNewClaimNumberAction,
};

export default connect(mapStateToProps, mapDispatchToProps)(SearchPage);

SearchPage.propTypes = {
    errorHeader: PropTypes.string.isRequired,
    errorDescription: PropTypes.string.isRequired,
    newClaimNumber: PropTypes.string,
    retrievingClaimData: PropTypes.bool.isRequired,
    getClaimDataAction: PropTypes.func.isRequired,
    clearClaimDataAction: PropTypes.func.isRequired,
    clearNewClaimNumberAction: PropTypes.func.isRequired,
};
