import React, {Component} from 'react';
import {connect} from 'react-redux';
import {withRouter} from 'react-router-dom';
import PropTypes from 'prop-types';
import GoogleMapContainer from '../common/GoogleMapContainer';
import {Diagram, getDiagramImage, getDiagramObjects} from 'sketchy-bird';
import analyticsHelper from '../../helpers/analyticsHelper';
import {getParticipantName, getSketchTemplateType, isReadOnly} from '../../helpers/claimDataHelper';
import {saveSketchAction} from '../../actions/claimDataActions';
import {PEDESTRIAN_BICYCLIST, PROPERTY} from '../../constants/loonConstants';
import {evidenceModalErrorAction, showEvidenceModalAction} from '../../actions/evidenceActions';

const SKETCH_VEHICLE_TYPE = 'auto';

export class Sketch extends Component {
    componentDidMount() {
        analyticsHelper.trackPage('claims/loon/sketchPage');
        window.scrollTo(0, 0);
        const claimNumberNoLeadingZero = this.props.claimNumber !== '' ? parseInt(this.props.claimNumber, 10) : '';
        document.title = 'Loon - ' + claimNumberNoLeadingZero;

        this.unblock = this.props.history.block(this.historyBlockCallback);
    }

    componentWillUnmount() {
        this.unblock();

        const {sketch, isReadOnly, garageImage, saveSketchAction} = this.props;
        if (!isReadOnly) {
            const diagramImage = getDiagramImage();
            const diagramObjects = getDiagramObjects() ;

            const updatedSketch = {...sketch};
            updatedSketch.imageSource = diagramImage ? diagramImage : updatedSketch.imageSource;
            updatedSketch.garageSource = garageImage ? garageImage : updatedSketch.garageSource;
            updatedSketch.completed = diagramObjects !== null && diagramObjects.filter(a => a.type === 'asset').length > 0;
            saveSketchAction(updatedSketch);
        }
    }

    historyBlockCallback = targetLocation => {
        if (targetLocation.pathname === '/initial-fault' && this.props.evidences.filter(e => !e.category).length > 0) {
            this.props.showEvidenceModalAction(true);
            this.props.evidenceModalErrorAction(true);
            return false;
        }
        return true;
    };

    /*
    1. Assets property has different names (`name`, `role`, `make`, `model`, `year`, `type`). [Component Updates Section](#componentUpdates) below updated
    2. Previous asset type of `vehicle` is now changed to `auto`.
        - Need to send `auto` as asset type
        - We can now also accept any other asset type, but will always default to `auto`
     */
    getVehicleList() {
        return this.props.liabilitySubjects
            .filter(ls => ls.role === PEDESTRIAN_BICYCLIST || ls.asset.assetTypeDescription !== PROPERTY)
            .map(s => {
                let vehicle = {};
                vehicle.id = s.role === PEDESTRIAN_BICYCLIST ? s.participantSourceId : s.asset.vehicleItemId;
                vehicle.name = getParticipantName(s);
                vehicle.role = s.role;
                vehicle.year = s.role === PEDESTRIAN_BICYCLIST ? '' : s.asset.vehicleYear;
                vehicle.make = s.role === PEDESTRIAN_BICYCLIST ? '' : s.asset.vehicleMake;
                vehicle.model = s.role === PEDESTRIAN_BICYCLIST ? '' : s.asset.vehicleModel;
                vehicle.type = SKETCH_VEHICLE_TYPE;
                return vehicle;
            });
    }

    render = () => (
        <div id="sketch-page" className="l-body background-very-light-gray u-vr-5">
            <div className="l-body">
                <GoogleMapContainer/>
            </div>
            <div className="u-color-white-background">
                <div className="u-vr-5-top">
                    <div id="liability-analysis--container" className="l-body__content l-body__main--1280">
                        <div className="loon-sketch-container">
                            <div className="sketch-diagram-container">
                                <div className="sketch-diagram-inner-container u-text-large"
                                     id="sketch-header-text">
                                    Sketch the <b>scene</b> to better explain initial fault:
                                </div>
                            </div>
                        </div>
                        <Diagram key={this.props.claimNumber}
                                 claimNumber={this.props.claimNumber}
                                 assets={this.getVehicleList()}
                                 templateType={getSketchTemplateType(this.props.lossDetailTypeCode)}
                                 readOnly={this.props.isReadOnly}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
}

export const mapStateToProps = ({claimData, user, diagram}) => {
    return {
        claimNumber: claimData.claimNumber,
        liabilitySubjects: claimData.liabilitySubjects,
        lossDetailTypeCode: claimData.lossDetailTypeCode,
        sketch: claimData.sketch,
        garageImage: diagram.assetsImage || '',
        isReadOnly: isReadOnly(user.userRoles, claimData.locked),
        evidences: claimData.evidences,
    };
};

export const mapDispatchToProps = {
    saveSketchAction,
    showEvidenceModalAction,
    evidenceModalErrorAction,
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Sketch));

Sketch.propTypes = {
    claimNumber: PropTypes.string.isRequired,
    liabilitySubjects: PropTypes.array.isRequired,
    lossDetailTypeCode: PropTypes.string.isRequired,
    sketch: PropTypes.object,
    garageImage: PropTypes.string.isRequired,
    isReadOnly: PropTypes.bool.isRequired,
    evidences: PropTypes.array.isRequired,
    history: PropTypes.object.isRequired,
    saveSketchAction: PropTypes.func.isRequired,
    showEvidenceModalAction: PropTypes.func.isRequired,
    evidenceModalErrorAction: PropTypes.func.isRequired,
};
