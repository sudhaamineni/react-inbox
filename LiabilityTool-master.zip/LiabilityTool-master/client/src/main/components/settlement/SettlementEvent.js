import React from 'react';
import {connect} from 'react-redux';
import PropTypes from 'prop-types';
import {Icon} from 'loon-pattern-library';
import {getParticipantName} from '../../helpers/claimDataHelper';
import {updateEventAction} from '../../actions/eventActions';
import LiabilityPercentage from '../common/LiabilityPercentage';
import ParticipantPill from '../common/ParticipantPill';
import {getCurrentTime} from '../../helpers/dateTimeHelper';

export const SettlementEvent = ({claimNumber, lossDetailType, event, eventIndex, liabilitySubjects, updateEventAction, isReadOnly}) => {
    const findLiabilitySubject = (participantSourceId, liabilitySubjects) => {
        return liabilitySubjects.filter(p => p.participantSourceId === participantSourceId)[0];
    };

    const saveScore = (affectedParticipant, faultAllocationPercent, involvedLiabilitySubject) => {
        const updatedEvent = {...event, faultAllocationPercentSaveTime: getCurrentTime()};
        let shouldUpdate = false;
        updatedEvent.involvedParties.forEach(p => {
            if (p.participantSourceId === involvedLiabilitySubject.participantSourceId) {
                p.affectedParties.forEach(a => {
                    if (a.participantSourceId === affectedParticipant.participantSourceId) {
                        a.faultAllocationPercent = faultAllocationPercent;
                        shouldUpdate = true;
                    }
                });
            }
        });
        if (shouldUpdate) {
            updateEventAction(claimNumber, updatedEvent);
        }
    };

    const renderAffectedParticipantFault = (party, affectedParticipant, liabilitySubjects) => {
        return (
            <div id={`affected-participant-${affectedParticipant.participantId}`}
                 key={affectedParticipant.participantId}
                 className="l-grid l-grid__col l-grid--end u-vr-top u-vr-2 l-grid--end u-hr-4-left event-item-row">
                <div
                    className="l-grid__col--4 l-grid--start u-text-xsmall gray-medium u-flex l-grid--middle padding-bottom-12">
                    <div id="to-label">TO</div>
                    <Icon id="arrow-icon"
                          icon="line-arrow"
                          color="loon-gray-light"
                          size={2}
                          className="u-hr-left"
                    />
                    <div id="participant-name" className="u-hr-left">
                        {(affectedParticipant.participantId && getParticipantName(findLiabilitySubject(affectedParticipant.participantSourceId, liabilitySubjects))) || 'UNKNOWN'}
                    </div>
                </div>
                <div id="submitted-affected-percent"
                     className="l-grid__col--2 determined-fault-text u-flex l-grid--middle u-flex--end padding-bottom-12">
                    {`${affectedParticipant.submittedInitialFaultPercent} %`}
                </div>
                <div id="negotiating-range"
                     className="l-grid__col--2 negotiation-range-color u-flex l-grid--middle u-flex--end padding-bottom-12">
                    {`${affectedParticipant.beginNegotiatingRange}-${affectedParticipant.endNegotiatingRange} %`}
                </div>
                <div className="l-grid__col--2 u-flex l-grid--middle u-flex--end">
                    <LiabilityPercentage
                        value={affectedParticipant.faultAllocationPercent}
                        readOnly={isReadOnly}
                        hasError={false}
                        onBlurCallback={val => saveScore(affectedParticipant, val, party)}
                    />
                </div>
                <div className="l-grid__col--2"/>
            </div>
        );
    };

    const renderInvolvedParty = (party, index, liabilitySubjects) => {
        const involvedLiabilitySubject = findLiabilitySubject(party.participantSourceId, liabilitySubjects);
        const {affectedParties} = party;
        return (
            <div key={party.participantSourceId}>
                <span className="u-flex u-flex--middle u-hr-5-left">
                    <ParticipantPill liabilitySubject={involvedLiabilitySubject}/>
                    <span id="involved-party-name" className="u-hr-left u-text-small">
                        {getParticipantName(involvedLiabilitySubject)}
                    </span>
                </span>
                {affectedParties.map(affectedParticipant => renderAffectedParticipantFault(party, affectedParticipant, liabilitySubjects))}
            </div>
        );
    };

    const isTwoParty = liabilitySubjects.length === 2;
    const eventTitle = (isTwoParty ? lossDetailType : 'Event ' + (eventIndex + 1)) + (event.title ? ' - ' + event.title : '');
    return (
        <div>
            <hr className="participant-section-header-border"/>
            <div id="event-title"
                 className="u-vr-3-top u-vr-2 u-text-gray-dark u-text-medium u-hr-5-left">{eventTitle}</div>
            {event.involvedParties
                .filter(p => p.affectedParties.length > 0)
                .map((party, index) => renderInvolvedParty(party, index, liabilitySubjects))}
        </div>
    );
};

export const mapDispatchToProps = {
    updateEventAction
};

export default connect(null, mapDispatchToProps)(SettlementEvent);

SettlementEvent.propTypes = {
    claimNumber: PropTypes.string.isRequired,
    lossDetailType: PropTypes.string.isRequired,
    event: PropTypes.object.isRequired,
    eventIndex: PropTypes.number.isRequired,
    liabilitySubjects: PropTypes.array.isRequired,
    updateEventAction: PropTypes.func.isRequired,
    isReadOnly: PropTypes.bool.isRequired,
};
