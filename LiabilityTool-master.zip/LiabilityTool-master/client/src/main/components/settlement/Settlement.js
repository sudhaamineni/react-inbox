import React, {Component} from 'react';
import analyticsHelper from '../../helpers/analyticsHelper';
import {connect} from 'react-redux';
import PropTypes from 'prop-types';
import {FormOption, Loader} from 'loon-pattern-library';
import SettlementEvent from './SettlementEvent';
import {saveNoFaultAllocationIndicatorAction} from '../../actions/claimDataActions';
import {isReadOnlyUser} from '../../helpers/claimDataHelper';
import {
    settlementSubmittedAction,
    submitSettlementAction,
    submitSettlementCancelAction,
    updateDamageApportionmentAction
} from '../../actions/submitActions';
import DamageApportionment from './DamageApportionment';
import {SubmitModal} from '../liability/SubmitModal';
import {ERROR_SUBMITTING, SUBMITTED, SUBMITTING} from '../../constants/loonConstants';
import {withRouter} from 'react-router-dom';
import {setErrorMessagesAction} from '../../actions/errorActions';

export class Settlement extends Component {
    constructor(props) {
        super(props);
        this.state = {
            openConfirmModal: false,
        };
    };

    componentDidMount = () => {
        const {claimData, history, setErrorMessagesAction} = this.props;

        analyticsHelper.trackPage('claims/loon/settlementPage');
        const claimNumberNoLeadingZero = this.props.claimData.claimNumber !== '' ? parseInt(this.props.claimData.claimNumber, 10) : '';
        document.title = 'Loon - ' + claimNumberNoLeadingZero;

        if (!claimData.initialFaultSubmitTime || !claimData.locked) {
            setErrorMessagesAction('Settlement unavailable', 'Settlement not available for this claim.');
            history.push('/');
        }
    };

    saveNoAgreement = (event, type) => {
        const noFaultAllocationAgreement = type === 'noFaultAllocationAgreement' ? event.target.checked : false;
        const noFaultAllocationResponse = type === 'noFaultAllocationResponse' ? event.target.checked : false;
        this.props.saveNoFaultAllocationIndicatorAction(this.props.claimData.claimNumber, noFaultAllocationAgreement, noFaultAllocationResponse);
    };

    eventHasEmptyField = () => {
        let isEmpty = false;
        this.props.claimData.events.forEach(e => {
            e.involvedParties.forEach(ip => {
                ip.affectedParties && ip.affectedParties.forEach(ap => {
                    if (ap.faultAllocationPercent === '' || ap.faultAllocationPercent === null || ap.faultAllocationPercent === undefined) {
                        isEmpty = true;
                    }
                });
            });
        });
        return isEmpty;
    }

    disableButtonFromStatus = () => {
        const {claimData, readOnlyUser, updatingDamageApportionment} = this.props;
        return readOnlyUser || updatingDamageApportionment || claimData.noFaultAllocationAgreement || claimData.noFaultAllocationResponse ? true : false;
    }

    isUpdateButtonDisabled = () => {
        return this.eventHasEmptyField() || this.disableButtonFromStatus();
    };

    isApportionedAllocatedFaultRecent = () => {
        const {claimData} = this.props;
        if (claimData.apportionedAllocatedFault) {
            let recentFaultAllocationSaveTime = null;
            claimData.events.forEach(e => {
                if (e.faultAllocationPercentSaveTime) {
                    if (!recentFaultAllocationSaveTime) {
                        recentFaultAllocationSaveTime = e.faultAllocationPercentSaveTime;
                    } else if (e.faultAllocationPercentSaveTime > recentFaultAllocationSaveTime) {
                        recentFaultAllocationSaveTime = e.faultAllocationPercentSaveTime;
                    }
                }
            });
            if (recentFaultAllocationSaveTime < claimData.apportionedAllocatedFaultSaveTime) {
                return true;
            }
        }
        return false;
    };

    isSubmitButtonDisabled = () => {
        const {claimData, readOnlyUser} = this.props;
        if (readOnlyUser) {
            return true;
        }
        if (claimData.noFaultAllocationAgreement) {
            return false;
        }
        if (claimData.noFaultAllocationResponse) {
            return false;
        }
        if (this.isApportionedAllocatedFaultRecent()) {
            return false;
        }
        return true;
    };

    closeModal = () => {
        this.setState({openConfirmModal: false});
    };

    onSubmitConfirmClick = () => {
        this.props.submitSettlementAction(this.props.claimData.claimNumber);
        this.setState({openConfirmModal: false});
    };

    redirectToHomePage = () => {
        this.props.settlementSubmittedAction();
        this.props.history.push('/');
    };

    getModalText = () => {
        const {noFaultAllocationAgreement, noFaultAllocationResponse} = this.props.claimData;
        if (noFaultAllocationAgreement)
            return 'Are you sure you want to submit your No Agreement decision?';
        if (noFaultAllocationResponse)
            return 'Are you sure you want to submit your No Response decision?';
        return 'Are you sure you want to submit your Damage Apportionment?';

    };

    getSuccessModalText = () => {
        const {noFaultAllocationAgreement, noFaultAllocationResponse} = this.props.claimData;
        if (noFaultAllocationAgreement)
            return 'Your No Agreement decision has been successfully submitted.';
        if (noFaultAllocationResponse)
            return 'Your No Response decision has been successfully submitted.';
        return 'Your Damage Apportionment has been successfully submitted.';
    };

    render = () => {
        const {claimData, readOnlyUser, updatingDamageApportionment, updateDamageApportionmentAction} = this.props;
        const apportionedFault = (claimData.apportionedAllocatedFaultSaveTime && claimData.apportionedAllocatedFaultSaveTime > claimData.initialFaultSubmitTime) ? claimData.apportionedAllocatedFault : claimData.apportionedInitialFault;
        const allocationIsRecent = (claimData.apportionedAllocatedFaultSaveTime && claimData.apportionedAllocatedFaultSaveTime > claimData.initialFaultSubmitTime);



        return (
            <div className="u-color-white-background">
                <div className="centered-content l-body__content l-body__main--1280 ">
                    <div id="liability-analysis--scene" className="u-hr-5-left">
                        <div id="settlement-header" className="u-text-large u-vr-5-top">Settlement</div>
                        <div id="fault-agreement-section" className="participant-section-border u-vr-3-top u-vr-5">
                            <div id="fault-agreement-header" className="background-very-light-gray border-top-radius-6">
                                <div className="u-hr-5-left fault-agreement-header">
                                    <ul className="l-h-list l-h-list--center-aligned">
                                        <li className="u-text-large u-text-color-gray-333333"
                                            id="fault-allocation-header-text">Fault Allocation
                                        </li>
                                        <li>
                                            <FormOption
                                                readOnly={readOnlyUser}
                                                disabled={readOnlyUser}
                                                className="u-hr-3-left u-text-smaller"
                                                id="fault-agreement-no-agreement"
                                                onChange={(event) => this.saveNoAgreement(event, 'noFaultAllocationAgreement')}
                                                checked={claimData.noFaultAllocationAgreement}
                                                name="no-fault-agreement"
                                            >
                                                <span>No Agreement</span>
                                            </FormOption>
                                            <FormOption
                                                readOnly={readOnlyUser}
                                                disabled={readOnlyUser}
                                                className="u-hr-3-left u-text-smaller"
                                                id="fault-agreement-no-response"
                                                onChange={(event) => this.saveNoAgreement(event, 'noFaultAllocationResponse')}
                                                checked={claimData.noFaultAllocationResponse}
                                                name="no-response"
                                            >
                                                <span>No Response</span>
                                            </FormOption>
                                        </li>
                                    </ul>
                                </div>
                                <div className="participant-section-header-border"/>
                            </div>
                            <div>
                                <div id="fault-agreement-columns"
                                     className="l-grid l-grid__col l-grid--end u-vr-top u-hr-4-left u-text-color-gray-444444">
                                    <div className="l-grid__col--4"/>
                                    <div id="fault-agreement-determined-column"
                                         className="u-text-xsmall l-grid__col--2">Initial Fault
                                    </div>
                                    <div id="fault-agreement-negotiation-column"
                                         className="u-text-xsmall l-grid__col--2">Negotiating Range
                                    </div>
                                    <div className="l-grid__col--2">
                                        <div id="fault-allocation-agreed-column"
                                             className="u-text-xsmall ">Fault Allocation
                                        </div>
                                    </div>
                                    <div className="l-grid__col--2"/>
                                </div>
                                <div id="settlement-faults-container">
                                    {claimData.events.map((event, index) =>
                                        <SettlementEvent
                                            key={event.id}
                                            claimNumber={claimData.claimNumber}
                                            lossDetailType={claimData.lossDetailType}
                                            event={event}
                                            eventIndex={index}
                                            liabilitySubjects={claimData.liabilitySubjects}
                                            isReadOnly={readOnlyUser}
                                        />
                                    )}
                                </div>
                            </div>
                            <hr className="participant-section-header-border"/>
                            <div id="update-damage-apportionment-btn-container"
                                 className="u-vr-2 u-vr-2-top l-grid l-grid__col u-hr-4-left">
                                <div className="l-grid__col--10 l-grid--end">
                                    <button id="update-damage-apportionment-btn"
                                            className="c-btn c-btn--tertiary button-width-16 button-height-2"
                                            disabled={this.isUpdateButtonDisabled()}
                                            onClick={() => updateDamageApportionmentAction(claimData.claimNumber)}
                                    >
                                        {updatingDamageApportionment ?
                                            <Loader className="c-loader--sm"/> : 'Update Damage Apportionment'}
                                    </button>
                                </div>
                                <div className="l-grid__col--2"/>
                            </div>
                        </div>

                        {apportionedFault && <DamageApportionment apportionedFault={apportionedFault} allocationIsRecent={allocationIsRecent} apportionedAllocatedFaultSaveTime={claimData.apportionedAllocatedFaultSaveTime}/>}

                        <div id="submit-button-container">
                            <button id="submit-settlement-button"
                                    className="c-btn c-btn--primary u-vr-5"
                                    disabled={this.isSubmitButtonDisabled()}
                                    onClick={() => this.setState({openConfirmModal: true})}
                            >
                                Submit Settlement
                            </button>
                        </div>
                    </div>
                </div>
                <SubmitModal
                    id="confirm-modal"
                    activeModal="Confirm"
                    isActive={this.state.openConfirmModal}
                    spinner={this.props.submitState === SUBMITTING}
                    firstButtonCallback={this.onSubmitConfirmClick}
                    secondButtonCallback={this.closeModal}
                    modalText={this.getModalText()}
                />
                <SubmitModal
                    id="success-modal"
                    activeModal="Success"
                    isActive={this.props.submitState === SUBMITTED}
                    modalText={this.getSuccessModalText()}
                    secondButtonLabel="Back to Settlement"
                    firstButtonCallback={this.redirectToHomePage}
                    secondButtonCallback={this.props.settlementSubmittedAction}
                    spinner={false}
                />
                <SubmitModal
                    id="error-modal"
                    activeModal="Error"
                    isActive={this.props.submitState === ERROR_SUBMITTING}
                    firstButtonCallback={() => this.onSubmitConfirmClick()}
                    secondButtonCallback={this.props.submitSettlementCancelAction}
                    spinner={this.props.submitState === SUBMITTING}
                    modalText="We are unable to submit your Damage Apportionment. Would you like to try submitting this again?"
                />
            </div>
        );
    };
}

export const mapStateToProps = ({claimData, user, status}, {history}) => {
    return {
        claimData,
        history,
        readOnlyUser: isReadOnlyUser(user.userRoles),
        updatingDamageApportionment: status.updatingDamageApportionment,
        submitState: status.submitState
    };
};

export const mapDispatchToProps = {
    saveNoFaultAllocationIndicatorAction,
    updateDamageApportionmentAction,
    submitSettlementAction,
    settlementSubmittedAction,
    submitSettlementCancelAction,
    setErrorMessagesAction,
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Settlement));

Settlement.propTypes = {
    claimData: PropTypes.object.isRequired,
    readOnlyUser: PropTypes.bool.isRequired,
    updatingDamageApportionment: PropTypes.bool.isRequired,
    saveNoFaultAllocationIndicatorAction: PropTypes.func.isRequired,
    updateDamageApportionmentAction: PropTypes.func.isRequired,
    submitSettlementAction: PropTypes.func.isRequired,
    submitState: PropTypes.string.isRequired,
    settlementSubmittedAction: PropTypes.func.isRequired,
    history: PropTypes.object,
    submitSettlementCancelAction: PropTypes.func.isRequired,
    setErrorMessagesAction: PropTypes.func.isRequired,
};
