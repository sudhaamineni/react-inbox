import React from 'react';
import PropTypes from 'prop-types';
import {connect} from 'react-redux';
import ParticipantPill from '../common/ParticipantPill';
import {getParticipantName} from '../../helpers/claimDataHelper';
import {Alert, Icon} from 'loon-pattern-library';
import {convertZuluTimeToLocalTime} from '../../helpers/dateTimeHelper';

export const DamageApportionment = ({apportionedFault, lossState, liabilitySubjects, allocationIsRecent, apportionedAllocatedFaultSaveTime}) => {
    const isInsured = id => liabilitySubjects.find(ls => ls.participantPartyId === id).role.toUpperCase() === 'INSURED';

    const owingPartiesSorted = apportionedFault.owingParties.slice();
    owingPartiesSorted.sort(op => isInsured(op.participantId) ? -1 : 1);

    const renderDamages = damages => {
        let groupedDamages = {};

        damages.forEach(damage => {
            if (groupedDamages[damage.allocation]) {
                groupedDamages[damage.allocation].push(damage.damageLocation);
            } else {
                groupedDamages[damage.allocation] = [damage.damageLocation];
            }
        });

        return Object.keys(groupedDamages).map((alloc, index) => (
            <div id={`damage-${index}`} className="l-grid__col--3" key={index}>
                <div id="allocation"
                     className="u-text-sm u-text-light-blue">{alloc ? parseInt(alloc, 10) : 0} %
                </div>
                {groupedDamages[alloc].map((location, index) =>
                    <div id={`location-${index}`}
                         key={index}
                         className="u-text-xs u-text-color-gray-333333 u-text-capitalize">
                        {location === 'hasDamage' ? 'Damages' : location}
                    </div>
                )}
            </div>
        ));
    };

    const renderCollectingParties = collectingParties => {
        return (
            collectingParties.map((cp, index) => {
                    const mainParticipant = liabilitySubjects.filter(subject => subject.participantPartyId === cp.participantId)[0];
                    return (
                        <div id={`collecting-party-${index}`} key={index}
                             className="l-grid l-grid__col u-text-color-gray-6d6d6d u-text-xs">
                            <div className="l-grid__col--5  u-flex l-grid--top">
                                <span id="collecting-party-label">OWES DAMAGES TO</span>
                                <Icon id="arrow-icon"
                                      icon="line-arrow"
                                      color="loon-gray-light"
                                      size={2}
                                      className="u-hr-left padding-bottom-12"
                                />
                                <span id="collecting-party-name"
                                      className="u-hr-left">{getParticipantName(mainParticipant)}</span>
                            </div>

                            <div id="damages" className="l-grid__col--7  u-flex l-grid--top">
                                {renderDamages(cp.damages)}
                            </div>

                        </div>
                    );
                }
            ));
    };

    const renderAlertBanner = () => {
        const type = allocationIsRecent ? 'info' : 'error';
        const className = allocationIsRecent ? 'u-text-gray-dark u-text-xs recent-allocation-banner' : 'non-recent-allocation-banner';
        const firstText = allocationIsRecent ?
            <span><b>Fault Allocation Updated: </b></span>
            : <span>No Fault Allocation recorded.</span>;
        const secondText = allocationIsRecent ?
            convertZuluTimeToLocalTime(apportionedAllocatedFaultSaveTime)
            : ('Percentages based on Initial Fault.');

        return (
            <Alert type={type} className={className}>
                {firstText} {secondText}
            </Alert>
        );
    };

    const renderOwingParties = owingParties => (
        owingParties.map((op, index) => {
            const ls = liabilitySubjects.filter(subject => subject.participantPartyId === op.participantId)[0];
            return (
                <div key={index} id={`owing-party-${index}`} className="u-vr-3-top ">
                    <div id="damage-recovery-pill" className="u-hr-5-left u-flex u-flex--middle u-vr">
                        <ParticipantPill liabilitySubject={ls}/>
                        <span id="owing-party-name" className="u-hr-left u-text-small u-text-color-gray-4a4a4a">
                            {getParticipantName(ls)}
                            </span>
                    </div>
                    <div className="u-hr-5-left u-vr-3">
                        {renderCollectingParties(op.collectingParties)}
                    </div>
                    <hr className="participant-section-header-border"/>
                </div>
            );
        })
    );

    return (

        <div id="damage-recovery-section" className="participant-section-border u-vr-5">
            <div id="damage-recovery-header"
                 className="background-very-light-gray border-top-radius-6 u-text-color-gray-333333 u-padding-top-1 u-padding-bottom-1">
                <div className="u-hr-5-left damage-recovery-header ">
                    <ul className="l-h-list l-h-list--center-aligned">
                        <li className="u-text-sm" id="damage-recovery-header-text">Damage Apportionment</li>
                    </ul>
                </div>
                <div id="comp-neg-rule" className="u-hr-5-left u-text-xs">Based on the state negligence laws in the
                    state of {lossState}
                    <span className="u-hr-4-left"> {apportionedFault.comparativeNegligenceRule}</span>
                </div>

            </div>

            <div className="participant-section-header-border"/>
            <div>
                {renderAlertBanner()}
            </div>
            <div>
                {renderOwingParties(owingPartiesSorted)}
            </div>
        </div>
    );
};

export const mapStateToProps = ({claimData}) => {
    return {
        lossState: claimData.lossState,
        liabilitySubjects: claimData.liabilitySubjects
    };
};
export default connect(mapStateToProps, null)(DamageApportionment);

DamageApportionment.propTypes = {
    apportionedFault: PropTypes.object.isRequired,
    apportionedAllocatedFaultSaveTime: PropTypes.string,
    allocationIsRecent: PropTypes.bool.isRequired,
    lossState: PropTypes.string.isRequired,
    liabilitySubjects: PropTypes.array.isRequired
};
