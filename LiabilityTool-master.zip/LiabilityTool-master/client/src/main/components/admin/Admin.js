import React, {Component} from 'react';
import {connect} from 'react-redux';
import {Form, FormField, FormOption} from 'loon-pattern-library';
import {insertAssignmentClaimListAction} from '../../actions/adminActions';
import PropTypes from 'prop-types';

export class Admin extends Component {
    constructor(props) {
        super(props);
        this.state = {
            clearQueue: false,
            useKafka: true,
            claimNumberList: '',
            displayStatusMessage: false
        };
    }

    render() {
        const {insertAssignmentClaimsState} = this.props;
        const {displayStatusMessage} = this.state;

        let statusMessage = '';
        if (displayStatusMessage === true && insertAssignmentClaimsState !== 'PROCESSING') {
            statusMessage = (insertAssignmentClaimsState === 'SUCCESS' ? 'Claim list was successfully inserted.' : 'An error occurred while processing your request.');
        }

        const statusMessageStyle = insertAssignmentClaimsState === 'SUCCESS' ? 'u-text-success' : 'u-text-error';
        return (
            <div className="start-review-container">
                <main>
                    <div className="l-body" id="logo-section">
                        <div className="l-body__section">
                            <div className="l-grid l-grid--center u-vr-14-top">
                                <div className="l-grid__col l-grid__col--5 u-vr-6-top">
                                    <img className="loon-logo" src="../images/ic-welcomelogo.svg" alt="Loon logo"/>
                                    <h2 className="u-align-center u-vr-2-top u-h2 u-text-thin" id="loon-title">
                                        Welcome to Loon Admin Page
                                    </h2>
                                    <h4 className="u-align-center u-text-gray u-vr-top u-text-md"
                                        id="loon-instructions">
                                        Enter a list of claim numbers to be added in the Assignment Queue.
                                    </h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="l-grid l-grid--center u-vr-4-top" id="insert-claim-list-container">
                        <div className="l-tile l-grid__col--8">
                            <Form onSubmit={() => {
                                this.props.insertAssignmentClaimListAction(this.state.claimNumberList, this.state.clearQueue, this.state.useKafka);
                                this.setState({displayStatusMessage: true});
                            }}>
                                <div className="l-grid u-vr-4-top u-vr-4 u-hr-2 u-hr-4-left">
                                    <div className="l-grid__col l-grid__col--6">
                                        <FormField name="claimNumberList"
                                                   onChange={e => this.setState({claimNumberList: e.target.value})}
                                                   onClick={() => this.setState({displayStatusMessage: false})}
                                                   value={this.state.claimNumberList}/>
                                    </div>
                                    <div className="l-grid__col l-grid__col--3 u-align-right">
                                        <button
                                            className="c-btn c-btn--primary"
                                            id="submit">Insert Claim List
                                        </button>
                                    </div>
                                    <div className="l-grid__col l-grid__col--3 position-relative">
                                        <div className="u-hr-4-left u-text-sm admin-checkbox">
                                            <FormOption
                                                id="clearQueue"
                                                label="Clear Queue"
                                                name="clearQueue"
                                                onClick={() => this.setState({
                                                    clearQueue: !this.state.clearQueue,
                                                    displayStatusMessage: false
                                                })}
                                                checked={this.state.clearQueue}
                                            />
                                            <FormOption
                                                id="useKafka"
                                                label="Use Kafka"
                                                name="useKafka"
                                                onClick={() => this.setState({
                                                    useKafka: !this.state.useKafka,
                                                    displayStatusMessage: false
                                                })}
                                                checked={this.state.useKafka}
                                            />
                                        </div>
                                    </div>
                                </div>
                            </Form>
                        </div>
                    </div>
                    <div className={`u-align-center u-vr-4-top ${statusMessageStyle}`}
                         id="status-message">{statusMessage}</div>
                </main>
            </div>);
    }
}

export const mapStateToProps = ({status}) => {
    return {insertAssignmentClaimsState: status.insertAssignmentClaimsState};
};

export const mapDispatchToProps = {insertAssignmentClaimListAction};

export default connect(mapStateToProps, mapDispatchToProps)(Admin);

Admin.propTypes = {
    insertAssignmentClaimsState: PropTypes.string,
    insertAssignmentClaimListAction: PropTypes.func.isRequired
};
