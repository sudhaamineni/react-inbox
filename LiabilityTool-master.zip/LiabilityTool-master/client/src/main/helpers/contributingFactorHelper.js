import {MEGA_MENU_ITEMS} from '../constants/contributingFactorConstants';

export const getCFLabel = (cfReason) => {
    let cfLabel = '';
    if (!cfReason) {
        return cfLabel;
    }
    MEGA_MENU_ITEMS.every(item => {
        const targetOption = item.options.find(option => option.value === cfReason);

        if (targetOption) {
            cfLabel = targetOption.label;
            return false;
        } else {
            return true;
        }
    });
    return cfLabel;
};

export const getCFCategory = (cfReason) => {
    let cfCategory = '';
    if (!cfReason) {
        return cfCategory;
    }
    MEGA_MENU_ITEMS.every(item => {
        const targetOption = item.options.find(option => option.value === cfReason);

        if (targetOption) {
            cfCategory = item.icon;
            return false;
        } else {
            return true;
        }
    });
    return cfCategory;
};
