import dateFormat from 'dateformat';
import moment from 'moment';

export const convertZuluTimeToLocalTime = (dateTime) => {
    try {
        const myMomentDate = moment(dateTime);
        return dateFormat(new Date(myMomentDate), 'ddd, mmm d, yyyy \'at\' h:MMTT Z');
    }
    catch (error) {
        return 'UNKNOWN';
    }
};

export const formatLossDateString = (lossDateString) => {
    //lossDate comes is in the format: mm/dd/yyyy.  Convert it to day of week, month abbreviation, dd, yyyy
    try {
        return dateFormat(new Date(lossDateString), 'ddd, mmm d, yyyy');
    }
    catch (error) {
        return 'UNKNOWN';
    }
};

export const formatVoiceDateTimeString = (date) => {
    //createdTime is in the format 2019-02-06T16:08:30.802. convert it to Wed, Feb 6, 2019 at 4:08PM CST
    try{
        return dateFormat(new Date(date), 'ddd, mmm d, yyyy \'at\' h:MMTT');
    }
    catch (e) {
        return 'UNKNOWN';
    }

};

export const getCurrentTime = () => {
    return new Date();
};
