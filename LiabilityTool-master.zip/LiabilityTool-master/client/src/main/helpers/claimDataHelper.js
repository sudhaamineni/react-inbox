import {
    AUTO,
    BOAT,
    CALL_TYPE_LABELS,
    INSURED,
    LOON_READ_ONLY_USER,
    MOTORCYCLE,
    PEDESTRIAN_BICYCLIST,
    PICK_CAMPER,
    PICK_UP_TRUCK,
    RV,
    UTIL_CAMPER
} from '../constants/loonConstants';
import { detailLossTypesAndIcons } from '../constants/detailLossTypeIconConstants';

export const padClaimNumber = claimNumber => {
    return claimNumber.length >= 12 ? claimNumber : new Array(12 - claimNumber.length + 1).join('0') + claimNumber;
};

export const getQueryStringValue = (location, name) => {
    if (location && location.search && location.search.trim().length > 0 && name && name.trim().length > 0) {
        const queryStringTokens = location.search.substring(1).split('&');
        const queryStringToken = queryStringTokens.filter(token => token.startsWith(`${name}=`))[0];
        if (queryStringToken) {
            return queryStringToken.split('=')[1];
        }
    }
    return null;
};

export const getParticipantName = participant => {
    return (participant && participant.name) || 'Other';
};

export const getCallTypeLabel = callType => {
    return CALL_TYPE_LABELS.has(callType) ? callType : 'Other';
};

export const getIconLabel = participant => {
    switch (participant.role) {
        case INSURED:
            return 'Insured Owner';
        case PEDESTRIAN_BICYCLIST:
            return 'Claimant';
        default:
            return 'Claimant Owner';
    }
};

export const getVehicleInfo = participant => {
    if (participant.role === 'PEDESTRIAN/BICYCLIST') return 'PEDESTRIAN/BICYCLIST';

    return participant.asset.assetYearMakeModel;
};

export const isInsured = participant => {
    return participant.role === INSURED;
};


export const isReadOnlyUser = userRoles => (!!userRoles && userRoles.length === 1 && userRoles.includes(LOON_READ_ONLY_USER));

export const isReadOnly = (userRoles, locked) => {
    return isReadOnlyUser(userRoles) || locked;
};


export const getSketchTemplateType = lossDetailTypeCode => {
    const foundLossDetail = detailLossTypesAndIcons.find(ea => {
        return ea.lossDetailTypeCode === lossDetailTypeCode;
    });
    return foundLossDetail ? foundLossDetail.sketchTemplateType : null;
};

export const getAssetTypeShortName = assetTypeDesc => {
    switch (assetTypeDesc) {
        case AUTO:
            return 'auto';
        case PICK_UP_TRUCK:
            return 'truck';
        case MOTORCYCLE:
            return 'motorcycle';
        case BOAT:
            return 'boat';
        case RV:
            return 'rv';
        case UTIL_CAMPER:
            return '';
        case PICK_CAMPER:
            return '';
        default:
            return '';
    }
};

const getDefaultDamageOptions = (assetTypeDesc) => {
    switch (assetTypeDesc) {
        case AUTO:
            return [];
        case PICK_UP_TRUCK:
        case RV:
            return [{
                value: 'front',
                label: 'Front',
            }, {
                value: 'rear',
                label: 'Rear',
            }, {
                value: 'driver',
                label: 'Driver Side',
            }, {
                value: 'passenger',
                label: 'Passenger Side',
            }, {
                value: 'noDamages',
                label: 'No Damages',
            }];
        case MOTORCYCLE:
            return [{
                value: 'front',
                label: 'Front',
            }, {
                value: 'rear',
                label: 'Rear',
            }, {
                value: 'noDamages',
                label: 'No Damages',
            }];
        case UTIL_CAMPER:
        case PICK_CAMPER:
        case BOAT:
            return [{
                value: 'hasDamage',
                label: 'Has Damage',
            }, {
                value: 'noDamages',
                label: 'No Damages',
            }];
        default:
            return [];
    }
};

export const getDamageOptions = (assetTypeDesc, options) => {
    const optionsSet = new Set(options);
    const allOptions = getDefaultDamageOptions(assetTypeDesc);
    return allOptions.map(option => {
        return {
            value: option.value,
            label: option.label,
            checked: optionsSet.has(option.value)
        };
    });
};

export const createId = type => `${type}${Number(new Date())}`;
