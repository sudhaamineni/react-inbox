const trackEvent = function (event, extraParams = {}) {
    window.digitalData.CtaResponse = event;
    Object.assign(window.digitalData, extraParams);
    if (typeof window._satellite !== 'undefined') {
        window._satellite.track('wl_continue');
    }
};

const trackTransaction = function (transaction) {
    window.digitalData.Transaction = transaction;
    if (typeof window._satellite !== 'undefined') {
        window._satellite.track('wl_continue');
    }
};

export default {
    initialize: function () {
        window.digitalData = {
            Page: {
                server: window.location.host,
                channel: 'claims/loon/',
                isitOverlay: false
            },
            CtaResponse: {},
            Transaction: {claimNumber: null}
        };
    },

    trackPage: function (page) {
        window.digitalData.Page.pageId = page;
        if (typeof window._satellite !== 'undefined') {
            window._satellite.track('warmup');
        }
    },

    trackEvent,

    trackTransaction,

    clickLink: function (id) {
        let siteCatEvent = {
            message: 'success',
            eventAction: id,
            eventSource: 'button',
            errorCode: '',
        };

        trackEvent(siteCatEvent);

        return false;
    }
};
