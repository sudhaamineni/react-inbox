const isSpecialFunction = event => {
    const {keyCode, ctrlKey, metaKey} = event;

    // Backspace (8), Tab (9), Left Arrow (37), Right Arrow (39), Delete (46)
    const allowedKeys = [8, 9, 37, 39, 46];
    if (allowedKeys.includes(keyCode)) {
        return true;
    }

    // Control/Command + A (65)/C (67)/V (86)
    if ((ctrlKey || metaKey) && (keyCode === 65 || keyCode === 67 || keyCode === 86)) {
        return true;
    }

    return false;
};

const isSelected = event => {
    // IE workaround
    if (event.target.selectionEnd - event.target.selectionStart === 3) {
        return true;
    }

    if (window.getSelection().toString() !== '') {
        return true;
    }

    return false;
};

const isNumber = event => {
    const {keyCode} = event;

    // 0 to 9
    if (!event.shiftKey && !event.altKey) {
        if ((keyCode >= 48 && keyCode <= 57) || (keyCode >= 96 && keyCode <= 105)) {
            return true;
        }
    }
    return false;
};

export const allowThreeDigitNumbers = event => {
    // Allow 3 digits
    if (event.target.value.length > 2 && !isSpecialFunction(event) && !isSelected(event)) {
        event.preventDefault();
    }

    // Allow number
    if (isNumber(event)) {
        return;
    }

    // Allow special function
    if (isSpecialFunction(event)) {
        return;
    }

    event.preventDefault();
};
