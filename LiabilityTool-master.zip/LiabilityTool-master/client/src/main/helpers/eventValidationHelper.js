import _ from 'lodash';
import {OTHER_REASONS_SET, REASON_TO_DETAILS_MAP} from '../constants/contributingFactorConstants';

export const hasSeverityError = (event, eventIndex) => {
    return eventIndex > 0 && (event.severity === null || event.severity === undefined);
};

export const hasTooFewInvolvedPartyError = (event, isSingleParty) => {
    return !event.involvedParties || (event.involvedParties.length < 2 && !isSingleParty);
};

export const hasAddFaultParticipantError = (event) => {
    const set = new Set();
    if (event.involvedParties) {
        event.involvedParties.forEach(ip => set.add(ip.participantId));

        for (let i = 0; i < event.involvedParties.length; i++) {
            const involvedParty = event.involvedParties[i];
            const affectedParties = involvedParty.affectedParties;
            if (affectedParties && affectedParties.length > 0) {
                set.delete(involvedParty.participantId);
                for (let j = 0; j < affectedParties.length; j++) {
                    set.delete(affectedParties[j].participantId);
                }
            }
        }
        return set.size > 0;
    }
    return true;
};

export const hasDamagesError = (involvedParty) => {
    return !involvedParty.damageSections || involvedParty.damageSections.length === 0;
};

export const hasAffectedParticipantNotSelectedError = (affectedParty, isSingleParty) => {
    return !isSingleParty && !affectedParty.participantId;
};

export const hasInitialFaultPercentError = (affectedParty) => {
    return !affectedParty.initialFaultPercent && affectedParty.initialFaultPercent !== 0;
};

export const hasTooMuchAssignedFaultError = (involvedParties) => {
    const totalInitialFaultPercentages = {};
    involvedParties.forEach(i => {
        totalInitialFaultPercentages[i.participantSourceId] = 0;
    });

    involvedParties.forEach(p => {
        p.affectedParties && p.affectedParties.forEach(a => {
            totalInitialFaultPercentages[a.participantSourceId] += a.initialFaultPercent;
        });
    });

    const hasError = [];
    involvedParties.forEach(j => {
        if (totalInitialFaultPercentages[j.participantSourceId] > 100) {
            hasError.push(j.participantSourceId);
        }
    });
    return hasError;
};

export const hasContributingFactorNotSelectedError = (involvedParty) => {
    if (!involvedParty.affectedParties || involvedParty.affectedParties.length === 0) return false;
    if (involvedParty.affectedParties.filter(ap => ap.initialFaultPercent > 0).length === 0) return false;
    if (!involvedParty.contributingFactors || involvedParty.contributingFactors.length === 0) return true;
    for (let i = 0; i < involvedParty.contributingFactors.length; i++) {
        const contributingFactor = involvedParty.contributingFactors[i];
        if (!_.isEmpty(contributingFactor) && null !== contributingFactor.reason) return false;
    }
    return true;
};

const hasMissingCfReasonError = (contributingFactor) => {
    return !contributingFactor.reason;
};

const hasMissingCfDetailError = (contributingFactor) => {
    if (REASON_TO_DETAILS_MAP[contributingFactor.reason]) {
        return !contributingFactor.details;
    }

    if (OTHER_REASONS_SET.has(contributingFactor.reason)) {
        return !contributingFactor.details;
    }
    return false;
};

export const hasSupportingEvidenceError = (contributingFactor, hasEvidence, validateContributingFactorEvidence) => {
    return validateContributingFactorEvidence &&
        !!(hasEvidence && contributingFactor.evidenceIds && contributingFactor.evidenceIds.length <= 0);

};

const createInitialEventValidation = (event) => {
    const eventValidation = {
        error: false,
        severityError: false,
        tooFewInvolvedPartyError: false,
        addFaultParticipantError: false,
        tooMuchAssignedFaultError: [],
        involvedParties: [],
    };

    for (let i = 0; i < event.involvedParties.length; i++) {
        const involvedParty = event.involvedParties[i];
        eventValidation.involvedParties.push({
            damagesError: false,
            minOneCfError: false,
            affectedParties: [],
            contributingFactors: [],
            minOneMissingSupportingEvidenceError: false
        });
        if (Array.isArray(involvedParty.affectedParties)) {
            for (let j = 0; j < involvedParty.affectedParties.length; j++) {
                eventValidation.involvedParties[i].affectedParties.push({
                    affectedParticipantNotSelectedError: false,
                    initialFaultPercentError: false,
                });
            }
        }
        if (Array.isArray(involvedParty.contributingFactors)) {
            for (let k = 0; k < involvedParty.contributingFactors.length; k++) {
                eventValidation.involvedParties[i].contributingFactors.push({
                    missingCfReasonError: false,
                    missingCfDetailsError: false,
                    missingSupportingEvidenceError: false
                });
            }
        }
    }

    return eventValidation;
};

export const createInitialEventValidationArray = (events) => {
    const eventsValidation = [];
    if (Array.isArray(events)) {
        for (let i = 0; i < events.length; i++) {
            eventsValidation.push(createInitialEventValidation(events[i]));
        }
    }
    return eventsValidation;
};

export const validateEvent = (event, eventIndex, isSingleParty = false, hasEvidence = false, validateContributingFactorEvidence = true) => {
    const severityError = hasSeverityError(event, eventIndex);
    const tooFewInvolvedPartyError = hasTooFewInvolvedPartyError(event, isSingleParty);
    const addFaultParticipantError = hasAddFaultParticipantError(event);


    let hasError = severityError || tooFewInvolvedPartyError || addFaultParticipantError;

    const eventValidation = {
        severityError,
        tooFewInvolvedPartyError,
        addFaultParticipantError,
        involvedParties: [],
        tooMuchAssignedFaultError: [],
    };

    if (event.involvedParties) {
        const tooMuchAssignedFaultError = hasTooMuchAssignedFaultError(event.involvedParties);
        if (!(tooMuchAssignedFaultError.length === 0)) {
            hasError = true;
            eventValidation.tooMuchAssignedFaultError = tooMuchAssignedFaultError;
        }

        for (let i = 0; i < event.involvedParties.length; i++) {
            const involvedParty = event.involvedParties[i];
            const damagesError = hasDamagesError(involvedParty);
            if (damagesError) {
                hasError = true;
            }
            const minOneCfError = hasContributingFactorNotSelectedError(involvedParty);
            if (minOneCfError) {
                hasError = true;
            }

            eventValidation.involvedParties.push({
                damagesError,
                minOneCfError,
                contributingFactors: [],
                affectedParties: [],
                minOneMissingSupportingEvidenceError: false
            });

            const contributingFactors = involvedParty.contributingFactors;

            for (let j = 0; j < contributingFactors.length; j++) {
                const cf = involvedParty.contributingFactors[j];
                const missingCfReasonError = hasMissingCfReasonError(cf);
                if (missingCfReasonError) {
                    hasError = true;
                }

                const missingCfDetailsError = hasMissingCfDetailError(cf);
                if (missingCfDetailsError) {
                    hasError = true;
                }

                const missingSupportingEvidenceError = hasSupportingEvidenceError(cf, hasEvidence, validateContributingFactorEvidence);
                if (missingSupportingEvidenceError) {
                    eventValidation.involvedParties[i].minOneMissingSupportingEvidenceError = true;
                    hasError = true;
                }

                eventValidation.involvedParties[i].contributingFactors.push({
                    missingCfReasonError,
                    missingCfDetailsError,
                    missingSupportingEvidenceError
                });
            }

            const affectedParties = involvedParty.affectedParties;
            for (let j = 0; affectedParties && j < affectedParties.length; j++) {
                const affectedParticipantNotSelectedError = hasAffectedParticipantNotSelectedError(affectedParties[j], isSingleParty);
                if (affectedParticipantNotSelectedError) {
                    hasError = true;
                }
                const initialFaultPercentError = hasInitialFaultPercentError(affectedParties[j]) || tooMuchAssignedFaultError.includes(affectedParties[j].participantSourceId);
                if (initialFaultPercentError) {
                    hasError = true;
                }
                eventValidation.involvedParties[i].affectedParties.push({
                    affectedParticipantNotSelectedError,
                    initialFaultPercentError
                });
            }
        }
    }
    eventValidation.error = hasError;
    return eventValidation;
};

export const revalidateEvent = (event, setEventsValidationAction, eventIndex, eventsValidation, evidences, validateContributingFactorEvidence = true) => {
    if (eventsValidation.length > eventIndex && eventsValidation[eventIndex].error) {
        const newEventsValidation = [...eventsValidation];
        newEventsValidation[eventIndex] = validateEvent(event, eventIndex, false, evidences ? evidences.length > 0 : false, validateContributingFactorEvidence);
        setEventsValidationAction(newEventsValidation);
    }
};
