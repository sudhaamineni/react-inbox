import {
    CLEAR_REPORT_DATA,
    GET_CLAIMS_BY_CREATED_TIME,
    GET_CLAIMS_BY_CREATED_TIME_SUCCESS,
    GET_INITIAL_FAULT_PENDING_CLAIMS,
    GET_INITIAL_FAULT_PENDING_CLAIMS_SUCCESS,
    GET_RESUBMITTED_CLAIMS,
    GET_RESUBMITTED_CLAIMS_SUCCESS,
    GET_SUBMITTED_BOOKMARKED_PHOTO_AVERAGE,
    GET_SUBMITTED_BOOKMARKED_PHOTO_AVERAGE_SUCCESS,
    GET_SUBMITTED_CLAIMS,
    GET_SUBMITTED_CLAIMS_SUCCESS,
    GET_CLAIMS_BY_INITIAL_FAULT_SUBMITTED_TIME,
    GET_CLAIMS_BY_INITIAL_FAULT_SUBMITTED_TIME_SUCCESS,
} from '../actions/actionTypes';

const initialState = {
    loading: false,
    claims: [],
    count: 0
};

export default function reportingReducer(state = initialState, action) {
    switch (action.type) {
        case GET_SUBMITTED_CLAIMS:
        case GET_SUBMITTED_BOOKMARKED_PHOTO_AVERAGE:
        case GET_RESUBMITTED_CLAIMS:
        case GET_INITIAL_FAULT_PENDING_CLAIMS:
        case GET_CLAIMS_BY_CREATED_TIME:
        case GET_CLAIMS_BY_INITIAL_FAULT_SUBMITTED_TIME:
            return {...state, loading: true};

        case GET_SUBMITTED_CLAIMS_SUCCESS:
        case GET_INITIAL_FAULT_PENDING_CLAIMS_SUCCESS:
        case GET_RESUBMITTED_CLAIMS_SUCCESS:
            return { ...state, loading: false, claims: action.claims };
        case GET_SUBMITTED_BOOKMARKED_PHOTO_AVERAGE_SUCCESS:
            return { ...state, loading: false, count: action.count };
        case CLEAR_REPORT_DATA:
            return initialState;

        case GET_CLAIMS_BY_CREATED_TIME_SUCCESS:
            return {...state, loading: false, claims: action.claims};

        case GET_CLAIMS_BY_INITIAL_FAULT_SUBMITTED_TIME_SUCCESS:
            return {...state, loading: false, claims: action.claims};

        default:
            return state;
    }
}
