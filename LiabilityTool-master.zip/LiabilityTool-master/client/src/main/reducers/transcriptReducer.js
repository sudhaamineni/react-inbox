import {
    CLEAR_CLAIMDATA,
    GET_CLAIMDATA,
    GET_TRANSCRIPT_FAILURE,
    GET_TRANSCRIPT_SUCCESS,
    SAVE_HIGHLIGHT
} from '../actions/actionTypes';
import { cloneDeep } from 'lodash';

const initialState = {
    nlp: {},
    success: [],
    errors: []
};

const getTranscriptForSuccess = (action) => {
    let beginIndex = 0;
    return action.transcript.transcriptData.map((c, ci) => {
        const endIndex = beginIndex + c.text.length;
        let chunk = {
            speaker: c.speaker,
            beginTime: c.startTime,
            endTime: c.endTime,
            beginIndex,
            endIndex,
            text: c.text,
            highlightTexts: [],
            nlp: {}
        };

        action.transcript.nlpData.forEach(n => {
            n.categoryIndices.forEach((nc, categoryIndex) => {
                const chunkCategory = chunk.nlp[n.categoryName] ? chunk.nlp[n.categoryName] : [];

                // NLP category completely falls in this chunk
                if (nc.startIndex >= beginIndex && nc.endIndex <= endIndex) {
                    chunkCategory.push({
                        categoryIndex: categoryIndex + 1,
                        beginIndex: nc.startIndex - beginIndex,
                        endIndex: nc.endIndex - beginIndex,
                    });
                }
                // NLP category begins in this chunk but ends in a different chunk
                else if (nc.startIndex >= beginIndex && nc.startIndex <= endIndex && nc.endIndex > endIndex) {
                    chunkCategory.push({
                        categoryIndex: categoryIndex + 1,
                        beginIndex: nc.startIndex - beginIndex,
                        endIndex: chunk.text.length,
                    });
                }
                // NLP category begins before this chunk but ends in this chunk
                else if (nc.startIndex < beginIndex && nc.endIndex >= beginIndex && nc.endIndex <= endIndex) {
                    chunkCategory.push({
                        beginIndex: 0,
                        endIndex: nc.endIndex - beginIndex,
                    });
                }
                // NLP category begins before this chunk and ends after this chunk
                else if (nc.startIndex < beginIndex && nc.endIndex > endIndex) {
                    chunkCategory.push({
                        beginIndex: 0,
                        endIndex: chunk.text.length,
                    });
                }
                if (chunkCategory.length !== 0) {
                    chunk.nlp[n.categoryName] = chunkCategory;
                }
            });
        });

        action.transcript.highlightEntities.forEach((he, entityIndex) => {
            he.highlightTexts.filter(ht => ht.chunkIndex === ci).forEach(ht => {
                chunk.highlightTexts.push({
                    entityIndex,
                    beginIndex: ht.beginIndex,
                    endIndex: ht.endIndex
                });
            });
        });

        beginIndex = beginIndex + c.text.length + 1;
        return chunk;
    });
};

export default function transcriptReducer(state = initialState, action) {
    let clonedState = cloneDeep(state);

    switch (action.type) {
        case GET_CLAIMDATA:
            clonedState.success = [];
            clonedState.errors = [];
            return clonedState;

        case GET_TRANSCRIPT_SUCCESS:
            clonedState[action.transcript.voiceId] = getTranscriptForSuccess(action);
            clonedState.nlp[action.transcript.voiceId] = action.transcript.nlpData;
            clonedState.success.push(action.transcript.voiceId);
            return clonedState;

        case GET_TRANSCRIPT_FAILURE:
            clonedState.errors.push(action.voiceId);
            return clonedState;

        case SAVE_HIGHLIGHT:
            clonedState[action.voiceId].forEach((c, ci) => {
                c.highlightTexts = [];
                action.highlightEntities.forEach((he, entityIndex) => {
                    he.highlightTexts.forEach(ht => {
                        if (ci === ht.chunkIndex) {
                            c.highlightTexts.push({
                                entityIndex,
                                beginIndex: ht.beginIndex,
                                endIndex: ht.endIndex
                            });
                        }
                    });
                });
            });
            return clonedState;

        case CLEAR_CLAIMDATA:
            return initialState;

        default:
            return state;
    }
}
