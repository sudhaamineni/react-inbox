import {
    CLEAR_CLAIMDATA,
    CREATE_EVENT,
    GET_ACTIVE_ASSIGNMENT_SUCCESS,
    GET_CLAIMDATA_SUCCESS,
    GET_NEXT_ASSIGNMENT_SUCCESS,
    GET_PHOTO_ATTACHMENTS_SUCCESS,
    GET_VOICE_ATTACHMENTS_SUCCESS,
    INIT_SUCCESS,
    PHOTO_ROTATION,
    PHOTO_TOGGLE_BOOKMARK,
    REMOVE_EVENT,
    SAVE_CLAIM_UNLOCK,
    SAVE_EVIDENCE,
    SAVE_HIGHLIGHT,
    SAVE_NO_FAULT_IND,
    SAVE_REPORTED_PCI,
    SAVE_SKETCH,
    SAVE_UPDATED_ASSIGNMENT_STATUS,
    SAVE_UPDATED_LOSS_LOCATION,
    SAVE_VOICE_PARTICIPANT_SUCCESS,
    SUBMIT_LIABILITY,
    SUBMIT_LIABILITY_ERROR,
    SUBMIT_LIABILITY_SUCCESS,
    UPDATE_DAMAGES,
    UPDATE_EVENT,
} from '../actions/actionTypes';
import * as _ from 'lodash';

const initialState = {
    id: '',
    claimSourceId: '',
    claimNumber: '',
    lossDetailType: '',
    lossStreet: '',
    lossAddress: '',
    lossCity: '',
    lossState: '',
    lossZip: '',
    lossCountyDescription: '',
    mapAddress: '',
    theoryOfDefenseAdditionalNotes: '',
    createdTime: 0,
    updatedTime: 0,
    initialFaultSubmitTime: null,
    settlementSubmitTime: null,
    lastModifiedByUserId: '',
    noFaultAllocationAgreement: false,
    noFaultAllocationResponse: false,
    locked: false,
    lossDate: '',
    liabilitySubjects: [],
    status: '',
    events: [],
    reportedPciDate: null,
    evidences: [],
};

const updatePhotoAttachments = (liabilitySubject, participantSourceId, photoAttachments) => {
    if (liabilitySubject.participantSourceId === participantSourceId) {
        liabilitySubject.photoAttachments = photoAttachments;
    }
};

const updateHighlightEntities = (voiceAttachment, voiceId, highlightEntities) => {
    if (voiceAttachment.sourceVoiceId === voiceId) {
        voiceAttachment.highlightEntities = highlightEntities;
    }
};

const updatePCIReportStatus = (voiceAttachment, sourceVoiceId, reportedPciDate) => {
    if (voiceAttachment.sourceVoiceId === sourceVoiceId) {
        voiceAttachment.reportedPciDate = reportedPciDate;
    }
    return voiceAttachment;
};

export default function claimDataReducer(state = initialState, action) {
    switch (action.type) {

        case CLEAR_CLAIMDATA:
            return initialState;

        case SAVE_UPDATED_ASSIGNMENT_STATUS:
            return action.updatedClaimData;

        case SAVE_UPDATED_LOSS_LOCATION:
            return {
                ...state,
                latitude: action.latitude,
                longitude: action.longitude,
                updatedLossLocation: action.updatedLossLocation
            };

        case GET_CLAIMDATA_SUCCESS:
        case GET_NEXT_ASSIGNMENT_SUCCESS:
        case GET_ACTIVE_ASSIGNMENT_SUCCESS:
            return action.claimData;

        case SUBMIT_LIABILITY_SUCCESS:
            return { ...action.claimData, locked: true };

        case SUBMIT_LIABILITY:
            return { ...action.claimData };

        case SUBMIT_LIABILITY_ERROR:
            return { ...state, locked: false };

        case SAVE_CLAIM_UNLOCK:
            return { ...state, locked: false, unlockReason: action.reason, unlockDescription: action.description };

        case SAVE_NO_FAULT_IND:
            return {
                ...state,
                noFaultAllocationAgreement: action.noFaultAllocationAgreement,
                noFaultAllocationResponse: action.noFaultAllocationResponse
            };

        case GET_PHOTO_ATTACHMENTS_SUCCESS:
            return { ...state, liabilitySubjects: action.liabilitySubjects };

        case GET_VOICE_ATTACHMENTS_SUCCESS:
            return { ...state, voiceAttachments: action.voiceAttachments };

        case PHOTO_TOGGLE_BOOKMARK:
        case PHOTO_ROTATION:
            const updatedLiabilitySubjects = _.cloneDeep(state.liabilitySubjects);
            updatedLiabilitySubjects.forEach(ls => {
                updatePhotoAttachments(ls, action.participantSourceId, action.photoAttachments);
            });
            return {
                ...state,
                liabilitySubjects: updatedLiabilitySubjects,
                evidences: action.evidences,
                events: action.events || state.events
            };

        case INIT_SUCCESS:
            return action.response.assignedClaimData ? action.response.assignedClaimData : state;

        case SAVE_SKETCH:
            return { ...state, sketch: action.sketch };

        case SAVE_HIGHLIGHT:
            const newVoiceAttachments = _.cloneDeep(state.voiceAttachments);
            newVoiceAttachments.forEach(v => {
                updateHighlightEntities(v, action.voiceId, action.highlightEntities);
            });
            return {
                ...state,
                voiceAttachments: newVoiceAttachments,
                evidences: action.evidences,
                events: action.events || state.events,
            };

        case CREATE_EVENT:
            const createdEvents = _.cloneDeep(state.events);
            createdEvents.push(action.event);
            return { ...state, events: createdEvents };

        case UPDATE_EVENT:
            const updatedEvents = [];
            state.events.forEach(e => {
                if (e.id === action.event.id) {
                    updatedEvents.push(action.event);
                } else {
                    updatedEvents.push(e);
                }
            });
            return { ...state, events: updatedEvents };

        case REMOVE_EVENT:
            const removedEvents = _.cloneDeep(state.events);
            removedEvents.splice(removedEvents.findIndex(e => e.id === action.event.id), 1);
            return { ...state, events: removedEvents };

        case UPDATE_DAMAGES:
            const updatedEventsForDamages = _.cloneDeep(state.events);
            updatedEventsForDamages[action.eventIndex].involvedParties[action.involvedPartyIndex].damageSections = action.damageSections;
            return { ...state, events: updatedEventsForDamages };

        case SAVE_VOICE_PARTICIPANT_SUCCESS:
            return { ...state, voiceAttachments: action.voiceAttachments, evidences: action.evidences };

        case SAVE_EVIDENCE:
            const updatedEvidences = [];
            state.evidences.forEach(e => {
                if (e.id === action.evidence.id) {
                    updatedEvidences.push(action.evidence);
                } else {
                    updatedEvidences.push(e);
                }
            });
            return { ...state, evidences: updatedEvidences };

        case SAVE_REPORTED_PCI:
            const updatedState = _.cloneDeep(state);
            const updatedAttachments = updatedState.voiceAttachments.map(va => {
                return updatePCIReportStatus(va, action.sourceVoiceId, action.reportedPciDate);
            });
            updatedState.voiceAttachments = updatedAttachments;
            return updatedState;
        default:
            return state;
    }
}
