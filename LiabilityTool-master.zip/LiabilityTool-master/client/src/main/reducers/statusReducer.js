import {
    CANCEL_SUBMIT_LIABILITY,
    CLEAR_ERROR_MESSAGES,
    CLEAR_NEW_CLAIM_NUMBER,
    CREATE_EVENT,
    EVIDENCE_MODAL_ERROR,
    GET_CLAIMDATA,
    GET_CLAIMDATA_FAILURE,
    GET_CLAIMDATA_SUCCESS,
    GET_PHOTO_ATTACHMENTS_FAILURE,
    GET_PHOTO_ATTACHMENTS_SUCCESS,
    GET_VOICE_ATTACHMENTS_FAILURE,
    GET_VOICE_ATTACHMENTS_SUCCESS,
    INIT_FAILURE,
    INSERT_ASSIGNMENT_ADMIN_ERROR,
    INSERT_ASSIGNMENT_ADMIN_SUCCESS,
    INSERT_ASSIGNMENT_CLAIM_LIST,
    LIABILITY_SUBMITTED,
    REMOVE_EVENT,
    SET_ACTIVE_ASSIGNMENT_RETRIEVED,
    SET_ERROR_MESSAGES,
    SET_ERROR_MESSAGES_WITH_CLAIM_NUMBER,
    SET_EVENTS_VALIDATION,
    SETTLEMENT_SUBMITTED,
    SHOW_EVIDENCE_MODAL,
    SUBMIT_LIABILITY,
    SUBMIT_LIABILITY_ERROR,
    SUBMIT_LIABILITY_SUCCESS,
    SUBMIT_SETTLEMENT,
    SUBMIT_SETTLEMENT_CANCEL,
    SUBMIT_SETTLEMENT_ERROR,
    SUBMIT_SETTLEMENT_SUCCESS,
    UPDATE_DAMAGE_APPORTIONMENT,
    UPDATE_EVENT
} from '../actions/actionTypes';
import {DEFAULT_STATE, ERROR_SUBMITTING, SUBMITTED, SUBMITTING} from '../constants/loonConstants';
import * as _ from 'lodash';
import {createInitialEventValidationArray} from '../helpers/eventValidationHelper';

const initialState = {
    retrievingClaimData: false,
    retrievingAttachments: false,
    attachmentsRetrievalFailed: false,
    insertAssignmentClaimsState: 'PROCESSING',
    activeAssignmentRetrieved: false,
    submitState: DEFAULT_STATE,
    errorHeader: '',
    errorDescription: '',
    errorButton: '',
    newClaimNumber: '',
    eventsValidation: [],
    updatingDamageApportionment: false,
    showEvidenceModal: false,
    evidenceModalError: false
};

export default function statusReducer(state = initialState, action) {
    switch (action.type) {
        case GET_CLAIMDATA:
            return {...state, retrievingClaimData: true, retrievingAttachments: true};

        case GET_CLAIMDATA_SUCCESS:
            return {
                ...state, retrievingClaimData: false,
                eventsValidation: createInitialEventValidationArray(action.claimData.events),
                updatingDamageApportionment: false
            };

        case GET_CLAIMDATA_FAILURE:
            return {...state, retrievingClaimData: false, updatingDamageApportionment: false};

        case GET_PHOTO_ATTACHMENTS_SUCCESS:
        case GET_VOICE_ATTACHMENTS_SUCCESS:
            return {...state, retrievingAttachments: false, attachmentsRetrievalFailed: false};

        case GET_PHOTO_ATTACHMENTS_FAILURE:
        case GET_VOICE_ATTACHMENTS_FAILURE:
            return {...state, retrievingAttachments: false, attachmentsRetrievalFailed: true};

        case INSERT_ASSIGNMENT_ADMIN_ERROR:
            return {...state, insertAssignmentClaimsState: 'ERROR'};

        case INSERT_ASSIGNMENT_ADMIN_SUCCESS:
            return {...state, insertAssignmentClaimsState: 'SUCCESS'};

        case INSERT_ASSIGNMENT_CLAIM_LIST:
            return {...state, insertAssignmentClaimsState: 'PROCESSING'};

        case SET_ACTIVE_ASSIGNMENT_RETRIEVED:
            return {...state, activeAssignmentRetrieved: action.assignmentRetrieved};

        case SUBMIT_LIABILITY:
        case SUBMIT_SETTLEMENT:
            return {...state, submitState: SUBMITTING};

        case SUBMIT_LIABILITY_SUCCESS:
        case SUBMIT_SETTLEMENT_SUCCESS:
            return {...state, submitState: SUBMITTED};

        case SUBMIT_LIABILITY_ERROR:
        case SUBMIT_SETTLEMENT_ERROR:
            return {...state, submitState: ERROR_SUBMITTING};

        case CANCEL_SUBMIT_LIABILITY:
        case SUBMIT_SETTLEMENT_CANCEL:
        case LIABILITY_SUBMITTED:
        case SETTLEMENT_SUBMITTED:
            return {...state, submitState: DEFAULT_STATE};

        case SET_ERROR_MESSAGES:
            return {
                ...state,
                errorHeader: action.errorHeader,
                errorDescription: action.errorDescription,
                updatingDamageApportionment: false
            };

        case SET_ERROR_MESSAGES_WITH_CLAIM_NUMBER:
            return {
                ...state,
                errorHeader: action.errorHeader,
                errorDescription: action.errorDescription,
                newClaimNumber: action.newClaimNumber
            };

        case CLEAR_ERROR_MESSAGES:
            return {
                ...state,
                errorHeader: '',
                errorDescription: '',
                newClaimNumber: '',
                errorButton: '',
            };

        case CLEAR_NEW_CLAIM_NUMBER:
            return {...state, newClaimNumber: ''};

        case SET_EVENTS_VALIDATION:
            return {...state, eventsValidation: action.eventsValidation};

        case CREATE_EVENT:
            const updatedValidations = _.cloneDeep(state.eventsValidation);
            updatedValidations.push({error: false, id: action.event.id});
            return {...state, eventsValidation: updatedValidations};

        case UPDATE_EVENT:
            return {...state};

        case REMOVE_EVENT:
            const eventsValidation = _.cloneDeep(state.eventsValidation);
            eventsValidation.splice(eventsValidation.findIndex(e => e.id === action.event.id), 1);
            return {...state, eventsValidation: eventsValidation};

        case UPDATE_DAMAGE_APPORTIONMENT:
            return {...state, updatingDamageApportionment: true};

        case SHOW_EVIDENCE_MODAL:
            return {...state, showEvidenceModal: action.showEvidenceModal};

        case EVIDENCE_MODAL_ERROR:
            return {...state, evidenceModalError: action.evidenceModalError};

        case INIT_FAILURE:
            if (action.status === 403) {
                return {
                    ...state,
                    errorHeader: 'Unauthorized',
                    errorDescription: 'You do not have access to Loon.',
                    errorButton: 'Back to Login'
                };
            }
            return {
                ...state,
                errorHeader: 'Unavailable',
                errorDescription: 'Our systems are currently unavailable. Please try again later.',
                errorButton: 'Back to Login'
            };

        default:
            return state;
    }
}
