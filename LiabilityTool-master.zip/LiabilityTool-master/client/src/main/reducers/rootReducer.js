import {combineReducers} from 'redux';
import claimDataReducer from './claimDataReducer';
import statusReducer from './statusReducer';
import userReducer from './userReducer';
import transcriptReducer from './transcriptReducer';
import featureSwitchesReducer from './featureSwitchesReducer';
import reportingReducer from './reportingReducer';
import {assetsReducer, diagramReducer, dragStartReducer, templateReducer} from 'sketchy-bird';

const rootReducer = combineReducers({
    claimData: claimDataReducer,
    status: statusReducer,
    user: userReducer,
    transcripts: transcriptReducer,
    featureSwitches: featureSwitchesReducer,
    reporting: reportingReducer,
    dragItem: dragStartReducer,
    diagram: diagramReducer,
    assets: assetsReducer,
    template: templateReducer,
});

export default rootReducer;
