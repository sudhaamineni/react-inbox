import {INIT_SUCCESS} from '../actions/actionTypes';

const initialState = {
    enableAdmin: false,
    renderSketchTab: false,
    enableSettleTab: false
};

export default function featureSwitchesReducer(state = initialState, action) {
    if (action.type === INIT_SUCCESS) {
        if (action.response.featureSwitches) {
            return action.response.featureSwitches;
        }
        return state;
    }
    return state;
}
