import {INIT_FAILURE, INIT_SUCCESS} from '../actions/actionTypes';

const initialState = {
    userId: '',
};

export default function userReducer(state = initialState, action) {
    switch (action.type) {
        case INIT_SUCCESS:
            return {
                ...state,
                userId: action.response.userId,
                userRoles: action.response.userRoles,
            };

        case INIT_FAILURE:
            return {
                ...state,
                userRoles: []
            };

        default:
            return state;
    }
}
