import {SIGNOUT} from './actionTypes';

export function signOutAction() {
    return {
        type: SIGNOUT
    };
}
