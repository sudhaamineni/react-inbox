import {
    CLEAR_CLAIMDATA,
    GET_CLAIMDATA,
    GET_CLAIMDATA_FAILURE,
    GET_CLAIMDATA_SUCCESS,
    SAVE_CLAIM_UNLOCK,
    SAVE_NO_FAULT_IND,
    SAVE_REPORTED_PCI,
    SAVE_SKETCH,
} from './actionTypes';

export const getClaimDataAction = claimNumber => {
    return {
        type: GET_CLAIMDATA,
        claimNumber,
    };
};

export const getClaimDataSuccessAction = claimData => {
    return {
        type: GET_CLAIMDATA_SUCCESS,
        claimData,
    };
};

export const getClaimDataFailureAction = claimData => {
    return {
        type: GET_CLAIMDATA_FAILURE,
        claimData,
    };
};

export const clearClaimDataAction = () => {
    return {
        type: CLEAR_CLAIMDATA,
    };
};

export const saveNoFaultAllocationIndicatorAction = (claimNumber, noFaultAllocationAgreement, noFaultAllocationResponse) => {
    return {
        type: SAVE_NO_FAULT_IND,
        claimNumber,
        noFaultAllocationAgreement,
        noFaultAllocationResponse
    };
};

export const saveSketchAction = sketch => {
    return {
        type: SAVE_SKETCH,
        sketch
    };
};

export const saveClaimUnlockAction = (claimNumber, reason, description) => {
    return {
        type: SAVE_CLAIM_UNLOCK,
        claimNumber,
        reason,
        description,
    };
};

export const saveReportedPciAction = (claimNumber, sourceVoiceId, transcriptId, pciCategories) => {
    return {
        type: SAVE_REPORTED_PCI,
        claimNumber,
        sourceVoiceId,
        transcriptId,
        pciCategories,
        reportedPciDate: Date.now()
    };
};
