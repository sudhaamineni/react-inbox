import {
    CLEAR_REPORT_DATA,
    GET_CLAIMS_BY_CREATED_TIME,
    GET_CLAIMS_BY_CREATED_TIME_SUCCESS,
    GET_CLAIMS_BY_INITIAL_FAULT_SUBMITTED_TIME,
    GET_CLAIMS_BY_INITIAL_FAULT_SUBMITTED_TIME_SUCCESS,
    GET_INITIAL_FAULT_PENDING_CLAIMS,
    GET_INITIAL_FAULT_PENDING_CLAIMS_SUCCESS,
    GET_RESUBMITTED_CLAIMS,
    GET_RESUBMITTED_CLAIMS_SUCCESS,
    GET_SUBMITTED_BOOKMARKED_PHOTO_AVERAGE_SUCCESS,
    GET_SUBMITTED_CLAIMS_SUCCESS
} from './actionTypes';

export const getSubmittedClaimsSuccessAction = claims => {
    return {
        type: GET_SUBMITTED_CLAIMS_SUCCESS,
        claims
    };
};

export const getSubmittedBookmarkedPhotoAverageSuccessAction = count => {
    return {
        type: GET_SUBMITTED_BOOKMARKED_PHOTO_AVERAGE_SUCCESS,
        count
    };
};

export const getReSubmittedClaimsAction = (beginDate, endDate) => {
    return {
        type: GET_RESUBMITTED_CLAIMS,
        beginDate,
        endDate
    };
};

export const getReSubmittedClaimsSuccessAction = claims => {
    return {
        type: GET_RESUBMITTED_CLAIMS_SUCCESS,
        claims
    };
};

export const clearReportDataAction = () => {
    return {
        type: CLEAR_REPORT_DATA
    };
};

export const getClaimsByCreatedTimeAction = (beginDate, endDate) => {
    return {
        type: GET_CLAIMS_BY_CREATED_TIME,
        beginDate,
        endDate
    };
};

export const getClaimsByCreatedTimeSuccessAction = claims => {
    return {
        type: GET_CLAIMS_BY_CREATED_TIME_SUCCESS,
        claims

    };
};

export const getInitialFaultPendingClaimsAction = () => {
    return {
        type: GET_INITIAL_FAULT_PENDING_CLAIMS,
    };
};

export const getInitialFaultPendingClaimsSuccessAction = (claims) => {
    return {
        type: GET_INITIAL_FAULT_PENDING_CLAIMS_SUCCESS,
        claims
    };
};

export const getClaimsByInitialFaultSubmittedAction = (beginDate, endDate) => {
    return {
        type: GET_CLAIMS_BY_INITIAL_FAULT_SUBMITTED_TIME,
        beginDate,
        endDate
    };
};

export const getClaimsByInitialFaultSubmittedSuccessAction = claims => {
    return {
        type: GET_CLAIMS_BY_INITIAL_FAULT_SUBMITTED_TIME_SUCCESS,
        claims

    };
};
