import * as types from './actionTypes';

export const insertAssignmentClaimListAction = (claimNumberList, clearQueue, useKafka) => {
    return {
        type: types.INSERT_ASSIGNMENT_CLAIM_LIST,
        claimNumberList,
        clearQueue,
        useKafka
    };
};

export const insertAssignmentAdminSuccessAction = () => {
    return {
        type: types.INSERT_ASSIGNMENT_ADMIN_SUCCESS,
    };
};

export const insertAssignmentAdminErrorAction = () => {
    return {
        type: types.INSERT_ASSIGNMENT_ADMIN_ERROR,
    };
};
