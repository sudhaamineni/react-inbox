import {
    GET_TRANSCRIPT_FAILURE,
    GET_TRANSCRIPT_SUCCESS,
    SAVE_HIGHLIGHT,
    SAVE_VOICE_PARTICIPANT,
    SAVE_VOICE_PARTICIPANT_SUCCESS
} from './actionTypes';

export const getTranscriptSuccessAction = transcript => {
    return {
        type: GET_TRANSCRIPT_SUCCESS,
        transcript
    };
};

export const saveHighlightAction = (claimNumber, voiceId, highlightEntities, evidences, events) => {
    return {
        type: SAVE_HIGHLIGHT,
        claimNumber,
        voiceId,
        highlightEntities,
        evidences,
        events
    };
};

export const saveVoiceParticipantAction = (claimNumber, index, participantSourceId, callType) => {
    return {
        type: SAVE_VOICE_PARTICIPANT,
        claimNumber,
        index,
        participantSourceId,
        callType,
    };
};

export const saveVoiceParticipantSuccessAction = (voiceAttachments, evidences) => {
    return {
        type: SAVE_VOICE_PARTICIPANT_SUCCESS,
        voiceAttachments,
        evidences
    };
};

export const getTranscriptDataFailureAction = voiceId => {
    return {
        type: GET_TRANSCRIPT_FAILURE,
        voiceId
    };
};
