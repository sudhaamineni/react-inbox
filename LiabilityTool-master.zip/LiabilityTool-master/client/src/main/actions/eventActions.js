import {CREATE_EVENT, REMOVE_EVENT, SET_EVENTS_VALIDATION, UPDATE_DAMAGES, UPDATE_EVENT} from './actionTypes';
import {createId} from '../helpers/claimDataHelper';

export const createEventAction = (claimNumber, event) => {
    event.id = createId('event');
    return {
        type: CREATE_EVENT,
        claimNumber,
        event
    };
};

export const updateEventAction = (claimNumber, event) => {
    return {
        type: UPDATE_EVENT,
        claimNumber,
        event
    };
};

export const removeEventAction = (claimNumber, event) => {
    return {
        type: REMOVE_EVENT,
        claimNumber,
        event
    };
};

export const updateDamagesAction = (eventIndex, involvedPartyIndex, damageSections) => {
    return {
        type: UPDATE_DAMAGES,
        eventIndex,
        involvedPartyIndex,
        damageSections
    };
};

export const setEventsValidationAction = eventsValidation => {
    return {
        type: SET_EVENTS_VALIDATION,
        eventsValidation
    };
};
