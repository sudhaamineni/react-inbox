import {PHOTO_TOGGLE_BOOKMARK, PHOTO_ROTATION} from './actionTypes';

export const photoToggleBookmarkAction = (claimNumber, participantSourceId, photoAttachments, evidences, events) => {
    return {
        type: PHOTO_TOGGLE_BOOKMARK,
        claimNumber,
        participantSourceId,
        photoAttachments,
        evidences,
        events
    };
};

export const photoRotationAction = (claimNumber, participantSourceId, photoAttachments, evidences) => {
    return {
        type: PHOTO_ROTATION,
        claimNumber,
        participantSourceId,
        photoAttachments,
        evidences
    };
};
