import {
    GET_PHOTO_ATTACHMENTS_FAILURE,
    GET_PHOTO_ATTACHMENTS_SUCCESS,
    GET_VOICE_ATTACHMENTS_FAILURE,
    GET_VOICE_ATTACHMENTS_SUCCESS,
    SAVE_EVIDENCE
} from './actionTypes';

export const getPhotoAttachmentsSuccessAction = liabilitySubjects => ({ type: GET_PHOTO_ATTACHMENTS_SUCCESS, liabilitySubjects });

export const getPhotoAttachmentsFailureAction = () => ({ type: GET_PHOTO_ATTACHMENTS_FAILURE });

export const getVoiceAttachmentsSuccessAction = voiceAttachments => ({ type: GET_VOICE_ATTACHMENTS_SUCCESS, voiceAttachments });

export const getVoiceAttachmentsFailureAction = () => ({ type: GET_VOICE_ATTACHMENTS_FAILURE });

export const saveEvidenceAction = (claimNumber, evidence) => ({ type: SAVE_EVIDENCE, claimNumber, evidence });

