import * as types from './actionTypes';

export const lossLocationSaveAction = (claimNumber, latitude, longitude, updatedLossLocation) => {
    return {
        type: types.SAVE_UPDATED_LOSS_LOCATION,
        claimNumber,
        latitude,
        longitude,
        updatedLossLocation
    };
};
