import * as types from './actionTypes';

export function sessionKeepAliveAction() {
    return {
        type: types.SESSION_KEEPALIVE
    };
}
