import {
    CANCEL_SUBMIT_LIABILITY,
    LIABILITY_SUBMITTED,
    SETTLEMENT_SUBMITTED,
    SUBMIT_LIABILITY,
    SUBMIT_LIABILITY_ERROR,
    SUBMIT_LIABILITY_SUCCESS,
    SUBMIT_SETTLEMENT,
    SUBMIT_SETTLEMENT_CANCEL,
    SUBMIT_SETTLEMENT_ERROR,
    SUBMIT_SETTLEMENT_SUCCESS,
    UPDATE_DAMAGE_APPORTIONMENT
} from './actionTypes';

export const submitLiabilityAction = (claimData, mapImage) => {
    return {
        type: SUBMIT_LIABILITY,
        claimData,
        mapImage
    };
};

export const submitLiabilitySuccessAction = claimData => {
    return {
        type: SUBMIT_LIABILITY_SUCCESS,
        claimData
    };
};

export const submitLiabilityErrorAction = () => {
    return {
        type: SUBMIT_LIABILITY_ERROR
    };
};

export const submitLiabilityCancelAction = () => {
    return {
        type: CANCEL_SUBMIT_LIABILITY
    };
};

export const liabilitySubmittedAction = () => {
    return {
        type: LIABILITY_SUBMITTED
    };
};

export const updateDamageApportionmentAction = claimNumber => {
    return {
        type: UPDATE_DAMAGE_APPORTIONMENT,
        claimNumber
    };
};

export const submitSettlementAction = claimNumber => {
    return {
        type: SUBMIT_SETTLEMENT,
        claimNumber
    };
};

export const submitSettlementSuccessAction = () => {
    return {
        type: SUBMIT_SETTLEMENT_SUCCESS,
    };
};

export const submitSettlementErrorAction = () => {
    return {
        type: SUBMIT_SETTLEMENT_ERROR,
    };
};

export const submitSettlementCancelAction = () => {
    return {
        type: SUBMIT_SETTLEMENT_CANCEL,
    };
};

export const settlementSubmittedAction = () => {
    return {
        type: SETTLEMENT_SUBMITTED,
    };
};
