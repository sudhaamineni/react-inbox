import {
    GET_NEXT_ASSIGNMENT,
    GET_NEXT_ASSIGNMENT_SUCCESS,
    ON_START_REVIEW_TIMEOUT,
    SAVE_UPDATED_ASSIGNMENT_STATUS
} from './actionTypes';

export const getNextAssignmentAction = () => {
    return {
        type: GET_NEXT_ASSIGNMENT
    };
};

export const getNextAssignmentSuccessAction = claimData => {
    return {
        type: GET_NEXT_ASSIGNMENT_SUCCESS,
        claimData
    };
};

export const updateAssignmentStatusAction = (updatedStatus, claimData) => {
    const updatedClaimData = {
        ...claimData,
        status: updatedStatus
    };
    return {
        type: SAVE_UPDATED_ASSIGNMENT_STATUS,
        updatedClaimData
    };
};

export const onStartReviewTimeoutAction = claimNumber => {
    return {
        type: ON_START_REVIEW_TIMEOUT,
        claimNumber
    };
};
