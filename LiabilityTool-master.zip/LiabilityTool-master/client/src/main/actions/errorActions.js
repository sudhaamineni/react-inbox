import {
    CLEAR_ERROR_MESSAGES,
    CLEAR_NEW_CLAIM_NUMBER,
    SET_ERROR_MESSAGES,
    SET_ERROR_MESSAGES_WITH_CLAIM_NUMBER
} from './actionTypes';

export const setErrorMessagesAction = (errorHeader, errorDescription) => {
    return {
        type: SET_ERROR_MESSAGES,
        errorHeader,
        errorDescription,
    };
};

export const setErrorWithClaimNumberAction = (errorHeader, errorDescription, newClaimNumber) => {
    return {
        type: SET_ERROR_MESSAGES_WITH_CLAIM_NUMBER,
        errorHeader,
        errorDescription,
        newClaimNumber
    };
};

export const clearErrorMessagesAction = () => {
    return {
        type: CLEAR_ERROR_MESSAGES
    };
};

export const clearNewClaimNumberAction = () => {
    return {
        type: CLEAR_NEW_CLAIM_NUMBER
    };
};
