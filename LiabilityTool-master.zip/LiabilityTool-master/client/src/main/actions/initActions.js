import {INIT_FAILURE, INIT_SUCCESS} from './actionTypes';

export const initSuccessAction = response => {
    return {
        type: INIT_SUCCESS,
        response
    };
};

export const initFailureAction = status => {
    return {
        type: INIT_FAILURE,
        status
    };
};
