import {
    EVIDENCE_MODAL_ERROR,
    SHOW_EVIDENCE_MODAL
} from './actionTypes';

export const showEvidenceModalAction = (showEvidenceModal) => {
    return {
        type: SHOW_EVIDENCE_MODAL,
        showEvidenceModal,
    };
};

export const evidenceModalErrorAction = (evidenceModalError) => {
    return {
        type: EVIDENCE_MODAL_ERROR,
        evidenceModalError,
    };
};
