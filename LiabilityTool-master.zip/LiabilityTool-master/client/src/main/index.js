import 'babel-polyfill';
import './styles/loonStyles.scss';
import './styles/headerStyles.scss';
import './styles/errorPageStyles.scss';
import './styles/searchPageStyles.scss';
import './styles/participantCardStyles.scss';
import './styles/reviewAnalysis.scss';
import './styles/contributingFactors.scss';
import './styles/participantOwner.scss';
import './styles/chunkStyles.scss';
import './styles/transcript.scss';
import './styles/assignmentStyles.scss';
import './styles/investigationPage.scss';
import './styles/admin.scss';
import './styles/lossDetailsCard.scss';
import './styles/bookmarkToolbar.scss';
import './styles/event.scss';
import './styles/pagination.scss';
import './styles/reporting.scss';
import './styles/participantAssetDamages.scss';
import './styles/liabilityPage.scss';
import './styles/settle.scss';
import './styles/evidenceModal.scss';
import React from 'react';
import {render} from 'react-dom';
import createBrowserHistory from 'history/createHashHistory';
import {applyMiddleware, compose, createStore} from 'redux';
import createSagaMiddleware from 'redux-saga';
import {connectRouter, routerMiddleware} from 'connected-react-router';
import LoonRouter from './LoonRouter';
import rootReducer from './reducers/rootReducer';
import rootSaga from './sagas/rootSagas';
import registerServiceWorker from '../registerServiceWorker';

const composeEnhancer = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose; // eslint-disable-line
const history = createBrowserHistory();
const sagaMiddleware = createSagaMiddleware();

const store = createStore(
    connectRouter(history)(rootReducer),
    composeEnhancer(
        applyMiddleware(sagaMiddleware),
        applyMiddleware(routerMiddleware(history))
    )
);

sagaMiddleware.run(rootSaga);

render(<LoonRouter store={store} history={history}/>, document.getElementById('app'));

registerServiceWorker();
