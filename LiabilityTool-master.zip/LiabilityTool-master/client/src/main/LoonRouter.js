import React, {Component} from 'react';
import {Provider} from 'react-redux';
import {Route, Switch} from 'react-router-dom';
import SearchPage from './components/SearchPage';
import Reporting from './components/reporting/Reporting';
import ReviewAssignment from './components/assignment/ReviewAssignment';
import Admin from './components/admin/Admin';
import {LoonRenderer} from './hoc/loonRenderer';
import {ConnectedRouter} from 'connected-react-router';
import {sessionKeepAliveAction} from './actions/keepAliveActions';
import Investigation from './components/investigation/Investigation';
import Liability from './components/liability/Liability';
import Sketch from './components/sketch/Sketch';
import AnalyticsHelper from './helpers/analyticsHelper';
import NextAssignment from './components/assignment/NextAssignment';
import PropTypes from 'prop-types';
import Settlement from './components/settlement/Settlement';

AnalyticsHelper.initialize();

export default class LoonRouter extends Component {
    componentDidMount() {
        setInterval(this.keepAlive, 60 * 60 * 1000);
    };

    keepAlive = () => {
        this.props.store.dispatch(sessionKeepAliveAction());
    };

    render() {
        return (
            <Provider store={this.props.store}>
                <ConnectedRouter history={this.props.history}>
                    <Switch>
                        <Route path="/search" exact component={LoonRenderer(SearchPage)}/>
                        <Route path="/investigate" exact component={LoonRenderer(Investigation)}/>
                        <Route path="/sketch" exact component={LoonRenderer(Sketch)}/>
                        <Route path="/initial-fault" exact component={LoonRenderer(Liability)}/>
                        <Route path="/settlement" exact component={LoonRenderer(Settlement)}/>
                        <Route path="/admin" exact component={LoonRenderer(Admin)}/>
                        <Route path="/next/review" exact component={LoonRenderer(ReviewAssignment)}/>
                        <Route path="/next" exact component={LoonRenderer(NextAssignment)}/>
                        <Route path="/rpt" exact component={LoonRenderer(Reporting)}/>
                        <Route path="/" exact component={LoonRenderer(SearchPage)}/>
                    </Switch>
                </ConnectedRouter>
            </Provider>
        );
    }
}

LoonRouter.propTypes = {
    store: PropTypes.object.isRequired,
    history: PropTypes.object
};
