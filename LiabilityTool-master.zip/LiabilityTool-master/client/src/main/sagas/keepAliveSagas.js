import { call} from 'redux-saga/effects';
import { takeEvery } from 'redux-saga';
import {getData} from '../httpClient';

import * as types from '../actions/actionTypes';

export function* watchSessionKeepAlive() {
    yield* takeEvery(types.SESSION_KEEPALIVE, sessionKeepalive);
}

export function* sessionKeepalive() {
   try {
        yield call(getData, '/api/v1/sessions');
    }
     catch (ex)
     {
         //do not rethrow exception
     }
}
