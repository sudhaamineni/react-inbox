import {call, fork, put, select} from 'redux-saga/effects';
import {
    GET_CLAIMDATA,
    GET_PHOTO_ATTACHMENTS,
    GET_VOICE_ATTACHMENTS,
    PHOTO_ROTATION,
    PHOTO_TOGGLE_BOOKMARK,
    SAVE_CLAIM_UNLOCK,
    SAVE_HIGHLIGHT,
    SAVE_NO_FAULT_IND,
    SAVE_REPORTED_PCI,
    SAVE_SKETCH,
    SAVE_UPDATED_LOSS_LOCATION,
    SAVE_VOICE_PARTICIPANT
} from '../actions/actionTypes';
import {takeEvery} from 'redux-saga';
import {push} from 'connected-react-router';
import {getData, postData} from '../httpClient';
import {getPhotoAttachments, getVoiceAttachments} from './attachmentsSagas';
import {getClaimDataFailureAction, getClaimDataSuccessAction} from '../actions/claimDataActions';
import {clearErrorMessagesAction, setErrorMessagesAction, setErrorWithClaimNumberAction} from '../actions/errorActions';
import {LOON_WIP_CLAIM_NUMBER, UNAVAILABLE_ERROR_MESSAGE} from '../constants/loonConstants';
import * as selectors from './selectors';
import {getParticipantName, padClaimNumber} from '../helpers/claimDataHelper';
import {saveVoiceParticipantSuccessAction} from '../actions/transcriptActions';

export const getUrlToGoTo = () => {
    if (window.location.hash === '#/'
        || window.location.hash.startsWith('#/investigate')) {
        return '/investigate';
    }
    return window.location.hash.substring(1);
};

const handleError = e => {
    if (!e || !e.data || !e.data.messageHeader) {
        e = {
            data: UNAVAILABLE_ERROR_MESSAGE
        };
    }
    return e;
};

export function* watchGetClaimData() {
    yield* takeEvery(GET_CLAIMDATA, getClaimData);
}

export const setSessionStorage = claimNumber => {
    window.sessionStorage.setItem(LOON_WIP_CLAIM_NUMBER, claimNumber);
};

export function* getClaimData(action) {
    try {
        const claimNumber = padClaimNumber(action.claimNumber);
        const url = `/api/v1/liabilityanalysis/${encodeURIComponent(claimNumber)}`;
        const response = yield call(getData, url);
        setSessionStorage(claimNumber);
        yield put(clearErrorMessagesAction());
        yield put(getClaimDataSuccessAction(response.data));
        const goTo = getUrlToGoTo();
        if (goTo.split('/')[1] !== window.location.hash.split('/')[1]) {
            yield put(push(goTo));
        }
        yield fork(getPhotoAttachments, {
            type: GET_PHOTO_ATTACHMENTS,
            claimNumber
        });
        yield fork(getVoiceAttachments, {
            type: GET_VOICE_ATTACHMENTS,
            claimNumber
        });
    } catch (e) {
        e = handleError(e);
        yield put(getClaimDataFailureAction());
        yield put(setErrorWithClaimNumberAction(e.data.messageHeader, e.data.messageDescription, e.data.newClaimNumber));

        if (e.data.messageHeader === UNAVAILABLE_ERROR_MESSAGE.messageHeader) {
            yield put(push('/investigate'));
        } else {
            yield put(push('/'));
        }
    }
}

export function* watchSaveUpdatedLossLocation() {
    yield* takeEvery(SAVE_UPDATED_LOSS_LOCATION, saveUpdatedLossLocation);
}

export function* saveUpdatedLossLocation(action) {
    const updatedLocation = {
        latitude: action.latitude,
        longitude: action.longitude,
        updatedLossLocation: action.updatedLossLocation
    };
    yield call(postData, `/api/v1/liabilityanalysis/losslocation/${action.claimNumber}`, updatedLocation);
}

export function* watchSaveVoiceParticipant() {
    yield* takeEvery(SAVE_VOICE_PARTICIPANT, saveVoiceParticipant);
}

export function* saveVoiceParticipant(action) {
    const voiceAttachments = yield select(selectors.selectVoiceAttachments);
    const participants = yield select(selectors.selectParticipants);
    const evidences = yield select(selectors.selectEvidences);
    const sourceVoiceId = voiceAttachments[action.index].sourceVoiceId;
    let modifiedEvidences = [...evidences];

    const participantDisplayName = getParticipantName(participants.find(c => c.participantSourceId === action.participantSourceId));
    for (let i = 0; i < modifiedEvidences.length; i++) {
        if (modifiedEvidences[i].type === 'highlight' && modifiedEvidences[i].sourceVoiceId === sourceVoiceId) {
            modifiedEvidences[i].callType = action.callType;
            if (action.participantSourceId === 'OTHER') {
                modifiedEvidences[i].participantSourceId = '';
                modifiedEvidences[i].participantDisplayName = 'Other';
            } else {
                modifiedEvidences[i].participantSourceId = action.participantSourceId;
                modifiedEvidences[i].participantDisplayName = participantDisplayName;
            }
        }
    }

    const updatedAttachments = JSON.parse(JSON.stringify(voiceAttachments));
    if (action.participantSourceId === 'OTHER') {
        updatedAttachments[action.index].participantSourceId = '';
        updatedAttachments[action.index].participantDisplayName = 'Other';
    } else {
        updatedAttachments[action.index].participantSourceId = action.participantSourceId;
        updatedAttachments[action.index].participantDisplayName = participantDisplayName;
    }
    updatedAttachments[action.index].sourceVoiceTitle = action.callType;

    yield call(saveVoiceAttachments, {
        claimNumber: action.claimNumber,
        voiceAttachments: updatedAttachments,
        evidences: modifiedEvidences
    });
    yield put(saveVoiceParticipantSuccessAction(updatedAttachments, modifiedEvidences));
}

export function* saveVoiceAttachments(action) {
    const url = `/api/v1/liabilityanalysis/voiceattachments/${padClaimNumber(action.claimNumber)}`;
    try {
        yield call(postData, url, {voiceAttachments: action.voiceAttachments, evidences: action.evidences});
    } catch (e) {
        if (!e || !e.data || !e.data.messageHeader) {
            e = {
                data: UNAVAILABLE_ERROR_MESSAGE
            };
        }
        yield put(setErrorMessagesAction(e.data.messageHeader, e.data.messageDescription));
    }
}

export function* watchSaveNoFaultAllocationIndicator() {
    yield* takeEvery(SAVE_NO_FAULT_IND, saveNoFaultAllocationIndicator);
}

export function* saveNoFaultAllocationIndicator(action) {
    try {
        const payload = {
            noFaultAllocationAgreement: action.noFaultAllocationAgreement,
            noFaultAllocationResponse: action.noFaultAllocationResponse
        };
        yield call(postData, `/api/v1/liabilityanalysis/save-no-fault-ind/${action.claimNumber}`, payload);
    } catch (e) {
        if (!e || !e.data || !e.data.messageHeader) {
            e = {
                data: UNAVAILABLE_ERROR_MESSAGE
            };
        }
        yield put(setErrorMessagesAction(e.data.messageHeader, e.data.messageDescription));
    }
}

export function* watchSaveHighlight() {
    yield* takeEvery(SAVE_HIGHLIGHT, saveHighlight);
}

export function* saveHighlight(action) {
    const url = `/api/v1/liabilityanalysis/${padClaimNumber(action.claimNumber)}/${action.voiceId}/highlight`;
    const payload = {highlightEntities: action.highlightEntities, evidences: action.evidences, events: action.events};
    try {
        yield call(postData, url, payload);
    } catch (e) {
        if (!e || !e.data || !e.data.messageHeader) {
            e = {
                data: UNAVAILABLE_ERROR_MESSAGE
            };
        }
        yield put(setErrorMessagesAction(e.data.messageHeader, e.data.messageDescription));
    }
}

export function* watchSaveSketch() {
    yield* takeEvery(SAVE_SKETCH, saveSketch);
}

export function* saveSketch(action) {
    try {
        const claimData = yield select(selectors.getClaimData);
        yield call(postData, `/api/v1/liabilityanalysis/${claimData.claimNumber}/sketch`, action.sketch);
    } catch (e) {
        if (!e || !e.data || !e.data.messageHeader) {
            e = {
                data: UNAVAILABLE_ERROR_MESSAGE
            };
        }
        yield put(setErrorMessagesAction(e.data.messageHeader, e.data.messageDescription));
    }
}

export function* watchSaveClaimUnlock() {
    yield* takeEvery(SAVE_CLAIM_UNLOCK, saveClaimUnlock);
}

export function* saveClaimUnlock(action) {
    try {
        const data = {
            unlockReason: action.reason,
            unlockDescription: action.description
        };
        yield call(postData, `/api/v1/liabilityanalysis/claim-unlock/${padClaimNumber(action.claimNumber)}`, data);
    } catch (e) {
        if (!e || !e.data || !e.data.messageHeader) {
            e = {
                data: UNAVAILABLE_ERROR_MESSAGE
            };
        }
        yield put(setErrorMessagesAction(e.data.messageHeader, e.data.messageDescription));
    }
}

export function* watchPhotoToggleBookmark() {
    yield* takeEvery(PHOTO_TOGGLE_BOOKMARK, savePhotoAttachments);
}

export function* watchPhotoRotation() {
    yield* takeEvery(PHOTO_ROTATION, savePhotoAttachments);
}

export function* savePhotoAttachments(action) {
    const url = `/api/v1/liabilityanalysis/${padClaimNumber(action.claimNumber)}/${action.participantSourceId}/photo`;
    const payload = {photoAttachments: action.photoAttachments, evidences: action.evidences, events: action.events};
    try {
        yield call(postData, url, payload);
    } catch (e) {
        if (!e || !e.data || !e.data.messageHeader) {
            e = {
                data: UNAVAILABLE_ERROR_MESSAGE
            };
        }
        yield put(setErrorMessagesAction(e.data.messageHeader, e.data.messageDescription));
    }
}

export function* watchSaveReportedPci() {
    yield* takeEvery(SAVE_REPORTED_PCI, saveReportedPci);
}

export function* saveReportedPci(action) {
    try {
        const data = {
            reportedPciDate: action.reportedPciDate,
            sourceVoiceId: action.sourceVoiceId,
            transcriptId: action.transcriptId,
            pciCategories: action.pciCategories,
        };
        yield call(postData, `/api/v1/liabilityanalysis/${padClaimNumber(action.claimNumber)}/saveReportedPci`, data);
    } catch (e) {
        if (!e || !e.data || !e.data.messageHeader) {
            e = {
                data: UNAVAILABLE_ERROR_MESSAGE
            };
        }
        yield put(setErrorMessagesAction(e.data.messageHeader, e.data.messageDescription));
    }
}
