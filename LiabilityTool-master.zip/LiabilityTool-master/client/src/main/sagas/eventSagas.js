import {call, put, select} from 'redux-saga/effects';
import {takeEvery} from 'redux-saga';
import {postData} from '../httpClient';
import {CREATE_EVENT, REMOVE_EVENT, UPDATE_DAMAGES, UPDATE_EVENT} from '../actions/actionTypes';
import {padClaimNumber} from '../helpers/claimDataHelper';
import {UNAVAILABLE_ERROR_MESSAGE} from '../constants/loonConstants';
import {setErrorMessagesAction} from '../actions/errorActions';
import * as selectors from './selectors';

export function* watchCreateEvent() {
    yield* takeEvery(CREATE_EVENT, createEvent);
}

export function* watchUpdateDamages() {
    yield* takeEvery(UPDATE_DAMAGES, updateDamages);
}

export function* createEvent(action) {
    try {
        yield call(postData, '/api/v1/liabilityanalysis/event/create/' + padClaimNumber(action.claimNumber), action.event);
    } catch (e) {
        if (!e || !e.data || !e.data.messageHeader) {
            e = {
                data: UNAVAILABLE_ERROR_MESSAGE
            };
        }
        yield put(setErrorMessagesAction(e.data.messageHeader, e.data.messageDescription));
    }
}

export function* updateDamages(action) {
    const claimData = yield select(selectors.getClaimData);
    const updatedEvent = JSON.parse(JSON.stringify(claimData.events[action.eventIndex]));

    updatedEvent.involvedParties[action.involvedPartyIndex].damageSections = action.damageSections;

    yield call(updateEvent, {claimNumber: claimData.claimNumber, event: updatedEvent});
}

export function* watchUpdateEvent() {
    yield* takeEvery(UPDATE_EVENT, updateEvent);
}

export function* updateEvent(action) {
    try {
        yield call(postData, '/api/v1/liabilityanalysis/event/update/' + padClaimNumber(action.claimNumber), action.event);
    } catch (e) {
        if (!e || !e.data || !e.data.messageHeader) {
            e = {
                data: UNAVAILABLE_ERROR_MESSAGE
            };
        }
        yield put(setErrorMessagesAction(e.data.messageHeader, e.data.messageDescription));
    }
}

export function* watchRemoveEvent() {
    yield* takeEvery(REMOVE_EVENT, removeEvent);
}

export function* removeEvent(action) {
    try {
        yield call(postData, '/api/v1/liabilityanalysis/event/remove/' + padClaimNumber(action.claimNumber), action.event);
    } catch (e) {
        if (!e || !e.data || !e.data.messageHeader) {
            e = {
                data: UNAVAILABLE_ERROR_MESSAGE
            };
        }
        yield put(setErrorMessagesAction(e.data.messageHeader, e.data.messageDescription));
    }
}
