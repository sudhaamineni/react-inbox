import {
    GET_CLAIMS_BY_CREATED_TIME,
    GET_INITIAL_FAULT_PENDING_CLAIMS,
    GET_RESUBMITTED_CLAIMS,
    GET_CLAIMS_BY_INITIAL_FAULT_SUBMITTED_TIME
} from '../actions/actionTypes';
import { takeEvery } from 'redux-saga';
import { call, put } from 'redux-saga/effects';
import { getData } from '../httpClient';
import {
    getClaimsByCreatedTimeSuccessAction,
    getInitialFaultPendingClaimsSuccessAction,
    getReSubmittedClaimsSuccessAction,
    getClaimsByInitialFaultSubmittedSuccessAction
} from '../actions/reportingActions';
import { setErrorMessagesAction } from '../actions/errorActions';

export function* watchGetReSubmittedClaims() {
    yield* takeEvery(GET_RESUBMITTED_CLAIMS, getReSubmittedClaims);
}

export function* getReSubmittedClaims(action) {
    try {
        const response = yield call(getData, `/api/v1/rpt/resubmitted/${action.beginDate}/${action.endDate}`);
        yield put(getReSubmittedClaimsSuccessAction(response.data));
    } catch (e) {
        yield put(setErrorMessagesAction('Error occurred', 'Error occurred while running report. Please retry.'));
    }
}

export function* watchGetClaimsByCreatedTime() {
    yield* takeEvery(GET_CLAIMS_BY_CREATED_TIME, getClaimsByCreatedTime);
}

export function* getClaimsByCreatedTime(action) {
    try {
        const response = yield call(getData, `/api/v1/rpt/claims-by-created-time/${action.beginDate}/${action.endDate}`);
        yield put(getClaimsByCreatedTimeSuccessAction(response.data));
    } catch (e) {
        yield put(setErrorMessagesAction('Error occurred', 'Error occurred while running report. Please retry.'));
    }
}

export function* watchGetInitialFaultPendingClaims() {
    yield* takeEvery(GET_INITIAL_FAULT_PENDING_CLAIMS, getInitialFaultPendingClaims);
}

export function* getInitialFaultPendingClaims() {
    try {
        const response = yield call(getData, '/api/v1/rpt/initial-fault-pending-claims');
        yield put(getInitialFaultPendingClaimsSuccessAction(response.data));
    } catch (e) {
        yield put(setErrorMessagesAction('Error occurred', 'Error occurred while running report. Please retry.'));
    }
}

export function* watchGetClaimsByInitialFaultSubmitted() {
    yield* takeEvery(GET_CLAIMS_BY_INITIAL_FAULT_SUBMITTED_TIME, getClaimsByInitialFaultSubmitted);
}

export function* getClaimsByInitialFaultSubmitted(action) {

    try {
        const response = yield call(getData, `/api/v1/rpt/claims-by-initial-fault-submitted-time/${action.beginDate}/${action.endDate}`);
        yield put(getClaimsByInitialFaultSubmittedSuccessAction(response.data));
    } catch (e) {
        yield put(setErrorMessagesAction('Error occurred', 'Error occurred while running report. Please retry.'));
    }
}