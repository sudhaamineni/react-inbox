import * as actionTypes from '../actions/actionTypes';
import {takeEvery} from 'redux-saga';
import {call, put} from 'redux-saga/effects';
import {postData} from '../httpClient';
import {insertAssignmentAdminErrorAction, insertAssignmentAdminSuccessAction} from '../actions/adminActions';

export function* watchInsertAssignmentClaimList() {
    yield* takeEvery(actionTypes.INSERT_ASSIGNMENT_CLAIM_LIST, insertAssignmentClaimList);
}

export function* insertAssignmentClaimList(action) {
    const claimNumberArray = action.claimNumberList.replace(/\s/g, '').split(',');
    try {
        yield call(postData, `/api/v1/admin?clearQueue=${action.clearQueue}&useKafka=${action.useKafka}`, claimNumberArray);
        yield put(insertAssignmentAdminSuccessAction());
    } catch (ex) {
        yield put(insertAssignmentAdminErrorAction());
    }
}
