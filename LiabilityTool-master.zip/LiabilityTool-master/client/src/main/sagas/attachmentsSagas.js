import { call, fork, put } from 'redux-saga/effects';
import { getData, postData } from '../httpClient';
import {
    getPhotoAttachmentsFailureAction,
    getPhotoAttachmentsSuccessAction,
    getVoiceAttachmentsFailureAction,
    getVoiceAttachmentsSuccessAction
} from '../actions/attachmentsActions';
import { getTranscriptData } from './transcriptSagas';
import { GET_TRANSCRIPT, SAVE_EVIDENCE } from '../actions/actionTypes';
import { padClaimNumber } from '../helpers/claimDataHelper';
import { takeEvery } from 'redux-saga';
import { UNAVAILABLE_ERROR_MESSAGE } from '../constants/loonConstants';
import { setErrorMessagesAction } from '../actions/errorActions';

const getTranscripts = voiceAttachments => {
    const transcripts = [];
    voiceAttachments.forEach(voiceAttachment => {
        if (voiceAttachment.sourceTranscriptUrl) {
            transcripts.push({
                voiceId: voiceAttachment.sourceVoiceId,
                transcriptUrl: voiceAttachment.sourceTranscriptUrl,
                highlightEntities: voiceAttachment.highlightEntities,
                nlpUrl: voiceAttachment.sourceNlpUrl ? voiceAttachment.sourceNlpUrl : null
            });
        }
    });
    return transcripts;
};

export function* getPhotoAttachments(action) {
    try {
        const url = `/api/v1/liabilityanalysis/photoattachments/${encodeURIComponent(padClaimNumber(action.claimNumber))}`;
        const response = yield call(getData, url);
        yield put(getPhotoAttachmentsSuccessAction(response.data));

    } catch (e) {
        yield put(getPhotoAttachmentsFailureAction());
    }
}

export function* getVoiceAttachments(action) {
    try {
        const url = `/api/v1/liabilityanalysis/voiceattachments/${encodeURIComponent(padClaimNumber(action.claimNumber))}`;
        const response = yield call(getData, url);
        yield put(getVoiceAttachmentsSuccessAction(response.data));

        const transcripts = getTranscripts(response.data);
        for (let index = 0; index < transcripts.length; index++) {
            let transcript = transcripts[index];
            yield fork(getTranscriptData, {
                type: GET_TRANSCRIPT,
                voiceId: transcript.voiceId,
                transcriptUrl: transcript.transcriptUrl,
                highlightEntities: transcript.highlightEntities,
                nlpUrl: transcript.nlpUrl
            });
        }
    } catch (e) {
        yield put(getVoiceAttachmentsFailureAction());
    }
}

export function* watchSaveEvidence() {
    yield* takeEvery(SAVE_EVIDENCE, saveEvidence);
}

export function* saveEvidence(action) {
    try {
        const url = `/api/v1/liabilityanalysis/${padClaimNumber(action.claimNumber)}/evidence`;
        yield call(postData, url, action.evidence);
    } catch (e) {
        if (!e || !e.data || !e.data.messageHeader) {
            e = {
                data: UNAVAILABLE_ERROR_MESSAGE
            };
        }
        yield put(setErrorMessagesAction(e.data.messageHeader, e.data.messageDescription));
    }
}
