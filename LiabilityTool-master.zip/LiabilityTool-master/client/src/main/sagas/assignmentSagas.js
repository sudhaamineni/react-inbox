import {GET_NEXT_ASSIGNMENT, ON_START_REVIEW_TIMEOUT} from '../actions/actionTypes';
import {call, put} from 'redux-saga/effects';
import {takeEvery} from 'redux-saga';
import {getData, postData} from '../httpClient';
import {getNextAssignmentSuccessAction,} from '../../../src/main/actions/assignmentActions';
import {push} from 'react-router-redux';
import {setErrorMessagesAction} from '../actions/errorActions';
import {UNAVAILABLE_ERROR_MESSAGE} from '../constants/loonConstants';
import {clearClaimDataAction} from '../actions/claimDataActions';

export function* watchGetNextAssignment() {
    yield* takeEvery(GET_NEXT_ASSIGNMENT, getNextAssignment);
}

export function* getNextAssignment() {
    const url = '/api/v1/assignment/next';
    try {
        const response = yield call(getData, url);
        yield put(getNextAssignmentSuccessAction(response.data));
        yield put(push('/next/review'));
    } catch (e) {
        if (!e || !e.data || !e.data.messageHeader) {
            e = {
                data: UNAVAILABLE_ERROR_MESSAGE
            };
        }
        yield put(setErrorMessagesAction(e.data.messageHeader, e.data.messageDescription));
    }
}

export function* watchOnStartReviewTimeout() {
    yield* takeEvery(ON_START_REVIEW_TIMEOUT, onStartReviewTimeout);
}

export function* onStartReviewTimeout() {
    yield put(clearClaimDataAction());
    yield put(push('/next'));

    try {
        yield call(postData, '/api/v1/assignment/status/a-rfa');
    } catch (e) {
        if (!e || !e.data || !e.data.messageHeader) {
            e = {
                data: UNAVAILABLE_ERROR_MESSAGE
            };
        }
        yield put(setErrorMessagesAction(e.data.messageHeader, e.data.messageDescription));
    }
}
