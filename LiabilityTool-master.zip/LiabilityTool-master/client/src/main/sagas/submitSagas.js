import {call, put, select} from 'redux-saga/effects';
import {SUBMIT_LIABILITY, SUBMIT_SETTLEMENT, UPDATE_DAMAGE_APPORTIONMENT} from '../actions/actionTypes';
import {takeEvery} from 'redux-saga';
import {openBlob, postData} from '../httpClient';
import {
    submitLiabilityErrorAction,
    submitLiabilitySuccessAction,
    submitSettlementErrorAction,
    submitSettlementSuccessAction
} from '../actions/submitActions';
import {getClaimDataSuccessAction} from '../actions/claimDataActions';
import {UNAVAILABLE_ERROR_MESSAGE} from '../constants/loonConstants';
import {setErrorMessagesAction} from '../actions/errorActions';
import {getCurrentTime} from '../helpers/dateTimeHelper';
import * as selectors from './selectors';

export function* watchSubmitLiabilty() {
    yield* takeEvery(SUBMIT_LIABILITY, submitLiability);
}

export function* submitLiability(action) {
    try {
        const response = yield call(postData, '/api/v1/liabilitydecision',
            {
                liabilityAnalysisEntity: {...action.claimData, locked: true},
                mapImage: action.mapImage
            },
            0 // No client timeout
        );
        yield put(submitLiabilitySuccessAction(response.data));

        const featureSwitches= yield select(selectors.getFeatureSwitches);

        if(featureSwitches.openSummaryDocOnSuccess){
        yield call(openBlob, `/api/v1/liabilitydecision/${action.claimData.claimNumber}/summary-pdf`, 'application/pdf');}
    } catch (ex) {
        yield put(submitLiabilityErrorAction());
    }
}

export function* watchUpdateDamageApportionment() {
    yield* takeEvery(UPDATE_DAMAGE_APPORTIONMENT, updateDamageApportionment);
}

export function* updateDamageApportionment(action) {
    try {
        const response = yield call(
            postData,
            `/api/v1/liabilitydecision/${action.claimNumber}/damage-apportionment`,
            {apportionedAllocatedFaultSaveTime: getCurrentTime()},
            0 // No client timeout
        );
        yield put(getClaimDataSuccessAction(response.data));
    } catch (e) {
        if (!e || !e.data || !e.data.messageHeader) {
            e = {
                data: UNAVAILABLE_ERROR_MESSAGE
            };
        }
        yield put(setErrorMessagesAction(e.data.messageHeader, e.data.messageDescription));
    }
}

export function* watchSubmitSettlement() {
    yield* takeEvery(SUBMIT_SETTLEMENT, submitSettlement);
}

export function* submitSettlement(action) {
    try {
        yield call(
            postData,
            `/api/v1/liabilitydecision/${action.claimNumber}/submit-settlement`,
            {},
            0 // No client timeout
        );
        yield put(submitSettlementSuccessAction());
    } catch (ex) {
        yield put(submitSettlementErrorAction());
    }
}
