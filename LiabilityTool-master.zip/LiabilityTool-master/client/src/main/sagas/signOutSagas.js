import {call, put, select} from 'redux-saga/effects';
import {takeEvery} from 'redux-saga';
import {replace} from 'connected-react-router';
import {getData, postData} from '../httpClient';
import {SIGNOUT} from '../actions/actionTypes';
import {getClaimData} from './selectors';
import {ASSIGNED} from '../constants/loonConstants';

export function* watchSignOut() {
    yield* takeEvery(SIGNOUT, signOut);
}

export function* signOut() {
    window.sessionStorage.clear();

    try {
        const claimData = yield select(getClaimData);
        if (claimData.status === ASSIGNED) {
            yield call(postData, '/api/v1/assignment/status/a-rfa');
        }
    } catch (error) {
    }
    try {
        yield call(getData, '/pkmslogout');
    } catch (error) {
    } finally {
        yield put(replace('/'));
        window.location.reload(true);
    }
}
