import {call, put} from 'redux-saga/effects';
import {getData} from '../httpClient';
import {getTranscriptDataFailureAction, getTranscriptSuccessAction} from '../actions/transcriptActions';

export function* getTranscriptData(action) {
    try {
        const transcriptResponse = yield call(getData, action.transcriptUrl);
        const nlpResponse = yield call(getData, action.nlpUrl);

        yield put(getTranscriptSuccessAction({
            voiceId: action.voiceId,
            transcriptData: transcriptResponse.data.contents,
            nlpData: nlpResponse.data.categories,
            highlightEntities: action.highlightEntities,
        }));
    } catch (e) {
        yield put(getTranscriptDataFailureAction(action.voiceId));
    }
}
