import { fork } from 'redux-saga/effects';
import { watchSessionKeepAlive } from './keepAliveSagas';
import { watchSignOut } from './signOutSagas';
import {
    watchGetClaimData,
    watchPhotoRotation,
    watchPhotoToggleBookmark,
    watchSaveClaimUnlock,
    watchSaveHighlight,
    watchSaveNoFaultAllocationIndicator,
    watchSaveReportedPci,
    watchSaveSketch,
    watchSaveUpdatedLossLocation,
    watchSaveVoiceParticipant
} from './claimDataSagas';
import { watchSubmitLiabilty, watchSubmitSettlement, watchUpdateDamageApportionment } from './submitSagas';
import { init } from './initSagas';
import { watchGetNextAssignment, watchOnStartReviewTimeout, } from './assignmentSagas';
import { watchInsertAssignmentClaimList } from './adminSagas';
import {
    watchGetClaimsByCreatedTime,
    watchGetInitialFaultPendingClaims,
    watchGetClaimsByInitialFaultSubmitted,
    watchGetReSubmittedClaims,
} from './reportingSagas';
import { watchCreateEvent, watchRemoveEvent, watchUpdateDamages, watchUpdateEvent } from './eventSagas';
import { watchRetrieveDiagram, watchSaveDiagram, watchSaveFalseDrag, watchSendFeedback } from 'sketchy-bird';
import { watchSaveEvidence } from './attachmentsSagas';

export default function* rootSaga() {
    yield [
        fork(init),
        fork(watchGetClaimData),
        fork(watchSaveNoFaultAllocationIndicator),
        fork(watchSubmitLiabilty),
        fork(watchSessionKeepAlive),
        fork(watchSignOut),
        fork(watchSaveUpdatedLossLocation),
        fork(watchSaveHighlight),
        fork(watchGetNextAssignment),
        fork(watchInsertAssignmentClaimList),
        fork(watchPhotoToggleBookmark),
        fork(watchPhotoRotation),
        fork(watchOnStartReviewTimeout),
        fork(watchGetReSubmittedClaims),
        fork(watchSaveDiagram),
        fork(watchRetrieveDiagram),
        fork(watchSaveFalseDrag),
        fork(watchSendFeedback),
        fork(watchSaveSketch),
        fork(watchCreateEvent),
        fork(watchUpdateEvent),
        fork(watchRemoveEvent),
        fork(watchSaveVoiceParticipant),
        fork(watchUpdateDamageApportionment),
        fork(watchUpdateDamages),
        fork(watchSaveClaimUnlock),
        fork(watchSubmitSettlement),
        fork(watchSaveReportedPci),
        fork(watchSaveEvidence),
        fork(watchGetClaimsByCreatedTime),
        fork(watchGetInitialFaultPendingClaims),
        fork(watchGetClaimsByInitialFaultSubmitted)
    ];
}
