import {call, put} from 'redux-saga/effects';
import {getData} from '../httpClient';
import {initFailureAction, initSuccessAction} from '../actions/initActions';

export function* init() {
    try {
        const response = yield call(getData, '/api/v1/init');
        yield put(initSuccessAction(response.data));
    } catch (e) {
        yield put(initFailureAction(e.status));
    }
}
