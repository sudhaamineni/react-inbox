export const getUser = ({user}) => user;

export const getClaimData = ({claimData}) => claimData;

export const getFeatureSwitches = ({featureSwitches}) => featureSwitches;

export const selectVoiceAttachments = ({claimData}) => claimData.voiceAttachments;

export const selectParticipants = ({claimData}) => claimData.participants;

export const selectEvidences = ({claimData}) => claimData.evidences;
