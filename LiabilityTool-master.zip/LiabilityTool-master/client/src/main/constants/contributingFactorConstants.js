export const MEGA_MENU_ITEMS = [
    {
        value: 'Right of Way',
        icon: 'right-of-way',
        options: [
            {value: 'participant-has-right-of-way', label: 'Has Right of Way'},
            {value: 'participant-did-not-have-right-of-way', label: 'Didn\'t Have Right of Way'},
            {value: 'failed-to-obey-traffic-control', label: 'Failed to Obey Traffic Control'},
            {value: 'failed-to-adhere-to-lane-of-travel', label: 'Failed to Adhere to Lane of Travel'}
        ]
    },
    {
        value: 'Driver Action',
        icon: 'point-of-impact-circle',
        options: [
            {value: 'improper-maneuver', label: 'Improper Maneuver'},
            {value: 'failed-to-signal', label: 'Failed to Signal'},
            {value: 'unsafe-speed-for-circumstances', label: 'Unsafe speed for circumstances'}
        ]
    },
    {
        value: 'Additional Factors',
        icon: 'additional-factors',
        options: [
            {value: 'driver-compromised', label: 'Driver Compromised'},
            {value: 'mechanical-failure', label: 'Mechanical Failure'},
            {value: 'additional-factors-other', label: 'Other'}
        ]
    },
    {
        value: 'Danger Recognition',
        icon: 'danger-recognition',
        options: [
            {value: 'proper-lookout', label: 'Proper Lookout'},
            {value: 'improper-lookout', label: 'Improper Lookout'},
            {value: 'late-recognition', label: 'Late Recognition'},
            {value: 'timely-recognition', label: 'Timely Recognition'},
            {value: 'timely-recognition-other', label: 'Other'}
        ]
    },
    {
        value: 'Evasive Action',
        icon: 'evasive-action',
        options: [
            {value: 'took-evasive-action', label: 'Took Evasive Action'},
            {value: 'did-not-take-evasive-action', label: 'Didn\'t Take Evasive Action'},
            {value: 'evasive-action-other', label: 'Other'}
        ]
    }
];

export const REASON_TO_DETAILS_MAP = {
    'failed-to-obey-traffic-control': [
        {
            value: 'failure-to-obey-appropriate-signage',
            label: 'Failure to obey appropriate signage'
        },
        {
            value: 'failure-to-obey-traffic-guard-officer',
            label: 'Failure to obey traffic guard/officer'
        }],
    'proper-lookout': [
        {
            value: 'saw-obstruction-in-roadway',
            label: 'Saw obstruction in roadway'
        },
        {
            value: 'saw-other-party',
            label: 'Saw other party'
        },
        {
            value: 'recognized-danger-on-roadway',
            label: 'Recognized danger on roadway'
        }
    ],
    'improper-lookout': [
        {
            value: 'didnt-see-obstruction-in-roadway',
            label: 'Didn\'t see obstruction in roadway'
        },
        {
            value: 'didnt-see-other-party',
            label: 'Didn\'t see other party'
        },
        {
            value: 'didnt-recognize-danger-on-roadway',
            label: 'Didn\'t recognize danger on roadway'
        }
    ],
    'improper-maneuver': [
        {
            value: 'improper-lane-change',
            label: 'Improper lane change'
        },
        {
            value: 'sudden-stop',
            label: 'Sudden stop'
        },
        {
            value: 'participant-following-too-closely',
            label: 'Participant following too closely'
        }
    ],
    'unsafe-speed-for-circumstances': [
        {
            value: 'for-weather-condition',
            label: 'For weather condition'
        },
        {
            value: 'for-driving-conditions',
            label: 'For driving conditions'
        },
        {
            value: 'driving-too-slow',
            label: 'Driving too slow'
        },
        {
            value: 'driving-too-fast',
            label: 'Driving too fast'
        },
    ],
    'took-evasive-action': [
        {
            value: 'proper-evasive-action-taken',
            label: 'Proper evasive action taken'
        },
        {
            value: 'improper-evasive-action-taken',
            label: 'Improper evasive action taken'
        },
        {
            value: 'created-greater-risk',
            label: 'Created greater risk'
        },
        {
            value: 'timely',
            label: 'Timely'
        },
        {
            value: 'late',
            label: 'Late'
        },
    ],
    'driver-compromised': [
        {
            value: 'tired-distracted',
            label: 'Tired / Distracted'
        },
        {
            value: 'under-influence',
            label: 'Under influence'
        },
        {
            value: 'medical-emergency',
            label: 'Medical Emergency'
        },
        {
            value: 'road-rage',
            label: 'Road Rage'
        }
    ],
    'mechanical-failure': [
        {
            value: 'failed-to-maintain-vehicle',
            label: 'Failed to maintain Vehicle'
        },
        {
            value: 'recent-repair',
            label: 'Recent Repair'
        },
    ]
};

export const OTHER_REASONS_SET = new Set(['additional-factors-other', 'timely-recognition-other', 'evasive-action-other']);

export const MEGA_MENU_ITEMS_REVERSE_MAPPING = [
    {value: 'participant-has-right-of-way', label: 'Has Right of Way', icon: 'right-of-way'},
    {value: 'participant-did-not-have-right-of-way', label: 'Didn\'t Have Right of Way', icon: 'right-of-way'},
    {value: 'failed-to-obey-traffic-control', label: 'Failed to Obey Traffic Control', icon: 'right-of-way'},
    {value: 'failed-to-adhere-to-lane-of-travel', label: 'Failed to Adhere to Lane of Travel', icon: 'right-of-way'},
    {value: 'improper-maneuver', label: 'Improper Maneuver', icon: 'point-of-impact-circle'},
    {value: 'failed-to-signal', label: 'Failed to Signal', icon: 'point-of-impact-circle'},
    {value: 'unsafe-speed-for-circumstances', label: 'Unsafe speed for circumstances', icon: 'point-of-impact-circle'},
    {value: 'driver-compromised', label: 'Driver Compromised', icon: 'additional-factors'},
    {value: 'mechanical-failure', label: 'Mechanical Failure', icon: 'additional-factors'},
    {value: 'additional-factors-other', label: 'Other', icon: 'additional-factors'},
    {value: 'proper-lookout', label: 'Proper Lookout', icon: 'danger-recognition'},
    {value: 'improper-lookout', label: 'Improper Lookout', icon: 'danger-recognition'},
    {value: 'late-recognition', label: 'Late Recognition', icon: 'danger-recognition'},
    {value: 'timely-recognition', label: 'Timely Recognition', icon: 'danger-recognition'},
    {value: 'timely-recognition-other', label: 'Other', icon: 'danger-recognition'},
    {value: 'took-evasive-action', label: 'Took Evasive Action', icon: 'evasive-action'},
    {value: 'did-not-take-evasive-action', label: 'Didn\'t Take Evasive Action', icon: 'evasive-action'},
    {value: 'evasive-action-other', label: 'Other', icon: 'evasive-action'}
];

