export const INSURED = 'INSURED';
export const CLAIMANT = 'CLAIMANT';
export const LOON_READ_ONLY_USER = 'LOON Read Only User';
export const LOON_WIP_CLAIM_NUMBER = 'loonWipClaimNumber';

// Asset Types
export const OTHER = 'Other';
export const PROPERTY = 'Property';
export const PEDESTRIAN_BICYCLIST = 'PEDESTRIAN/BICYCLIST';
export const AUTO = 'Auto';
export const PICK_UP_TRUCK = 'Pick Up Truck';
export const RV = 'RV';
export const MOTORCYCLE = 'Motorcycle';
export const UTIL_CAMPER = 'UTIL/CAMPER';
export const PICK_CAMPER = 'PICK/CAMPER';
export const BOAT = 'Boat';
export const damageAreaAssetTypes = [
    'Auto',
    'Pick Up Truck',
    'RV',
    'Motorcycle',
    'UTIL/CAMPER',
    'PICK/CAMPER',
    'Boat',
];

export const SUBMITTED = 'SUBMITTED';
export const SUBMITTING = 'SUBMITTING';
export const ERROR_SUBMITTING = 'ERROR_SUBMITTING';
export const DEFAULT_STATE = 'DEFAULT_STATE';
export const ASSIGNED = 'ASSIGNED';
export const IN_PROGRESS = 'IN_PROGRESS';

export const UNAVAILABLE_ERROR_MESSAGE = {
    messageHeader: 'Our systems are currently unavailable',
    messageDescription: 'Our systems are currently unable to process your search. Please try again later.'
};

export const transcriptEvidenceMenuOptions = [
    {label: 'Loss Address', value: 'loss-address'},
    {label: 'Road Attributes', value: 'road-attributes'},
    {label: 'Condition of Roadway', value: 'condition-of-roadway'},
    {label: 'Weather', value: 'weather'},
    {label: 'Traffic Control Measures', value: 'traffic-control-measures'},
    {label: 'Amount of Traffic', value: 'amount-of-traffic'},
    {label: 'Time of Day', value: 'time-of-day'},
    {label: 'Direction of Travel', value: 'direction-of-travel'},
    {label: 'Participant Speed', value: 'participant-speed'},
    {label: 'Point of Impact', value: 'point-of-impact'},
    {label: 'Damages', value: 'damages'},
    {label: 'Driver Actions', value: 'driver-actions'},
    {label: 'Injuries', value: 'injuries'},
    {label: 'Other', value: 'other'},
];

export const EVIDENCE_LABEL_MAP = {
    'loss-address': 'Loss Address',
    'road-attributes': 'Road Attributes',
    'condition-of-roadway': 'Condition of Roadway',
    'weather': 'Weather',
    'traffic-control-measures': 'Traffic Control Measures',
    'amount-of-traffic': 'Amount of Traffic',
    'time-of-day': 'Time of Day',
    'direction-of-travel': 'Direction of Travel',
    'participant-speed': 'Participant Speed',
    'point-of-impact': 'Point of Impact',
    'damages': 'Damages',
    'driver-actions': 'Driver Actions',
    'injuries': 'Injuries',
    'other': 'Other',
    'untagged': 'Untagged',
};

export const CALL_TYPE_LABELS = new Set([
    'FNOL', 'Inquiry', 'Loss Investigation', 'Attempted Contact', 'Settlement',
    'Status Update', 'Vendor/Provider Contact', 'Attorney Contact', 'Other'
]);

export const photoEvidenceMenuOptions = [
    { label: 'Road Attributes', value: 'road-attributes' },
    { label: 'Condition of Roadway', value: 'condition-of-roadway' },
    { label: 'Traffic Control Measures', value: 'traffic-control-measures' },
    { label: 'Point of Impact', value: 'point-of-impact' },
    { label: 'Damages', value: 'damages' },
    { label: 'Other', value: 'other' },
];

export const PCI_OPTIONS = [
    {displayText: 'Credit Card/Debit Card Number', value: 'creditCardNumber'},
    {displayText: 'Social Security Number', value: 'socialSecurityNumber'},
    {displayText: 'Driver\'s License Number', value: 'driversLicense'},
];
