export const SKETCH_TEMPLATE_FOURWAYINTERSECTION = 'fourWayIntersection';
export const SKETCH_TEMPLATE_TINTERSECTION = 'tIntersection';
export const SKETCH_TEMPLATE_STRAIGHTAWAY = 'straightAway';
export const SKETCH_TEMPLATE_PARKINGLOT = 'parkingLot';

export const detailLossTypesAndIcons = [
    {
        lossDetailTypeCode: '06',
        icon: 'backing-accident-circle',
        desc: 'Backing accident - both parties moving',
        sketchTemplateType: SKETCH_TEMPLATE_PARKINGLOT
    },
    {
        lossDetailTypeCode: '07',
        icon: 'intersection-circle',
        desc: 'Intersection accident',
        sketchTemplateType: SKETCH_TEMPLATE_FOURWAYINTERSECTION
    },
    {
        lossDetailTypeCode: '08',
        icon: 'standing-water-circle',
        desc: 'Insured drove into standing water',
        sketchTemplateType: SKETCH_TEMPLATE_STRAIGHTAWAY
    },
    {
        lossDetailTypeCode: '09',
        icon: 'changing-lanes-circle',
        desc: 'Changing lanes',
        sketchTemplateType: SKETCH_TEMPLATE_STRAIGHTAWAY
    },
    {
        lossDetailTypeCode: '11',
        icon: 'head-on-collision-circle',
        desc: 'Head-on collision',
        sketchTemplateType: SKETCH_TEMPLATE_TINTERSECTION
    },
    {
        lossDetailTypeCode: '14',
        icon: 'hit-fixed-object-circle',
        desc: 'Insured hit a fixed object',
        sketchTemplateType: SKETCH_TEMPLATE_STRAIGHTAWAY
    },
    {
        lossDetailTypeCode: '15',
        icon: 'hit-bike-circle',
        desc: 'Insured Hit a Pedestrian/Bicycle',
        sketchTemplateType: SKETCH_TEMPLATE_TINTERSECTION
    },
    {
        lossDetailTypeCode: '17',
        icon: 'right-of-way-circle',
        desc: 'Making a turn',
        sketchTemplateType: SKETCH_TEMPLATE_TINTERSECTION
    },
    {
        lossDetailTypeCode: '19',
        icon: 'parked-vehicle-circle',
        desc: 'Parked Vehicle - insured hit parked vehicle.',
        sketchTemplateType: SKETCH_TEMPLATE_PARKINGLOT
    },
    {
        lossDetailTypeCode: '20',
        icon: 'parked-vehicle-circle',
        desc: 'Parked Vehicle - Other Party hit parked Insured',
        sketchTemplateType: SKETCH_TEMPLATE_PARKINGLOT
    },
    {
        lossDetailTypeCode: '21',
        icon: 'rear-end-accident-circle',
        desc: 'Rear-end accident - insured rear-ended other party',
        sketchTemplateType: SKETCH_TEMPLATE_FOURWAYINTERSECTION
    },
    {
        lossDetailTypeCode: '22',
        icon: 'rear-end-accident-circle',
        desc: 'Rear-end accident - multiple cars',
        sketchTemplateType: SKETCH_TEMPLATE_FOURWAYINTERSECTION
    },
    {
        lossDetailTypeCode: '23',
        icon: 'rear-end-accident-circle',
        desc: 'Rear-end accident - Other party rear-ended insured',
        sketchTemplateType: SKETCH_TEMPLATE_FOURWAYINTERSECTION
    },
    {
        lossDetailTypeCode: '24',
        icon: 'sideswipe-circle',
        desc: 'Sideswipe accident',
        sketchTemplateType: SKETCH_TEMPLATE_STRAIGHTAWAY
    },
];
