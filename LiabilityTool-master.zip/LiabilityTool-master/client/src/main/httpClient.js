import axios from 'axios';

axios.defaults.baseURL = '';
axios.defaults.headers.post['Content-Type'] = 'application/json; charset=utf-8';
axios.defaults.headers.put['Content-Type'] = 'application/json; charset=utf-8';

export const reloadOnIsamExpiry = response => {
    if (response && response.headers) {
        const contentTypeHeader = response.headers['content-type'];
        if (contentTypeHeader && contentTypeHeader.match(/text\/html/i) && response.data.match(/pkmslogin/i)) {
            window.location.reload(true);
        }
    }
};

export const getData = url => {
    return axios
        .get(url)
        .then(response => {
            reloadOnIsamExpiry(response);
            return response;
        })
        .catch(errorResponse => {
            reloadOnIsamExpiry(errorResponse.response);
            throw errorResponse.response;
        });
};

export const openBlob = (url, type) => {
    return axios
        .get(url, {responseType: 'blob'})
        .then(response => {
            window.open(URL.createObjectURL(new Blob([response.data], {type})));
            return null;
            }
        )
        .catch(error => {
            throw error.response;
            return null;
        });
};

export const postData = (url, data, timeout = 30000) => {
    return axios
        .post(url, data, {timeout})
        .then(response => {
            reloadOnIsamExpiry(response);
            return response;
        })
        .catch(errorResponse => {
            reloadOnIsamExpiry(errorResponse.response);
            throw errorResponse.response;
        });
};
