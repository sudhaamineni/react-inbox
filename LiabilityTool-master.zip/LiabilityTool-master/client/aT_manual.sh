./aT_startup.sh &> /dev/null
./node_modules/.bin/codeceptjs run ./acceptance/ --steps
./aT_shutdown.sh

