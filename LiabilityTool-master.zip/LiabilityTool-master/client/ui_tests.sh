#!/usr/bin/env bash

echo ""
echo "!==== Running UI Tests ====!"
echo ""

echo "!--- Starting phantomjs"
./node_modules/.bin/phantomjs --webdriver=4444 &
PHANTOM_PID=$! # capture PhantomJS PID with $!

echo "!--- Sleeping for a bit"
sleep 1


npm run test:acceptanceCi


echo "!--- Sleeping for a bit"
sleep 1

echo "!--- Killing app server"
kill -9 $APP_SERVER_PID # normal kill

echo "!--- Killing phantomjs"
pkill -P $PHANTOM_PID # kill process and all spawned child processes

exit $SUCCESS