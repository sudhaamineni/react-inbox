#!/bin/bash

echo 'Starting up Selenium and Spring server'
./aT_startup.sh &> /dev/null
npm run-script acceptanceTest
ec=$?
echo 'Shutting down Selenium and Spring server'
./aT_shutdown.sh &> /dev/null
exit $ec