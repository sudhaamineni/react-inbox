Feature('assignment');

// Scenario('test assignment', (I) => {
//     I.amOnPage("/");
//     I.see("Welcome to Loon");
//     I.see("Click Get Next Claim to start making your next liability analysis.");
//     I.seeElement('//button[contains(., "Get Next Claim")]');
//     I.click("Get Next Claim");
//     I.waitUrlEquals('/#/startReviewPage');
//
//     //startReview test is here since /startReviewPage route
//     //does not load with data without going through Assignment currently
//     I.see("Welcome to Loon");
//     I.see("Claim has been assigned. Please Start Review");
//     I.see("Detailed Loss Type");
//     I.see("Making a turn");
//     I.see("Date of Loss");
//     I.see("06/08/2014");
//     I.see("Time of Loss");
//     I.see("09:00 pm");
//     I.see("Loss State");
//     I.see("Washington");
//     I.seeElement('//button[contains(., "Start Review")]');
//     I.click("Start Review");
//     I.waitUrlEquals('/#/liabilityAnalysis/000178336020');
// });