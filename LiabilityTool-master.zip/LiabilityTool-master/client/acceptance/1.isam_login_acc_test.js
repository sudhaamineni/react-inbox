Feature('isam');

if (process.env.NODE_ENV === 'devci') {
    // Scenario('test ISAM login', (I) => {
    //     I.amOnPage("/");
    //     I.see("User ID");
    //     I.see("Password");
    //     I.fillField("username", "tst-loon2");
    //     I.fillField("password", "Thlp1If6");
    //     I.click("#submit");
    //     I.waitForText("Welcome to Loon", 5);
    // })
};
