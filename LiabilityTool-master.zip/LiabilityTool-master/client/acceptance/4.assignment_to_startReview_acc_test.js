Feature('assignment');

//POC
Scenario('test assignment to startReview', (I) => {
    I.amOnPage('/');
    I.see('Welcome to Loon');
    I.see('Search for a claim number to begin a liability analysis');
    I.seeElement('//button[contains(., "Find Claim")]');
    I.fillField("Enter a claim number", "0179459037");
    I.click('.c-btn');
    I.see('We were unable to find this claim number. Please check and try again.');
    I.waitUrlEquals('#/investigate/participant');
});



// Scenario('test assignment to startReview', (I) => {
//     I.amOnPage('/');
//     I.waitUrlEquals('/#/startReviewPage');
//     I.see('Welcome to Loon');
//     I.see('Claim has been assigned. Please Resume Review');
//     I.see('Detailed Loss Type');
//     I.see('Making a turn');
//     I.see('Date of Loss');
//     I.see('06/08/2014');
//     I.see('Time of Loss');
//     I.see('09:00 pm');
//     I.see('Loss State');
//     I.see('Washington');
//     I.seeElement('//button[contains(., "Resume Review")]');
// });




// Scenario('test \'Resume Review\' click',(I) => {
//     I.seeElement('//button[contains(., "Resume Review")]');
//     I.click('Resume Review');
//     I.waitUrlEquals('/#/liabilityAnalysis/000178336020');
// }).retry(3);
