Feature('admin');
//
// Scenario('test Admin', (I) => {
//     I.amOnPage("/#/admin");
//     I.see("Welcome to Loon Admin Page");
//     I.see("Enter a list of claim numbers to be added in the Assignment Queue.");
//     I.seeElement("#companyLogo")
//     I.seeElement('//button[contains(., "Insert Claim List")]');
//     I.fillField("claimNumberList", "0178336020");
//     I.click("#clearQueue");
//     I.click("#submit");
//     I.waitForText("Claim list was successfully inserted.");
// });
