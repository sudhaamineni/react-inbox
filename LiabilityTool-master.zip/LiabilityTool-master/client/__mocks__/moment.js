import {when} from 'jest-when';
const moment = jest.fn();

when(moment).calledWith("").mockReturnValue('error');
when(moment).calledWith("2018-07-19T20:14:37.421+0000").mockReturnValue(new Date('2018-07-19T15:14:37.421'));

export default moment;