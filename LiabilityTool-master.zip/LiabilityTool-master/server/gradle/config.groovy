//environments {
//    local {
//        flywayUrl = 'jdbc:oracle:thin:@//localhost:49161/XE'
//        flywayUsername = 'LOON'
//        flywayPassword = 'LOON'
//        flywayLocations = 'db/migration'
//        dataTablespace = 'D01'
//        indexTablespace = 'I01'
//        lobTablespace = 'L01'
//        springDatasourceUrl = 'jdbc:oracle:thin:@//localhost:49161/XE'
//        springDatasourceUsername = 'LOONUSR'
//        springDatasourcePassword = 'LOONUSR'
//    }
//}
