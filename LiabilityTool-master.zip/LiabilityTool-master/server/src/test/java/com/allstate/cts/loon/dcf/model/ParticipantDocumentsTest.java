package com.allstate.cts.loon.dcf.model;

import org.junit.Test;

import java.util.ArrayList;

import static org.assertj.core.api.Java6Assertions.assertThat;

public class ParticipantDocumentsTest {
    @Test
    public void claimData_defaultValues_whenNotUsingBuilder() {
        ParticipantDocuments participantDocuments = new ParticipantDocuments();
        assertThat(participantDocuments.getFullName()).isNull();
        assertThat(participantDocuments.getPhotoUrlList()).isNull();
    }

    @Test
    public void claimData_defaultValues_whenUsingBuilder() {
        ParticipantDocuments participantDocuments = ParticipantDocuments.builder().build();
        assertThat(participantDocuments.getFullName()).isNull();
        assertThat(participantDocuments.getPhotoUrlList()).isEqualTo(new ArrayList<>());
    }
}
