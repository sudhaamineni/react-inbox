package com.allstate.cts.loon.claimData.model;

import org.junit.Test;

import java.util.ArrayList;

import static org.assertj.core.api.Java6Assertions.assertThat;

public class FileNotesTest {
    @Test
    public void fileNotes_defaultValues_whenNotUsingBuilder() {
        FileNotes fileNotes = new FileNotes();
        assertThat(fileNotes.getAttachments()).isNull();
        assertThat(fileNotes.getFileNoteId()).isNull();
        assertThat(fileNotes.getFileNoteText()).isNull();
    }

    @Test
    public void fileNotes_defaultValues_whenUsingBuilder() {
        FileNotes fileNotes = FileNotes.builder().build();
        assertThat(fileNotes.getAttachments()).isEqualTo(new ArrayList<>());
        assertThat(fileNotes.getFileNoteId()).isNull();
        assertThat(fileNotes.getFileNoteText()).isNull();
    }
}