package com.allstate.cts.loon.automatedLiability.service;

import com.allstate.cts.loon.automatedLiability.entity.AutomatedLiabilityEntity;
import com.allstate.cts.loon.automatedLiability.entity.Liability;
import com.allstate.cts.loon.automatedLiability.entity.LiabilityScore;
import com.allstate.cts.loon.exception.LoonInvalidMessageException;
import com.allstate.cts.loon.helpers.DateTimeHelper;
import com.allstate.cts.loon.helpers.ObjectMapperFactory;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.kafka.support.Acknowledgment;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.assertj.core.api.Java6Assertions.assertThat;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class KafkaAutomatedLiabilityConsumerTest {
    @Mock
    private AutomatedLiabilityService mockAutomatedLiabilityService;

    @Mock
    private DateTimeHelper dateTimeHelper;

    @Mock
    private ObjectMapperFactory mockObjectMapperFactory;

    private ObjectMapper mockObjectMapper;
    private JsonParser mockJsonParser;
    private JsonFactory mockJsonFactory;

    @Spy
    @InjectMocks
    private KafkaAutomatedLiabilityConsumer subject;

    @Before
    public void setUp() throws Exception {
        mockObjectMapper = Mockito.mock(ObjectMapper.class);
        mockJsonFactory = Mockito.mock(JsonFactory.class);
        mockJsonParser = Mockito.mock(JsonParser.class);

        when(mockObjectMapperFactory.getObjectMapper()).thenReturn(mockObjectMapper);
        when(mockObjectMapper.getFactory()).thenReturn(mockJsonFactory);
        when(mockJsonFactory.createParser(anyString())).thenReturn(mockJsonParser);
    }

    @Test
    public void onReceiving() throws Exception {

        String expectedEntryString = "test";
        byte[] automatedLiabilityEntry = expectedEntryString.getBytes(StandardCharsets.UTF_8);

        Acknowledgment mockAcknowledgment = mock(Acknowledgment.class);

        AutomatedLiabilityEntity expectedAutomatedLiabilityEntity = AutomatedLiabilityEntity
                .builder()
                .claimNumber("000487412345")
                .build();

        doReturn(expectedAutomatedLiabilityEntity).when(subject).getAutomatedLiabilityFromMessage(anyString());

        subject.onReceiving(automatedLiabilityEntry, mockAcknowledgment);

        verify(subject).getAutomatedLiabilityFromMessage(expectedEntryString);
        verify(mockAutomatedLiabilityService).processAutomatedLiability(expectedAutomatedLiabilityEntity);
        verify(mockAcknowledgment).acknowledge();
    }

    @Test
    public void onReceiving_doesNotAcknowledgeMessageAndCallsEndLogError_whenUnhandledExceptionIsReturnedFromService() throws Exception {
        String expectedEntryString = "test";
        byte[] automatedLiabilityEntry = expectedEntryString.getBytes(StandardCharsets.UTF_8);

        Acknowledgment mockAcknowledgment = mock(Acknowledgment.class);
        RuntimeException expectedException = new RuntimeException("test");

        AutomatedLiabilityEntity expectedAutomatedLiabilityEntity = AutomatedLiabilityEntity
                .builder()
                .claimNumber("12")
                .build();

        doReturn(expectedAutomatedLiabilityEntity).when(subject).getAutomatedLiabilityFromMessage(anyString());
        doThrow(expectedException).when(mockAutomatedLiabilityService).processAutomatedLiability(anyObject());

        subject.onReceiving(automatedLiabilityEntry, mockAcknowledgment);
        verify(mockAutomatedLiabilityService).processAutomatedLiability(expectedAutomatedLiabilityEntity);
        verify(mockAcknowledgment, times(0)).acknowledge();
    }

    @Test
    public void onReceiving_acknowledgesMessageAndCallsEndLogError_whenGetAutomatedLiabilityFromMessageThrowsLoonInvalidMessageException() throws Exception {
        String expectedEntryString = "test";
        byte[] automatedLiabilityEntry = expectedEntryString.getBytes(StandardCharsets.UTF_8);

        Acknowledgment mockAcknowledgment = mock(Acknowledgment.class);

        LoonInvalidMessageException expectedException = new LoonInvalidMessageException("msg", new RuntimeException());
        doThrow(expectedException).when(subject).getAutomatedLiabilityFromMessage(anyString());

        subject.onReceiving(automatedLiabilityEntry, mockAcknowledgment);

        verify(mockAutomatedLiabilityService, times(0)).processAutomatedLiability(anyObject());
        verify(mockAcknowledgment).acknowledge();
    }

    @Test
    public void getAutomatedLiabilityFromMessage() throws Exception {
        String entryString = "{\n" +
                "\"claimNumber\": \"000487412345\",\n" +
                "\"correlationID\": \"6eccf90f-60a9-47e7-a0c6-9a9b234be6da\",\n" +
                "\"feederVersion\": \"1.0.762\",\n" +
                "\"liability\": [\n" +
                "{\n" +
                "\"mainParticipant\": \"01\",\n" +
                "\"affectedParticipant\": \"02\",\n" +
                "\"liabilityScore\": {\n" +
                "\"id\": \"3019\",\n" +
                "\"gretzkyVersion\": \"ScoringLib-0.3.17\",\n" +
                "\"score0\": 0.186801,\n" +
                "\"score100\": 0.695687,\n" +
                "\"scoreGreaterThan0LessThan100\": 0.117512\n" +
                "},\n" +
                "\"seagullVersion\": \"1.0.279\"\n" +
                "}\n" +
                "]\n" +
                "}";
        Date expectedCreatedDate = new Date();

        LiabilityScore expectedLiabilityScore = LiabilityScore
                .builder()
                .id("3019")
                .gretzkyVersion("ScoringLib-0.3.17")
                .score0(0.186801)
                .score100(0.695687)
                .scoreGreaterThan0LessThan100(0.117512)
                .build();
        List<Liability> expectedLiabilityList = new ArrayList<>();
        Liability liability = Liability
                .builder()
                .mainParticipant("01")
                .affectedParticipant("02")
                .liabilityScore(expectedLiabilityScore)
                .seagullVersion("1.0.279")
                .build();
        expectedLiabilityList.add(liability);

        AutomatedLiabilityEntity expectedAutomatedLiabilityEntity = AutomatedLiabilityEntity
                .builder()
                .correlationID("6eccf90f-60a9-47e7-a0c6-9a9b234be6da")
                .feederVersion("1.0.762")
                .claimNumber("000487412345")
                .createdDate(expectedCreatedDate)
                .liability(expectedLiabilityList)
                .build();

        when(dateTimeHelper.getCurrentDateTime()).thenReturn(expectedCreatedDate);

        when(mockJsonParser.readValueAs(AutomatedLiabilityEntity.class)).thenReturn(expectedAutomatedLiabilityEntity);

        assertThat(subject.getAutomatedLiabilityFromMessage(entryString)).isEqualTo(expectedAutomatedLiabilityEntity);

        verify(dateTimeHelper).getCurrentDateTime();
        verify(mockJsonParser).close();
    }

    @Test(expected = LoonInvalidMessageException.class)
    public void getFNOLClaimDataFromMessage_throwsIOException() throws Exception {
        String entryString = "test";

        when(mockJsonFactory.createParser(anyString())).thenThrow(IOException.class);

        subject.getAutomatedLiabilityFromMessage(entryString);
    }
}