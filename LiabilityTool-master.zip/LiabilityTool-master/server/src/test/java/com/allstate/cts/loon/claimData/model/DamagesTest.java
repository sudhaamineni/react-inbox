package com.allstate.cts.loon.claimData.model;

import org.junit.Test;

import java.util.ArrayList;

import static org.assertj.core.api.Java6Assertions.assertThat;

public class DamagesTest {
    @Test
    public void damages_defaultValues_whenNotUsingBuilder() {
        Damages damages = new Damages();
        assertThat(damages.getDamageId()).isNull();
        assertThat(damages.getRear()).isNull();
        assertThat(damages.getOther()).isNull();
        assertThat(damages.getPassengerSideExterior()).isNull();
        assertThat(damages.getDriverSideExterior()).isNull();
        assertThat(damages.getMechanical()).isNull();
        assertThat(damages.getFront()).isNull();
        assertThat(damages.getInterior()).isNull();
    }

    @Test
    public void damages_defaultValues_whenUsingBuilder() {
        Damages damages = Damages.builder().build();
        assertThat(damages.getDamageId()).isNull();
        assertThat(damages.getRear()).isEqualTo(new ArrayList<>());
        assertThat(damages.getOther()).isEqualTo(new ArrayList<>());
        assertThat(damages.getPassengerSideExterior()).isEqualTo(new ArrayList<>());
        assertThat(damages.getDriverSideExterior()).isEqualTo(new ArrayList<>());
        assertThat(damages.getMechanical()).isEqualTo(new ArrayList<>());
        assertThat(damages.getFront()).isEqualTo(new ArrayList<>());
        assertThat(damages.getInterior()).isEqualTo(new ArrayList<>());
    }
}
