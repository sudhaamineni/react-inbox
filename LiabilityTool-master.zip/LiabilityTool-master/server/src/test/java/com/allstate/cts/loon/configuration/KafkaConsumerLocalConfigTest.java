package com.allstate.cts.loon.configuration;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.kafka.support.serializer.JsonSerializer;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class KafkaConsumerLocalConfigTest {
    @Mock
    private KafkaProperties kafkaProperties;

    @InjectMocks
    private KafkaLocalConfig kafkaConsumerLocalConfig;

    @Test
    public void producerConfigs() throws Exception {

        when(kafkaProperties.getBootstrap()).thenReturn("myServerName");
        Map<String, Object> expectedProps = new HashMap<>();
        expectedProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "myServerName");
        expectedProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        expectedProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
        expectedProps.put(ProducerConfig.MAX_BLOCK_MS_CONFIG, "3000");

        assertEquals(expectedProps, kafkaConsumerLocalConfig.producerConfigs());
    }

    @Test
    public void consumerProps() throws Exception {
        when(kafkaProperties.getBootstrap()).thenReturn("myServer");
        when(kafkaProperties.getGroup()).thenReturn("group");

        Map<String, Object> expectedProps = new HashMap<>();
        expectedProps.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "myServer");
        expectedProps.put(ConsumerConfig.GROUP_ID_CONFIG, "group");
        expectedProps.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
        expectedProps.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, "100");
        expectedProps.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, "15000");

        assertEquals(expectedProps, kafkaConsumerLocalConfig.consumerProps());
    }
}