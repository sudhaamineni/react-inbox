package com.allstate.cts.loon.dcf.model;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import static org.assertj.core.api.Java6Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class AttachmentTest {

    @Test
    public void attachment_setsObjectIdtoEmptyStringWhenSetToNull() {
        Attachment attachment = Attachment.builder().build();
        attachment.setObjectId(null);
        assertThat(attachment.getObjectId()).isEqualTo("");
    }

    @Test
    public void attachment_setsPropertiesToEmptyObjectWhenSetToNull() {
        Attachment attachment = Attachment.builder().build();
        attachment.setProperties(null);
        assertThat(attachment.getProperties()).isEqualTo(Properties.builder().build());
    }
    @Test
    public void attachment_setsObjectIdtoGivenStringWhenObjectIdIsNotNull() {
        Attachment expectedAttachment = Attachment.builder().objectId("123").build();
        Attachment attachment = Attachment.builder().build();
        attachment.setObjectId("123");

        assertThat(attachment).isEqualTo(expectedAttachment);
    }
    @Test
    public void attachment_setsPropertiesToGivenObjectWhenObjectNotNull() {
        Properties properties = Properties.builder()
                .allstate_participant("participant")
                .build();
        Attachment expected = Attachment.builder()
                .objectId("123")
                .properties(properties)
                .build();
        Attachment attachment = Attachment.builder()
                .objectId("123")
                .build();

        attachment.setProperties(properties);

        assertThat(attachment).isEqualTo(expected);
    }
}