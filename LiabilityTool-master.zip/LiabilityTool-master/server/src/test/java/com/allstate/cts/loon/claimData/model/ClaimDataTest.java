package com.allstate.cts.loon.claimData.model;

import org.junit.Test;

import java.util.ArrayList;

import static java.util.Collections.singletonList;
import static org.assertj.core.api.Java6Assertions.assertThat;

public class ClaimDataTest {
    @Test
    public void claimData_defaultValues_whenNotUsingBuilder() {
        ClaimData claimData = new ClaimData();
        assertThat(claimData.getClaim()).isNull();
        assertThat(claimData.getAsset()).isNull();
        assertThat(claimData.getPerformers()).isNull();
        assertThat(claimData.getParticipants()).isNull();
        assertThat(claimData.getKeyFactAnswers()).isNull();
        assertThat(claimData.getClaimReset()).isNull();
    }

    @Test
    public void claimData_defaultValues_whenUsingBuilder() {
        ClaimData claimData = ClaimData.builder().build();
        assertThat(claimData.getClaim()).isNull();
        assertThat(claimData.getAsset()).isEqualTo(new ArrayList<>());
        assertThat(claimData.getPerformers()).isEqualTo(new ArrayList<>());
        assertThat(claimData.getParticipants()).isEqualTo(new ArrayList<>());
        assertThat(claimData.getKeyFactAnswers()).isEqualTo(new KeyFactAnswers());
        assertThat(claimData.getClaimReset()).isEqualTo(new ClaimReset());
    }
}