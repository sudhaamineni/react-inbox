package com.allstate.cts.loon.constants;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import static org.assertj.core.api.Java6Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class SecurityConstantsTest {
    @Test
    public void security_constants_returnsISAMUserHeader(){
        assertThat(SecurityConstants.ISAM_USER_HEADER).isEqualTo("IV-USER");
    }

    @Test
    public void security_constants_returnsISAMGroupsHeader(){
        assertThat(SecurityConstants.ISAM_GROUPS_HEADER).isEqualTo("IV-GROUPS");
    }

    @Test
    public void security_constants_returnsAD_Non_Prod_General_AccessGroup(){
        assertThat(SecurityConstants.AD_NON_PROD_GENERAL_ACCESS_GROUP).isEqualTo("LOON-NONPROD");
    }

    @Test
    public void security_constants_returnsAD_Prod_General_AccessGroup(){
        assertThat(SecurityConstants.AD_PROD_GENERAL_ACCESS_GROUP).isEqualTo("LOON-PROD");
    }

    @Test
    public void security_constants_returnsLoonApiKeyHeader(){
        assertThat(SecurityConstants.LOON_API_KEY_HEADER).isEqualTo("API-KEY");
    }

    @Test
    public void security_constants_returnsReadOnlyAccessUser(){
        assertThat(SecurityConstants.ORG_ROLE_LOON_READ_ONLY_USER).isEqualTo("LOON Read Only User");
    }

    @Test
    public void security_constants_returnsReadOnlyAccessCode(){
        assertThat(SecurityConstants.ORG_ROLE_LOON_READ_ONLY_USER_CODE).isEqualTo("1908");
    }
}