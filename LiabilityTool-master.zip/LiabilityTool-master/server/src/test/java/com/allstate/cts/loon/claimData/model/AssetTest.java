package com.allstate.cts.loon.claimData.model;

import org.junit.Test;

import java.util.ArrayList;

import static java.util.Collections.singletonList;
import static org.assertj.core.api.Java6Assertions.assertThat;

public class AssetTest {
    Asset asset;

    @Test
    public void asset_defaultValues_whenNotUsingBuilder() {
        asset = new Asset();
        assertThat(asset.getVehicle()).isNull();
        assertThat(asset.getParticipants()).isNull();
        assertThat(asset.getDamages()).isNull();
        assertThat(asset.getItemId()).isNull();
        assertThat(asset.getAssetTypeDescription()).isNull();
    }

    @Test
    public void asset_defaultValues_whenUsingBuilder() {
        asset = Asset.builder().build();
        assertThat(asset.getVehicle()).isEqualTo(null);
        assertThat(asset.getParticipants()).isEqualTo(new ArrayList<>());
        assertThat(asset.getDamages()).isEqualTo(null);
        assertThat(asset.getItemId()).isEqualTo("");
        assertThat(asset.getAssetTypeDescription()).isEqualTo("");
    }
}
