package com.allstate.cts.loon.admin.service;

import com.allstate.cts.loon.assignment.service.AssignmentService;
import com.allstate.cts.loon.configuration.FeatureSwitches;
import com.allstate.cts.loon.eligibility.model.FNOLContext;
import com.allstate.cts.loon.eligibility.service.KafkaAutomatedLiabilityProducerService;
import com.allstate.cts.loon.exception.SystemErrorException;
import com.allstate.cts.loon.helpers.Validator;
import com.allstate.cts.loon.liabilityAnalysis.entity.LiabilityAnalysisEntity;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.apache.kafka.common.KafkaException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import static java.util.Arrays.asList;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.data.mongodb.core.query.Criteria.where;

@RunWith(MockitoJUnitRunner.class)
public class AdminServiceTest {

    @Spy
    @InjectMocks
    private AdminService subject;

    @Mock
    MongoTemplate mockMongoTemplate;

    @Mock
    AssignmentService mockAssignmentService;

    @Mock
    KafkaAutomatedLiabilityProducerService mockKafkaAutomatedLiabilityProducerService;

    @Mock
    Validator mockValidator;

    @Mock
    FeatureSwitches mockFeatureSwitches;

    @Before
    public void setUp() {
        when(mockValidator.padClaimNumber("01234")).thenReturn("000000001234");
        when(mockValidator.padClaimNumber("1111")).thenReturn("000000001111");
        when(mockFeatureSwitches.isEnableAdmin()).thenReturn(true);
    }


    @Test
    public void clearAssignmentQueue_callsMongoTemplateFindAndRemove() {
        Query expectedQuery = new Query()
                .addCriteria(where("assignedTime")
                        .is(null))
                .addCriteria(where("isComplex")
                        .is(true));

        subject.clearAssignmentQueue();

        verify(mockMongoTemplate).findAllAndRemove(expectedQuery, LiabilityAnalysisEntity.class);
    }

    @Test(expected = UnsupportedOperationException.class)
    public void clearAssignment_throwsExceptionWhenEnableAdminIsFalse(){
        when(mockFeatureSwitches.isEnableAdmin()).thenReturn(false);
        subject.clearAssignmentQueue();
    }

    @Test
    public void clearAssignment_doesNotInteractWithComponentsWhenAdminIsDisabled(){
        when(mockFeatureSwitches.isEnableAdmin()).thenReturn(false);
        try {
            subject.clearAssignmentQueue();
            fail("Exception expected but did not occured");
        }
        catch (UnsupportedOperationException ex) {
            verifyZeroInteractions(mockMongoTemplate);
            verifyZeroInteractions(mockKafkaAutomatedLiabilityProducerService);
            verifyZeroInteractions(mockAssignmentService);
        }
    }



    @Test
    public void insertAssignmentClaimList_callsClearAssignmentQueue_whenClearQueueIsTrue() {
        subject.insertAssignmentClaimList(null, true, false);

        verify(subject).clearAssignmentQueue();
    }

    @Test(expected = UnsupportedOperationException.class)
    public void insertAssignmentClaimList_throwsExceptionWhenEnableAdminIsFalse(){
        when(mockFeatureSwitches.isEnableAdmin()).thenReturn(false);
        subject.insertAssignmentClaimList(null,false,false);
    }

    @Test
    public void insertAssignmentClaimList_doesNotInteractWithComponentsWhenAdminIsDisabled(){
        when(mockFeatureSwitches.isEnableAdmin()).thenReturn(false);
        try {
            subject.insertAssignmentClaimList(null, false, false);
            fail("Exception expected but did not occured");
        }
        catch (UnsupportedOperationException ex) {
            verifyZeroInteractions(mockMongoTemplate);
            verifyZeroInteractions(mockKafkaAutomatedLiabilityProducerService);
            verifyZeroInteractions(mockAssignmentService);
        }
    }

    @Test(expected = UnsupportedOperationException.class)
    public void deleteClaimListFromAssignmentQueue_throwsExceptionWhenEnableAdminIsFalse(){
        when(mockFeatureSwitches.isEnableAdmin()).thenReturn(false);
        subject.deleteClaimListFromAssignmentQueue(null);
    }

    @Test
    public void deleteClaimListFromAssignmentQueue_doesNotInteractWithComponentsWhenAdminIsDisabled(){
        when(mockFeatureSwitches.isEnableAdmin()).thenReturn(false);
        try {
            subject.deleteClaimListFromAssignmentQueue(null);
            fail("Exception expected but did not occured");
        }
        catch (UnsupportedOperationException ex) {
            verifyZeroInteractions(mockMongoTemplate);
            verifyZeroInteractions(mockKafkaAutomatedLiabilityProducerService);
            verifyZeroInteractions(mockAssignmentService);
        }
    }

    @Test(expected = UnsupportedOperationException.class)
    public void publishAssignmentToKafka_throwsExceptionWhenEnableAdminIsFalse() throws Exception{
        when(mockFeatureSwitches.isEnableAdmin()).thenReturn(false);
        subject.publishAssignmentToKafka(null);
    }

    @Test
    public void publishAssignmentToKafka_doesNotInteractWithComponentsWhenAdminIsDisabled() throws Exception{
        when(mockFeatureSwitches.isEnableAdmin()).thenReturn(false);
        try {
            subject.publishAssignmentToKafka(null);
            fail("Exception expected but did not occured");
        }
        catch (UnsupportedOperationException ex) {
            verifyZeroInteractions(mockMongoTemplate);
            verifyZeroInteractions(mockKafkaAutomatedLiabilityProducerService);
            verifyZeroInteractions(mockAssignmentService);
        }
    }

    @Test
    public void insertAssignmentClaimList_doesNotCallClearAssignmentQueue_whenClearQueueIsFalse() {
        subject.insertAssignmentClaimList(null, false,false);

        verify(subject, times(0)).clearAssignmentQueue();
    }

    @Test
    public void deleteClaimListFromAssignmentQueue_callsMongoTemplateFindAndRemove() {

        List<String> claimList = asList("01234", "1111");
        Query expectedQuery = new Query()
                .addCriteria(where("claimNumber")
                        .in(claimList));

        subject.deleteClaimListFromAssignmentQueue(claimList);

        verify(mockMongoTemplate).findAllAndRemove(expectedQuery, LiabilityAnalysisEntity.class);
    }

    @Test
    public void insertAssignmentClaimList_callsdeleteClaimListFromAssignmentQueue() {
        List<String> claimList = asList("01234", "1111");
        List<String> expectedClaimList = asList("000000001234", "000000001111");
        subject.insertAssignmentClaimList(claimList, true, false);

        verify(subject).deleteClaimListFromAssignmentQueue(expectedClaimList);
    }

    @Test
    public void insertAssignmentClaimList_callsCreateAssignment_forEachClaimNumber_whenUseKafkaIsFalse() {
        List<String> claimList = asList("01234", "1111");
        subject.insertAssignmentClaimList(claimList, true, false);

        verify(mockAssignmentService).createAssignment("000000001234");
        verify(mockAssignmentService).createAssignment("000000001111");
    }

    @Test
    public void insertAssignmentClaimList_callsPublishAssignmentToKafka_forEachClaimNumber_whenUseKafkaIsTrue() throws InterruptedException, ExecutionException, JsonProcessingException {
        List<String> claimList = asList("01234", "1111");
        subject.insertAssignmentClaimList(claimList, true, true);

        verify(subject).publishAssignmentToKafka("000000001234");
        verify(subject).publishAssignmentToKafka("000000001111");
    }

    @Test(expected = SystemErrorException.class)
    public void insertAssignmentClaimList_throwsSystemErrorException_whenPublishToKafkaErrorsOut() throws InterruptedException, ExecutionException, JsonProcessingException {
        List<String> claimList = asList("01234", "1111");

        doThrow(new KafkaException()).when(mockKafkaAutomatedLiabilityProducerService).publishFNOLToKafka(any(FNOLContext.class));
        subject.insertAssignmentClaimList(claimList, true, true);

    }

    @Test
    public void insertAssignmentClaimList_doesNotReturnError_whenClaimListIsNull() {
        subject.insertAssignmentClaimList(null, true, false);
    }

    @Test
    public void insertAssignmentClaimList_doesNotReturnError_whenClaimListIsEmpty() {
        List<String> claimList = new ArrayList<>();
        subject.insertAssignmentClaimList(claimList, true,false);
    }

    @Test
    public void publishAssignmentToKafka_callsKafkaAutomatedLiabilityProducerService_publishFNOLToKafka() throws InterruptedException, ExecutionException, JsonProcessingException {
        FNOLContext fnolContext = FNOLContext.builder()
                .claimNumber("012345")
                .lineOfBusiness("Auto - Personal")
                .build();

        subject.publishAssignmentToKafka("012345");

        verify(mockKafkaAutomatedLiabilityProducerService).publishFNOLToKafka(fnolContext);
    }

}