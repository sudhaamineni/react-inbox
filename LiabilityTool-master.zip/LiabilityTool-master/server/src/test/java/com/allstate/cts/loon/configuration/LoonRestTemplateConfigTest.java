package com.allstate.cts.loon.configuration;

import com.allstate.cts.loon.resttemplate.LoonRestTemplate;
import com.allstate.cts.loon.utils.SecurityUtility;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpHeaders;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.doReturn;
import static org.mockito.MockitoAnnotations.initMocks;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.http.MediaType.MULTIPART_FORM_DATA;
import static org.springframework.test.util.ReflectionTestUtils.setField;

@RunWith(MockitoJUnitRunner.class)
public class LoonRestTemplateConfigTest {
    @Mock
    private SecurityUtility mockSecurityUtility;

    @InjectMocks
    private LoonRestTemplateConfig subject;

    @Before
    public void setUp() {
        initMocks(this);
        setField(subject, "leelaClaimUrl", "leelaClaimUrl");
        setField(subject, "leelaClientKey", "leelaClientKey");
        setField(subject, "orgDataUrl", "orgDataUrl");
        setField(subject, "orgDataClientKey", "orgDataClientKey");
        setField(subject, "ravenUrl", "ravenUrl");
        setField(subject, "ravenUsername", "ravenUsername");
        setField(subject, "ravenPassword", "ravenPassword");
        setField(subject, "dcfUrl", "dcfUrl");
        setField(subject, "dcfContentUrl", "dcfContentUrl");
        setField(subject, "dcfStoreUrl", "dcfStoreUrl");
        setField(subject, "dcfClientKey", "dcfClientKey");
        setField(subject, "nextGenUrl", "nextGenUrl");
        setField(subject, "nextGenUserId", "nextGenUserId");
        setField(subject, "parakeetUrl", "parakeetUrl");
        setField(subject, "parakeetApiKey", "parakeetApiKey");
        setField(subject, "liabilityAnalysisSystemId", "liabilityAnalysisSystemId");
        setField(subject, "griffinUrl", "griffinUrl");
    }

    @Test
    public void leelaClaimRestTemplate() {
        HttpHeaders mockHttpHeaders = new HttpHeaders();
        mockHttpHeaders.setContentType(APPLICATION_JSON);
        mockHttpHeaders.add("CLIENT_KEY", "leelaClientKey");

        LoonRestTemplate result = subject.leelaClaimRestTemplate();

        assertThat(result.getHttpHeaders()).isEqualTo(mockHttpHeaders);
        assertThat(result.getSystemName()).isEqualTo("Liability Tool");
        assertThat(result.getTargetSystemName()).isEqualTo("Leela");
        assertThat(result.getTargetSystemUrl()).isEqualTo("leelaClaimUrl");
    }

    @Test
    public void orgDataRestTemplate() {
        HttpHeaders mockHttpHeaders = new HttpHeaders();
        mockHttpHeaders.setContentType(APPLICATION_JSON);
        mockHttpHeaders.add("CLIENT_KEY", "orgDataClientKey");

        LoonRestTemplate result = subject.orgDataRestTemplate();

        assertThat(result.getHttpHeaders()).isEqualTo(mockHttpHeaders);
        assertThat(result.getSystemName()).isEqualTo("Liability Tool");
        assertThat(result.getTargetSystemName()).isEqualTo("Shadow");
        assertThat(result.getTargetSystemUrl()).isEqualTo("orgDataUrl");
    }

    @Test
    public void testRavenRestTemplate() {
        HttpHeaders mockHttpHeaders = new HttpHeaders();
        mockHttpHeaders.setContentType(APPLICATION_JSON);
        mockHttpHeaders.add("Authorization", "authorization");

        doReturn("authorization").when(mockSecurityUtility).encodeCredentials("ravenUsername", "ravenPassword");

        LoonRestTemplate result = subject.ravenRestTemplate();

        assertThat(result.getHttpHeaders()).isEqualTo(mockHttpHeaders);
        assertThat(result.getSystemName()).isEqualTo("Liability Tool");
        assertThat(result.getTargetSystemName()).isEqualTo("Raven");
        assertThat(result.getTargetSystemUrl()).isEqualTo("ravenUrl");
    }

    @Test
    public void dcfRestTemplate() {
        HttpHeaders mockHttpHeaders = new HttpHeaders();
        mockHttpHeaders.setContentType(APPLICATION_JSON);
        mockHttpHeaders.add("CLIENT_KEY", "dcfClientKey");
        mockHttpHeaders.add("SYSTEM_ID", "liabilityAnalysisSystemId");

        LoonRestTemplate result = subject.dcfRestTemplate();

        assertThat(result.getHttpHeaders()).isEqualTo(mockHttpHeaders);
        assertThat(result.getSystemName()).isEqualTo("Liability Tool");
        assertThat(result.getTargetSystemName()).isEqualTo("DCF");
        assertThat(result.getTargetSystemUrl()).isEqualTo("dcfUrl");
    }

    @Test
    public void dcfContentRestTemplate() {
        HttpHeaders mockHttpHeaders = new HttpHeaders();
        mockHttpHeaders.setContentType(APPLICATION_JSON);
        mockHttpHeaders.add("CLIENT_KEY", "dcfClientKey");
        mockHttpHeaders.add("SYSTEM_ID", "liabilityAnalysisSystemId");

        LoonRestTemplate result = subject.dcfContentRestTemplate();

        assertThat(result.getHttpHeaders()).isEqualTo(mockHttpHeaders);
        assertThat(result.getSystemName()).isEqualTo("Liability Tool");
        assertThat(result.getTargetSystemName()).isEqualTo("DCF Content");
        assertThat(result.getTargetSystemUrl()).isEqualTo("dcfContentUrl");
    }

    @Test
    public void dcfStoreRestTemplate() {
        HttpHeaders mockHttpHeaders = new HttpHeaders();
        mockHttpHeaders.setContentType(MULTIPART_FORM_DATA);
        mockHttpHeaders.add("CLIENT_KEY", "dcfClientKey");
        mockHttpHeaders.add("SYSTEM_ID", "liabilityAnalysisSystemId");

        LoonRestTemplate result = subject.dcfStoreRestTemplate();

        assertThat(result.getHttpHeaders()).isEqualTo(mockHttpHeaders);
        assertThat(result.getSystemName()).isEqualTo("Liability Tool");
        assertThat(result.getTargetSystemName()).isEqualTo("DCF Store");
        assertThat(result.getTargetSystemUrl()).isEqualTo("dcfStoreUrl");
    }

    @Test
    public void nextGenRestTemplate() {
        HttpHeaders mockHttpHeaders = new HttpHeaders();
        mockHttpHeaders.setContentType(APPLICATION_JSON);
        mockHttpHeaders.add("user", "nextGenUserId");

        LoonRestTemplate result = subject.nextGenRestTemplate();

        assertThat(result.getHttpHeaders()).isEqualTo(mockHttpHeaders);
        assertThat(result.getSystemName()).isEqualTo("Liability Tool");
        assertThat(result.getTargetSystemName()).isEqualTo("NextGen");
        assertThat(result.getTargetSystemUrl()).isEqualTo("nextGenUrl");
    }

    @Test
    public void parakeetRestTemplate() {
        HttpHeaders mockHttpHeaders = new HttpHeaders();
        mockHttpHeaders.setContentType(APPLICATION_JSON);
        mockHttpHeaders.add("api-key", "parakeetApiKey");

        LoonRestTemplate result = subject.parakeetRestTemplate();

        assertThat(result.getHttpHeaders()).isEqualTo(mockHttpHeaders);
        assertThat(result.getSystemName()).isEqualTo("Liability Tool");
        assertThat(result.getTargetSystemName()).isEqualTo("Parakeet");
        assertThat(result.getTargetSystemUrl()).isEqualTo("parakeetUrl");
    }

    @Test
    public void griffinRestTemplate_shouldHaveRequiredAnnotations() throws NoSuchMethodException {
        assertThat(subject.getClass().getMethod("griffinRestTemplate").getAnnotation(Bean.class).name()[0]).isEqualTo("griffinRestTemplate");
    }

    @Test
    public void griffinRestTemplate() {
        HttpHeaders mockHttpHeaders = new HttpHeaders();
        mockHttpHeaders.setContentType(APPLICATION_JSON);

        LoonRestTemplate actual = subject.griffinRestTemplate();
        assertThat(actual.getHttpHeaders()).isEqualTo(mockHttpHeaders);
        assertThat(actual.getSystemName()).isEqualTo("Liability Tool");
        assertThat(actual.getTargetSystemName()).isEqualTo("Griffin");
        assertThat(actual.getTargetSystemUrl()).isEqualTo("griffinUrl");
    }
}