package com.allstate.cts.loon.dcf.model;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import static org.assertj.core.api.Java6Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class DocumentTest {

    @Test
    public void document_setsMimeTypeToEmptyStringWhenSetToNull() {
        Document document = Document.builder().build();
        document.setMimetype(null);
        assertThat(document.getMimetype()).isEqualTo("");
    }

    @Test
    public void document_setsMimeTypeToPorvidedValueWhenProvidedValueIsNotNull() {
        Document document = Document.builder()
                .build();
        document.setMimetype("type");
        assertThat(document.getMimetype()).isEqualTo("type");
    }
}