package com.allstate.cts.loon.configuration;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static com.mongodb.MongoCredential.PLAIN_MECHANISM;
import static java.util.Collections.singletonList;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;
import static org.springframework.test.util.ReflectionTestUtils.setField;

@RunWith(MockitoJUnitRunner.class)
public class MongoConfigurationTest {
    @Mock
    private ServerConfiguration mockServerConfiguration;

    @InjectMocks
    private MongoConfiguration subject;

    @Before
    public void setUp() {
        initMocks(this);

        setField(subject, "replicaSet", null);
        setField(subject, "databaseName", "databaseName");
        setField(subject, "socketTimeout", 0);
        setField(subject, "serverSelectTimeout", 0);
        setField(subject, "connectTimeout", 0);
        setField(subject, "userName", "userName");
        setField(subject, "password", "password");

        when(mockServerConfiguration.getServer()).thenReturn(singletonList(new ServerConfiguration.Server()));
    }

    @Test
    public void testMongoClient_whenReplicaSetIsNull() {
        assertNotNull(subject.mongoClient());
        assertNull(subject.mongoClient().getCredentialsList().get(0).getMechanism());
    }

    @Test
    public void testMongoClient_whenReplicaSetIsNotNull() {
        setField(subject, "replicaSet", "replicaSet");

        assertNotNull(subject.mongoClient());
        assertThat(subject.mongoClient().getCredentialsList().get(0).getMechanism()).isEqualTo(PLAIN_MECHANISM);
    }
}