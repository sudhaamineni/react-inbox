package com.allstate.cts.loon.automatedLiability.service;

import com.allstate.cts.loon.automatedLiability.entity.AutomatedLiabilityEntity;
import com.allstate.cts.loon.automatedLiability.repository.AutomatedLiabilityRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Date;

import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class AutomatedLiabilityServiceTest {

    @Mock
    private AutomatedLiabilityRepository mockAutomatedLiabilityRepository;

    private AutomatedLiabilityService subject;

    @Before
    public void setUp() {
        subject = new AutomatedLiabilityService(mockAutomatedLiabilityRepository);
    }

    @Test
    public void processAutomatedLiabilityAnalysis_saves_automatedLiabilityAnalysis() {
        Date expectedCreatedDate = new Date();

        AutomatedLiabilityEntity expectedAutomatedLiabilityEntity = AutomatedLiabilityEntity
                .builder()
                .claimNumber("000487412345")
                .createdDate(expectedCreatedDate)
                .build();

        subject.processAutomatedLiability(expectedAutomatedLiabilityEntity);
        verify(mockAutomatedLiabilityRepository).save(expectedAutomatedLiabilityEntity);
    }
}