package com.allstate.cts.loon.configuration;

import com.allstate.cts.auditLog.exception.AuditLogException;
import com.allstate.cts.loon.exception.*;
import com.compozed.appfabric.logging.AppFabricLogger;
import com.compozed.appfabric.logging.LoggingEventType;
import com.compozed.appfabric.logging.LoggingResultType;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import static com.allstate.cts.loon.constants.LoonConstants.LOON_SERVER_EXCEPTION;
import static org.mockito.Mockito.verify;
import static org.assertj.core.api.Java6Assertions.assertThat;
import static com.compozed.appfabric.logging.LoggingEventType.SYSTEM;
import static com.compozed.appfabric.logging.LoggingEventType.VALIDATION;
import static com.compozed.appfabric.logging.LoggingResultType.FAILURE;
import static org.springframework.http.HttpStatus.*;

@RunWith(MockitoJUnitRunner.class)
public class LoonExceptionHandlingControllerAdviceTest {
    @InjectMocks
    private LoonExceptionHandlingControllerAdvice subject;

    @Mock
    private AppFabricLogger mockLogger;

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(subject, "logger", mockLogger);
    }

    @Test
    public void handleCustomExceptions_returnsA400HttpStatus_forInvalidCharacter() throws AuditLogException {
        InvalidCharacterException exception = new InvalidCharacterException("!@#@R$");
        ApiError expectedError = new ApiError(exception.getMessageHeader(), exception.getMessageDescription());

        ResponseEntity<ApiError> response = subject.handleCustomExceptions(exception);

        verify(mockLogger)
                .error(LOON_SERVER_EXCEPTION, VALIDATION, "InvalidCharacterException",
                        "Claim #!@#@R$ is invalid", FAILURE,
                        "We were unable to find this claim number. Please check and try again.");
        assertThat(response).isEqualTo(new ResponseEntity<>(expectedError, BAD_REQUEST));

    }

    @Test
    public void handleCustomExceptions_returnsA400HttpStatus_forInvalidReason() throws AuditLogException {
        InvalidUnlockReasonDescriptionException exception = new InvalidUnlockReasonDescriptionException("123","other",null);
        ApiError expectedError = new ApiError(exception.getMessageHeader(), exception.getMessageDescription());

        ResponseEntity<ApiError> response = subject.handleCustomExceptions(exception);

        verify(mockLogger)
                .error(LOON_SERVER_EXCEPTION, VALIDATION, "InvalidUnlockReasonDescriptionException",
                        "Claim #123 has invalid description. Reason: other Desc: null", FAILURE,
                        "This claim has invalid description for the reason other");
        assertThat(response).isEqualTo(new ResponseEntity<>(expectedError, BAD_REQUEST));

    }

    @Test
    public void handleCustomExceptions_returnsA400HttpStatus_forInvalidClaim() {
        InvalidClaimException exception = new InvalidClaimException("invalid@@");
        ApiError expectedError = new ApiError(exception.getMessageHeader(), exception.getMessageDescription());

        ResponseEntity<ApiError> response = subject.handleCustomExceptions(exception);

        verify(mockLogger)
                .error(LOON_SERVER_EXCEPTION, VALIDATION, "InvalidClaimException",
                        "Claim #invalid@@ does not qualify for analysis", FAILURE,
                        "This claim does not qualify for analysis in Loon.");
        assertThat(response).isEqualTo(new ResponseEntity<>(expectedError, BAD_REQUEST));
    }

    @Test
    public void handleCustomExceptions_returnsA400HttpStatus_forUnauthorizedClaim() throws AuditLogException {
        UnauthorizedClaimException exception = new UnauthorizedClaimException();
        ApiError expectedError = new ApiError(exception.getMessageHeader(), exception.getMessageDescription());

        ResponseEntity<ApiError> response = subject.handleCustomExceptions(exception);

        verify(mockLogger)
                .error(LOON_SERVER_EXCEPTION, VALIDATION, "UnauthorizedClaimException",
                        "Unauthorized", FAILURE, "You do not have access to this claim");
        assertThat(response).isEqualTo(new ResponseEntity<>(expectedError, BAD_REQUEST));
    }

    @Test
    public void handleResetClaimException_returnsA400HttpStatus_forResetClaim() throws AuditLogException {
        ClaimResetException exception = new ClaimResetException("002");
        ApiError expectedError = new ApiError(exception.getMessageHeader(), exception.getMessageDescription(), exception.getNewClaimNumber());

        ResponseEntity<ApiError> response = subject.handleResetClaimException(exception);

        verify(mockLogger)
                .error(LOON_SERVER_EXCEPTION, VALIDATION, "ClaimResetException",
                        "Claim reset error", FAILURE, "This claim has been reset.");
        assertThat(response).isEqualTo(new ResponseEntity<>(expectedError, BAD_REQUEST));
    }

    @Test
    public void handleNotAcceptableExceptions_returnsA406HttpStatus_forSubmittedSystemErrors() {
        SubmissionSystemErrorException exception = new SubmissionSystemErrorException(new RuntimeException("an error"));
        ApiError expectedError = new ApiError(exception.getMessageHeader(), exception.getMessageDescription());

        ResponseEntity<ApiError> response = subject.handleNotAcceptableExceptions(exception);

        verify(mockLogger)
                .error(LOON_SERVER_EXCEPTION, SYSTEM, "SubmissionSystemErrorException",
                        "Claim analysis submission failed.", FAILURE, "an error");
        assertThat(response).isEqualTo(new ResponseEntity<>(expectedError, NOT_ACCEPTABLE));
    }

    @Test
    public void handleServiceUnavailableExceptions_returnsA503HttpStatus_forSystemErrors() {
        SystemErrorException exception = new SystemErrorException();
        ApiError expectedError = new ApiError(exception.getMessageHeader(), exception.getMessageDescription());

        ResponseEntity<ApiError> response = subject.handleServiceUnavailableExceptions(exception);

        verify(mockLogger)
                .error(LOON_SERVER_EXCEPTION, SYSTEM, "SystemErrorException",
                        "Our systems are currently unavailable", FAILURE,
                        "Our systems are currently unable to process your search. Please try again later.");
        assertThat(response).isEqualTo(new ResponseEntity<>(expectedError, SERVICE_UNAVAILABLE));
    }

    @Test
    public void handleCustomExceptions_returnsA404HttpStatus_forClaimNotFound() {
        ClaimNotFoundException exception = new ClaimNotFoundException("123");
        ApiError expectedError = new ApiError(exception.getMessageHeader(), exception.getMessageDescription());

        ResponseEntity<ApiError> response = subject.handleNotFoundCustomExceptions(exception);

        verify(mockLogger)
                .error(LOON_SERVER_EXCEPTION, VALIDATION, "ClaimNotFoundException",
                        "No Results for Claim #123", FAILURE,
                        "We were unable to find this claim number. Please check and try again.");
        assertThat(response).isEqualTo(new ResponseEntity<>(expectedError, HttpStatus.NOT_FOUND));
    }

    @Test
    public void handleCustomExceptions_returnsA404HttpStatus_forNoAssignmentAvailableException() {
        NoAssignmentAvailableException exception = new NoAssignmentAvailableException();
        ApiError expectedError = new ApiError(exception.getMessageHeader(), exception.getMessageDescription());

        ResponseEntity<ApiError> response = subject.handleNotFoundCustomExceptions(exception);

        verify(mockLogger)
                .error(LOON_SERVER_EXCEPTION, VALIDATION, "NoAssignmentAvailableException",
                        "No Assignments.", FAILURE,
                        "No assignments available in the queue.");
        assertThat(response).isEqualTo(new ResponseEntity<>(expectedError, HttpStatus.NOT_FOUND));
    }

    @Test
    public void handleEverythingElse_returnsA500HttpStatus() {
        Exception exception = new Exception("Oh no!");
        ApiError expectedError = new ApiError("Our systems are currently unavailable", "Our systems are currently unable to process your search. Please try again later.");

        ResponseEntity<ApiError> response = subject.handleEverythingElse(exception);

        verify(mockLogger)
                .error(LOON_SERVER_EXCEPTION,exception, SYSTEM,"Exception","LoonExceptionHandlingControllerAdvice", FAILURE,"Oh no!");
        assertThat(response).isEqualTo(new ResponseEntity<>(expectedError, SERVICE_UNAVAILABLE));
    }
}