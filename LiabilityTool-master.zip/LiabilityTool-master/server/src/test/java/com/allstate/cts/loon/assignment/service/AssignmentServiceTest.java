package com.allstate.cts.loon.assignment.service;

import com.allstate.cts.loon.exception.NoAssignmentAvailableException;
import com.allstate.cts.loon.helpers.DateTimeHelper;
import com.allstate.cts.loon.liabilityAnalysis.entity.LiabilityAnalysisEntity;
import com.allstate.cts.loon.liabilityAnalysis.repository.LiabilityAnalysisRepository;
import com.allstate.cts.loon.liabilityAnalysis.service.LiabilityAnalysisService;
import com.allstate.cts.loon.startup.service.UserService;
import com.compozed.appfabric.logging.AppFabricLogger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Date;
import java.util.Optional;

import static com.compozed.appfabric.logging.LoggingEventType.APPLICATION;
import static com.compozed.appfabric.logging.LoggingResultType.FAILURE;
import static org.assertj.core.api.Java6Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;
import static org.springframework.data.domain.Sort.Direction.ASC;
import static org.springframework.data.mongodb.core.query.Criteria.where;

@RunWith(MockitoJUnitRunner.class)
public class AssignmentServiceTest {
    @Mock
    private LiabilityAnalysisService mockLiabilityAnalysisService;

    @Mock
    private LiabilityAnalysisRepository mockLiabilityAnalysisRepository;

    @Mock
    private MongoTemplate mockMongoTemplate;

    @Mock
    private UserService mockUserService;

    @Mock
    private DateTimeHelper mockDateTimeHelper;

    @Mock
    private AppFabricLogger mockLogger;

    @InjectMocks
    private AssignmentService subject;

    @Before
    public void setup() {
        ReflectionTestUtils.setField(subject, "logger", mockLogger);
    }

    @Test
    public void getNextAssignment() {
        Query query = new Query()
                .with(new Sort(ASC, "claimOpenedDate"))
                .addCriteria(where("status")
                        .is("READY_FOR_ASSIGNMENT"));
        LiabilityAnalysisEntity assignment = LiabilityAnalysisEntity.builder()
                .claimNumber("123")
                .build();
        LiabilityAnalysisEntity expected = LiabilityAnalysisEntity.builder()
                .claimNumber("123")
                .status("ASSIGNED")
                .assignedUser("mitch")
                .assignedTime(new Date())
                .build();

        when(mockMongoTemplate.findOne(query, LiabilityAnalysisEntity.class)).thenReturn(assignment);
        when(mockUserService.getUserName()).thenReturn("mitch");
        when(mockDateTimeHelper.getCurrentDateTime()).thenReturn(new Date());
        when(mockLiabilityAnalysisService.save(any(LiabilityAnalysisEntity.class))).thenReturn(expected);

        assertThat(subject.getNextAssignment()).isEqualTo(expected);
    }

    @Test(expected = NoAssignmentAvailableException.class)
    public void getNextAssignment_throwsNoAssignmentAvailableException_whenNoAssignmentsAreAvailable() {
        subject.getNextAssignment();
    }

    @Test
    public void getAssignmentByAssignedUser() {
        LiabilityAnalysisEntity expected = LiabilityAnalysisEntity.builder()
                .claimNumber("123")
                .status("ASSIGNED")
                .assignedUser("spamq")
                .assignedTime(new Date())
                .build();

        when(mockUserService.getUserName()).thenReturn("spamq");
        when(mockLiabilityAnalysisRepository.
                findByAssignedUser("spamq"))
                .thenReturn(Optional.of(expected));

        assertThat(subject.getAssignmentByAssignedUser()).isEqualTo(expected);
    }

    @Test
    public void getAssignmentByAssignedUser_returnsNull_whenRepositoryReturnsNull() {
        assertThat(subject.getAssignmentByAssignedUser()).isNull();
    }

    @Test
    public void updateAssignmentStatus() {
        LiabilityAnalysisEntity saved = LiabilityAnalysisEntity.builder()
                .claimNumber("123")
                .status("FROM_STATUS")
                .assignedUser("spamq")
                .assignedTime(new Date())
                .build();
        LiabilityAnalysisEntity expected = LiabilityAnalysisEntity.builder()
                .claimNumber("123")
                .status("TO_STATUS")
                .assignedUser("spamq")
                .assignedTime(new Date())
                .build();

        when(mockUserService.getUserName()).thenReturn("spamq");
        when(mockLiabilityAnalysisRepository.
                findByAssignedUserAndStatus("spamq", "FROM_STATUS"))
                .thenReturn(Optional.of(saved));

        subject.updateAssignmentStatus("FROM_STATUS", "TO_STATUS");

        verify(mockLiabilityAnalysisService).save(expected);
    }

    @Test
    public void updateAssignmentStatus_whenToStatusIsReadyForAssignment() {
        LiabilityAnalysisEntity saved = LiabilityAnalysisEntity.builder()
                .claimNumber("123")
                .status("FROM_STATUS")
                .assignedUser("spamq")
                .assignedTime(new Date())
                .build();
        LiabilityAnalysisEntity expected = LiabilityAnalysisEntity.builder()
                .claimNumber("123")
                .status("READY_FOR_ASSIGNMENT")
                .assignedUser(null)
                .assignedTime(null)
                .build();

        when(mockUserService.getUserName()).thenReturn("spamq");
        when(mockLiabilityAnalysisRepository.
                findByAssignedUserAndStatus("spamq", "FROM_STATUS"))
                .thenReturn(Optional.of(saved));

        subject.updateAssignmentStatus("FROM_STATUS", "READY_FOR_ASSIGNMENT");

        verify(mockLiabilityAnalysisService).save(expected);
    }

    @Test
    public void updateAssignmentStatus_whenNoDataFoundForFromStatus() {
        subject.updateAssignmentStatus("FROM_STATUS", "TO_STATUS");

        verifyZeroInteractions(mockLiabilityAnalysisService);
    }

    @Test
    public void createAssignment_savesWorkItemToLiabilityAnalysisRepository() {
        Date expectedDate = new Date();
        LiabilityAnalysisEntity expectedLiabilityAnalysisEntity = LiabilityAnalysisEntity.builder()
                .claimNumber("123")
                .status("READY_FOR_ASSIGNMENT")
                .createdTime(expectedDate)
                .build();

        when(mockDateTimeHelper.getCurrentDateTime()).thenReturn(expectedDate);

        subject.createAssignment("123");

        verify(mockLiabilityAnalysisRepository).save(expectedLiabilityAnalysisEntity);
    }

    @Test
    public void createAssignment_doesNotUpdateExistingAssignment_callsLogger_ifClaimNumberMatchesWithStatusReadyAnExistingAssignment() {
        LiabilityAnalysisEntity existingRecord = LiabilityAnalysisEntity.builder()
                .claimNumber("123")
                .status("READY_FOR_ASSIGNMENT")
                .build();

        when(mockLiabilityAnalysisRepository.findByClaimNumber(anyString())).thenReturn(Optional.of(existingRecord));

        subject.createAssignment("123");

        verify(mockLogger, times(1)).warn("LOON_SERVER_WARNING", APPLICATION,
                "AssignmentService.createAssignment",
                "Assignment already exists.", FAILURE,
                "Request to create assignment for claim number 123 ignored: Assignment already exists.");
    }

    @Test
    public void createAssignment_doesNotUpdatesExistingAssignment_callsLogger_ifClaimNumberMatchesWithStatusNotReadyAnExistingAssignment() {
        LiabilityAnalysisEntity existingRecord = LiabilityAnalysisEntity.builder()
                .claimNumber("123")
                .status("SAVED")
                .build();

        when(mockLiabilityAnalysisRepository.findByClaimNumber(anyString())).thenReturn(Optional.of(existingRecord));

        subject.createAssignment("123");
        verify(mockLogger, times(0)).warn(any(), any(), any(), any(), any(), any());
    }

    @Test
    public void createAssignment_doesNotCallsLoggerAndCreatesNewDocument_ifClaimNumberDoesNotMatchesAnExistingAssignment() {
        Date expectedDateCreated = new Date();
        ArgumentCaptor<LiabilityAnalysisEntity> argumentCaptor = ArgumentCaptor.forClass(LiabilityAnalysisEntity.class);
        LiabilityAnalysisEntity expected = LiabilityAnalysisEntity.builder()
                .createdTime(expectedDateCreated)
                .isComplex(true)
                .claimNumber("123")
                .status("READY_FOR_ASSIGNMENT")
                .build();

        when(mockDateTimeHelper.getCurrentDateTime()).thenReturn(expectedDateCreated);
        when(mockLiabilityAnalysisRepository.findByClaimNumber(anyString())).thenReturn(Optional.empty());

        subject.createAssignment("123");

        verify(mockLiabilityAnalysisRepository).save(argumentCaptor.capture());
        verify(mockLogger, times(0)).warn(any(), any(), any(), any(), any(), any());

        assertThat(argumentCaptor.getValue()).isEqualTo(expected);
    }
}