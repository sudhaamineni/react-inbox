package com.allstate.cts.loon.dcf.model;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static java.util.Collections.singletonList;
import static org.assertj.core.api.Java6Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class PropertiesTest {

    @Test
    public void properties_setsDocumentToGivenDocument() {
        Properties properties = Properties.builder().build();
        Document doc = Document.builder().mimetype("Mr Mime").build();

        properties.setDocument(doc);

        assertThat(properties.getDocument() == doc);
        assertThat(properties.getDocument().getMimetype()).isEqualTo(doc.getMimetype());
    }

    @Test
    public void properties_setsDocumentToAnEmptyObjectWhenSetToNull() {
        Properties properties = Properties.builder().build();
        properties.setDocument(null);
        assertThat(properties.getDocument()).isEqualTo(Document.builder().build());
    }

    @Test
    public void properties_setsAllstate_participantToAnEmptyStringWhenSetToNull() {
        Properties properties = Properties.builder().build();
        properties.setAllstate_participant(null);
        assertThat(properties.getAllstate_participant()).isEqualTo("");
    }

    @Test
    public void properties_setsAllstate_documentCategoryToAnEmptyArrayListWhenSetToNull() {
        Properties properties = Properties.builder().build();
        properties.setAllstate_documentCategory(null);
        assertThat(properties.getAllstate_documentCategory()).isEqualTo(new ArrayList<>());
    }

    @Test
    public void properties_setsAllstate_documentCategoryToWithTheGivenCategoryWhenDocumentCategoryIsNotNull() {
        List<String> categoryList = singletonList("test");
        Properties expectedProperties = Properties.builder()
                .allstate_documentCategory(categoryList)
                .build();
        Properties properties = Properties.builder()
                .build();

        properties.setAllstate_documentCategory(categoryList);

        assertThat(properties).isEqualTo(expectedProperties);
    }

    @Test
    public void properties_setsAllstate_participantToWithTheGivenParticipantWhenParticipantIsNotNull() {

        Properties expectedProperties = Properties.builder()
                .allstate_participant("participantName")
                .build();
        Properties properties = Properties.builder()
                .build();

        properties.setAllstate_participant("participantName");

        assertThat(properties).isEqualTo(expectedProperties);
    }
}