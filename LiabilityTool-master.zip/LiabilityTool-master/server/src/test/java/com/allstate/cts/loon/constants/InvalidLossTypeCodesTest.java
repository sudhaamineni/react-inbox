package com.allstate.cts.loon.constants;

import org.junit.Test;

import static com.allstate.cts.loon.constants.InvalidLossTypeCodes.*;
import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class InvalidLossTypeCodesTest {
    @Test
    public void InvalidLossTypeCodes_hasThreeEnums() {
        assertEquals(3, values().length);
    }

    @Test
    public void containsCode_returnsTrueGivenValidCode() {
        assertTrue(InvalidLossTypeCodes.containsCode("03"));
        assertTrue(InvalidLossTypeCodes.containsCode("11"));
        assertTrue(InvalidLossTypeCodes.containsCode("12"));
    }

    @Test
    public void getEnumFromCode_returnsEnumGivenValidCode() {
        assertEquals(GLASS_AND_TOWING, InvalidLossTypeCodes.getEnumFromCode("03"));
        assertEquals(GLASS_ONLY, InvalidLossTypeCodes.getEnumFromCode("11"));
        assertEquals(TOWING_ONLY, InvalidLossTypeCodes.getEnumFromCode("12"));
    }

    @Test
    public void getEnumFromCode_returnsNullGivenInvalidCode() {
        assertNull(InvalidLossTypeCodes.getEnumFromCode("05"));
    }
}