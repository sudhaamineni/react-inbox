package com.allstate.cts.loon.assignment.controller;

import com.allstate.cts.loon.assignment.service.AssignmentService;
import com.allstate.cts.loon.liabilityAnalysis.entity.LiabilityAnalysisEntity;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.standaloneSetup;

@RunWith(MockitoJUnitRunner.class)
public class AssignmentControllerTest {
    @Mock
    private AssignmentService mockAssignmentService;

    private MockMvc mockMvc;

    @Before
    public void setUp() {
        AssignmentController subject = new AssignmentController(mockAssignmentService);
        mockMvc = standaloneSetup(subject).build();
    }

    @Test
    public void getNextAssignment() throws Exception {
        LiabilityAnalysisEntity liabilityAnalysisEntity = LiabilityAnalysisEntity.builder()
                .claimNumber("123")
                .build();

        when(mockAssignmentService.getNextAssignment()).thenReturn(liabilityAnalysisEntity);

        mockMvc.perform(get("/api/v1/assignment/next")
                .contentType(APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.claimNumber").value("123"));

        verify(mockAssignmentService).getNextAssignment();
    }

    @Test
    public void updateStatusFromAssignedToReadyForAssignment() throws Exception {
        mockMvc.perform(post("/api/v1/assignment/status/a-rfa")
                .contentType(APPLICATION_JSON))
                .andExpect(status().isOk());

        verify(mockAssignmentService).updateAssignmentStatus("ASSIGNED", "READY_FOR_ASSIGNMENT");
    }
}
