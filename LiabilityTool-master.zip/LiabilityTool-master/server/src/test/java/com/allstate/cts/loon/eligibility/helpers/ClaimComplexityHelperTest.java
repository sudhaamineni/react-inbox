package com.allstate.cts.loon.eligibility.helpers;

import com.allstate.cts.loon.claimData.model.Claim;
import com.allstate.cts.loon.claimData.model.ClaimData;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import static com.allstate.cts.loon.constants.LoonConstants.*;
import static org.assertj.core.api.Java6Assertions.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class ClaimComplexityHelperTest {
    private ClaimComplexityHelper subject;

    @Before
    public void setup() {
        subject = new ClaimComplexityHelper();
    }

    @Test
    public void isNonComplexClaim_returnsTrue_WhenInsuredHitFixedObject() throws Exception {
        ClaimData claimData = setUpClaimData("14");
        assertTrue(subject.isNonComplexClaim(claimData));
    }

    @Test
    public void isNonComplexClaim_returnsTrue_WhenInsuredHitParkedParticipant() throws Exception {
        ClaimData claimData = setUpClaimData("19");
        assertTrue(subject.isNonComplexClaim(claimData));
    }

    @Test
    public void isNonComplexClaim_returnsTrue_WhenParticipantHitParkedInsured() throws Exception {
        ClaimData claimData = setUpClaimData("20");
        assertTrue(subject.isNonComplexClaim(claimData));
    }

    @Test
    public void isNonComplexClaim_returnsTrue_WhenParticipantRearEndedInsured() throws Exception {
        ClaimData claimData = setUpClaimData("23");
        assertTrue(subject.isNonComplexClaim(claimData));
    }

    @Test
    public void isNonComplexClaim_returnsTrue_WhenInsuredDroveIntoStandingWater() throws Exception {
        ClaimData claimData = setUpClaimData("08");
        assertTrue(subject.isNonComplexClaim(claimData));
    }

    @Test
    public void isNonComplexClaim_returnsTrue_WhenInsuredDroveIntoStandingWaterWithTrailingSpaces() throws Exception {
        ClaimData claimData = setUpClaimData("  08  ");
        assertTrue(subject.isNonComplexClaim(claimData));
    }

    @Test
    public void isNonComplexClaim_returnsTrue_WhenDriverAssaultedOrCarJacked() throws Exception {
        ClaimData claimData = setUpClaimData("45");
        assertTrue(subject.isNonComplexClaim(claimData));
    }

    @Test
    public void isNonComplexClaim_returnsTrue_WhenInjuredEnteringOrExiting() throws Exception {
        ClaimData claimData = setUpClaimData("49");
        assertTrue(subject.isNonComplexClaim(claimData));
    }

    @Test
    public void isNonComplexClaim_returnsTrue_WhenInjuredLoadingUnloading() throws Exception {
        ClaimData claimData = setUpClaimData("50");
        assertTrue(subject.isNonComplexClaim(claimData));
    }

    @Test
    public void isNonComplexClaim_returnsTrue_WhenInsuredRearEndedParticipantAndStopIndicatorIsNull() throws Exception {
        ClaimData claimData = setUpClaimData("21");
        claimData.getKeyFactAnswers().setVehStopInd(null);
        assertTrue(subject.isNonComplexClaim(claimData));
    }

    @Test
    public void isNonComplexClaim_returnsTrue_WhenInsuredRearEndedParticipantAndStopIndicatorIsNo() throws Exception {
        ClaimData claimData = setUpClaimData("21");
        claimData.getKeyFactAnswers().setVehStopInd("N");
        assertTrue(subject.isNonComplexClaim(claimData));
    }

    @Test
    public void isNonComplexClaim_returnsFalse_WhenInsuredRearEndedParticipantAndStopIndicatorIsYes() throws Exception {
        ClaimData claimData = setUpClaimData("21");
        claimData.getKeyFactAnswers().setVehStopInd("Y");
        assertFalse(subject.isNonComplexClaim(claimData));
    }

    @Test
    public void isNonComplexClaim_returnsFalse_WhenChangingLanes() throws Exception {
        ClaimData claimData = setUpClaimData("Changing Lanes");
        assertFalse(subject.isNonComplexClaim(claimData));
    }

    @Test
    public void isNonComplexClaim_returnsFalse_WhenHeadOnCollision() throws Exception {
        ClaimData claimData = setUpClaimData("Head-On Collision");
        assertFalse(subject.isNonComplexClaim(claimData));
    }

    @Test
    public void isNonComplexClaim_returnsFalse_WhenUnknownLossFacts() throws Exception {
        ClaimData claimData = setUpClaimData("Unknown Loss Facts");
        assertFalse(subject.isNonComplexClaim(claimData));
    }

    @Test
    public void isNonComplexClaim_returnsFalse_WhenDetailedLossTypeIsNull() throws Exception {
        ClaimData claimData = setUpClaimData(null);
        assertFalse(subject.isNonComplexClaim(claimData));
    }

    @Test
    public void isNonComplexClaim_returnsFalse_WhenClaimsNull() throws Exception {
        ClaimData claimData = ClaimData.builder()
                .claim(null)
                .build();

        assertFalse(subject.isNonComplexClaim(claimData));
    }

    @Test
    public void isNonComplexClaim_returnsFalse_WhenClaimsDataIsNull() throws Exception {
        assertFalse(subject.isNonComplexClaim(null));
    }

    @Test
    public void getNonComplexInsuredScore_returnsTheScoreOfInsured() {
        assertThat(subject.getNonComplexInsuredScore(INSD_HIT_A_FIXED_OBJECT)).isEqualTo(100);
        assertThat(subject.getNonComplexInsuredScore(INSD_HIT_PARKED_PART)).isEqualTo(100);
        assertThat(subject.getNonComplexInsuredScore(PART_HIT_PARKED_INSD)).isEqualTo(0);
        assertThat(subject.getNonComplexInsuredScore(PART_REARENDED_INSD)).isEqualTo(0);
        assertThat(subject.getNonComplexInsuredScore(DROVE_INTO_STANDING_WATER)).isEqualTo(100);
        assertThat(subject.getNonComplexInsuredScore(DRIVER_ASSAULT_CAR_JACK)).isEqualTo(0);
        assertThat(subject.getNonComplexInsuredScore(INJURED_ENTERING_EXITING)).isEqualTo(100);
        assertThat(subject.getNonComplexInsuredScore(INJURED_LOAD_UNLOAD_ASSET)).isEqualTo(100);
        assertThat(subject.getNonComplexInsuredScore(INSD_REAR_ENDED_PART)).isEqualTo(100);
    }

    @Test
    public void getNonComplexClaimantScore_returnsTheScoreOfClaimant() {
        assertThat(subject.getNonComplexClaimantScore(INSD_HIT_A_FIXED_OBJECT)).isEqualTo(0);
        assertThat(subject.getNonComplexClaimantScore(INSD_HIT_PARKED_PART)).isEqualTo(0);
        assertThat(subject.getNonComplexClaimantScore(PART_HIT_PARKED_INSD)).isEqualTo(100);
        assertThat(subject.getNonComplexClaimantScore(PART_REARENDED_INSD)).isEqualTo(100);
        assertThat(subject.getNonComplexClaimantScore(DROVE_INTO_STANDING_WATER)).isEqualTo(0);
        assertThat(subject.getNonComplexClaimantScore(DRIVER_ASSAULT_CAR_JACK)).isEqualTo(100);
        assertThat(subject.getNonComplexClaimantScore(INJURED_ENTERING_EXITING)).isEqualTo(0);
        assertThat(subject.getNonComplexClaimantScore(INJURED_LOAD_UNLOAD_ASSET)).isEqualTo(0);
        assertThat(subject.getNonComplexClaimantScore(INSD_REAR_ENDED_PART)).isEqualTo(0);
    }

    @Test
    public void getNonComplexInsuredScore_returnsNullWhenDetailedLossTypeIsNull() {
        assertThat(subject.getNonComplexInsuredScore(null)).isEqualTo(null);
    }

    @Test
    public void getNonComplexInsuredScore_returnsNullWhenDetailedLossTypeIsNotNonComplex() {
        assertThat(subject.getNonComplexInsuredScore("Complex Detailed Loss Type")).isEqualTo(null);
    }

    @Test
    public void getNonComplexClaimantScore_returnsNullWhenDetailedLossTypeIsNull() {
        assertThat(subject.getNonComplexClaimantScore(null)).isEqualTo(null);
    }

    @Test
    public void getNonComplexClaimantScore_returnsNullWhenDetailedLossTypeIsNotNonComplex() {
        assertThat(subject.getNonComplexClaimantScore("Complex Detailed Loss Type")).isEqualTo(null);
    }

    private ClaimData setUpClaimData(String detailedLossType) {
        Claim claim = Claim
                .builder()
                .lossDetailTypeCode(detailedLossType)
                .build();

        ClaimData claimData = ClaimData.builder()
                .claim(claim)
                .build();

        return claimData;
    }
}

