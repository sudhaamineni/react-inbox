package com.allstate.cts.loon.eligibility.service;

import com.allstate.cts.loon.eligibility.model.FNOLClaimData;
import com.allstate.cts.loon.exception.LoonInvalidMessageException;
import com.allstate.cts.loon.helpers.DateTimeHelper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.kafka.support.Acknowledgment;

import java.nio.charset.StandardCharsets;
import java.util.Date;

import static org.assertj.core.api.Java6Assertions.assertThat;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class KafkaFNOLConsumerTest {
    @Mock
    private EligibilityService mockEligibilityService;

    @Mock
    private DateTimeHelper dateTimeHelper;

    @Spy
    @InjectMocks
    private KafkaFNOLConsumer subject;

    @Test
    public void onReceiving() throws Exception {
        String expectedEntryString = "{\"claimNumber\":\"000487412345\",\"lineOfBusiness\":\"Auto - Personal\"}";
        byte[] fnolEntry = expectedEntryString.getBytes(StandardCharsets.UTF_8);

        Date expectedCreatedDate = new Date();

        Acknowledgment mockAcknowledgment = mock(Acknowledgment.class);

        FNOLClaimData expectedFnolClaimData = FNOLClaimData
                .builder()
                .claimNumber("000487412345")
                .createdDate(expectedCreatedDate)
                .lineOfBusiness("Auto - Personal")
                .build();

        doReturn(expectedFnolClaimData).when(subject).getFNOLClaimDataFromMessage(anyString());

        subject.onReceiving(fnolEntry, mockAcknowledgment);

        verify(subject).getFNOLClaimDataFromMessage(expectedEntryString);
        verify(mockAcknowledgment).acknowledge();
        verify(mockEligibilityService).processClaim(expectedFnolClaimData);
    }

    @Test
    public void onReceiving_doesNotAcknowledgeMessageAndCallsEndLogError_whenUnhandledExceptionIsReturnedFromService() throws Exception {
        String expecteEntryString = "{\"claimNumber\":\"000487412345\",\"lineOfBusiness\":\"Auto - Personal\"}";
        byte[] fnolEntry = expecteEntryString.getBytes(StandardCharsets.UTF_8);
        Acknowledgment mockAcknowledgment = mock(Acknowledgment.class);
        RuntimeException expectedException = new RuntimeException("test");
        Date expectedCreatedDate = new Date();
        FNOLClaimData expectedFnolClaimData = FNOLClaimData
                .builder()
                .claimNumber("000487412345")
                .createdDate(expectedCreatedDate)
                .lineOfBusiness("Auto - Personal")
                .build();

        doReturn(expectedFnolClaimData).when(subject).getFNOLClaimDataFromMessage(anyString());
        doThrow(expectedException).when(mockEligibilityService).processClaim(anyObject());

        subject.onReceiving(fnolEntry, mockAcknowledgment);

        verify(mockAcknowledgment, times(0)).acknowledge();
    }

    @Test
    public void onReceiving_acknowledgesMessageAndCallsEndLogError_whenGetFNOLClaimDataFromMessageThrowsLoonInvalidMessageException() throws Exception {
        String expecteEntryString = "{\"claimNumber\":\"000487412345\",\"lineOfBusiness\":\"Auto - Personal\"}";
        byte[] fnolEntry = expecteEntryString.getBytes(StandardCharsets.UTF_8);
        Acknowledgment mockAcknowledgment = mock(Acknowledgment.class);
        LoonInvalidMessageException expectedException = new LoonInvalidMessageException("msg", new RuntimeException());

        doThrow(expectedException).when(subject).getFNOLClaimDataFromMessage(anyString());

        subject.onReceiving(fnolEntry, mockAcknowledgment);

        verify(mockAcknowledgment).acknowledge();
    }

    @Test
    public void getFNOLClaimDataFromMessage() throws Exception {
        String mockEntryString = "{\"claimNumber\":\"000487412345\",\"lineOfBusiness\":\"Auto - Personal\"}";
        Date expectedCreatedDate = new Date();
        FNOLClaimData expectedFnolClaimData = FNOLClaimData
                .builder()
                .claimNumber("000487412345")
                .createdDate(expectedCreatedDate)
                .lineOfBusiness("Auto - Personal")
                .build();

        when(dateTimeHelper.getCurrentDateTime()).thenReturn(expectedCreatedDate);

        assertThat(subject.getFNOLClaimDataFromMessage(mockEntryString)).isEqualTo(expectedFnolClaimData);

        verify(dateTimeHelper).getCurrentDateTime();
    }

    @Test(expected = LoonInvalidMessageException.class)
    public void getFNOLClaimDataFromMessage_throwsIOException() throws Exception {
        String mockEntryString = "{\"\"}";

        subject.getFNOLClaimDataFromMessage(mockEntryString);
    }
}