package com.allstate.cts.loon.dcf.model;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static java.util.Collections.singletonList;
import static org.assertj.core.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class RetrieveAttachmentResponseTest {

    private RetrieveAttachmentResponse subject;

    @Before
    public void setUp() {
        subject = new RetrieveAttachmentResponse();
    }

    @Test
    public void testSetResults() {
        List<Attachment> results = new ArrayList<>();

        subject.setResults(results);

        assertThat(subject.getSearch_results()).isEqualTo(results);
    }

    @Test
    public void testSetResults_setsResultsToEmptyList_whenCalledWithNullValue() {
        List<Attachment> results = new ArrayList<>();

        subject.setResults(null);

        assertThat(subject.getSearch_results()).isEqualTo(results);
    }

    @Test
    public void testSetResults_setsResultsToGivenResult_whenCalledWithNotNullValue() {

        Attachment attachment = Attachment.builder().objectId("123").build();
        List<Attachment> attachmentList = singletonList(attachment);

        List<Attachment> expectedAttachmentList = singletonList(attachment);

        subject.setResults(attachmentList);

        assertThat(subject.getSearch_results()).isEqualTo(expectedAttachmentList);
    }
}
