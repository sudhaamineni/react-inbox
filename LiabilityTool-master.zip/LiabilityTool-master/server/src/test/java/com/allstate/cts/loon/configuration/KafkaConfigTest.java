package com.allstate.cts.loon.configuration;

import com.allstate.cts.loon.eligibility.model.FNOLClaimData;
import com.allstate.cts.loon.exception.KafkaProducerConfigException;
import com.allstate.cts.loon.helpers.CipherWrapper;
import com.allstate.cts.loon.helpers.FileUtilsWrapper;
import com.compozed.appfabric.logging.AppFabricLogger;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.serialization.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;
import org.springframework.test.util.ReflectionTestUtils;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;

import static com.allstate.cts.loon.constants.LoonConstants.LOON_SERVER_EXCEPTION;
import static com.allstate.cts.loon.utils.ErrorConstants.KAFKA_CONSUMER_CONFIG_INTERNAL_ERROR;
import static com.compozed.appfabric.logging.LoggingEventType.SYSTEM;
import static com.compozed.appfabric.logging.LoggingResultType.FAILURE;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.kafka.listener.ContainerProperties.AckMode.MANUAL;

@RunWith(MockitoJUnitRunner.class)
public class KafkaConfigTest {
    @Mock
    private KafkaProperties mockKafkaProperties;

    @Mock
    private FileUtilsWrapper mockFileUtilsWrapper;

    @Mock
    private CipherWrapper mockCipherWrapper;

    @Mock
    private AppFabricLogger mockLogger;

    @Spy
    @InjectMocks
    private KafkaConfig kafkaConfig;

    @Before
    public void setup() throws KafkaProducerConfigException {
        ReflectionTestUtils.setField(kafkaConfig, "kerberosConfig", "kafka-kerberos/krb5.conf");
        ReflectionTestUtils.setField(kafkaConfig, "authJaas", "kafka-kerberos/rtalab_feeder_nonprod.jaas");
        ReflectionTestUtils.setField(kafkaConfig, "encryptionKey", "encryptionKey");
        ReflectionTestUtils.setField(kafkaConfig, "keytabFile", "keytabFile");
        ReflectionTestUtils.setField(kafkaConfig, "logger", mockLogger);
    }

    @Test
    public void kafkaListenerContainerFactory_shouldReturnAConcurrentKafkaListenerContainerFactoryInstance() {

        ConsumerFactory<String, byte[]> mockFactory = (ConsumerFactory<String, byte[]>) Mockito.mock(ConsumerFactory.class);

        doReturn(mockFactory).when(kafkaConfig).consumerFactory();

        ConcurrentKafkaListenerContainerFactory<String, byte[]> actualFactory = kafkaConfig.kafkaListenerContainerFactory();
        assertNotNull(actualFactory);
        assertThat(actualFactory.getContainerProperties().getAckMode()).isEqualTo(MANUAL);
        assertThat(ReflectionTestUtils.getField(actualFactory, "concurrency")).isEqualTo(1);
        assertThat(actualFactory.getConsumerFactory()).isEqualTo(mockFactory);
        verify(kafkaConfig).consumerFactory();
    }

    @Test
    public void consumerFactory_shouldReturnDefaultKafkaConsumerFactory() {
        ConsumerFactory<String, byte[]> actualFactory = kafkaConfig.consumerFactory();
        assertNotNull(actualFactory);
        verify(kafkaConfig, times(1)).consumerProps();
        verify(kafkaConfig, times(1)).stringKeyDeserializer();
        verify(kafkaConfig, times(1)).byteArrayDeserializer();
    }

    @Test
    public void kafkaTemplate_returnsNewTemplate() throws Exception {
        ProducerFactory<Integer, FNOLClaimData> mockFactory = (ProducerFactory<Integer, FNOLClaimData>) Mockito.mock(ProducerFactory.class);

        doReturn(mockFactory).when(kafkaConfig).producerFactory();

        KafkaTemplate<Integer, FNOLClaimData> actualTemplate = kafkaConfig.kafkaTemplate();
        assertNotNull(actualTemplate);
        assertThat(ReflectionTestUtils.getField(actualTemplate, "producerFactory")).isEqualTo(mockFactory);
    }

    @Test
    public void producerConfigs_returnsProducerConfigMap() throws Exception {
        when(mockKafkaProperties.getBootstrap()).thenReturn("bootstrap");
        byte[] mockByteArray = {0xA};
        doReturn(mockByteArray).when(kafkaConfig).decryptFile(any(File.class));

        HashMap<String, Object> expectedProps = new HashMap<>();
        expectedProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, mockKafkaProperties.getBootstrap());
        expectedProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        expectedProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
        expectedProps.put(ProducerConfig.MAX_BLOCK_MS_CONFIG, "3000");
        expectedProps.put("security.protocol", "SASL_PLAINTEXT");
        expectedProps.put("sasl.kerberos.service.name", "kafka");
        expectedProps.put(SaslConfigs.SASL_MECHANISM, SaslConfigs.GSSAPI_MECHANISM);

        assertEquals(expectedProps, kafkaConfig.producerConfigs());
    }

    @Test
    public void producerConfigs_callsConfigureKerberos() throws Exception {
        when(mockKafkaProperties.getBootstrap()).thenReturn("bootstrap");
        byte[] mockByteArray = {0xA};
        doReturn(mockByteArray).when(kafkaConfig).decryptFile(any(File.class));

        kafkaConfig.producerConfigs();
        verify(kafkaConfig).configureKerberos();
    }

    @Test
    public void configureKerberos_setsUpKerberosSecurity() throws Exception {
        byte[] mockByteArray = {0xA};
        doReturn(mockByteArray).when(kafkaConfig).decryptFile(any(File.class));

        kafkaConfig.configureKerberos();

        assertThat(System.getProperty("java.security.krb5.conf")).isEqualTo("/tmp/krb5.conf");
        assertThat(System.getProperty("java.security.auth.login.config")).contains("kafka-kerberos/rtalab_feeder_nonprod.jaas");
        assertThat(System.getProperty("javax.security.auth.useSubjectCredsOnly")).isEqualTo("false");

        ArgumentCaptor<URL> urlArgumentCaptor = ArgumentCaptor.forClass(URL.class);
        ArgumentCaptor<File> fileArgumentCaptor = ArgumentCaptor.forClass(File.class);

        verify(mockFileUtilsWrapper, times(2)).copyURLToFile(urlArgumentCaptor.capture(), fileArgumentCaptor.capture());
        assertThat(urlArgumentCaptor.getAllValues().get(0).getFile()).contains("kafka-kerberos/krb5.conf");
        assertThat(fileArgumentCaptor.getAllValues().get(0).getPath()).isEqualTo("/tmp/krb5.conf");

        verify(kafkaConfig, times(1)).decryptFile(any(File.class));
        verify(mockFileUtilsWrapper, times(1)).writeByteArrayToFile(fileArgumentCaptor.capture(), eq(mockByteArray));
        assertThat(fileArgumentCaptor.getAllValues().get(2).getPath()).contains("tmp/rtalab_feeder_nonprod.keytab");

    }

    @Test
    public void producerFactory_shouldReturnDefaultKafkaProducerFactory() throws Exception {
        Map<String, Object> configProps = new HashMap<>();
        configProps.put("test", "testing producer config");

        doReturn(configProps).when(kafkaConfig).producerConfigs();
        ProducerFactory<Integer, FNOLClaimData> actualProducerFactory = kafkaConfig.producerFactory();
        assertThat(((DefaultKafkaProducerFactory) actualProducerFactory).getConfigurationProperties()).isEqualTo(configProps);
        verify(kafkaConfig).producerConfigs();
    }

    @Test
    public void consumerProps_shouldReturnMapOfProps() {
        when(mockKafkaProperties.getBootstrap()).thenReturn("bootstrap");
        when(mockKafkaProperties.getGroup()).thenReturn("group");

        Map<String, Object> expectedProps = new HashMap<>();
        expectedProps.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, mockKafkaProperties.getBootstrap());
        expectedProps.put(ConsumerConfig.GROUP_ID_CONFIG, mockKafkaProperties.getGroup());
        expectedProps.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
        expectedProps.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, "100");
        expectedProps.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, "15000");
        expectedProps.put("security.protocol", "SASL_PLAINTEXT");
        expectedProps.put("sasl.kerberos.service.name", "kafka");
        expectedProps.put(SaslConfigs.SASL_MECHANISM, SaslConfigs.GSSAPI_MECHANISM);

        assertEquals(expectedProps, kafkaConfig.consumerProps());
    }

    @Test
    public void byteArrayDeserializer_returnsByteArrayDeserializer() {
        Deserializer actualDeserializer = kafkaConfig.byteArrayDeserializer();
        assertThat(actualDeserializer).isInstanceOf(ByteArrayDeserializer.class);
        assertNotNull(actualDeserializer);
    }

    @Test
    public void stringKeyDeserializer_returnsStringDeserializer() {
        Deserializer actualDeserializer = kafkaConfig.stringKeyDeserializer();
        assertThat(actualDeserializer).isInstanceOf(StringDeserializer.class);
        assertNotNull(actualDeserializer);
    }

    @Test
    public void jsonSerializer_returnsFNOLClaimDataSerializer() {
        Serializer<FNOLClaimData> actualSerializer = kafkaConfig.jsonSerializer();
        assertThat(actualSerializer).isInstanceOf(JsonSerializer.class);
        assertNotNull(actualSerializer);
    }

    @Test
    public void decryptFile_returnsByteArray() throws Exception {
        byte[] mockEncryptedByteArray = {0xA};
        byte[] mockDecryptedByteArray = {0xB};
        File encryptedFile = new File("myFile");
        Key expectedKeySpec = new SecretKeySpec("encryptionKey".getBytes(), "AES");
        when(mockCipherWrapper.doFinal(mockEncryptedByteArray)).thenReturn(mockDecryptedByteArray);
        when(mockFileUtilsWrapper.readFileToByteArray(any(File.class))).thenReturn(mockEncryptedByteArray);

        byte[] actualDecryptedByteArray = kafkaConfig.decryptFile(encryptedFile);

        assertThat(actualDecryptedByteArray).isEqualTo(mockDecryptedByteArray);
        verify(mockFileUtilsWrapper).readFileToByteArray(encryptedFile);
        verify(mockCipherWrapper).init(Cipher.DECRYPT_MODE, expectedKeySpec);
        verify(mockCipherWrapper).doFinal(mockEncryptedByteArray);
    }

    @Test
    public void decryptFile_LogsAndThrowsException() throws Exception {
        File encryptedFile = new File("myFile");
        IOException expectedException = new IOException("myException");

        when(mockFileUtilsWrapper.readFileToByteArray(any(File.class))).thenThrow(expectedException);

        try {
            kafkaConfig.decryptFile(encryptedFile);
            fail("Exception expected but did not occur");
        } catch (KafkaProducerConfigException ex) {
            verify(mockLogger)
                    .error(LOON_SERVER_EXCEPTION, expectedException, SYSTEM, KAFKA_CONSUMER_CONFIG_INTERNAL_ERROR,
                            "KafkaConfig.decryptFile", FAILURE, expectedException.getMessage());
        }
    }
}