package com.allstate.cts.loon.aspect;

import com.allstate.cts.loon.exception.UnauthorizedClaimException;
import org.aspectj.lang.annotation.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;

import static java.util.Arrays.asList;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ValidateLoonUserRoleAspectTest {
    @InjectMocks
    private ValidateLoonUserRoleAspect subject;

    @Test
    public void validateLoonUser_shouldHaveBeforeValidateLoonUserRoleAnnotation() throws NoSuchMethodException {
        assertThat(subject.getClass().getMethod("validateLoonUser").getAnnotation(Before.class).value()).isEqualTo("@annotation(ValidateLoonUserRole)");
    }

    @Test
    public void validateLoonUser_doesNotThrowExceptionIfLoggedInUserHasLoonUserRole() {
        UserDetails userDetails = User.withUsername("santa claus")
                .password("")
                .authorities(asList(new SimpleGrantedAuthority("LOON User")))
                .build();
        User user = (User) userDetails;
        User expectedUser = user;
        SecurityContext context = mock(SecurityContext.class);
        Authentication authentication = mock(Authentication.class);
        SecurityContextHolder.setContext(context);

        when(context.getAuthentication()).thenReturn(authentication);
        when(context.getAuthentication().getPrincipal()).thenReturn(expectedUser);

        subject.validateLoonUser();
    }

    @Test(expected = UnauthorizedClaimException.class)
    public void validateLoonUser_throwsExceptionIfLoggedInUserHasLoonUserRole() {
        UserDetails userDetails = User.withUsername("santa claus")
                .password("")
                .authorities(asList(new SimpleGrantedAuthority("LOON Read Only User")))
                .build();
        User user = (User) userDetails;
        User expectedUser = user;
        SecurityContext context = mock(SecurityContext.class);
        Authentication authentication = mock(Authentication.class);
        SecurityContextHolder.setContext(context);

        when(context.getAuthentication()).thenReturn(authentication);
        when(context.getAuthentication().getPrincipal()).thenReturn(expectedUser);

        subject.validateLoonUser();
    }
}