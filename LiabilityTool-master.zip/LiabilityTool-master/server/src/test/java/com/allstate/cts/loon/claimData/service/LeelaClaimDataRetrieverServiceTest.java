package com.allstate.cts.loon.claimData.service;

import com.allstate.cts.loon.claimData.model.Claim;
import com.allstate.cts.loon.claimData.model.ClaimData;
import com.allstate.cts.loon.claimData.model.RetrieveClaimDataResponse;
import com.allstate.cts.loon.exception.ClaimDataRetrieverException;
import com.allstate.cts.loon.exception.ClaimNotFoundException;
import com.allstate.cts.loon.exception.SystemErrorException;
import com.allstate.cts.loon.resttemplate.LoonRestTemplate;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpClientErrorException;

import static org.assertj.core.api.Java6Assertions.assertThat;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class LeelaClaimDataRetrieverServiceTest {
    @Mock
    private LoonRestTemplate mockRestTemplate;

    @Mock
    private HttpClientErrorException httpClientErrorException;

    @InjectMocks
    private LeelaClaimDataRetrieverService subject;

    private ClaimData mockClaimData;

    @Before
    public void setUp() throws Exception {
        Claim mockClaim = Claim.builder()
                .claimNumber("123")
                .build();
        mockClaimData = ClaimData.builder()
                .claim(mockClaim)
                .build();
    }

    @Test
    public void getClaimData() throws Exception {
        RetrieveClaimDataResponse mockResponse = RetrieveClaimDataResponse.builder()
                .claimData(mockClaimData)
                .result("200")
                .build();

        when(mockRestTemplate.getObject(eq(RetrieveClaimDataResponse.class), anyString(), anyString(), anyString())).thenReturn(mockResponse);

        assertThat(subject.getClaimData("123", "vars")).isEqualTo(mockClaimData);

        verify(mockRestTemplate).getObject(RetrieveClaimDataResponse.class, "123", "123", "vars");
    }

    @Test(expected = ClaimNotFoundException.class)
    public void getClaimData_throwsClaimNotFoundException_whenExceptionIsBadRequest() throws Exception {
        when(mockRestTemplate.getObject(eq(RetrieveClaimDataResponse.class), anyString(), anyString(), anyString())).thenThrow(httpClientErrorException);
        when(httpClientErrorException.getStatusCode()).thenReturn(HttpStatus.BAD_REQUEST);

        subject.getClaimData("123", "vars");
    }

    @Test(expected = SystemErrorException.class)
    public void getClaimData_throwsSystemErrorException_whenExceptionisNotBadRequest() throws Exception {
        when(mockRestTemplate.getObject(eq(RetrieveClaimDataResponse.class), anyString(), anyString(), anyString())).thenThrow(httpClientErrorException);

        subject.getClaimData("123", "vars");
    }

    @Test(expected = ClaimDataRetrieverException.class)
    public void getClaimData_throwsClaimDataRetrieverException_whenExceptionisNotHttpClientErrorException() throws Exception {
        when(mockRestTemplate.getObject(eq(RetrieveClaimDataResponse.class), anyString(), anyString(), anyString())).thenThrow(new Exception());

        subject.getClaimData("123", "vars");
    }
}
