package com.allstate.cts.loon.configuration;

import org.assertj.core.api.Java6Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.interceptor.CacheErrorHandler;
import org.springframework.context.annotation.Profile;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.test.util.ReflectionTestUtils;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;
import static org.springframework.test.util.ReflectionTestUtils.setField;

@RunWith(MockitoJUnitRunner.class)
public class RedisCacheConfigTest {
    @InjectMocks
    RedisCacheConfig subject;

    @Mock
    Cache cache;

    @Test
    public void RedisCacheConfig_shouldHaveProfileAnnotation() {
        Java6Assertions.assertThat(subject.getClass().getAnnotation(Profile.class).value()[0]).isEqualTo("!devci");
    }

    @Test
    public void redisConnectionFactory_shouldReturnAJedisConnectionFactory_withHostNamePortAndPassword() {
        JedisConnectionFactory actualJedisConnectionFactory =
            subject.redisConnectionFactory("redis-hostname", 8080, "redis-password");

        assertThat(actualJedisConnectionFactory).isInstanceOf(JedisConnectionFactory.class);
        assertThat(actualJedisConnectionFactory.getHostName()).isEqualTo("redis-hostname");
        assertThat(actualJedisConnectionFactory.getPort()).isEqualTo(8080);
    }

    @Test
    public void redisConnectionFactory_setsPasswordWhenActiveProfileIsNotLocalOrLocalci() {
        setField(subject, "activeProfile", "dev");

        JedisConnectionFactory actualJedisConnectionFactory =
            subject.redisConnectionFactory("redis-hostname", 8080, "redis-password");
        assertThat(actualJedisConnectionFactory.getPassword()).isEqualTo("redis-password");
    }

    @Test
    public void redisConnectionFactory_doesNotSetPasswordWhenActiveProfileIsLocal() {
        setField(subject, "activeProfile", "local");

        JedisConnectionFactory actualJedisConnectionFactory =
            subject.redisConnectionFactory("redis-hostname", 8080, "redis-password");
        assertThat(actualJedisConnectionFactory.getPassword()).isEqualTo(null);
    }

    @Test
    public void redisConnectionFactory_doesNotSetPasswordWhenActiveProfileIsLocalci() {
        setField(subject, "activeProfile", "localci");

        JedisConnectionFactory actualJedisConnectionFactory =
            subject.redisConnectionFactory("redis-hostname", 8080, "redis-password");
        assertThat(actualJedisConnectionFactory.getPassword()).isEqualTo(null);
    }

    @Test
    public void redisTemplate_returnsARedisTemplate_withConnectionFactory() {
        RedisConnectionFactory redisConnectionFactory = new JedisConnectionFactory();

        assertThat(subject.redisTemplate(redisConnectionFactory)).isInstanceOf(RedisTemplate.class);
        assertThat(subject.redisTemplate(redisConnectionFactory).getConnectionFactory()).isEqualTo(redisConnectionFactory);
    }

    @Test
    public void cacheManager_shouldReturnCacheManager_withDurationInSeconds() {
        CacheManager cacheManager = subject.cacheManager(new JedisConnectionFactory(), 5);
        RedisCacheConfiguration cacheDefaults =
            (RedisCacheConfiguration) ReflectionTestUtils.getField(cacheManager, "defaultCacheConfig");

        assertThat(cacheManager).isInstanceOf(CacheManager.class);
        assertThat(cacheDefaults.getTtl().toMinutes()).isEqualTo(5);
    }

    @Test
    public void errorHandler_returnsACacheErrorHandler() {
        assertThat(subject.errorHandler()).isInstanceOf(CacheErrorHandler.class);
    }

    @Test
    public void errorHandler_handleCacheGetError_logsAnError() {
        RuntimeException ex = new RuntimeException("An error occurred.");

        subject.errorHandler().handleCacheGetError(ex, cache, new Object());
    }

    @Test
    public void errorHandler_handleCachePutError_logsAnError() {
        RuntimeException ex = new RuntimeException("An error occurred.");

        subject.errorHandler().handleCachePutError(ex, cache, new Object(), new Object());
    }

    @Test
    public void errorHandler_handleCacheEvictError_logsAnError() {
        RuntimeException ex = new RuntimeException("An error occurred.");

        subject.errorHandler().handleCacheEvictError(ex, cache, new Object());
    }

    @Test
    public void errorHandler_handleCacheClearError_logsAnError() {
        RuntimeException ex = new RuntimeException("An error occurred.");

        subject.errorHandler().handleCacheClearError(ex, cache);
    }
}
