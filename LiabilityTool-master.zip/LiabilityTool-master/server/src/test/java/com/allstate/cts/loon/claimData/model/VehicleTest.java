package com.allstate.cts.loon.claimData.model;

import org.junit.Test;

import static org.assertj.core.api.Java6Assertions.assertThat;

public class VehicleTest {
    @Test
    public void vehicle_defaultValues_whenNotUsingBuilder() {
        Vehicle vehicle = new Vehicle();
        assertThat(vehicle.getYear()).isNull();
        assertThat(vehicle.getMake()).isNull();
        assertThat(vehicle.getModel()).isNull();
    }

    @Test
    public void damages_defaultValues_whenUsingBuilder() {
        Vehicle vehicle = Vehicle.builder().build();
        assertThat(vehicle.getYear()).isEqualTo("");
        assertThat(vehicle.getMake()).isEqualTo("");
    }
}