package com.allstate.cts.loon.eligibility.service;

import com.allstate.cts.loon.assignment.service.AssignmentService;
import com.allstate.cts.loon.claimData.model.Claim;
import com.allstate.cts.loon.claimData.model.ClaimData;
import com.allstate.cts.loon.claimData.service.ClaimDataRetrieverServiceInterface;
import com.allstate.cts.loon.eligibility.helpers.ClaimComplexityHelper;
import com.allstate.cts.loon.eligibility.model.FNOLClaimData;
import com.allstate.cts.loon.eligibility.repository.FnolMessageRepository;
import com.allstate.cts.loon.helpers.DateTimeHelper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InOrder;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Date;

import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class EligibilityServiceTest {
    @Mock
    private ClaimDataRetrieverServiceInterface mockClaimDataRetrieverServiceInterface;

    @Mock
    private FnolMessageRepository mockFnolMessageRepository;

    @Mock
    private ClaimComplexityHelper mockClaimComplexityHelper;

    @Mock
    private AssignmentService mockAssignmentService;

    @Mock
    private NonComplexLiabilityAnalysisService mockNonComplexLiabilityAnalysisService;

    @Mock
    private DateTimeHelper mockDateTimeHelper;

    private EligibilityService subject;

    @Before
    public void setUp() {
        subject = new EligibilityService(mockClaimDataRetrieverServiceInterface, mockFnolMessageRepository,
                mockClaimComplexityHelper, mockAssignmentService, mockNonComplexLiabilityAnalysisService,
                mockDateTimeHelper);
    }

    @Test
    public void processClaim_DoesNotCallClaimData_whenClaimIsEligible() {
        Claim claim = Claim.builder().claimNumber("1234").build();
        ClaimData claimData = ClaimData.builder().claim(claim).build();
        when(mockClaimDataRetrieverServiceInterface.getClaimData(anyString(),anyString())).thenReturn(claimData);

        FNOLClaimData fnolClaimData = FNOLClaimData
                .builder()
                .claimNumber("1234")
                .lineOfBusiness("Auto - Personal")
                .build();

        subject.processClaim(fnolClaimData);
        verifyZeroInteractions(mockFnolMessageRepository);
    }

    @Test
    public void processClaim_savesClaimData_whenClaimIsNotEligible() {

        FNOLClaimData fnolClaimData = FNOLClaimData
                .builder()
                .claimNumber("1234")
                .lineOfBusiness("Property")
                .build();

        FNOLClaimData expectedFnolClaimData = FNOLClaimData
                .builder()
                .claimNumber("1234")
                .lineOfBusiness("Property")
                .build();

        subject.processClaim(fnolClaimData);
        verify(mockFnolMessageRepository).save(expectedFnolClaimData);
    }

    @Test
    public void processClaim_setsCreateDate_whenClaimIsInEligible() {
        Date expectedDate = new Date();
        when(mockDateTimeHelper.getCurrentDateTime()).thenReturn(expectedDate);
        FNOLClaimData fnolClaimData = FNOLClaimData
                .builder()
                .claimNumber("1234")
                .lineOfBusiness("Personal")
                .build();

        FNOLClaimData expectedFnolClaimData = FNOLClaimData
                .builder()
                .claimNumber("1234")
                .lineOfBusiness("Personal")
                .createdDate(expectedDate)
                .build();

        subject.processClaim(fnolClaimData);
        verify(mockFnolMessageRepository).save(expectedFnolClaimData);
    }

    @Test
    public void processClaim_setsCreateDate_whenClaimIsNotEligible() {
        Date expectedDate = new Date();
        when(mockDateTimeHelper.getCurrentDateTime()).thenReturn(expectedDate);
        FNOLClaimData fnolClaimData = FNOLClaimData
                .builder()
                .claimNumber("1234")
                .lineOfBusiness("Property")
                .build();

        FNOLClaimData expectedFnolClaimData = FNOLClaimData
                .builder()
                .claimNumber("1234")
                .lineOfBusiness("Property")
                .createdDate(expectedDate)
                .build();

        subject.processClaim(fnolClaimData);
        verify(mockFnolMessageRepository).save(expectedFnolClaimData);
    }

    @Test
    public void processClaim_retreivesClaimData_whenClaimIsEligible() {

        FNOLClaimData fnolClaimData = FNOLClaimData
                .builder()
                .claimNumber("1234")
                .lineOfBusiness("Auto - Personal")
                .build();

        subject.processClaim(fnolClaimData);
        verify(mockClaimDataRetrieverServiceInterface).getClaimData("1234", "claim,keyFactAnswers");
    }

    @Test
    public void processClaim_doesNotRetreivesClaimData_whenClaimIsNotEligible() {

        FNOLClaimData fnolClaimData = FNOLClaimData
                .builder()
                .claimNumber("1234")
                .lineOfBusiness("Auto - Commercial")
                .build();

        subject.processClaim(fnolClaimData);
        verifyZeroInteractions(mockClaimDataRetrieverServiceInterface);
    }

    @Test
    public void processClaim_callsAssignmentServiceCreateAssignment_whenClaimIsEligibleAndComplex() {
        Claim claim = Claim.builder().claimNumber("1234").build();
        ClaimData claimData = ClaimData.builder().claim(claim).build();

        FNOLClaimData fnolClaimData = FNOLClaimData
                .builder()
                .claimNumber("1234")
                .lineOfBusiness("Auto - Personal")
                .build();

        when(mockClaimDataRetrieverServiceInterface.getClaimData(anyString(), anyString())).thenReturn(claimData);
        when(mockClaimComplexityHelper.isNonComplexClaim(claimData)).thenReturn(false);

        subject.processClaim(fnolClaimData);
        verify(mockAssignmentService).createAssignment("1234");
    }

    @Test
    public void processClaim_doesNotCallsAssignmentServiceCreateAssignment_whenClaimIsEligibleAndNonComplex() {
        Claim claim = Claim.builder().claimNumber("1234").build();
        ClaimData claimData = ClaimData.builder().claim(claim).build();

        FNOLClaimData fnolClaimData = FNOLClaimData
                .builder()
                .claimNumber("1234")
                .lineOfBusiness("Auto - Personal")
                .build();

        when(mockClaimDataRetrieverServiceInterface.getClaimData(anyString(), anyString())).thenReturn(claimData);
        when(mockClaimComplexityHelper.isNonComplexClaim(claimData)).thenReturn(true);

        subject.processClaim(fnolClaimData);
        verifyZeroInteractions(mockAssignmentService);
    }

    @Test
    public void processClaim_callsNonComplexLiabilityAnalysisService_whenClaimIsEligibleAndNonComplex() {
        Claim claim = Claim.builder().claimNumber("1234").build();
        ClaimData claimData = ClaimData.builder().claim(claim).build();

        FNOLClaimData fnolClaimData = FNOLClaimData
                .builder()
                .claimNumber("1234")
                .lineOfBusiness("Auto - Personal")
                .build();

        when(mockClaimDataRetrieverServiceInterface.getClaimData(anyString(), anyString())).thenReturn(claimData);
        when(mockClaimComplexityHelper.isNonComplexClaim(claimData)).thenReturn(true);

        subject.processClaim(fnolClaimData);
        verify(mockNonComplexLiabilityAnalysisService).processNonComplexAssignment(claimData);
    }

    @Test
    public void processClaim_callsClaimDataRetrievServiceToGetAssetAndParticipants_whenClaimIsEligibleAndNonComplex() {
        Claim claim = Claim.builder().claimNumber("1234").build();
        ClaimData claimData = ClaimData.builder().claim(claim).build();

        FNOLClaimData fnolClaimData = FNOLClaimData
                .builder()
                .claimNumber("1234")
                .lineOfBusiness("Auto - Personal")
                .build();

        when(mockClaimDataRetrieverServiceInterface.getClaimData(anyString(), anyString())).thenReturn(claimData);
        when(mockClaimComplexityHelper.isNonComplexClaim(claimData)).thenReturn(true);

        subject.processClaim(fnolClaimData);
        verify(mockClaimDataRetrieverServiceInterface).getClaimData("1234","claim,asset,participant");
    }

    @Test
    public void processClaim_callsGetClaimDataToGetAssetAndParticipantsBeforeProcessNonComplexAssignment_whenClaimIsEligibleAndNonComplex() {
        Claim claim = Claim.builder().claimNumber("1234").build();
        ClaimData claimData = ClaimData.builder().claim(claim).build();

        FNOLClaimData fnolClaimData = FNOLClaimData
                .builder()
                .claimNumber("1234")
                .lineOfBusiness("Auto - Personal")
                .build();

        when(mockClaimDataRetrieverServiceInterface.getClaimData(anyString(), anyString())).thenReturn(claimData);
        when(mockClaimComplexityHelper.isNonComplexClaim(claimData)).thenReturn(true);

        subject.processClaim(fnolClaimData);
        InOrder inOrderVerifier = inOrder(mockClaimDataRetrieverServiceInterface,mockClaimComplexityHelper,mockNonComplexLiabilityAnalysisService);
        inOrderVerifier.verify(mockClaimDataRetrieverServiceInterface).getClaimData("1234","claim,asset,participant");
        inOrderVerifier.verify(mockNonComplexLiabilityAnalysisService).processNonComplexAssignment(claimData);
    }

    @Test
    public void processClaim_doesNotCallNonComplexLiabilityAnalysisService_whenClaimIsEligibleAndNonComplex() {
        Claim claim = Claim.builder().claimNumber("1234").build();
        ClaimData claimData = ClaimData.builder().claim(claim).build();

        FNOLClaimData fnolClaimData = FNOLClaimData
                .builder()
                .claimNumber("1234")
                .lineOfBusiness("Auto - Personal")
                .build();

        when(mockClaimDataRetrieverServiceInterface.getClaimData(anyString(), anyString())).thenReturn(claimData);
        when(mockClaimComplexityHelper.isNonComplexClaim(claimData)).thenReturn(false);

        subject.processClaim(fnolClaimData);
        verifyZeroInteractions(mockNonComplexLiabilityAnalysisService);
    }

    @Test
    public void processClaim_savesClaimData_whenLineOfBusinessWithMixedCaseAndAutoPersonal() {
        Claim claim = Claim.builder().claimNumber("1234").build();
        ClaimData claimData = ClaimData.builder().claim(claim).build();
        when(mockClaimDataRetrieverServiceInterface.getClaimData(anyString(), anyString())).thenReturn(claimData);
        FNOLClaimData fnolClaimData = FNOLClaimData
                .builder()
                .claimNumber("1234")
                .lineOfBusiness("Auto-Personal")
                .build();

        subject.processClaim(fnolClaimData);
        verifyZeroInteractions(mockFnolMessageRepository);
    }

    @Test
    public void processClaim_savesFnolButDoesNotProcessClaimDataIsNullFromLeela() {
        FNOLClaimData fnolClaimData = FNOLClaimData
                .builder()
                .claimNumber("1234")
                .lineOfBusiness("Auto-Personal")
                .build();

        when(mockClaimDataRetrieverServiceInterface.getClaimData(anyString(), anyString())).thenReturn(null);
        subject.processClaim(fnolClaimData);
        verify(mockFnolMessageRepository).save(fnolClaimData);

        verifyZeroInteractions(mockNonComplexLiabilityAnalysisService);
        verifyZeroInteractions(mockAssignmentService);
    }

    @Test
    public void processClaim_savesFnolButDoesNotProcessClaimIsNullFromLeela() {
        FNOLClaimData fnolClaimData = FNOLClaimData
                .builder()
                .claimNumber("1234")
                .lineOfBusiness("Auto-Personal")
                .build();

        when(mockClaimDataRetrieverServiceInterface.getClaimData(anyString(), anyString())).thenReturn(ClaimData.builder().build());
        subject.processClaim(fnolClaimData);
        verify(mockFnolMessageRepository).save(fnolClaimData);

        verifyZeroInteractions(mockNonComplexLiabilityAnalysisService);
        verifyZeroInteractions(mockAssignmentService);
    }

    @Test
    public void processNlpNotification_doesNothingRightNow() {
        //We put this test in as a reminder.... needed the method for NlpListener unit test.
    }
}