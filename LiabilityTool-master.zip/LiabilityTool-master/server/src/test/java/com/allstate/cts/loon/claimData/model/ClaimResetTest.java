package com.allstate.cts.loon.claimData.model;

import org.junit.Test;

import java.util.ArrayList;

import static org.assertj.core.api.Java6Assertions.assertThat;

public class ClaimResetTest {

    @Test
    public void claimReset_defaultVaues_whenNotUsingBuilder(){
        ClaimReset claimReset = new ClaimReset();
        assertThat(claimReset.getClaimResetList()).isNull();
    }

    @Test
    public void claimReset_defaultValues_whenUsingBuilder(){
        ClaimReset claimReset = ClaimReset.builder().build();
        assertThat(claimReset.getClaimResetList()).isEqualTo(new ArrayList<>());
    }
}