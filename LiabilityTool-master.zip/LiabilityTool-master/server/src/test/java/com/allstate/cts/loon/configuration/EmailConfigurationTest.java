package com.allstate.cts.loon.configuration;

import org.junit.Test;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import static org.junit.Assert.assertEquals;

public class EmailConfigurationTest {
    @Test
    public void getJavaMailSender() {
        EmailConfiguration emailConfig = new EmailConfiguration("host", 123);
        JavaMailSenderImpl javaMail = (JavaMailSenderImpl) emailConfig.getJavaMailSender();

        assertEquals(javaMail.getHost(), "host");
        assertEquals(javaMail.getPort(), 123);
        assertEquals(javaMail.getJavaMailProperties().getProperty("mail.transport.protocol"), "smtp");
        assertEquals(javaMail.getJavaMailProperties().getProperty("mail.smtp.auth"), "false");
        assertEquals(javaMail.getJavaMailProperties().getProperty("mail.smtp.starttls.enable"), "false");
    }
}
