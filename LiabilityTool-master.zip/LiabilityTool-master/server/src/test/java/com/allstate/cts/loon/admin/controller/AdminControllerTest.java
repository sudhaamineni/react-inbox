package com.allstate.cts.loon.admin.controller;

import com.allstate.cts.loon.admin.service.AdminService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static java.util.Arrays.asList;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.standaloneSetup;

@RunWith(MockitoJUnitRunner.class)
public class AdminControllerTest {
    @Mock
    private AdminService mockAdminService;

    private AdminController subject;
    private MockMvc mockMvc;

    @Before
    public void setUp() {
        subject = new AdminController(mockAdminService);
        mockMvc = standaloneSetup(subject).build();
    }

    @Test
    public void insertAssignmentClaimList() throws Exception {

        List<String> claimList = asList("012345", "11111", "22222");
        ObjectMapper mapper = new ObjectMapper();

        mockMvc.perform(post("/api/v1/admin?clearQueue=true&useKafka=false")
                .contentType(MediaType.APPLICATION_JSON)
                .content(mapper.writeValueAsString(claimList)))
                .andExpect(status().isOk());

        verify(mockAdminService).insertAssignmentClaimList(claimList, true, false);
    }
}