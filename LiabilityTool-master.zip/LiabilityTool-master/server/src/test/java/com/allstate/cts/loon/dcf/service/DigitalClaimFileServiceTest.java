package com.allstate.cts.loon.dcf.service;

import com.allstate.cts.auditLog.utilities.UUIDWrapper;
import com.allstate.cts.loon.dcf.model.*;
import com.allstate.cts.loon.exception.SystemErrorException;
import com.allstate.cts.loon.resttemplate.LoonRestTemplate;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.util.MultiValueMap;

import java.util.HashMap;
import java.util.List;

import static com.allstate.cts.loon.constants.LoonConstants.ALLSTATE_BRANDNAME;
import static com.allstate.cts.loon.constants.LoonConstants.SYSTEM_NAME;
import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class DigitalClaimFileServiceTest {
    @Mock
    private LoonRestTemplate dcfRestTemplate;

    @Mock
    private LoonRestTemplate dcfStoreRestTemplate;

    @Mock
    private UUIDWrapper uuidWrapper;

    private DigitalClaimFileService subject;

    @Captor
    ArgumentCaptor<MultiValueMap<String, Object>> payloadCaptor;

    @Captor
    ArgumentCaptor<HashMap<String, String>> headersCaptor;

    @Before
    public void setUp() {
        subject = spy(new DigitalClaimFileService(dcfRestTemplate, dcfStoreRestTemplate, uuidWrapper));
    }

    @Test
    public void getParticipantDocuments() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        RetrieveAttachmentResponse retrieveAttachmentResponse = RetrieveAttachmentResponse.builder()
                .search_results(singletonList(
                        Attachment.builder().objectId("objectId")
                                .properties(Properties.builder()
                                        .allstate_participantID(singletonList("ID"))
                                        .allstate_participant("Name")
                                        .document(Document.builder()
                                                .mimetype("image/jpeg")
                                                .build())
                                        .build())
                                .build())
                )
                .build();

        List<ParticipantDocuments> participantDocumentsList = singletonList(
                ParticipantDocuments.builder()
                        .participantSourceId("ID")
                        .fullName("Name")
                        .photoUrlList(singletonList(
                                PhotoDetail.builder()
                                        .dcfId("objectId")
                                        .url("/v3/retrieve?alfrescoId=objectId&versionLabel=1.0")
                                        .build()
                        ))
                        .build()
        );

        when(dcfRestTemplate.getObject(eq(String.class), anyString(), anyString())).thenReturn(mapper.writeValueAsString(retrieveAttachmentResponse));

        assertThat(subject.getParticipantDocuments("123")).isEqualTo(participantDocumentsList);

        verify(dcfRestTemplate).getObject(String.class, "123", "123");
    }

    @Test
    public void getParticipantDocuments_callsSearchByClaimNumberAndReturnsEmptyArrayList() throws Exception {
        when(dcfRestTemplate.getObject(eq(String.class), anyString(), anyString())).thenReturn("{\"search_results\":[\"NO RESULTS FOUND\"]}");

        assertThat(subject.getParticipantDocuments("123")).isEmpty();

        verify(dcfRestTemplate).getObject(String.class, "123", "123");
    }

    @Test(expected = SystemErrorException.class)
    public void searchByClaimNumber_throwsExceptionWhenDcfThrowsException() throws Exception {
        when(dcfRestTemplate.getObject(eq(String.class), anyString(), anyString())).thenThrow(new RuntimeException());

        subject.getParticipantDocuments("123");
    }

    @Test
    public void storeSummary_callsDcfStoreRestTemplate_withCorrectMultipartFormVariables() throws Exception {
        String randomUUID = "9e098a08-6ed7-47c3-a6ee-d5c0c0904607";
        when(uuidWrapper.getRandomUUID()).thenReturn(randomUUID);

        String claimNumber = "123";
        String participantId = "participantId";
        byte[] mockByteArr = new byte[5];

        subject.storeSummary(claimNumber, participantId, mockByteArr);

        verify(dcfStoreRestTemplate).sendObject(payloadCaptor.capture(), eq(StoreResponse.class), headersCaptor.capture(), eq(claimNumber));
        ByteArrayResource file = (ByteArrayResource) payloadCaptor.getValue().getFirst("file");
        assertTrue(file.getFilename().contains("Initial-Fault-Analysis-Claim123-"));
        assertThat(file.getFilename().length()).isEqualTo(53);
        assertThat(payloadCaptor.getValue().getFirst("participantId")).isEqualTo("participantId");
        assertThat(payloadCaptor.getValue().getFirst("docTypeCode")).isEqualTo("2025");
        assertThat(payloadCaptor.getValue().getFirst("additionalProps")).isEqualTo("{\"DocTypeCode\":\"2025\"}");
        assertThat(payloadCaptor.getValue().getFirst("systemName")).isEqualTo(SYSTEM_NAME);
        assertThat(payloadCaptor.getValue().getFirst("brandName")).isEqualTo(ALLSTATE_BRANDNAME);
        assertThat(payloadCaptor.getValue().getFirst("claimNumber")).isEqualTo("123");
        assertThat(payloadCaptor.getValue().getFirst("referenceId")).isEqualTo(randomUUID);

        assertThat(headersCaptor.getValue().get("LOON_DCF_PDF_DOC_TYPE_CODE")).isEqualTo("2025");
        assertTrue(headersCaptor.getValue().get("LOON_DCF_PDF_FILE_NAME").contains("Initial-Fault-Analysis-Claim123-"));
        assertThat(headersCaptor.getValue().get("LOON_DCF_PDF_FILE_NAME").length()).isEqualTo(53);
        assertThat(headersCaptor.getValue().get("LOON_DCF_PDF_PARTICIPANT_ID")).isEqualTo("participantId");
    }

    @Test
    public void getParticipantDocuments_skipsDocumentsWhenParticipantSourceIdIsEmptyArray() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        RetrieveAttachmentResponse retrieveAttachmentResponse = RetrieveAttachmentResponse.builder()
                .search_results(singletonList(
                        Attachment.builder().objectId("objectId")
                                .properties(Properties.builder()
                                        .allstate_participantID(emptyList())
                                        .allstate_participant("Name")
                                        .document(Document.builder()
                                                .mimetype("image/jpeg")
                                                .build())
                                        .build())
                                .build())
                )
                .build();

        List<ParticipantDocuments> participantDocumentsList = emptyList();

        when(dcfRestTemplate.getObject(eq(String.class), anyString(), anyString())).thenReturn(mapper.writeValueAsString(retrieveAttachmentResponse));

        assertThat(subject.getParticipantDocuments("123")).isEqualTo(participantDocumentsList);
    }

    @Test
    public void getParticipantDocuments_skipsDocumentsWhenParticipantSourceIdIsNull() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        RetrieveAttachmentResponse retrieveAttachmentResponse = RetrieveAttachmentResponse.builder()
                .search_results(singletonList(
                        Attachment.builder().objectId("objectId")
                                .properties(Properties.builder()
                                        .allstate_participantID(null)
                                        .allstate_participant("Name")
                                        .document(Document.builder()
                                                .mimetype("image/jpeg")
                                                .build())
                                        .build())
                                .build())
                )
                .build();

        List<ParticipantDocuments> participantDocumentsList = emptyList();

        when(dcfRestTemplate.getObject(eq(String.class), anyString(), anyString())).thenReturn(mapper.writeValueAsString(retrieveAttachmentResponse));

        assertThat(subject.getParticipantDocuments("123")).isEqualTo(participantDocumentsList);
    }
}
