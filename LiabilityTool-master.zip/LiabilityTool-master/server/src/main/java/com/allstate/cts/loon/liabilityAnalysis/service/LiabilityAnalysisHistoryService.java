package com.allstate.cts.loon.liabilityAnalysis.service;

import com.allstate.cts.loon.helpers.DateTimeHelper;
import com.allstate.cts.loon.liabilityAnalysis.entity.LiabilityAnalysisEntity;
import com.allstate.cts.loon.liabilityAnalysis.entity.LiabilityAnalysisHistoryEntity;
import com.allstate.cts.loon.liabilityAnalysis.repository.LiabilityAnalysisHistoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LiabilityAnalysisHistoryService {
    private LiabilityAnalysisHistoryRepository liabilityAnalysisHistoryRepository;
    private DateTimeHelper dateTimeHelper;

    @Autowired
    public LiabilityAnalysisHistoryService(LiabilityAnalysisHistoryRepository liabilityAnalysisHistoryRepository,
                                           DateTimeHelper dateTimeHelper) {
        this.liabilityAnalysisHistoryRepository = liabilityAnalysisHistoryRepository;
        this.dateTimeHelper = dateTimeHelper;
    }

    public LiabilityAnalysisHistoryEntity save(LiabilityAnalysisEntity liabilityAnalysisEntity) {
        LiabilityAnalysisHistoryEntity history = LiabilityAnalysisHistoryEntity.builder()
                .liabilityAnalysisEntity(liabilityAnalysisEntity)
                .createdTime(dateTimeHelper.getCurrentDateTime())
                .claimNumber(liabilityAnalysisEntity.getClaimNumber())
                .build();

        return liabilityAnalysisHistoryRepository.save(history);
    }
}
