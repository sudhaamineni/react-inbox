package com.allstate.cts.loon.helpers;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

public class ResourceFileUtils {
    public String readResourceAsString(String path) throws IOException {
        Resource resource = new ClassPathResource(path);
        BufferedReader br = new BufferedReader(new InputStreamReader(resource.getInputStream()), 1024);
        StringBuilder stringBuilder = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) {
            stringBuilder.append(line).append('\n');
        }
        br.close();

        return stringBuilder.toString();
    }

    public File getResourceFile(String path) throws IOException {
        return new ClassPathResource(path).getFile();
    }
}
