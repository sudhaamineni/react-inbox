package com.allstate.cts.loon.liabilityScorePublisher.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RavenLiabilityScorePublisherRequest {
    private String sourceSystem;
    private String correlationID;
    private String claimNumber;
    @JsonProperty("liability")
    private List<RavenLiabilityParties> ravenLiabilityParties;

}
