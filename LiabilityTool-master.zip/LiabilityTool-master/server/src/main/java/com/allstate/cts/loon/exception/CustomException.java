package com.allstate.cts.loon.exception;

public interface CustomException {
    String getMessageHeader();

    String getMessageDescription();
}
