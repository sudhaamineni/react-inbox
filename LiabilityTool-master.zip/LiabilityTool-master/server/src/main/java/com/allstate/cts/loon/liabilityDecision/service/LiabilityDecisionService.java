package com.allstate.cts.loon.liabilityDecision.service;

import com.allstate.cts.loon.configuration.FeatureSwitches;
import com.allstate.cts.loon.dcf.service.DigitalClaimFileService;
import com.allstate.cts.loon.exception.SubmissionSystemErrorException;
import com.allstate.cts.loon.griffin.service.GriffinService;
import com.allstate.cts.loon.helpers.DateTimeHelper;
import com.allstate.cts.loon.helpers.Validator;
import com.allstate.cts.loon.liabilityAnalysis.entity.*;
import com.allstate.cts.loon.liabilityAnalysis.service.LiabilityAnalysisService;
import com.allstate.cts.loon.liabilityAnalysis.service.LiabilityAnalysisSummaryPdfService;
import com.allstate.cts.loon.liabilityDecision.model.SubmitLiabilityDecisionRequest;
import com.allstate.cts.loon.liabilityScorePublisher.service.RavenLiabilityScorePublisherService;
import com.allstate.cts.loon.nextGenComponents.model.FileNote;
import com.allstate.cts.loon.nextGenComponents.service.FileNoteCreator;
import com.allstate.cts.loon.nextGenComponents.service.NextGenComponentsServiceInterface;
import com.compozed.appfabric.logging.AppFabricLogger;
import com.compozed.appfabric.logging.LoggingResultType;
import com.compozed.appfabric.logging.annotations.AppFabricLog;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

import static com.allstate.cts.loon.constants.LoonConstants.INSURED_CAPS;
import static com.allstate.cts.loon.constants.LoonConstants.LOON_SERVER_EXCEPTION;
import static com.compozed.appfabric.logging.LoggingEventType.SYSTEM;

@Service
public class LiabilityDecisionService {
    private LiabilityAnalysisService liabilityAnalysisService;
    private DateTimeHelper dateTimeHelper;
    private RavenLiabilityScorePublisherService ravenLiabilityScorePublisherService;
    private FeatureSwitches featureSwitches;
    private DigitalClaimFileService digitalClaimFileService;
    private LiabilitySummaryPdfGeneratorService liabilitySummaryPdfGeneratorService;
    private LiabilityAnalysisSummaryPdfService liabilityAnalysisSummaryPdfService;
    private GriffinService griffinService;
    private Validator validator;
    private FileNoteCreator fileNoteCreator;
    private NextGenComponentsServiceInterface nextGenComponentsServiceInterface;

    @AppFabricLog
    private AppFabricLogger logger;

    public LiabilityDecisionService(FileNoteCreator fileNoteCreator,
                                    NextGenComponentsServiceInterface nextGenComponentsServiceInterface,
                                    LiabilityAnalysisService liabilityAnalysisService,
                                    RavenLiabilityScorePublisherService ravenLiabilityScorePublisherService,
                                    DateTimeHelper dateTimeHelper,
                                    FeatureSwitches featureSwitches,
                                    DigitalClaimFileService digitalClaimFileService,
                                    GriffinService griffinService,
                                    LiabilitySummaryPdfGeneratorService liabilitySummaryPdfGeneratorService,
                                    LiabilityAnalysisSummaryPdfService liabilityAnalysisSummaryPdfService,
                                    Validator validator) {
        this.liabilityAnalysisService = liabilityAnalysisService;
        this.ravenLiabilityScorePublisherService = ravenLiabilityScorePublisherService;
        this.dateTimeHelper = dateTimeHelper;
        this.featureSwitches = featureSwitches;
        this.digitalClaimFileService = digitalClaimFileService;
        this.liabilitySummaryPdfGeneratorService = liabilitySummaryPdfGeneratorService;
        this.liabilityAnalysisSummaryPdfService = liabilityAnalysisSummaryPdfService;
        this.griffinService = griffinService;
        this.validator = validator;
        this.fileNoteCreator = fileNoteCreator;
        this.nextGenComponentsServiceInterface = nextGenComponentsServiceInterface;
    }

    public LiabilityAnalysisEntity submitInitialFault(SubmitLiabilityDecisionRequest submitLiabilityDecisionRequest) {
        LiabilityAnalysisEntity savedLiabilityAnalysisEntity;
        LiabilityAnalysisEntity submittedLiabilityAnalysisEntity = submitLiabilityDecisionRequest.getLiabilityAnalysisEntity();
        String insuredParticipantId;
        try {
            submittedLiabilityAnalysisEntity.setInitialFaultSubmitTime(dateTimeHelper.getCurrentDateTime());
            insuredParticipantId = submittedLiabilityAnalysisEntity.getLiabilitySubjects().stream().filter(p -> INSURED_CAPS.equals(p.getRole())).findFirst().get().getParticipantPartyId();

            createLiabilityRangeInTheEvents(submittedLiabilityAnalysisEntity.getEvents());

            submittedLiabilityAnalysisEntity.setApportionedInitialFault(griffinService.submitToGriffin(submittedLiabilityAnalysisEntity, true));

            if (featureSwitches.isSendLiabilityScoreOnSubmit()) {
                ravenLiabilityScorePublisherService.publishLiabilityScore(submittedLiabilityAnalysisEntity, false);
            }

            byte[] summaryPdf = liabilitySummaryPdfGeneratorService.generateSummaryPdf(submitLiabilityDecisionRequest);
            if (featureSwitches.isSaveSummaryDocOnSubmit()) {
                digitalClaimFileService.storeSummary(submittedLiabilityAnalysisEntity.getClaimNumber(), insuredParticipantId, summaryPdf);
            }
            if (featureSwitches.isOpenSummaryDocOnSuccess()) {
                liabilityAnalysisSummaryPdfService.save(
                        LiabilityAnalysisSummaryPdf.builder()
                                .claimNumber(submittedLiabilityAnalysisEntity.getClaimNumber())
                                .summaryPdf(summaryPdf)
                                .build()
                );
            }
            savedLiabilityAnalysisEntity = liabilityAnalysisService.save(submittedLiabilityAnalysisEntity);
            return savedLiabilityAnalysisEntity;
        } catch (SubmissionSystemErrorException | IllegalArgumentException ex) {
            throw ex;

        } catch (Exception ex) {
            logger.error(LOON_SERVER_EXCEPTION, ex, SYSTEM, "LiabilityDecisionService",
                    "submitLiabilityDecision",
                    LoggingResultType.FAILURE, ex.getMessage());
            throw new SubmissionSystemErrorException(ex);
        }
    }

    public LiabilityAnalysisEntity updateDamageApportionment(String claimNumber, Date apportionedAllocatedFaultSaveTime) throws Exception {
        LiabilityAnalysisEntity liabilityAnalysisEntityFromDb = liabilityAnalysisService.getLiabilityAnalysisData(validator.padClaimNumber(claimNumber));
        liabilityAnalysisEntityFromDb.setApportionedAllocatedFault(griffinService.submitToGriffin(liabilityAnalysisEntityFromDb, false));
        liabilityAnalysisEntityFromDb.setApportionedAllocatedFaultSaveTime(apportionedAllocatedFaultSaveTime);
        return liabilityAnalysisService.save(liabilityAnalysisEntityFromDb);
    }

    public void submitSettlement(String claimNumber) throws Exception {
        LiabilityAnalysisEntity liabilityAnalysisEntityFromDb = liabilityAnalysisService.getLiabilityAnalysisData(validator.padClaimNumber(claimNumber));

        if (featureSwitches.isSendLiabilityScoreOnSubmit()) {
            ravenLiabilityScorePublisherService.publishLiabilityScore(liabilityAnalysisEntityFromDb, true);
        }

        if (featureSwitches.isSubmitSettlementFileNote()) {
            FileNote fileNote = fileNoteCreator.createSubmitSettlementFileNote(liabilityAnalysisEntityFromDb);
            nextGenComponentsServiceInterface.publishFileNote(liabilityAnalysisEntityFromDb.getClaimNumber(), fileNote);
        }

        liabilityAnalysisEntityFromDb.setSettlementSubmitTime(dateTimeHelper.getCurrentDateTime());
        liabilityAnalysisService.save(liabilityAnalysisEntityFromDb);
    }

    private void createLiabilityRangeInTheEvents(List<Event> events) {
        for (Event event : events) {
            List<InvolvedParty> involvedParties = event.getInvolvedParties();
            for (InvolvedParty involvedParty : involvedParties) {
                List<AffectedParty> affectedParties = involvedParty.getAffectedParties();
                for (AffectedParty affectedParty : affectedParties) {
                    affectedParty.setSubmittedInitialFaultPercent(affectedParty.getInitialFaultPercent());
                    switch (affectedParty.getSubmittedInitialFaultPercent()) {
                        case 0:
                            affectedParty.setBeginNegotiatingRange(0);
                            affectedParty.setEndNegotiatingRange(0);
                            break;
                        case 100:
                            affectedParty.setBeginNegotiatingRange(100);
                            affectedParty.setEndNegotiatingRange(100);
                            break;
                        default:
                            affectedParty.setBeginNegotiatingRange(Math.max(affectedParty.getSubmittedInitialFaultPercent() - 5, 0));
                            affectedParty.setEndNegotiatingRange(Math.min(affectedParty.getSubmittedInitialFaultPercent() + 5, 100));
                            break;
                    }
                }
            }
        }
    }
}
