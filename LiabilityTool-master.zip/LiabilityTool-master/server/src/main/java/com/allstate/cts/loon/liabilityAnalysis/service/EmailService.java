package com.allstate.cts.loon.liabilityAnalysis.service;

import com.allstate.cts.loon.startup.service.UserService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.lang.String.format;
import static java.util.TimeZone.getTimeZone;

@Service
public class EmailService {
    private UserService userService;
    private JavaMailSender javaMailSender;
    private String to;
    private String from;
    private MimeMessageHelper helper;

    private static Map<String, String> pciCategoryCodeLabel = new HashMap<>();

    static {
        pciCategoryCodeLabel.put("creditCardNumber", "Credit Card/Debit Card Number");
        pciCategoryCodeLabel.put("socialSecurityNumber", "Social Security Number");
        pciCategoryCodeLabel.put("driversLicense", "Driver's License Number");
    }

    public EmailService(UserService userService, JavaMailSender javaMailSender, @Value("${email.from}") String from, @Value("${email.to}") String to) {
        this.userService = userService;
        this.javaMailSender = javaMailSender;
        this.from = from;
        this.to = to;
    }

    public void reportSensitiveTranscript(String claimNumber, String sourceVoiceId, String transcriptId, List<String> pciCategories) throws MessagingException {
        SimpleDateFormat date = new SimpleDateFormat("MM/dd/yyyy");
        date.setTimeZone(getTimeZone("America/Chicago"));
        SimpleDateFormat time = new SimpleDateFormat("HH:mm");
        time.setTimeZone(getTimeZone("America/Chicago"));
        String body = format("Loon User %s has marked following transcript for sensitive information on %s at %s (CST):<br/>"
                + "Claim Number: %s<br/>"
                + "Transcript ID: %s<br/>"
                + "Voice ID: %s<br/>"
                + "PCI Categories: ", userService.getUserName(), date.format(new Date()), time.format(new Date()), claimNumber, transcriptId, sourceVoiceId);

        for (int i = 0; i < pciCategories.size(); i++) {
            body += pciCategoryCodeLabel.get(pciCategories.get(i)) + (i != pciCategories.size() - 1 ? ", " : "");
        }
        createAndSendEmail(format("Redact Request from Loon - Claim #%s", claimNumber), body);
    }

    private void createAndSendEmail(String subject, String body) throws MessagingException {
        MimeMessage message = javaMailSender.createMimeMessage();
        helper = new MimeMessageHelper(message, true);
        helper.setFrom(new InternetAddress(from));
        helper.setTo(to.split(";"));
        helper.setSubject(subject);
        helper.setText(body, true);

        javaMailSender.send(message);
    }
}
