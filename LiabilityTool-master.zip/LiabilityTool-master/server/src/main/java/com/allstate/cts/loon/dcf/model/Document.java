package com.allstate.cts.loon.dcf.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import static java.util.Objects.nonNull;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Document {

    @Builder.Default
    private String mimetype = "";

    public void setMimetype(String mimetype) {
        this.mimetype = nonNull(mimetype) ? mimetype : "";
    }
}