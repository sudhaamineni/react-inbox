package com.allstate.cts.loon.configuration;

import com.allstate.cts.loon.LiabilityToolApplication;
import com.allstate.cts.loon.eligibility.model.FNOLClaimData;
import com.allstate.cts.loon.exception.KafkaProducerConfigException;
import com.allstate.cts.loon.helpers.CipherWrapper;
import com.allstate.cts.loon.helpers.FileUtilsWrapper;
import com.compozed.appfabric.logging.AppFabricLogger;
import com.compozed.appfabric.logging.annotations.AppFabricLog;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.serialization.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.*;
import org.springframework.kafka.support.serializer.JsonSerializer;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;

import static com.allstate.cts.loon.constants.LoonConstants.LOON_SERVER_EXCEPTION;
import static com.allstate.cts.loon.utils.ErrorConstants.KAFKA_CONSUMER_CONFIG_INTERNAL_ERROR;
import static com.compozed.appfabric.logging.LoggingEventType.SYSTEM;
import static com.compozed.appfabric.logging.LoggingResultType.FAILURE;
import static org.springframework.kafka.listener.ContainerProperties.AckMode.MANUAL;

public class KafkaConfig {
    private static String KRB5_CONF_PROPERTY = "java.security.krb5.conf";
    private static String AUTH_LOGIN_CONFIG_PROPERTY = "java.security.auth.login.config";
    private static String AUTH_SUBJECT_CREDS_PROPERTY = "javax.security.auth.useSubjectCredsOnly";

    @Value("${looneligibility.encryption.key}")
    String encryptionKey;

    @Value("${looneligibility.encryption.keytab-file}")
    String keytabFile;

    @Value("${kerberos.config}")
    String kerberosConfig;

    @Value("${kerberos.auth}")
    String authJaas;

    @Autowired
    private KafkaProperties kafkaProperties;

    @Autowired
    FileUtilsWrapper fileUtilsWrapper;

    @Autowired
    CipherWrapper cipherWrapper;

    @AppFabricLog
    private AppFabricLogger logger;


    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, byte[]> kafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, byte[]> factory =
                new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConcurrency(1);
        factory.getContainerProperties().setAckMode(MANUAL);
        factory.setConsumerFactory(consumerFactory());
        return factory;
    }

    @Bean
    public ProducerFactory<Integer, FNOLClaimData> producerFactory() throws IOException, KafkaProducerConfigException {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    @Bean
    public KafkaTemplate<Integer, FNOLClaimData> kafkaTemplate() throws IOException, KafkaProducerConfigException {
        return new KafkaTemplate<>(producerFactory());
    }

    @Bean
    public Map<String, Object> producerConfigs() throws IOException, KafkaProducerConfigException {
        configureKerberos();

        Map<String, Object> props = new HashMap<>();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaProperties.getBootstrap());
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
        props.put(ProducerConfig.MAX_BLOCK_MS_CONFIG, "3000");
        props.put("security.protocol", "SASL_PLAINTEXT");
        props.put("sasl.kerberos.service.name", "kafka");
        props.put(SaslConfigs.SASL_MECHANISM, SaslConfigs.GSSAPI_MECHANISM);

        return props;
    }

    public void configureKerberos() throws IOException, KafkaProducerConfigException {
        System.setProperty(KRB5_CONF_PROPERTY, kerberosConfig);
        System.setProperty(AUTH_LOGIN_CONFIG_PROPERTY, authJaas);
        System.setProperty(AUTH_SUBJECT_CREDS_PROPERTY, "false");

        ClassLoader classLoader = LiabilityToolApplication.class.getClassLoader();

        String configFile = System.getProperty(AUTH_LOGIN_CONFIG_PROPERTY);
        URL configUrl = classLoader.getResource(configFile);
        System.setProperty(AUTH_LOGIN_CONFIG_PROPERTY, configUrl.toExternalForm());

        String krb5ConfConfigFile = System.getProperty(KRB5_CONF_PROPERTY);
        URL krb5ConfUrl = classLoader.getResource(krb5ConfConfigFile);
        File krb5ConfDest = new File("/tmp/krb5.conf");
        fileUtilsWrapper.copyURLToFile(krb5ConfUrl, krb5ConfDest);


        URL encryptedUrl = classLoader.getResource("kafka-kerberos/" + keytabFile);
        File encryptedDest = new File("/tmp/feeder_enc.keytab");
        fileUtilsWrapper.copyURLToFile(encryptedUrl, encryptedDest);


        File actualDest = new File("/tmp/rtalab_feeder_nonprod.keytab");
        fileUtilsWrapper.writeByteArrayToFile(actualDest, decryptFile(encryptedDest));

        System.setProperty(KRB5_CONF_PROPERTY, "/tmp/krb5.conf");
    }

    @Bean
    public ConsumerFactory<String, byte[]> consumerFactory() {
        return new DefaultKafkaConsumerFactory<>(consumerProps(), stringKeyDeserializer(), byteArrayDeserializer());
    }

    @Bean
    public Map<String, Object> consumerProps() {
        Map<String, Object> props = new HashMap<>();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaProperties.getBootstrap());
        props.put(ConsumerConfig.GROUP_ID_CONFIG, kafkaProperties.getGroup());
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
        props.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, "100");
        props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, "15000");
        props.put("security.protocol", "SASL_PLAINTEXT");
        props.put("sasl.kerberos.service.name", "kafka");
        props.put(SaslConfigs.SASL_MECHANISM, SaslConfigs.GSSAPI_MECHANISM);
        return props;
    }

    @Bean
    public Deserializer byteArrayDeserializer() {
        return new ByteArrayDeserializer();
    }

    @Bean
    public Deserializer stringKeyDeserializer() {
        return new StringDeserializer();
    }

    @Bean
    Serializer<FNOLClaimData> jsonSerializer() {
        return new JsonSerializer<>();
    }

    public byte[] decryptFile(File file) throws KafkaProducerConfigException {
        try {
            byte[] encrypted = fileUtilsWrapper.readFileToByteArray(file);
            Key aesKey = new SecretKeySpec(encryptionKey.getBytes(), "AES");
            cipherWrapper.init(Cipher.DECRYPT_MODE, aesKey);
            return cipherWrapper.doFinal(encrypted);
        } catch (Exception ex) {
            logger.error(LOON_SERVER_EXCEPTION, ex, SYSTEM, KAFKA_CONSUMER_CONFIG_INTERNAL_ERROR,
                    "KafkaConfig.decryptFile", FAILURE, ex.getMessage());
            throw new KafkaProducerConfigException(ex);
        }
    }
}