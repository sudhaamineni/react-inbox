package com.allstate.cts.loon.mongobee;

import com.github.mongobee.changeset.ChangeLog;
import com.github.mongobee.changeset.ChangeSet;
import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.IndexOptions;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

@ChangeLog(order = "001")
public class MongobeeScripts {
    @Autowired
    MongoDatabase mongoDatabase;

    private static final String LIABILITY_ANALYSIS_COLLECTION = "LiabilityAnalysis";
    private static final String LIABILITY_ANALYSIS_HISTORY_COLLECTION = "LiabilityAnalysisHistory";
    private static final String LIABILITY_ANALYSIS_SUMMARY_PDF_COLLECTION = "LiabilityAnalysisSummaryPdf";

    private static final String CLAIM_NUMBER_FIELD = "claimNumber";
    private static final String ASSIGNED_USER_FIELD = "assignedUser";
    private static final String INITIAL_FAULT_SUBMIT_TIME = "initialFaultSubmitTime";
    private static final String CREATED_TIME = "createdTime";

    @ChangeSet(order = "001", id = "createInitialCollections", author = "loon")
    public void createInitialCollections(MongoDatabase db) {
        List<String> collections = getCollections(db);
        if (!collections.contains(LIABILITY_ANALYSIS_COLLECTION)) {
            db.createCollection(LIABILITY_ANALYSIS_COLLECTION);
        }
        if (!collections.contains(LIABILITY_ANALYSIS_HISTORY_COLLECTION)) {
            db.createCollection(LIABILITY_ANALYSIS_HISTORY_COLLECTION);
        }
        if (!collections.contains(LIABILITY_ANALYSIS_SUMMARY_PDF_COLLECTION)) {
            db.createCollection(LIABILITY_ANALYSIS_SUMMARY_PDF_COLLECTION);
        }
    }

    private List<String> getCollections(MongoDatabase db) {
        List<String> collections = new ArrayList<>();
        for (String collection : db.listCollectionNames()) {
            collections.add(collection);
        }
        return collections;
    }

    @ChangeSet(order = "002", id = "createInitialIndexes", author = "loon")
    public void createInitialIndexes(MongoDatabase db) {
        createBackgroundIndex(db, LIABILITY_ANALYSIS_COLLECTION, CLAIM_NUMBER_FIELD, CLAIM_NUMBER_FIELD, 1, true);
        createBackgroundIndex(db, LIABILITY_ANALYSIS_COLLECTION, ASSIGNED_USER_FIELD, ASSIGNED_USER_FIELD, 1, false);
        createBackgroundIndex(db, LIABILITY_ANALYSIS_HISTORY_COLLECTION, CLAIM_NUMBER_FIELD, CLAIM_NUMBER_FIELD, 1, false);
        createBackgroundIndex(db, LIABILITY_ANALYSIS_SUMMARY_PDF_COLLECTION, CLAIM_NUMBER_FIELD, CLAIM_NUMBER_FIELD, 1, true);
    }

    @ChangeSet(order = "003", id = "createInitialIndexes_003", author = "loon")
    public void createInitialIndexes_003(MongoDatabase db) {
        createBackgroundIndex(db, LIABILITY_ANALYSIS_COLLECTION, INITIAL_FAULT_SUBMIT_TIME, INITIAL_FAULT_SUBMIT_TIME, 1, false);
        createBackgroundIndex(db, LIABILITY_ANALYSIS_COLLECTION, CREATED_TIME, CREATED_TIME, 1, false);
    }

    private void createBackgroundIndex(MongoDatabase db, String collectionName, String fieldName, String indexName, int indexOrder, boolean isUnique) {
        MongoCollection loonCollection = db.getCollection(collectionName);
        IndexOptions indexOptions = new IndexOptions();
        indexOptions.background(true);
        indexOptions.name(indexName);
        indexOptions.unique(isUnique);
        loonCollection.createIndex(new BasicDBObject(fieldName, indexOrder), indexOptions);
    }
}
