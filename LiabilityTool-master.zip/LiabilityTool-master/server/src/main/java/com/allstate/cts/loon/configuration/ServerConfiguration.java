package com.allstate.cts.loon.configuration;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Configuration
@ConfigurationProperties(prefix = "spring.data.mongodb")
public class ServerConfiguration {
    private List<Server> server;

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < server.size(); i++) {
            sb.append(server.get(i).toString());
            if (i != server.size() - 1)
                sb.append(",");
        }
        return sb.toString();
    }

    @NoArgsConstructor
    @AllArgsConstructor
    @Data
    public static class Server {
        private String host;
        private int port;

        @Override
        public String toString() {
            return host + ":" + port;
        }
    }
}