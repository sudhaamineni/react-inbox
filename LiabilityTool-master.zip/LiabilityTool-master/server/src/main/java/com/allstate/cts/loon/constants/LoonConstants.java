package com.allstate.cts.loon.constants;

public class LoonConstants {
    public static final String SYSTEM_NAME = "Loon";
    public static final String ALLSTATE_BRANDNAME = "ALL";

    public static final String SAVED = "SAVED";
    public static final String READY_FOR_ASSIGNMENT = "READY_FOR_ASSIGNMENT";
    public static final String ASSIGNED = "ASSIGNED";
    public static final String IN_PROGRESS = "IN_PROGRESS";

    public static final String INSURED_CAPS = "INSURED";
    public static final String CLAIMANT_CAPS = "CLAIMANT";
    public static final String PED_BIKE_CAPS = "PEDESTRIAN/BICYCLIST";
    public static final String PASSENGER_CAPS = "PASSENGER";

    public static final String INSD_HIT_A_FIXED_OBJECT = "14";
    public static final String INSD_HIT_PARKED_PART = "19";
    public static final String PART_HIT_PARKED_INSD = "20";
    public static final String PART_REARENDED_INSD = "23";
    public static final String DROVE_INTO_STANDING_WATER = "08";
    public static final String DRIVER_ASSAULT_CAR_JACK = "45";
    public static final String INJURED_ENTERING_EXITING = "49";
    public static final String INJURED_LOAD_UNLOAD_ASSET = "50";
    public static final String INSD_REAR_ENDED_PART = "21";

    public static final String CLAIMANT_CODE = "CMT";
    public static final String OWNER_CODE = "OWNR";
    public static final String DRIVER_CODE = "DRVR";
    public static final String PEDESTRIAN_BICYCLIST_CODE = "PEDBI";
    public static final String PASSENGER = "PASS";
    public static final String INSURED_CODE = "PIN";
    public static final String AUTO_PERSONAL_CODE = "LB01";
    public static final String SENSITIVE = "Sensitive";

    public static final String LOON_SERVER_WARNING = "LOON_SERVER_WARNING";
    public static final String LOON_SERVER_EXCEPTION = "LOON_SERVER_EXCEPTION";
    public static final String LOON_SERVER_INFO = "LOON_SERVER_INFO";
    public static final String EMPTY = "";
    public static final String DCF_PDF_DOC_TYPE_CODE = "2025";

    private LoonConstants() {
    }
}