package com.allstate.cts.loon.highlight.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HighlightEntity {

    @Field("id")
    private String id;
    private List<HighlightText> highlightTexts;
    private Double audioHighlightTimeStart;
}
