package com.allstate.cts.loon.claimData.service;

import com.allstate.cts.loon.claimData.model.ClaimData;

public interface ClaimDataRetrieverServiceInterface {

    ClaimData getClaimData(String claimNumber, String uriVariables) ;
}
