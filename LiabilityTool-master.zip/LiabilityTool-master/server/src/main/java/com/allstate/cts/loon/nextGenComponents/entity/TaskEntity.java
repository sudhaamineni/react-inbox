package com.allstate.cts.loon.nextGenComponents.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaskEntity {

    private String taskId;
    private String performerId;
    private Date createdDateTime;
}