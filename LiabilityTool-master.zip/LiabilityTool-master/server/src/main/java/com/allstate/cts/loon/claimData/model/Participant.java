package com.allstate.cts.loon.claimData.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

import static com.allstate.cts.loon.constants.LoonConstants.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Participant {
    private String legacyInvolvedId;
    private String insInvolvementId;
    private Client client;

    @Builder.Default
    private List<InvolvementRole> involvementRole = new ArrayList<>();

    @Builder.Default
    private List<Liabilities> liabilities = new ArrayList<>();

    public boolean isClaimantAndOwner() {
        return involvementRole.stream().anyMatch(role -> role.getInvolvementRole().equals(CLAIMANT_CODE)) &&
                involvementRole.stream().anyMatch(role -> role.getInvolvementRole().equals(OWNER_CODE));
    }

    public boolean isDriver() {
        return involvementRole.stream().anyMatch(role -> role.getInvolvementRole().equals(DRIVER_CODE));
    }

    public boolean isPedestrianBicyclist() {
        return involvementRole.stream().anyMatch(role -> role.getInvolvementRole().equals(PEDESTRIAN_BICYCLIST_CODE));
    }

    private boolean isPassenger() {
        return involvementRole.stream().anyMatch(role -> role.getInvolvementRole().equals(PASSENGER));
    }

    public boolean isInsured() {
        return involvementRole.stream().anyMatch(role -> role.getInvolvementRole().equals(INSURED_CODE));
    }

    public String getRole() {
        if (isInsured()) {
            return INSURED_CAPS;
        } else if (isPedestrianBicyclist()) {
            return PED_BIKE_CAPS;
        } else if (isPassenger()) {
            return PASSENGER_CAPS;
        }
        return getClaimantRole();
    }

    private String getClaimantRole() {
        return isClaimantAndOwner() ? CLAIMANT_CAPS : null;
    }
}