package com.allstate.cts.loon.exception;

public class UnauthorizedClaimException extends RuntimeException implements CustomException {
    private final String msgHeader;
    private final String msgDescription;

    public UnauthorizedClaimException() {
        this.msgHeader = "Unauthorized";
        this.msgDescription = "You do not have access to this claim";
    }

    @Override
    public String getMessageHeader() {
        return this.msgHeader;
    }

    @Override
    public String getMessageDescription() {
        return this.msgDescription;
    }
}
