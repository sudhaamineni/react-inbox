package com.allstate.cts.loon.helpers;

import org.springframework.stereotype.Component;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;

@Component
public class CipherWrapper {
    public static final String AES_CBC_PKCS5_PADDING = "AES/CBC/PKCS5Padding";
    private Cipher aesInstance;

    public CipherWrapper() throws NoSuchPaddingException, NoSuchAlgorithmException {
        aesInstance = Cipher.getInstance(AES_CBC_PKCS5_PADDING);
    }

    public void init(int mode, Key key) throws InvalidKeyException, InvalidAlgorithmParameterException {
        byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        IvParameterSpec ivspec = new IvParameterSpec(iv);
        aesInstance.init(mode, key, ivspec);
    }

    public byte[] doFinal(byte[] encryptedData) throws BadPaddingException, IllegalBlockSizeException {
        return aesInstance.doFinal(encryptedData);
    }
}
