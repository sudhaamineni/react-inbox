package com.allstate.cts.loon.exception;

public class ClaimNotFoundException extends RuntimeException implements CustomException {
    private final String msgHeader;
    private final String msgDescription;

    public ClaimNotFoundException(String claimNumber) {
        this.msgHeader ="No Results for Claim #" + claimNumber;
        this.msgDescription = "We were unable to find this claim number. Please check and try again.";
    }

    @Override
    public String getMessageHeader() {
        return this.msgHeader;
    }

    @Override
    public String getMessageDescription() { return this.msgDescription; }
}
