package com.allstate.cts.loon.exception;

import org.springframework.http.HttpStatus;

public class KafkaProducerConfigException extends LoonEligibilityException {
    public KafkaProducerConfigException(Throwable ex) {
        super(HttpStatus.INTERNAL_SERVER_ERROR, false, ex.getMessage(), ex);
    }
}