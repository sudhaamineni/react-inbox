package com.allstate.cts.loon.eligibility.service;

import com.allstate.cts.loon.eligibility.model.FNOLClaimData;
import com.allstate.cts.loon.exception.LoonInvalidMessageException;
import com.allstate.cts.loon.helpers.DateTimeHelper;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

@Service
public class KafkaFNOLConsumer {
    private DateTimeHelper dateTimeHelper;
    private EligibilityService eligibilityService;

    public KafkaFNOLConsumer(DateTimeHelper dateTimeHelper,
                             EligibilityService eligibilityService
    ) {
        this.dateTimeHelper = dateTimeHelper;
        this.eligibilityService = eligibilityService;
    }

    public void onReceiving(byte[] entry, Acknowledgment ack) {

        String entryString = new String(entry, StandardCharsets.UTF_8);

        try {
            FNOLClaimData fnolClaimData = getFNOLClaimDataFromMessage(entryString);

            eligibilityService.processClaim(fnolClaimData);
            ack.acknowledge();

        } catch (LoonInvalidMessageException ex) {
            ex.printStackTrace();
            ack.acknowledge();
            return;
        } catch (Exception ex) {
            ex.printStackTrace();
            return;
        }

    }

    protected FNOLClaimData getFNOLClaimDataFromMessage(String entryString) throws LoonInvalidMessageException, IOException {
        FNOLClaimData fnolClaimData;
        JsonParser jsonParser = null;
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            JsonFactory jsonFactory = objectMapper.getFactory();
            jsonParser = jsonFactory.createParser(entryString);
            fnolClaimData = jsonParser.readValueAs(FNOLClaimData.class);
        } catch (IOException parserException) {
            throw new LoonInvalidMessageException("Deserialization of kafka message into FNOLClaimData failed", parserException);
        } finally {
            if (jsonParser != null) {
                jsonParser.close();
            }
        }
        fnolClaimData.setCreatedDate(dateTimeHelper.getCurrentDateTime());

        return fnolClaimData;
    }
}