package com.allstate.cts.loon.exception;

import lombok.Data;

@Data
public class ApiError {
    private String messageHeader;
    private String messageDescription;
    private String newClaimNumber;

    public ApiError (String messageHeader, String messageDescription) {
        this.messageHeader = messageHeader;
        this.messageDescription = messageDescription;
    }

    public ApiError (String messageHeader, String messageDescription, String newClaimNumber){
        this.messageHeader = messageHeader;
        this.messageDescription = messageDescription;
        this.newClaimNumber = newClaimNumber;
    }
}
