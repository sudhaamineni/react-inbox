package com.allstate.cts.loon.nextGenComponents.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AddTaskRequest {
    String TaskTargetID;
    String TaskName;
    String TaskDueDate;
    String TaskStatus;
    String TaskPriority;
    Date TaskDisplayDate;
    String TaskSource;
    String TaskType;
    Boolean TaskMandatoryIndicator;
    String TaskAutomaticInd;
    String TaskAssnID;
    String TaskAssnType;
    String TaskClaimID;
    String TaskTemplateID;
    String TaskPerfID;
    String TaskOEID;
    String TaskDesc;
    String TaskSecondaryStatus;
    String TaskURLLink;
}
