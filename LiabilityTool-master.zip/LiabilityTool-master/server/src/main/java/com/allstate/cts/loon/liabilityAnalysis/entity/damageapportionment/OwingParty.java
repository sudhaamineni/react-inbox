package com.allstate.cts.loon.liabilityAnalysis.entity.damageapportionment;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OwingParty {
    private String participantId;

    @Builder.Default
    private List<CollectingParty> collectingParties = new ArrayList<>();
}