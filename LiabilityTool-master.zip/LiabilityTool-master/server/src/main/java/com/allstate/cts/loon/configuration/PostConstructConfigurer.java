package com.allstate.cts.loon.configuration;

import com.mongodb.WriteConcern;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Component;

@Component
public class PostConstructConfigurer {

    @Value("${spring.data.mongodb.writeConcern}")
    private String writeConcern;
    private MongoTemplate mongoTemplate;

    public PostConstructConfigurer(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    public void configure() {
        mongoTemplate.setWriteConcern(writeConcern.equals("1") ? WriteConcern.W1 : WriteConcern.W2);
    }
}