package com.allstate.cts.loon.admin.service;

import com.allstate.cts.loon.assignment.service.AssignmentService;
import com.allstate.cts.loon.configuration.FeatureSwitches;
import com.allstate.cts.loon.eligibility.model.FNOLContext;
import com.allstate.cts.loon.eligibility.service.KafkaAutomatedLiabilityProducerService;
import com.allstate.cts.loon.exception.SystemErrorException;
import com.allstate.cts.loon.helpers.Validator;
import com.allstate.cts.loon.liabilityAnalysis.entity.LiabilityAnalysisEntity;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

import static org.springframework.data.mongodb.core.query.Criteria.where;

@Service
public class AdminService {
    private final MongoTemplate mongoTemplate;
    private final KafkaAutomatedLiabilityProducerService kafkaAutomatedLiabilityProducerService;
    private final AssignmentService assignmentService;
    private final Validator validator;
    private final FeatureSwitches featureSwitches;

    public AdminService(MongoTemplate mongoTemplate,
                        KafkaAutomatedLiabilityProducerService kafkaAutomatedLiabilityProducerService,
                        AssignmentService assignmentService,
                        Validator validator,
                        FeatureSwitches featureSwitches) {
        this.mongoTemplate = mongoTemplate;
        this.kafkaAutomatedLiabilityProducerService = kafkaAutomatedLiabilityProducerService;
        this.assignmentService = assignmentService;
        this.validator = validator;
        this.featureSwitches = featureSwitches;
    }

    public void insertAssignmentClaimList(List<String> claimNumberList, Boolean clearQueue, Boolean useKafka) {

        checkFeatureSwitch();

        if (clearQueue) {
            clearAssignmentQueue();
        }

        List<String> paddedClaimNumberList = new ArrayList<>();
        if (claimNumberList != null) {
            paddedClaimNumberList = claimNumberList.stream().map(validator:: padClaimNumber).collect(Collectors.toList());
        }
        deleteClaimListFromAssignmentQueue(paddedClaimNumberList);

        paddedClaimNumberList.stream().forEach(claimNumber -> {

            if (useKafka) {
                try {
                    publishAssignmentToKafka(claimNumber);
                } catch (Exception ex) {
                    throw new SystemErrorException();
                }
            } else
                assignmentService.createAssignment(claimNumber);
        });
    }

    protected void clearAssignmentQueue() {
        checkFeatureSwitch();

        Query query = new Query()
                .addCriteria(where("assignedTime")
                        .is(null))
                .addCriteria(where("isComplex")
                        .is(true));
        mongoTemplate.findAllAndRemove(query, LiabilityAnalysisEntity.class);
    }

    protected void deleteClaimListFromAssignmentQueue(List<String> claimNumberList) {
        checkFeatureSwitch();
        Query query = new Query()
                .addCriteria(where("claimNumber")
                        .in(claimNumberList));

        mongoTemplate.findAllAndRemove(query, LiabilityAnalysisEntity.class);
    }

    public void publishAssignmentToKafka(String claimNumber) throws InterruptedException, ExecutionException, JsonProcessingException {
        checkFeatureSwitch();
        FNOLContext fnolContext = FNOLContext.builder()
                .claimNumber(claimNumber)
                .lineOfBusiness("Auto - Personal")
                .build();
        kafkaAutomatedLiabilityProducerService.publishFNOLToKafka(fnolContext);
    }

    private void checkFeatureSwitch() {
        if (!featureSwitches.isEnableAdmin()) {
            throw new UnsupportedOperationException("Feature is not enabled");
        }
    }
}