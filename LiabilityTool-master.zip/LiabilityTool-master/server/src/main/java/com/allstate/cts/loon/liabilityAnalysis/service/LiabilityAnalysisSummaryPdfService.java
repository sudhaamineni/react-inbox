package com.allstate.cts.loon.liabilityAnalysis.service;

import com.allstate.cts.loon.liabilityAnalysis.entity.LiabilityAnalysisSummaryPdf;
import com.allstate.cts.loon.liabilityAnalysis.repository.LiabilityAnalysisSummaryPdfRepository;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.util.Date;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Update.update;

@Service
public class LiabilityAnalysisSummaryPdfService {
    private MongoTemplate mongoTemplate;
    private LiabilityAnalysisSummaryPdfRepository liabilityAnalysisSummaryPdfRepository;

    public LiabilityAnalysisSummaryPdfService(MongoTemplate mongoTemplate, LiabilityAnalysisSummaryPdfRepository liabilityAnalysisSummaryPdfRepository) {
        this.mongoTemplate = mongoTemplate;
        this.liabilityAnalysisSummaryPdfRepository = liabilityAnalysisSummaryPdfRepository;
    }

    public void save(LiabilityAnalysisSummaryPdf liabilityAnalysisSummaryPdf) {
        Query query = new Query().addCriteria(where("claimNumber").is(liabilityAnalysisSummaryPdf.getClaimNumber()));

        Update update = update("updatedTime", new Date());
        update.set("summaryPdf", liabilityAnalysisSummaryPdf.getSummaryPdf());

        FindAndModifyOptions options = new FindAndModifyOptions().upsert(true);

        mongoTemplate.findAndModify(query, update, options, LiabilityAnalysisSummaryPdf.class);
    }

    public byte[] getSummaryPdf(String claimNumber) {
        return liabilityAnalysisSummaryPdfRepository.findByClaimNumber(claimNumber).get().getSummaryPdf();
    }
}
