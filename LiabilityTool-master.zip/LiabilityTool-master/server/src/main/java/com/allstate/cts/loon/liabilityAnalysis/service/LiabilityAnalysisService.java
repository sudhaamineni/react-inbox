package com.allstate.cts.loon.liabilityAnalysis.service;

import com.allstate.cts.loon.exception.ClaimNotFoundException;
import com.allstate.cts.loon.exception.InvalidUnlockReasonDescriptionException;
import com.allstate.cts.loon.exception.SystemErrorException;
import com.allstate.cts.loon.helpers.DateTimeHelper;
import com.allstate.cts.loon.liabilityAnalysis.entity.*;
import com.allstate.cts.loon.liabilityAnalysis.model.SaveHighlightRequest;
import com.allstate.cts.loon.liabilityAnalysis.model.SavePhotoAttachmentRequest;
import com.allstate.cts.loon.liabilityAnalysis.repository.LiabilityAnalysisRepository;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import javax.mail.MessagingException;
import java.util.*;
import java.util.stream.Collectors;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Update.update;
import static org.springframework.util.ObjectUtils.isEmpty;

@Service
public class LiabilityAnalysisService {
    private LiabilityAnalysisRepository liabilityAnalysisRepository;
    private LiabilityAnalysisHistoryService liabilityAnalysisHistoryService;
    private DateTimeHelper dateTimeHelper;
    private MongoTemplate mongoTemplate;
    private EmailService emailService;

    public LiabilityAnalysisService(LiabilityAnalysisRepository liabilityAnalysisRepository,
                                    LiabilityAnalysisHistoryService liabilityAnalysisHistoryService,
                                    DateTimeHelper dateTimeHelper,
                                    MongoTemplate mongoTemplate,
                                    EmailService emailService
    ) {
        this.liabilityAnalysisHistoryService = liabilityAnalysisHistoryService;
        this.liabilityAnalysisRepository = liabilityAnalysisRepository;
        this.dateTimeHelper = dateTimeHelper;
        this.mongoTemplate = mongoTemplate;
        this.emailService = emailService;
    }

    public LiabilityAnalysisEntity save(LiabilityAnalysisEntity liabilityAnalysisEntity) {
        if (liabilityAnalysisEntity.getCreatedTime() == null) {
            liabilityAnalysisEntity.setCreatedTime(dateTimeHelper.getCurrentDateTime());
        }

        liabilityAnalysisEntity.setUpdatedTime(dateTimeHelper.getCurrentDateTime());
        try {
            liabilityAnalysisEntity = liabilityAnalysisRepository.save(liabilityAnalysisEntity);
            liabilityAnalysisHistoryService.save(liabilityAnalysisEntity);
        } catch (Exception e) {
            throw new SystemErrorException();
        }
        return liabilityAnalysisEntity;
    }

    public LiabilityAnalysisEntity getLiabilityAnalysisData(String claimNumber) {
        Optional<LiabilityAnalysisEntity> liabilityAnalysisEntityFromDb = liabilityAnalysisRepository.findByClaimNumber(claimNumber);
        if (!liabilityAnalysisEntityFromDb.isPresent()) {
            throw new ClaimNotFoundException(claimNumber);
        }
        return liabilityAnalysisEntityFromDb.get();
    }

    public Optional<LiabilityAnalysisEntity> findLiabilityAnalysisData(String claimNumber) {
        return liabilityAnalysisRepository.findByClaimNumber(claimNumber);
    }

    public LiabilityAnalysisEntity updateParticipant(LiabilitySubject participantToSave, String claimNumber) {
        LiabilityAnalysisEntity liabilityAnalysisEntity;
        Optional<LiabilityAnalysisEntity> getLiabilityAnalysisEntity = liabilityAnalysisRepository.findByClaimNumber(claimNumber);
        if (getLiabilityAnalysisEntity.isPresent()) {
            liabilityAnalysisEntity = getLiabilityAnalysisEntity.get();
        } else {
            throw new SystemErrorException();
        }

        List<LiabilitySubject> newParticipantList = liabilityAnalysisEntity.getLiabilitySubjects().stream().map(
                participant -> participantToSave.getParticipantSourceId().equalsIgnoreCase(participant.getParticipantSourceId()) ? participantToSave : participant
        ).collect(Collectors.toList());

        liabilityAnalysisEntity.setLiabilitySubjects(newParticipantList);
        return save(liabilityAnalysisEntity);
    }

    private void upsert(String claimNumber, Map<String, Object> fields) {
        Query query = new Query().addCriteria(where("claimNumber").is(claimNumber));

        Update update = update("updatedTime", new Date());
        fields.forEach(update::set);

        FindAndModifyOptions options = new FindAndModifyOptions().returnNew(true).upsert(true);

        LiabilityAnalysisEntity result = mongoTemplate.findAndModify(query, update, options, LiabilityAnalysisEntity.class);
        liabilityAnalysisHistoryService.save(result);
    }

    public void saveSketch(String claimNumber, Sketch sketch) {
        Map<String, Object> fields = new HashMap<>();
        fields.put("sketch", sketch);
        upsert(claimNumber, fields);
    }

    public void saveLiabilitySubjects(String claimNumber, List<LiabilitySubject> liabilitySubjects) {
        Map<String, Object> fields = new HashMap<>();
        fields.put("liabilitySubjects", liabilitySubjects);
        upsert(claimNumber, fields);
    }

    public void saveVoiceAttachments(String claimNumber, List<VoiceAttachment> voiceAttachments, boolean resetClaimVoiceSynced) {
        Map<String, Object> fields = new HashMap<>();
        fields.put("voiceAttachments", voiceAttachments);
        fields.put("resetClaimVoiceSynced", resetClaimVoiceSynced);
        upsert(claimNumber, fields);
    }

    public void saveVoiceAttachments(String claimNumber, List<VoiceAttachment> voiceAttachments, List<Evidence> evidences) {
        Map<String, Object> fields = new HashMap<>();
        fields.put("voiceAttachments", voiceAttachments);
        fields.put("evidences", evidences);
        upsert(claimNumber, fields);
    }

    public void createEvent(String claimNumber, Event event) {
        Query query = new Query().addCriteria(where("claimNumber").is(claimNumber));

        Update update = update("updatedTime", new Date());
        update.push("events", event);

        FindAndModifyOptions options = new FindAndModifyOptions().returnNew(true);

        LiabilityAnalysisEntity result = mongoTemplate.findAndModify(query, update, options, LiabilityAnalysisEntity.class);
        liabilityAnalysisHistoryService.save(result);
    }

    public void updateEvent(String claimNumber, Event event) {
        Query query = new Query().addCriteria(
                where("claimNumber").is(claimNumber)
                        .and("events.id").is(event.getId())
        );

        Update update = update("updatedTime", new Date());
        update.set("events.$", event);

        FindAndModifyOptions options = new FindAndModifyOptions().returnNew(true);

        LiabilityAnalysisEntity result = mongoTemplate.findAndModify(query, update, options, LiabilityAnalysisEntity.class);
        liabilityAnalysisHistoryService.save(result);
    }

    public void removeEvent(String claimNumber, Event event) {
        Query query = new Query().addCriteria(where("claimNumber").is(claimNumber));

        Update update = update("updatedTime", new Date());
        update.pull("events", event);

        FindAndModifyOptions options = new FindAndModifyOptions().returnNew(true);

        LiabilityAnalysisEntity result = mongoTemplate.findAndModify(query, update, options, LiabilityAnalysisEntity.class);
        liabilityAnalysisHistoryService.save(result);
    }

    public void saveLossLocation(String claimNumber, Double latitude, Double longitude, String updatedLossLocation) {
        Map<String, Object> fields = new HashMap<>();
        fields.put("latitude", latitude);
        fields.put("longitude", longitude);
        fields.put("updatedLossLocation", updatedLossLocation);
        upsert(claimNumber, fields);
    }

    public void saveFaultAllocationIndicators(String claimNumber, boolean noAgreement, boolean noResponse) {
        Map<String, Object> fields = new HashMap<>();
        fields.put("noFaultAllocationAgreement", noAgreement);
        fields.put("noFaultAllocationResponse", noResponse);
        upsert(claimNumber, fields);
    }

    public void saveClaimUnlock(String claimNumber, String reason, String description) throws InvalidUnlockReasonDescriptionException {
        if (reason.equals("other") && isEmpty(description)) {
            throw new InvalidUnlockReasonDescriptionException(claimNumber, reason, description);
        }
        Map<String, Object> fields = new HashMap<>();
        fields.put("locked", false);
        fields.put("unlockReason", reason);
        fields.put("unlockDescription", description);
        upsert(claimNumber, fields);
    }

    public void saveHighlights(String claimNumber, String voiceId, SaveHighlightRequest saveHighlightRequest) {
        Query query = new Query().addCriteria(
                where("claimNumber").is(claimNumber)
                        .and("voiceAttachments.sourceVoiceId").is(voiceId)
        );

        Update update = update("updatedTime", new Date());
        update.set("voiceAttachments.$.highlightEntities", saveHighlightRequest.getHighlightEntityList());
        update.set("evidences", saveHighlightRequest.getEvidenceList());
        if (saveHighlightRequest.getEventList() != null) {
            update.set("events", saveHighlightRequest.getEventList());
        }

        FindAndModifyOptions options = new FindAndModifyOptions().returnNew(true);

        LiabilityAnalysisEntity result = mongoTemplate.findAndModify(query, update, options, LiabilityAnalysisEntity.class);
        liabilityAnalysisHistoryService.save(result);
    }

    public void saveEvidence(String claimNumber, Evidence evidence) {
        Query query = new Query().addCriteria(
                where("claimNumber").is(claimNumber)
                        .and("evidences.id").is(evidence.getId())
        );

        Update update = update("updatedTime", new Date());
        update.set("evidences.$", evidence);

        FindAndModifyOptions options = new FindAndModifyOptions().returnNew(true);

        LiabilityAnalysisEntity result = mongoTemplate.findAndModify(query, update, options, LiabilityAnalysisEntity.class);
        liabilityAnalysisHistoryService.save(result);
    }

    public void savePhotoAttachments(String claimNumber, String participantSourceId, SavePhotoAttachmentRequest savePhotoAttachmentRequest) {
        Query query = new Query().addCriteria(
                where("claimNumber").is(claimNumber)
                        .and("liabilitySubjects.participantSourceId").is(participantSourceId)
        );

        Update update = update("updatedTime", new Date());
        update.set("liabilitySubjects.$.photoAttachments", savePhotoAttachmentRequest.getPhotoAttachmentList());
        update.set("evidences", savePhotoAttachmentRequest.getEvidenceList());
        if (savePhotoAttachmentRequest.getEventList() != null) {
            update.set("events", savePhotoAttachmentRequest.getEventList());
        }

        FindAndModifyOptions options = new FindAndModifyOptions().returnNew(true);

        LiabilityAnalysisEntity result = mongoTemplate.findAndModify(query, update, options, LiabilityAnalysisEntity.class);
        liabilityAnalysisHistoryService.save(result);
    }


    public void saveReportedPci(String claimNumber, Date reportedPciDate, String sourceVoiceId, String transcriptId, List<String> pciCategories) throws MessagingException {
        Query query = new Query().addCriteria(
            where("claimNumber").is(claimNumber)
                .and("voiceAttachments.sourceVoiceId").is(sourceVoiceId)
        );


        Update update = update("updatedTime", new Date());
        update.set("voiceAttachments.$.pciCategories", pciCategories);
        update.set("voiceAttachments.$.reportedPciDate", reportedPciDate);

        FindAndModifyOptions options = new FindAndModifyOptions().returnNew(true);

        LiabilityAnalysisEntity result = mongoTemplate.findAndModify(query, update, options, LiabilityAnalysisEntity.class);
        emailService.reportSensitiveTranscript(claimNumber, sourceVoiceId, transcriptId, pciCategories);
        liabilityAnalysisHistoryService.save(result);
    }
}
