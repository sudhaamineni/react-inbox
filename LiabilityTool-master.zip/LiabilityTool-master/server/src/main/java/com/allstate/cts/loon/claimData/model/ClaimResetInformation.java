package com.allstate.cts.loon.claimData.model;


import com.allstate.cts.loon.liabilityAnalysis.entity.VoiceAttachment;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimResetInformation {
    private String resetOnDate;
    private String claimNumber;
    private String claimId;
}
