package com.allstate.cts.loon.liabilityDecision.itext;

import com.allstate.cts.loon.liabilityAnalysis.entity.LiabilityAnalysisEntity;
import com.allstate.cts.loon.liabilityDecision.model.SubmitLiabilityDecisionRequest;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.xmp.impl.Base64;
import org.springframework.stereotype.Component;

import java.io.IOException;

import static com.allstate.cts.loon.liabilityDecision.itext.ITextConstants.FontColors.GRAY_333333;
import static com.allstate.cts.loon.liabilityDecision.itext.ITextConstants.FontColors.GRAY_484848;
import static com.allstate.cts.loon.liabilityDecision.itext.ITextHelper.*;
import static com.itextpdf.text.Font.BOLD;
import static com.itextpdf.text.Rectangle.NO_BORDER;
import static org.springframework.util.ObjectUtils.isEmpty;

@Component
public class ITextLocationSectionGenerator {

    void generateLocationSection(SubmitLiabilityDecisionRequest submitLiabilityDecisionRequest, Document document) throws DocumentException, IOException {
        PdfPTable table = getDefaultTable();

        table.addCell(getLocationHeaderAndGoogleMap(submitLiabilityDecisionRequest));

        if (submitLiabilityDecisionRequest.getLiabilityAnalysisEntity().getSketch() != null && submitLiabilityDecisionRequest.getLiabilityAnalysisEntity().getSketch().isCompleted()) {
            table.addCell(getSketchHeaderAndImage(submitLiabilityDecisionRequest.getLiabilityAnalysisEntity()));
            if (submitLiabilityDecisionRequest.getLiabilityAnalysisEntity().getSketch().getGarageSource() != null && !isEmpty(submitLiabilityDecisionRequest.getLiabilityAnalysisEntity().getSketch().getGarageSource())) {
                table.addCell(Image.getInstance((decode(submitLiabilityDecisionRequest.getLiabilityAnalysisEntity().getSketch().getGarageSource()))));
            }
        }

        document.add(table);
    }

    private PdfPTable getLocationHeaderAndGoogleMap(SubmitLiabilityDecisionRequest submitLiabilityDecisionRequest) throws IOException, DocumentException {
        PdfPTable table = getDefaultTable();

        table.addCell(new Phrase("Location", getAllstateSansRegularFont(20, BOLD, GRAY_333333)));
        table.addCell(getLossDetailsAndLocation(submitLiabilityDecisionRequest.getLiabilityAnalysisEntity()));
        table.addCell(getMapImage(submitLiabilityDecisionRequest.getMapImage()));

        table.setKeepTogether(true);
        return table;
    }

    private PdfPTable getLossDetailsAndLocation(LiabilityAnalysisEntity liabilityAnalysisEntity) throws IOException, DocumentException {
        Font headerGrayFont = getAllstateSansRegularFont(16, BOLD, GRAY_484848);
        Font normalGrayFont = getAllstateSansRegularFont(12, GRAY_484848);

        PdfPTable table = getDefaultTable(2);

        PdfPTable lossDetailTable = getDefaultTable();
        lossDetailTable.addCell(new Phrase("Loss Details", headerGrayFont));
        lossDetailTable.addCell(getCell(new Phrase(liabilityAnalysisEntity.getLossDetailType(), normalGrayFont), 16, 8));
        lossDetailTable.addCell(getCell(new Phrase(liabilityAnalysisEntity.getLossDate() + " at " + liabilityAnalysisEntity.getLossTime(), normalGrayFont), 16, 8));
        table.addCell(lossDetailTable);

        PdfPTable lossLocationTable = getDefaultTable();
        lossLocationTable.addCell(new Phrase("Loss Location", headerGrayFont));
        String lossLocation = liabilityAnalysisEntity.getUpdatedLossLocation() != null ? liabilityAnalysisEntity.getUpdatedLossLocation() :
            liabilityAnalysisEntity.getMapAddress();
        if (lossLocation.split(",").length > 1) {
            lossLocationTable.addCell(getCell(new Phrase(lossLocation.split(",")[0], normalGrayFont), 16, 8));
            lossLocationTable.addCell(getCell(new Phrase(lossLocation.substring(lossLocation.indexOf(",") + 1).trim(), normalGrayFont), 16, 8));
        } else {
            lossLocationTable.addCell(getCell(new Phrase(lossLocation, normalGrayFont), 16, 8));
        }
        table.addCell(lossLocationTable);

        return table;
    }

    private PdfPTable getMapImage(String mapImage) throws IOException, BadElementException {
        PdfPTable mapImageTable = getDefaultTable();
        Image image = Image.getInstance(decode(mapImage));
        image.scalePercent(69);
        PdfPCell mapCell = new PdfPCell(image);
        mapCell.setBorder(NO_BORDER);
        mapImageTable.addCell(mapCell);
        return mapImageTable;
    }

    private PdfPTable getSketchHeaderAndImage(LiabilityAnalysisEntity liabilityAnalysisEntity) throws IOException, DocumentException {
        PdfPTable table = getDefaultTable();
        table.addCell(new Phrase("Scene Sketch", getAllstateSansRegularFont(16, BOLD, GRAY_484848)));

        if (liabilityAnalysisEntity.getSketch().getImageSource() != null && !isEmpty(liabilityAnalysisEntity.getSketch().getImageSource())) {
            table.addCell(Image.getInstance((decode(liabilityAnalysisEntity.getSketch().getImageSource()))));
        }

        table.setKeepTogether(true);
        return table;
    }

    private byte[] decode(String mapImage) {
        return Base64.decode(mapImage.substring(mapImage.indexOf(",") + 1).getBytes());
    }
}
