package com.allstate.cts.loon.messaging.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties(prefix = "messaging")
public class MessagingProperties {

    private String parakeetNlpQueueName;
    private String connectionCacheSize;
    private int receiveTimeout;
    private Tibco tibco;

    @Data
    public static class Tibco {
        private Jndi jndi;
        private Ems ems;
    }

    @Data
    public static class Jndi {
        private String initialContextFactory;
        private String url;
        private String principal;
        private String credentials;
        private String queueConnectionFactoryName;
    }

    @Data
    public static class Ems {
        private String username;
        private String password;
        private String connectionAttempts;
        private String connectionTimeout;
        private String reconnectionAttempts;
        private String reconnectionTimeout;
    }
}