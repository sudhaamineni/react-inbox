package com.allstate.cts.loon.helpers;

import com.allstate.cts.loon.claimData.model.Asset;
import com.allstate.cts.loon.claimData.model.Participant;
import com.allstate.cts.loon.liabilityAnalysis.entity.DamagesEntity;
import com.allstate.cts.loon.liabilityAnalysis.entity.LiabilitySubject;
import com.allstate.cts.loon.liabilityAnalysis.entity.ParticipantEntity;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static com.allstate.cts.loon.constants.LoonConstants.EMPTY;
import static com.allstate.cts.loon.constants.LoonConstants.PED_BIKE_CAPS;

@Component
public class LiabilitySubjectConverter {
    private DamageConverter damageConverter;

    LiabilitySubjectConverter(DamageConverter damageConverter) {
        this.damageConverter = damageConverter;
    }

    public LiabilitySubject convertLiabilitySubject(Participant sourceParticipant, Asset asset, List<Participant> allAssetParticipants, String role, List<ParticipantEntity> allParticipants) {
        if (sourceParticipant == null) {
            return null;
        }
        List<ParticipantEntity> relatedParticipants = new ArrayList<>();
        for (Participant participant : allAssetParticipants) {
            if (!sourceParticipant.getLegacyInvolvedId().equalsIgnoreCase(participant.getLegacyInvolvedId())) {
                relatedParticipants.add(allParticipants.stream().filter(p -> p.getParticipantPartyId().equalsIgnoreCase(participant.getLegacyInvolvedId())).findFirst().get());
            }
        }
        return getLiabilitySubject(sourceParticipant, asset, relatedParticipants, role);
    }

    private LiabilitySubject getLiabilitySubject(Participant sourceParticipant, Asset asset, List<ParticipantEntity> relatedParticipants, String role) {
        String firstName = null;
        String lastName = null;
        String phoneNumber = null;
        String organizationName = null;

        if (sourceParticipant.getClient() != null) {
            firstName = sourceParticipant.getClient().getFirstName();
            lastName = sourceParticipant.getClient().getLastName();
            phoneNumber = sourceParticipant.getClient().getPhoneNumber();
            organizationName = sourceParticipant.getClient().getOrganizationName();
        }

        com.allstate.cts.loon.liabilityAnalysis.entity.Asset liabilitySubjectAsset = null;
        if (PED_BIKE_CAPS.equals(role)) {
            liabilitySubjectAsset = com.allstate.cts.loon.liabilityAnalysis.entity.Asset.builder()
                    .assetTypeDescription(PED_BIKE_CAPS)
                    .damages(Collections.singletonList(DamagesEntity.builder().build()))
                    .build();
        } else if (asset != null) {
            liabilitySubjectAsset = com.allstate.cts.loon.liabilityAnalysis.entity.Asset.builder()
                    .vehicleMake(asset.getVehicle() != null ? asset.getVehicle().getMake() : EMPTY)
                    .vehicleModel(asset.getVehicle() != null ? asset.getVehicle().getModel() : EMPTY)
                    .vehicleYear(asset.getVehicle() != null ? asset.getVehicle().getYear() : EMPTY)
                    .vehicleItemId(asset.getItemId())
                    .assetTypeDescription((asset.getAssetTypeDescription() != null)?asset.getAssetTypeDescription().trim():"")
                    .damages(damageConverter.convertDamages(asset.getDamages()))
                    .build();
        }

        LiabilitySubject liabilitySubject = LiabilitySubject.builder()
                .firstName(firstName)
                .lastName(lastName)
                .phoneNumber(phoneNumber)
                .organizationName(organizationName)
                .role(role)
                .isDriver(sourceParticipant.isDriver())
                .participantPartyId(sourceParticipant.getLegacyInvolvedId())
                .participantSourceId(sourceParticipant.getInsInvolvementId())
                .photoAttachments(Collections.emptyList())
                .relatedParticipants(PED_BIKE_CAPS.equals(role) ? new ArrayList<>() : relatedParticipants)
                .asset(liabilitySubjectAsset)
                .build();

        if (!liabilitySubject.isDriver() && liabilitySubject.getRelatedParticipants().size() > 0) {
            liabilitySubject.setDriverName(getDriverName(liabilitySubject));
        }
        return liabilitySubject;
    }

    public String getDriverName(LiabilitySubject liabilitySubject) {
        Optional<ParticipantEntity> driverParticipant = liabilitySubject.getRelatedParticipants().stream().filter(pe -> pe.isDriver()).findFirst();
        return driverParticipant.isPresent() ? driverParticipant.get().getFirstName() + " " + driverParticipant.get().getLastName() : null;
    }
}