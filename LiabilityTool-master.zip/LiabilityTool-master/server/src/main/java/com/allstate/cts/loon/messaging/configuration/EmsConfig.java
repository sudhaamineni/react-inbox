package com.allstate.cts.loon.messaging.configuration;

import com.tibco.tibjms.naming.TibjmsFederatedQueueConnectionFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jndi.JndiObjectFactoryBean;
import org.springframework.jndi.JndiTemplate;

import javax.jms.ConnectionFactory;
import javax.naming.NamingException;
import java.util.Properties;

import static java.lang.Integer.valueOf;

@Configuration
@Profile("!PRODUCTION")
public class EmsConfig extends CommonMessagingConfig {
    // TODO look into this in the sample app
    // @Autowired
    // private JmsErrorHandler jmsErrorHandler;

    @Bean
    @Primary
    public JmsTemplate ctsjmsTemplate(ConnectionFactory emsQueueConnectionFactory, MessagingProperties properties) {
        JmsTemplate jmsTemplate = new JmsTemplate(emsQueueConnectionFactory);
        jmsTemplate.setReceiveTimeout(properties.getReceiveTimeout());
        jmsTemplate.setMessageConverter(jsonMessageConverter());
        return jmsTemplate;
    }

    @Bean
    @Primary
    public ConnectionFactory eMSQueueConnectionFactory(MessagingProperties messagingProperties,
                                                       @Qualifier("jndiQueueConnectionFactory") TibjmsFederatedQueueConnectionFactory jndiQueueConnectionFactory) {
        ConnectionFactory factory;
        MessagingProperties.Ems ems = messagingProperties.getTibco().getEms();

        jndiQueueConnectionFactory.setUserName(ems.getUsername());
        jndiQueueConnectionFactory.setUserPassword(ems.getPassword());
        jndiQueueConnectionFactory.setConnAttemptCount(valueOf(ems.getConnectionAttempts()));
        jndiQueueConnectionFactory.setReconnAttemptCount(valueOf(ems.getReconnectionAttempts()));
        jndiQueueConnectionFactory.setReconnAttemptTimeout(valueOf(ems.getReconnectionTimeout()));
        jndiQueueConnectionFactory.setConnAttemptTimeout(valueOf(ems.getConnectionTimeout()));

        CachingConnectionFactory cachingConnectionFactory = new CachingConnectionFactory(jndiQueueConnectionFactory);
        cachingConnectionFactory.setSessionCacheSize(valueOf(messagingProperties.getConnectionCacheSize()));
        // this will break all caching if set to true; caching is handled by the listener setup
        cachingConnectionFactory.setCacheConsumers(false);
        cachingConnectionFactory.setCacheProducers(true);
        factory = cachingConnectionFactory;
        return factory;
    }

    @Bean
    public JndiTemplate jndiTemplate(MessagingProperties messagingProperties) {
        MessagingProperties.Jndi jndi = messagingProperties.getTibco().getJndi();

        Properties properties = new Properties();
        properties.setProperty("java.naming.factory.initial", jndi.getInitialContextFactory());
        properties.setProperty("java.naming.provider.url", jndi.getUrl());
        properties.setProperty("java.naming.security.principal", jndi.getPrincipal());
        properties.setProperty("java.naming.security.credentials", jndi.getCredentials());

        JndiTemplate jndiTemplate = new JndiTemplate();
        jndiTemplate.setEnvironment(properties);
        return jndiTemplate;
    }

    @Bean
    public String jndiClaimsEmsQueueConnectionFactoryName(MessagingProperties messagingProperties) {
        return messagingProperties.getTibco().getJndi().getQueueConnectionFactoryName();
    }

    @Bean(name = "jndiQueueConnectionFactory")
    public TibjmsFederatedQueueConnectionFactory jndiQueueConnectionFactory(JndiTemplate jndiTemplate, String jndiClaimsEmsQueueConnectionFactoryName) throws NamingException {
        JndiObjectFactoryBean jndiObjectFactoryBean = new JndiObjectFactoryBean();
        jndiObjectFactoryBean.setJndiTemplate(jndiTemplate);
        jndiObjectFactoryBean.setJndiName(jndiClaimsEmsQueueConnectionFactoryName);
        jndiObjectFactoryBean.afterPropertiesSet();
        return ((TibjmsFederatedQueueConnectionFactory) jndiObjectFactoryBean.getObject());
    }
}