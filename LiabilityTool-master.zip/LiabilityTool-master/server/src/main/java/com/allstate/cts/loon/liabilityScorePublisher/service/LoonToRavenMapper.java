package com.allstate.cts.loon.liabilityScorePublisher.service;

import com.allstate.cts.auditLog.utilities.UUIDWrapper;
import com.allstate.cts.loon.exception.SubmissionSystemErrorException;
import com.allstate.cts.loon.liabilityAnalysis.entity.AffectedParty;
import com.allstate.cts.loon.liabilityAnalysis.entity.LiabilityAnalysisEntity;
import com.allstate.cts.loon.liabilityAnalysis.entity.LiabilitySubject;
import com.allstate.cts.loon.liabilityAnalysis.entity.ParticipantEntity;
import com.allstate.cts.loon.liabilityScorePublisher.model.AffectedParticipant;
import com.allstate.cts.loon.liabilityScorePublisher.model.RavenLiabilityParties;
import com.allstate.cts.loon.liabilityScorePublisher.model.RavenLiabilityScore;
import com.allstate.cts.loon.liabilityScorePublisher.model.RavenLiabilityScorePublisherRequest;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

import static java.util.Collections.singletonList;
import static java.util.Comparator.comparing;
import static java.util.stream.IntStream.range;

@Service
public class LoonToRavenMapper {
    private final UUIDWrapper uuidWrapper;

    LoonToRavenMapper(UUIDWrapper uuidWrapper) {
        this.uuidWrapper = uuidWrapper;
    }

    public RavenLiabilityScorePublisherRequest map(LiabilityAnalysisEntity lae, boolean isFaultAllocation) {
        return RavenLiabilityScorePublisherRequest.builder()
            .sourceSystem("Loon")
            .correlationID(uuidWrapper.getRandomUUID())
            .claimNumber(lae.getClaimNumber())
            .ravenLiabilityParties(createRavenLiabilityParties(lae, isFaultAllocation))
            .build();
    }

    private List<RavenLiabilityParties> createRavenLiabilityParties(LiabilityAnalysisEntity lae, boolean isFaultAllocation) {
        List<RavenLiabilityParties> ravenLiabilityParties = new ArrayList<>();
        lae.getEvents().forEach(e -> e.getInvolvedParties().forEach(ip -> {
            LiabilitySubject involvedLiabilitySubject = lae.getLiabilitySubjects().stream()
                .filter(ls -> ls.getParticipantPartyId().equals(ip.getParticipantId())).findFirst().get();
            List<AffectedParty> sortedAffectedParties = ip.getAffectedParties();
            if (isFaultAllocation) {
                try {
                    sortedAffectedParties.sort(comparing(AffectedParty::getFaultAllocationPercent).reversed());
                } catch (NullPointerException npe) {
                    throw new SubmissionSystemErrorException(new RuntimeException("Agreed affected percent not found!"));
                }
            } else {
                try {
                    sortedAffectedParties.sort(comparing(AffectedParty::getBeginNegotiatingRange).reversed());
                } catch (NullPointerException npe) {
                    throw new SubmissionSystemErrorException(new RuntimeException("Liability range not found!"));
                }
            }

            range(0, sortedAffectedParties.size()).forEach(index -> {
                AffectedParty ap = sortedAffectedParties.get(index);
                LiabilitySubject affectedLiabilitySubject = null;
                if (lae.getLiabilitySubjects().size() > 1) {
                    affectedLiabilitySubject = lae.getLiabilitySubjects().stream()
                        .filter(ls -> ls.getParticipantPartyId().equals(ap.getParticipantId())).findFirst().get();
                }
                RavenLiabilityScore ravenLiabilityScore;
                if (isFaultAllocation) {
                    ravenLiabilityScore = RavenLiabilityScore.builder()
                        .finalScore(ap.getFaultAllocationPercent())
                        .build();
                } else {
                    ravenLiabilityScore = RavenLiabilityScore.builder()
                        .beginRange(ap.getBeginNegotiatingRange())
                        .endRange(ap.getEndNegotiatingRange())
                        .build();
                }

                AffectedParticipant affectedParticipant = AffectedParticipant.builder().affectedParticipant(ap.getParticipantId()).build();
                RavenLiabilityParties liabilityParties = RavenLiabilityParties.builder()
                    .mainParticipant(ip.getParticipantId())
                    .ravenLiabilityScore(ravenLiabilityScore)
                    .affectedParties(lae.getLiabilitySubjects().size() > 1 ? singletonList(affectedParticipant) : null)
                    .build();
                ravenLiabilityParties.add(liabilityParties);

                // Passengers
                if (ap.getPassengerPartyIds() != null && !ap.getPassengerPartyIds().isEmpty()) {
                    List<AffectedParticipant> affectedPassengers = new ArrayList<>();
                    if (index == 0 && ip.getPassengerPartyIds() != null) {
                        ip.getPassengerPartyIds().forEach(p -> affectedPassengers.add(AffectedParticipant.builder().affectedParticipant(p).build()));
                    }
                    ap.getPassengerPartyIds().forEach(p -> affectedPassengers.add(AffectedParticipant.builder().affectedParticipant(p).build()));
                    RavenLiabilityParties passengerParties = RavenLiabilityParties.builder()
                        .mainParticipant(ip.getParticipantId())
                        .ravenLiabilityScore(ravenLiabilityScore)
                        .affectedParties(affectedPassengers)
                        .build();
                    ravenLiabilityParties.add(passengerParties);
                }

                // Drivers
                if ((!involvedLiabilitySubject.isDriver() && involvedLiabilitySubject.getDriverName() != null)
                    || (affectedLiabilitySubject != null && !affectedLiabilitySubject.isDriver() && affectedLiabilitySubject.getDriverName() != null)) {
                    List<AffectedParticipant> affectedDrivers = new ArrayList<>();
                    if (index == 0 && !involvedLiabilitySubject.isDriver() && involvedLiabilitySubject.getDriverName() != null) {
                        affectedDrivers.add(
                            AffectedParticipant.builder()
                                .affectedParticipant(involvedLiabilitySubject.getRelatedParticipants().stream().filter(ParticipantEntity::isDriver).findFirst().get().getParticipantPartyId())
                                .build()
                        );
                    }
                    if (!affectedLiabilitySubject.isDriver() && affectedLiabilitySubject.getDriverName() != null) {
                        affectedDrivers.add(
                            AffectedParticipant.builder()
                                .affectedParticipant(affectedLiabilitySubject.getRelatedParticipants().stream().filter(ParticipantEntity::isDriver).findFirst().get().getParticipantPartyId())
                                .build()
                        );
                    }
                    RavenLiabilityParties passengerParties = RavenLiabilityParties.builder()
                        .mainParticipant(ip.getParticipantId())
                        .ravenLiabilityScore(ravenLiabilityScore)
                        .affectedParties(affectedDrivers)
                        .build();
                    ravenLiabilityParties.add(passengerParties);
                }
            });
        }));
        if (ravenLiabilityParties.isEmpty()) {
            throw new SubmissionSystemErrorException(new RuntimeException("Liability range not found!"));
        }
        return ravenLiabilityParties;
    }
}