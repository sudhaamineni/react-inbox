package com.allstate.cts.loon.liabilityAnalysis.service;

import com.allstate.cts.loon.claimData.model.ClaimResetInformation;
import com.allstate.cts.loon.configuration.FeatureSwitches;
import com.allstate.cts.loon.dcf.model.ParticipantDocuments;
import com.allstate.cts.loon.dcf.model.PhotoDetail;
import com.allstate.cts.loon.dcf.service.DigitalClaimFileService;
import com.allstate.cts.loon.exception.ClaimInsuredNotFoundException;
import com.allstate.cts.loon.exception.ClaimNotFoundException;
import com.allstate.cts.loon.exception.InvalidCharacterException;
import com.allstate.cts.loon.exception.SystemErrorException;
import com.allstate.cts.loon.helpers.Validator;
import com.allstate.cts.loon.liabilityAnalysis.entity.LiabilityAnalysisEntity;
import com.allstate.cts.loon.liabilityAnalysis.entity.LiabilitySubject;
import com.allstate.cts.loon.liabilityAnalysis.entity.PhotoAttachment;
import com.allstate.cts.loon.liabilityAnalysis.entity.VoiceAttachment;
import com.allstate.cts.loon.parakeet.model.AudioFileInformation;
import com.allstate.cts.loon.parakeet.model.RecordedMediaMetadata;
import com.allstate.cts.loon.parakeet.model.RecordedObjectsResponse;
import com.allstate.cts.loon.parakeet.model.TranscriptInformation;
import com.allstate.cts.loon.parakeet.service.ParakeetService;
import com.amazonaws.util.CollectionUtils;
import com.google.common.base.Strings;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.*;

import static com.allstate.cts.loon.constants.LoonConstants.INSURED_CAPS;
import static java.util.Arrays.asList;
import static java.util.Comparator.comparing;

@Service
public class RetrieveLiabilityAnalysisAttachmentService {
    private LiabilityAnalysisService liabilityAnalysisService;
    private DigitalClaimFileService digitalClaimFileService;
    private Validator validator;
    private ParakeetService parakeetService;
    private Map<String, String> claimsWithLocalVoiceFiles;
    protected String parakeetNlpUrl;
    private FeatureSwitches featureSwitches;

    public RetrieveLiabilityAnalysisAttachmentService(LiabilityAnalysisService liabilityAnalysisService,
                                                      DigitalClaimFileService digitalClaimFileService,
                                                      Validator validator,
                                                      ParakeetService parakeetService,
                                                      @Value("${parakeet.nlp.url}") String parakeetNlpUrl,
                                                      FeatureSwitches featureSwitches) {
        this.liabilityAnalysisService = liabilityAnalysisService;
        this.digitalClaimFileService = digitalClaimFileService;
        this.validator = validator;
        this.parakeetService = parakeetService;
        this.parakeetNlpUrl = parakeetNlpUrl;
        this.featureSwitches = featureSwitches;

        //todo remove all this once parakeet can return urls to voice files
        // add any new temp voice files here and in ParticipantOwner.js
        this.claimsWithLocalVoiceFiles = new HashMap<>();

        claimsWithLocalVoiceFiles.put("000442519138", "000442519138_02"); //02  participantPartyId
        claimsWithLocalVoiceFiles.put("000179459037", "000179459037_01"); //01  participantPartyId
        claimsWithLocalVoiceFiles.put("000178517140", "000178517140_01");
        claimsWithLocalVoiceFiles.put("000196487904", "000196487904_06");
        claimsWithLocalVoiceFiles.put("000178332250", "000178332250_01");
        claimsWithLocalVoiceFiles.put("000179632509", "000179632509_01");
    }

    private LiabilityAnalysisEntity getLiabilityAnalysisEntityFromDb(String claimNumber) {
        if (!validator.isStringSafeForLeela(claimNumber)) {
            throw new InvalidCharacterException(claimNumber);
        }
        return liabilityAnalysisService.getLiabilityAnalysisData(validator.padClaimNumber(claimNumber));
    }

    public List<LiabilitySubject> getPhotoAttachments(String claimNumber) {
        try {
            LiabilityAnalysisEntity liabilityAnalysisEntityFromDB = getLiabilityAnalysisEntityFromDb(claimNumber);
            List<ParticipantDocuments> participantDocumentsList = digitalClaimFileService.getParticipantDocuments(claimNumber);
            setDocumentsToParticipant(liabilityAnalysisEntityFromDB, participantDocumentsList);
            liabilityAnalysisService.saveLiabilitySubjects(liabilityAnalysisEntityFromDB.getClaimNumber(), liabilityAnalysisEntityFromDB.getLiabilitySubjects());
            return liabilityAnalysisEntityFromDB.getLiabilitySubjects();
        } catch (InvalidCharacterException | ClaimNotFoundException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new SystemErrorException();
        }
    }

    public List<VoiceAttachment> getVoiceAttachments(String claimNumber) {
        try {
            LiabilityAnalysisEntity liabilityAnalysisEntityFromDB = getLiabilityAnalysisEntityFromDb(claimNumber);
            mergeVoiceAttachments(claimNumber, liabilityAnalysisEntityFromDB);
            if (!CollectionUtils.isNullOrEmpty(liabilityAnalysisEntityFromDB.getResetClaims())) {
                liabilityAnalysisService.saveVoiceAttachments(liabilityAnalysisEntityFromDB.getClaimNumber(), liabilityAnalysisEntityFromDB.getVoiceAttachments(), true);
            } else {
                liabilityAnalysisService.saveVoiceAttachments(liabilityAnalysisEntityFromDB.getClaimNumber(), liabilityAnalysisEntityFromDB.getVoiceAttachments(), false);
            }
            return liabilityAnalysisEntityFromDB.getVoiceAttachments();
        } catch (InvalidCharacterException | ClaimNotFoundException | ClaimInsuredNotFoundException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new SystemErrorException();
        }
    }

    private void mergeVoiceAttachments(String claimNumber, LiabilityAnalysisEntity liabilityAnalysisEntityFromDB) {
        RecordedObjectsResponse recordedObjects;
        if (!CollectionUtils.isNullOrEmpty(liabilityAnalysisEntityFromDB.getResetClaims())
                && !liabilityAnalysisEntityFromDB.isResetClaimVoiceSynced()) {
            recordedObjects = getParakeetDataForResetClaims(liabilityAnalysisEntityFromDB.getResetClaims());
        } else {
            recordedObjects = parakeetService.getRecordedObjects(claimNumber);
        }

        // TEMP code until Parakeet is ready
        // All transcripts are associated with the insured.
        Optional<LiabilitySubject> insured = liabilityAnalysisEntityFromDB.getLiabilitySubjects()
                .stream().filter(p -> p.getRole().equalsIgnoreCase(INSURED_CAPS)).findFirst();
        String ownerId;
        if (insured.isPresent()) {
            ownerId = insured.get().getParticipantSourceId();
        } else {
            throw new ClaimInsuredNotFoundException(claimNumber);
        }
        if (claimsWithLocalVoiceFiles.containsKey(claimNumber)) {
            // Find the associated participant from the voice file's legacyInvolvedId
            String legacyInvolvedID = claimsWithLocalVoiceFiles.get(claimNumber).split("_")[1];
            Optional<LiabilitySubject> participantEntity = liabilityAnalysisEntityFromDB.getLiabilitySubjects()
                    .stream().filter(p -> p.getParticipantPartyId().equals(legacyInvolvedID)).findFirst();
            if (participantEntity.isPresent()) {
                ownerId = participantEntity.get().getParticipantSourceId();
            } else {
                throw new ClaimInsuredNotFoundException(claimNumber);
            }
        }
        mergeVoiceAttachments(liabilityAnalysisEntityFromDB.getVoiceAttachments(), recordedObjects, ownerId);
    }

    private RecordedObjectsResponse getParakeetDataForResetClaims(List<ClaimResetInformation> resetClaims) {
        RecordedObjectsResponse recordedObjects = null;
        HashSet<String> ucIds = new HashSet<>();
        for (ClaimResetInformation resetClaim : resetClaims) {
            RecordedObjectsResponse response = parakeetService.getRecordedObjects(resetClaim.getClaimNumber());
            if (response != null && response.getMetadata() != null) {
                if (recordedObjects == null) {
                    recordedObjects = response;
                    for (RecordedMediaMetadata metadata : response.getMetadata()) {
                        if (metadata.getAudioFileInformation() != null
                                && !Strings.isNullOrEmpty(metadata.getAudioFileInformation().getUcId())) {
                            ucIds.add(metadata.getAudioFileInformation().getUcId());
                        }
                    }
                } else {
                    for (RecordedMediaMetadata metadata : response.getMetadata()) {
                        if (metadata.getAudioFileInformation() != null
                                && !Strings.isNullOrEmpty(metadata.getAudioFileInformation().getUcId())
                                && !ucIds.contains(metadata.getAudioFileInformation().getUcId())) {
                            recordedObjects.getMetadata().add(metadata);
                            ucIds.add(metadata.getAudioFileInformation().getUcId());
                        }
                    }
                }
            }
        }
        return recordedObjects;
    }

    private void mergeVoiceAttachments(List<VoiceAttachment> vaDb, RecordedObjectsResponse parakeetResponse, String ownerId) {
        if (parakeetResponse != null && parakeetResponse.getMetadata() != null && ownerId != null) {
            parakeetResponse.getMetadata().sort(comparing(RecordedMediaMetadata::getCreatedAt).reversed());
            for (RecordedMediaMetadata o : parakeetResponse.getMetadata()) {
                boolean voicePresentInDB = false;
                for (VoiceAttachment voiceAttachment : vaDb) {
                    if (voiceAttachment.getSourceVoiceId().equalsIgnoreCase(o.getAudioFileInformation().getUcId())) {
                        voicePresentInDB = true;
                        voiceAttachment.setSourceVoiceUrl("/radpro" + o.getAudioFileInformation().getAudioRetrievalLocation());
                        voiceAttachment.setSourceTranscriptUrl(o.getTranscriptInformation().getTranscriptRetrievalLocation());
                        break;
                    }
                }
                if (!voicePresentInDB) {
                    vaDb.add(
                            VoiceAttachment.builder()
                                    .sourceVoiceId(o.getAudioFileInformation().getUcId())
                                    .sourceVoiceTitle(o.getCallType())
                                    .sourceVoiceUrl("/radpro" + o.getAudioFileInformation().getAudioRetrievalLocation())
                                    .sourceTranscriptUrl(o.getTranscriptInformation().getTranscriptRetrievalLocation())
                                    .sourceNlpUrl(parakeetNlpUrl + o.getTranscriptInformation().getRecordingId())
                                    .participantSourceId(ownerId)
                                    .createdDate(o.getCreatedAt())
                                    .build()
                    );
                }
            }
        }
    }

    private void setDocumentsToParticipant(LiabilityAnalysisEntity analysisEntity, List<ParticipantDocuments> participantDocumentsList) {
        analysisEntity.getLiabilitySubjects().forEach(participantOwner -> {
            List<LiabilitySubject> participants = new ArrayList<>();
            participantOwner.getRelatedParticipants().forEach(rp -> participants.add(LiabilitySubject.builder().participantSourceId(rp.getParticipantSourceId()).build()));
            participants.add(participantOwner);

            addDocs(participants, participantOwner, participantDocumentsList);
        });
    }

    private void addDocs(List<LiabilitySubject> participants, LiabilitySubject participantOwner, List<ParticipantDocuments> participantDocuments) {
        participantDocuments.forEach(documents -> participants.stream().filter(participant -> isMatch(participant, documents)).findAny()
                .ifPresent(p -> {
                    List<PhotoAttachment> photos = participantOwner.getPhotoAttachments();
                    documents.getPhotoUrlList().forEach(photoDetail -> {
                        boolean photoPresentInDB = false;
                        addPhotoUrls(photos, photoDetail, photoPresentInDB);
                    });
                }));
    }

    private void addPhotoUrls(List<PhotoAttachment> photos, PhotoDetail photoDetail, boolean photoPresentInDB) {
        for (PhotoAttachment photo : photos) {
            if (photo.getDcfId().equalsIgnoreCase(photoDetail.getDcfId())) {
                photo.setUrl(photoDetail.getUrl());
                photoPresentInDB = true;
            }
        }
        if (!photoPresentInDB) {
            photos.add(PhotoAttachment.builder()
                    .dcfId(photoDetail.getDcfId())
                    .url(photoDetail.getUrl())
                    .build());
        }
    }

    private boolean isMatch(LiabilitySubject participant, ParticipantDocuments participantDocuments) {
        return participant.getParticipantSourceId() != null
                && participant.getParticipantSourceId().equals(participantDocuments.getParticipantSourceId());
    }
}
