package com.allstate.cts.loon.liabilityAnalysis.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

import static com.allstate.cts.loon.constants.LoonConstants.CLAIMANT_CAPS;
import static com.allstate.cts.loon.constants.LoonConstants.INSURED_CAPS;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LiabilitySubject implements Comparable {
    private String participantPartyId;
    private String participantSourceId;
    private String role;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String organizationName;
    private boolean isDriver;
    private String driverName;
    private Asset asset;

    @Builder.Default
    private List<PhotoAttachment> photoAttachments = new ArrayList<>();

    @Builder.Default
    private List<ParticipantEntity> relatedParticipants = new ArrayList<>();

    public String getName() {
        if (organizationName != null && !organizationName.trim().equals("")) {
            return organizationName;
        }

        if ((firstName == null || firstName.trim().equals("")) && (lastName == null || lastName.trim().equals(""))) {
            return "UNKNOWN";
        }

        String name = "";

        if (firstName != null && firstName.trim().length() > 0) {
            name += firstName.trim() + " ";
        }
        if (lastName != null) {
            name += lastName.trim();
        }

        return name;
    }

    @Override
    public int compareTo(Object otherObject) {
        LiabilitySubject otherParticipant = (LiabilitySubject) otherObject;

        if (INSURED_CAPS.equals(this.getRole())) {
            return -1;
        }
        if (CLAIMANT_CAPS.equals(this.getRole()) && INSURED_CAPS.equals(otherParticipant.getRole())) {
            return 1;
        }
        if (CLAIMANT_CAPS.equals(this.getRole()) && CLAIMANT_CAPS.equals(otherParticipant.getRole())) {
            return this.getParticipantPartyId().compareTo(otherParticipant.getParticipantPartyId());
        }
        return 1;
    }
}
