package com.allstate.cts.loon.helpers;

import com.allstate.cts.loon.claimData.model.AssetParticipant;
import com.allstate.cts.loon.claimData.model.Participant;
import com.allstate.cts.loon.liabilityAnalysis.entity.LiabilitySubject;
import com.allstate.cts.loon.liabilityAnalysis.entity.ParticipantEntity;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

import static com.allstate.cts.loon.constants.LoonConstants.INSURED_CAPS;

@Component
public class ClaimDataModelHelper {
    public Participant getMatchingParticipant(AssetParticipant assetParticipant, List<Participant> participants) {
        return participants.stream().filter(participant ->
                participant.getLegacyInvolvedId().equals(assetParticipant.getLegacyInvolvedId())).findAny().orElse(null);
    }

    public List<Participant> getClaimantOwnerAssetParticipants(List<Participant> participants) {

        List<Participant> allClaimantOwners = new ArrayList<>();

        participants.forEach(participant -> {
            if (participant.getInvolvementRole()!= null && participant.isClaimantAndOwner())
                allClaimantOwners.add(participant);
        });

        return allClaimantOwners;
    }

    public String getParticipantNameByParticipantId(String participantId, List<LiabilitySubject> liabilitySubjects) {

        LiabilitySubject liabilitySubject = liabilitySubjects.stream().filter(ls -> participantId.equals(ls.getParticipantPartyId())).findFirst().get();
        if (liabilitySubject.getOrganizationName() != null) {
            return liabilitySubject.getOrganizationName();
        } else {
            if (liabilitySubject.getLastName() != null || liabilitySubject.getFirstName() != null) {
                return liabilitySubject.getFirstName() + " " + liabilitySubject.getLastName();
            } else {
                return "";
            }
        }
    }

    public boolean isInsuredByPartyId(String participantId, List<LiabilitySubject> liabilitySubjects) {
        LiabilitySubject liabilitySubject = liabilitySubjects.stream().filter(ls -> participantId.equals(ls.getParticipantPartyId())).findFirst().get();
        return liabilitySubject.getRole().equals(INSURED_CAPS);
    }
}