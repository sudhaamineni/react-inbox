package com.allstate.cts.loon.claimData.service;

import com.allstate.cts.auditLog.annotation.AuditLoggedTemplate;
import com.allstate.cts.loon.claimData.model.ClaimData;
import com.allstate.cts.loon.claimData.model.RetrieveClaimDataResponse;
import com.allstate.cts.loon.exception.ClaimDataRetrieverException;
import com.allstate.cts.loon.exception.ClaimNotFoundException;
import com.allstate.cts.loon.exception.SystemErrorException;
import com.allstate.cts.loon.resttemplate.LoonRestTemplate;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;

import static org.springframework.http.HttpStatus.BAD_REQUEST;

@Service
@Profile("!performanceTest")
public class LeelaClaimDataRetrieverService implements ClaimDataRetrieverServiceInterface {
    private final LoonRestTemplate leelaClaimRestTemplate;

    public LeelaClaimDataRetrieverService(LoonRestTemplate leelaClaimRestTemplate) {
        this.leelaClaimRestTemplate = leelaClaimRestTemplate;
    }

    @Override
    public ClaimData getClaimData(String claimNumber, String uriVariables) {

        try {
            return leelaClaimRestTemplate.getObject(
                    RetrieveClaimDataResponse.class,
                    claimNumber,
                    claimNumber,
                    uriVariables)
                    .getClaimData();
        } catch (HttpClientErrorException ex) {
            if (ex.getStatusCode() == BAD_REQUEST) {
                throw new ClaimNotFoundException(claimNumber);
            } else {
                throw new SystemErrorException();
            }
        } catch (Exception ex) {
            throw new ClaimDataRetrieverException(claimNumber, ex);
        }
    }
}