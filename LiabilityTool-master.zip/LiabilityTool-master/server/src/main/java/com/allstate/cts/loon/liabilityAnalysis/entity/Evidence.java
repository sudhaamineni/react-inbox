package com.allstate.cts.loon.liabilityAnalysis.entity;

import com.allstate.cts.loon.highlight.entity.HighlightText;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Field;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Evidence {
    @Field("id")
    private String id;
    private String type;
    private String category;
    private String role;
    private String sourceId;
    private String participantPartyId;
    private String participantSourceId;
    private String participantDisplayName;

    //Transcripts
    private String sourceVoiceId;
    private String callType;
    private String transcriptCreatedDate;
    private List<HighlightText> highlightTexts;

    //Photos
    private String photoUrl;
    private Integer rotation;
}
