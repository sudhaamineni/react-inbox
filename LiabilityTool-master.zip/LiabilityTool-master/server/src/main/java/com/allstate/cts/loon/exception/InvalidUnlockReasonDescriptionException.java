package com.allstate.cts.loon.exception;

public class InvalidUnlockReasonDescriptionException extends RuntimeException implements CustomException{

    private final String msgHeader;
    private final String msgDescription;

    public InvalidUnlockReasonDescriptionException(String claimNumber, String reason, String description) {
        this.msgHeader = "Claim #" + claimNumber + " has invalid description. " + "Reason: " +reason + " Desc: " + description;
        this.msgDescription = "This claim has invalid description for the reason other";
    }

    @Override
    public String getMessageHeader() {
        return this.msgHeader;
    }

    @Override
    public String getMessageDescription() {
        return this.msgDescription;
    }
}
