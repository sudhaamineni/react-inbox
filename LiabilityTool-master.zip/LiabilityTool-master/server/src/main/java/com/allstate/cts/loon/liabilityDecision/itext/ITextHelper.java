package com.allstate.cts.loon.liabilityDecision.itext;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;

import java.io.IOException;

import static com.allstate.cts.loon.liabilityDecision.itext.ITextConstants.FontColors.GRAY_6B6B6B;
import static com.itextpdf.text.Font.NORMAL;
import static com.itextpdf.text.Rectangle.NO_BORDER;
import static com.itextpdf.text.html.WebColors.getRGBColor;
import static com.itextpdf.text.pdf.BaseFont.EMBEDDED;
import static com.itextpdf.text.pdf.BaseFont.IDENTITY_H;

class ITextHelper {
    private ITextHelper() {
        throw new IllegalStateException("Helper class");
    }

    static PdfPTable getDefaultTable() {
        return getDefaultTable(1);
    }

    static PdfPTable getDefaultTable(int columnCount) {
        PdfPTable table = new PdfPTable(columnCount);
        table.setWidthPercentage(100);
        table.getDefaultCell().setBorder(NO_BORDER);
        return table;
    }

    static PdfPCell getEmptyCell() {
        PdfPCell emptyCell = new PdfPCell();
        emptyCell.setBorder(NO_BORDER);
        return emptyCell;
    }

    static PdfPCell getEmptyCell(int border) {
        PdfPCell cell = new PdfPCell();
        cell.setUseVariableBorders(true);
        cell.setBorder(border);
        cell.setBorderColorTop(getRGBColor(GRAY_6B6B6B));
        return cell;
    }

    static PdfPCell getCell(Phrase phrase, int paddingLeft, int paddingTop) {
        PdfPCell pdfPCell = new PdfPCell(phrase);
        pdfPCell.setPaddingTop(convertToPoints(paddingTop));
        pdfPCell.setPaddingLeft(convertToPoints(paddingLeft));
        pdfPCell.setBorder(NO_BORDER);
        return pdfPCell;
    }

    static float convertToPoints(int pixels) {
        return (float) (pixels * 0.75);
    }

    static Font getAllstateSansRegularFont(int size, String color) throws DocumentException, IOException {
        return getAllstateSansRegularFont(size, NORMAL, color);
    }

    static Font getAllstateSansRegularFont(int size, int style, String color) throws DocumentException, IOException {
        int sizeInPoints = (int) (size * 0.75);
        return new Font(getAllstateSansRegularBaseFont(), sizeInPoints, style, getRGBColor(color));
    }

    private static BaseFont getAllstateSansRegularBaseFont() throws DocumentException, IOException {
        return BaseFont.createFont("fonts/AllstateSans-Regular.otf", IDENTITY_H, EMBEDDED);
    }

    static String capitalizeFirstLetters(String s) {
        StringBuilder sb = new StringBuilder();
        String[] array = s.split("\\s");
        for (int i = 0; i < array.length; i++) {
            String correctlyCapitalizedString = array[i].substring(0, 1).toUpperCase() + array[i].substring(1);
            sb.append(correctlyCapitalizedString);
            if (i < array.length - 1) {
                sb.append(" ");
            }
        }
        return sb.toString();
    }
}
