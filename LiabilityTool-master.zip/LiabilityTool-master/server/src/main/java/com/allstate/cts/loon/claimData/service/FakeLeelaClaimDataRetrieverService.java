package com.allstate.cts.loon.claimData.service;

import com.allstate.cts.loon.claimData.model.ClaimData;
import com.allstate.cts.loon.claimData.model.RetrieveClaimDataResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Charsets;
import com.google.common.io.Resources;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.URL;

@Service
@Profile("performanceTest")
public class FakeLeelaClaimDataRetrieverService implements ClaimDataRetrieverServiceInterface {

    @Override
    public ClaimData getClaimData(String claimNumber, String uriVariables) {
        try {
            String path = "data/jmeter/leelastubs/" + claimNumber +".json";
            URL url = Resources.getResource(path);

            RetrieveClaimDataResponse fakeLeelaResponse = new ObjectMapper().readValue(Resources.toString(url, Charsets.UTF_8), RetrieveClaimDataResponse.class);
            return fakeLeelaResponse.getClaimData();
        } catch (IOException ignored) {
        }
        return null;
    }
}
