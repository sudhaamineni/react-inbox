package com.allstate.cts.loon.org.service;

import com.allstate.cts.loon.exception.OrgDataException;
import com.allstate.cts.loon.org.model.OrgData;
import com.allstate.cts.loon.org.model.OrgDataResponse;
import com.allstate.cts.loon.resttemplate.LoonRestTemplate;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class OrgDataService {
    private final LoonRestTemplate orgDataRestTemplate;

    public OrgDataService(LoonRestTemplate orgDataRestTemplate) {
        this.orgDataRestTemplate = orgDataRestTemplate;
    }

    @Cacheable(cacheNames = "orgUsers", key = "#ntId")
    public OrgData getOrgData(String ntId) {
        try {
            return orgDataRestTemplate.getObject(
                OrgDataResponse.class,
                ntId.toUpperCase(),
                ntId.toUpperCase())
                .getOrgData();
        } catch (Exception ex) {
            throw new OrgDataException(ntId);
        }
    }
}
