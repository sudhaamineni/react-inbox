package com.allstate.cts.loon.eligibility.service;

import com.allstate.cts.loon.claimData.model.ClaimData;
import com.allstate.cts.loon.constants.LoonConstants;
import com.allstate.cts.loon.eligibility.helpers.ClaimComplexityHelper;
import com.allstate.cts.loon.helpers.DateTimeHelper;
import com.allstate.cts.loon.liabilityAnalysis.entity.LiabilityAnalysisEntity;
import com.allstate.cts.loon.liabilityAnalysis.service.LiabilityAnalysisService;
import com.allstate.cts.loon.liabilityAnalysis.service.RetrieveLiabilityAnalysisDataService;
import com.allstate.cts.loon.liabilityScorePublisher.service.RavenLiabilityScorePublisherService;
import org.springframework.stereotype.Service;

@Service
public class NonComplexLiabilityAnalysisService {
    private LiabilityAnalysisService liabilityAnalysisService;
    private RetrieveLiabilityAnalysisDataService retrieveLiabilityAnalysisDataService;
    private RavenLiabilityScorePublisherService ravenLiabilityScorePublisherService;
    private DateTimeHelper dateTimeHelper;

    public NonComplexLiabilityAnalysisService(LiabilityAnalysisService liabilityAnalysisService,
                                              DateTimeHelper dateTimeHelper,
                                              RetrieveLiabilityAnalysisDataService retrieveLiabilityAnalysisDataService,
                                              RavenLiabilityScorePublisherService ravenLiabilityScorePublisherService) {
        this.liabilityAnalysisService = liabilityAnalysisService;
        this.dateTimeHelper = dateTimeHelper;
        this.retrieveLiabilityAnalysisDataService = retrieveLiabilityAnalysisDataService;
        this.ravenLiabilityScorePublisherService = ravenLiabilityScorePublisherService;
    }

    public void processNonComplexAssignment(ClaimData claimData) {
        LiabilityAnalysisEntity liabilityAnalysisEntity = retrieveLiabilityAnalysisDataService.getLiabilityAnalysisData(claimData.getClaim().getClaimNumber());
        liabilityAnalysisEntity.setIsComplex(false);
        liabilityAnalysisEntity.setCreatedTime(dateTimeHelper.getCurrentDateTime());
        liabilityAnalysisEntity.setStatus(LoonConstants.SAVED);
        liabilityAnalysisService.save(liabilityAnalysisEntity);

        try {
            ravenLiabilityScorePublisherService.publishLiabilityScore(liabilityAnalysisEntity, false);
        } catch (Exception ex) {
            // do nothing - publishLiabilityScoreWithRetry handles exceptions
        }
    }
}