package com.allstate.cts.loon.exception;

public class InvalidClaimException extends RuntimeException implements CustomException {
    private final String msgHeader;
    private final String msgDescription;

    public InvalidClaimException(String claimNumber) {
        this.msgHeader = "Claim #" + claimNumber + " does not qualify for analysis";
        this.msgDescription = "This claim does not qualify for analysis in Loon.";
    }

    @Override
    public String getMessageHeader() {
        return this.msgHeader;
    }

    @Override
    public String getMessageDescription() {
        return this.msgDescription;
    }
}