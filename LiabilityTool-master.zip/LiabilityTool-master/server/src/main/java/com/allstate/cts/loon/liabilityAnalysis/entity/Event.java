package com.allstate.cts.loon.liabilityAnalysis.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Event {
    @Field("id")
    private String id;
    private String title;
    private Integer severity;
    private Date faultAllocationPercentSaveTime;

    @Builder.Default
    private List<InvolvedParty> involvedParties = new ArrayList<>();
}
