package com.allstate.cts.loon.liabilityAnalysis.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ParticipantEntity {
    private String participantPartyId;
    private String participantSourceId;
    private String firstName;
    private String lastName;
    private String organizationName;
    private String role;
    private boolean isDriver;

    public String getName() {
        if (organizationName != null && !organizationName.trim().equals("")) {
            return organizationName;
        }

        if ((firstName == null || firstName.trim().equals("")) && (lastName == null || lastName.trim().equals(""))) {
            return "UNKNOWN";
        }

        String name = "";

        if (firstName != null && firstName.trim().length() > 0) {
            name += firstName.trim() + " ";
        }
        if (lastName != null) {
            name += lastName.trim();
        }

        return name;
    }
}
