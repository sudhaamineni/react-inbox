package com.allstate.cts.loon.assignment.controller;


import com.allstate.cts.loon.assignment.service.AssignmentService;
import com.allstate.cts.loon.liabilityAnalysis.entity.LiabilityAnalysisEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static com.allstate.cts.loon.constants.LoonConstants.ASSIGNED;
import static com.allstate.cts.loon.constants.LoonConstants.READY_FOR_ASSIGNMENT;

@Controller
@RestController
@RequestMapping("/api/v1/assignment")
public class AssignmentController {
    private final AssignmentService assignmentService;

    public AssignmentController(AssignmentService assignmentService) {
        this.assignmentService = assignmentService;
    }

    @GetMapping("/next")
    public LiabilityAnalysisEntity getNextAssignment() {
        return assignmentService.getNextAssignment();
    }

    @PostMapping("/status/a-rfa")
    public void updateStatusFromAssignedToReadyForAssignment() {
        assignmentService.updateAssignmentStatus(ASSIGNED, READY_FOR_ASSIGNMENT);
    }
}
