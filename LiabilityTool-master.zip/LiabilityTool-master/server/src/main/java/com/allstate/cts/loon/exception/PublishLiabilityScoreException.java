package com.allstate.cts.loon.exception;

public class PublishLiabilityScoreException extends RuntimeException implements CustomException {

    private final String msgHeader;
    private final String msgDescription;

    public PublishLiabilityScoreException() {
        this.msgHeader = "";
        this.msgDescription = "Unable to publish score to Raven.";
    }

    @Override
    public String getMessageHeader() {
        return this.msgHeader;
    }

    @Override
    public String getMessageDescription() { return this.msgDescription; }
}
