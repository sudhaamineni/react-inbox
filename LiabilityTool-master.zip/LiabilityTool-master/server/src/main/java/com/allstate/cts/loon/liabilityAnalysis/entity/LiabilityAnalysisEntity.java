package com.allstate.cts.loon.liabilityAnalysis.entity;

import com.allstate.cts.loon.claimData.model.ClaimResetInformation;
import com.allstate.cts.loon.liabilityAnalysis.entity.damageapportionment.DamageApportionment;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "LiabilityAnalysis")
public class LiabilityAnalysisEntity {
    @Id
    private String id;
    private String claimId;
    private String claimSourceId;
    private String claimNumber;
    private String lossDetailTypeCode;
    private String lossDetailType;
    private String negligenceRuleFromClaimSource;
    private String lossStreet;
    private String lossAddress;
    private String lossCity;
    private String lossState;
    private String lossZip;
    private String lossCountyDescription;
    private String mapAddress;
    private String updatedLossLocation;
    private Double longitude;
    private Double latitude;
    private String theoryOfDefenseAdditionalNotes;
    private Date updatedTime;
    private Date initialFaultSubmitTime;
    private Date settlementSubmitTime;
    private boolean locked;
    private String unlockReason;
    private String unlockDescription;
    private String lastModifiedByUserId;
    private String createdByUserId;
    private String lossDate;
    private String lossTime;
    private String status;
    private Date createdTime;
    private Date assignedTime;
    private String assignedUser;
    private String lineOfBusinessCode;
    private String lineOfBusiness;
    private Date claimOpenedDate;
    private AppVersion appVersion;
    private DataVersion dataVersion;


    @Builder.Default
    private Boolean isComplex = true;
    private boolean resetClaimVoiceSynced;
    private boolean noFaultAllocationAgreement;
    private boolean noFaultAllocationResponse;
    private List<ClaimResetInformation> resetClaims;

    @Builder.Default
    private List<ParticipantEntity> participants = new ArrayList<>();

    @Builder.Default
    private List<LiabilitySubject> liabilitySubjects = new ArrayList<>();

    @Builder.Default
    private List<VoiceAttachment> voiceAttachments = new ArrayList<>();

    @Builder.Default
    private List<Event> events = new ArrayList<>();

    private Sketch sketch;
    private DamageApportionment apportionedInitialFault;
    private DamageApportionment apportionedAllocatedFault;
    private Date apportionedAllocatedFaultSaveTime;

    @Builder.Default
    private List<Evidence> evidences = new ArrayList<>();
}
