package com.allstate.cts.loon.liabilityAnalysis.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InvolvedParty {
    private String participantId;
    private String participantSourceId;
    private String assetId;
    private List<String> passengerPartyIds;

    @Builder.Default
    private List<String> damageSections = new ArrayList<>();

    @Builder.Default
    private List<ContributingFactorEntity> contributingFactors = new ArrayList<>();

    @Builder.Default
    private List<AffectedParty> affectedParties = new ArrayList<>();
}