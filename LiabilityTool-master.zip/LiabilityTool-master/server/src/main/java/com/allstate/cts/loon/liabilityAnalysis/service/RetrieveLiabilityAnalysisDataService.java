package com.allstate.cts.loon.liabilityAnalysis.service;

import com.allstate.cts.loon.claimData.model.Address;
import com.allstate.cts.loon.claimData.model.ClaimData;
import com.allstate.cts.loon.claimData.model.Participant;
import com.allstate.cts.loon.claimData.model.Performer;
import com.allstate.cts.loon.claimData.service.ClaimDataRetrieverServiceInterface;
import com.allstate.cts.loon.constants.LoonConstants;
import com.allstate.cts.loon.constants.ValidClaimStatuses;
import com.allstate.cts.loon.exception.*;
import com.allstate.cts.loon.helpers.*;
import com.allstate.cts.loon.liabilityAnalysis.entity.*;
import com.allstate.cts.loon.startup.service.UserService;
import io.spring.gradle.dependencymanagement.org.codehaus.plexus.util.StringUtils;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

import static com.allstate.cts.loon.constants.InvalidLossTypeCodes.containsCode;
import static com.allstate.cts.loon.constants.LoonConstants.*;
import static java.util.Arrays.asList;
import static java.util.Collections.singletonList;
import static java.util.Collections.sort;
import static java.util.stream.Collectors.toList;
import static org.apache.commons.lang3.EnumUtils.isValidEnum;

@Service
public class RetrieveLiabilityAnalysisDataService {
    private LiabilityAnalysisService liabilityAnalysisService;
    private ClaimDataRetrieverServiceInterface claimDataRetrieverServiceInterface;
    private ClaimDataModelHelper claimDataModelHelper;
    private LiabilitySubjectConverter liabilitySubjectConverter;
    private AddressHelper addressHelper;
    private DateTimeHelper dateTimeHelper;
    private Validator validator;
    private UserService userService;
    private AppVersion appVersion;
    private DataVersion dataVersion;

    public RetrieveLiabilityAnalysisDataService(LiabilityAnalysisService liabilityAnalysisService,
                                                ClaimDataRetrieverServiceInterface claimDataRetrieverServiceInterface,
                                                ClaimDataModelHelper claimDataModelHelper,
                                                LiabilitySubjectConverter liabilitySubjectConverter,
                                                AddressHelper addressHelper,
                                                DateTimeHelper dateTimeHelper,
                                                Validator validator,
                                                UserService userService,
                                                AppVersion appVersion,
                                                DataVersion dataVersion
    ) {
        this.liabilityAnalysisService = liabilityAnalysisService;
        this.claimDataRetrieverServiceInterface = claimDataRetrieverServiceInterface;
        this.claimDataModelHelper = claimDataModelHelper;
        this.liabilitySubjectConverter = liabilitySubjectConverter;
        this.addressHelper = addressHelper;
        this.dateTimeHelper = dateTimeHelper;
        this.validator = validator;
        this.userService = userService;
        this.appVersion = appVersion;
        this.dataVersion = dataVersion;
    }

    public LiabilityAnalysisEntity getLiabilityAnalysisData(String claimNumber) {
        if (!validator.isStringSafeForLeela(claimNumber)) {
            throw new InvalidCharacterException(claimNumber);
        }
        Optional<LiabilityAnalysisEntity> liabilityAnalysisEntityFromDB = liabilityAnalysisService.findLiabilityAnalysisData(StringUtils.leftPad(claimNumber, 12, "0"));
        LiabilityAnalysisEntity liabilityAnalysisEntityFromLeela = null;
        try {
            ClaimData claimData = claimDataRetrieverServiceInterface.getClaimData(claimNumber, "claim,asset,participant,performer,claimReset");
            if (claimData != null) {
                liabilityAnalysisEntityFromLeela = buildLiabilityAnalysisEntity(claimData, claimNumber);
            } else if (!liabilityAnalysisEntityFromDB.isPresent()) {
                throw new ClaimNotFoundException(claimNumber);
            }
        } catch (ClaimResetException | ClaimNotFoundException | InvalidClaimException | SystemErrorException | UnauthorizedClaimException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new SystemErrorException();
        }
        LiabilityAnalysisEntity liabilityAnalysisEntity = updatedLiabilityAnalysisEntity(liabilityAnalysisEntityFromLeela, liabilityAnalysisEntityFromDB);
        if (!StringUtils.isEmpty(liabilityAnalysisEntity.getStatus()) && LoonConstants.ASSIGNED.equals(liabilityAnalysisEntity.getStatus())) {
            liabilityAnalysisEntity.setStatus(LoonConstants.IN_PROGRESS);
        }
        createEvent(liabilityAnalysisEntity);
        liabilityAnalysisEntity.setLastModifiedByUserId(userService.getUserName());
        return liabilityAnalysisService.save(liabilityAnalysisEntity);
    }

    public LiabilityAnalysisEntity updatedLiabilityAnalysisEntity(LiabilityAnalysisEntity liabilityAnalysisEntityFromLeela, Optional<LiabilityAnalysisEntity> liabilityAnalysisEntityFromDB) {
        LiabilityAnalysisEntity liabilityAnalysisEntity = LiabilityAnalysisEntity.builder().build();
        if (liabilityAnalysisEntityFromDB.isPresent() && liabilityAnalysisEntityFromLeela != null) {
            liabilityAnalysisEntity = getUpdatedLiabilityAnalysis(liabilityAnalysisEntityFromLeela, liabilityAnalysisEntityFromDB.get());
        } else if (liabilityAnalysisEntityFromDB.isPresent()) {
            liabilityAnalysisEntity = liabilityAnalysisEntityFromDB.get();
        } else if (liabilityAnalysisEntityFromLeela != null) {
            liabilityAnalysisEntity = liabilityAnalysisEntityFromLeela;
            liabilityAnalysisEntity.setCreatedByUserId(userService.getUserName());
        }

        liabilityAnalysisEntity.setAppVersion(this.appVersion);
        liabilityAnalysisEntity.setDataVersion(this.dataVersion);
        return liabilityAnalysisEntity;
    }

    public LiabilityAnalysisEntity getUpdatedLiabilityAnalysis(LiabilityAnalysisEntity liabilityAnalysisEntityFromLeela, LiabilityAnalysisEntity liabilityAnalysisEntityFromDB) {
        List<LiabilitySubject> participantsFromLeela = liabilityAnalysisEntityFromLeela.getLiabilitySubjects();
        List<LiabilitySubject> participantsFromDb = liabilityAnalysisEntityFromDB.getLiabilitySubjects();

        List<ParticipantEntity> claimParticipantsFromLeela = liabilityAnalysisEntityFromLeela.getParticipants();
        List<ParticipantEntity> claimParticipantsFromDb = liabilityAnalysisEntityFromDB.getParticipants();

        liabilityAnalysisEntityFromLeela.setId(liabilityAnalysisEntityFromDB.getId());
        liabilityAnalysisEntityFromLeela.setNoFaultAllocationAgreement(liabilityAnalysisEntityFromDB.isNoFaultAllocationAgreement());
        liabilityAnalysisEntityFromLeela.setNoFaultAllocationResponse(liabilityAnalysisEntityFromDB.isNoFaultAllocationResponse());
        liabilityAnalysisEntityFromLeela.setTheoryOfDefenseAdditionalNotes(liabilityAnalysisEntityFromDB.getTheoryOfDefenseAdditionalNotes());
        liabilityAnalysisEntityFromLeela.setCreatedTime(liabilityAnalysisEntityFromDB.getCreatedTime());
        liabilityAnalysisEntityFromLeela.setUpdatedTime(dateTimeHelper.getCurrentDateTime());
        liabilityAnalysisEntityFromLeela.setInitialFaultSubmitTime(liabilityAnalysisEntityFromDB.getInitialFaultSubmitTime());
        liabilityAnalysisEntityFromLeela.setLocked(liabilityAnalysisEntityFromDB.isLocked());
        liabilityAnalysisEntityFromLeela.setLastModifiedByUserId(liabilityAnalysisEntityFromDB.getLastModifiedByUserId());
        liabilityAnalysisEntityFromLeela.setUpdatedLossLocation(liabilityAnalysisEntityFromDB.getUpdatedLossLocation());
        liabilityAnalysisEntityFromLeela.setLongitude(liabilityAnalysisEntityFromDB.getLongitude());
        liabilityAnalysisEntityFromLeela.setLatitude(liabilityAnalysisEntityFromDB.getLatitude());

        liabilityAnalysisEntityFromLeela.setAssignedTime(liabilityAnalysisEntityFromDB.getAssignedTime());
        liabilityAnalysisEntityFromLeela.setAssignedUser(liabilityAnalysisEntityFromDB.getAssignedUser());
        liabilityAnalysisEntityFromLeela.setStatus(liabilityAnalysisEntityFromDB.getStatus());

        liabilityAnalysisEntityFromLeela.setSketch(liabilityAnalysisEntityFromDB.getSketch());

        liabilityAnalysisEntityFromLeela.setVoiceAttachments(liabilityAnalysisEntityFromDB.getVoiceAttachments());
        liabilityAnalysisEntityFromLeela.setEvents(liabilityAnalysisEntityFromDB.getEvents());
        liabilityAnalysisEntityFromLeela.setApportionedInitialFault(liabilityAnalysisEntityFromDB.getApportionedInitialFault());
        liabilityAnalysisEntityFromLeela.setApportionedAllocatedFaultSaveTime(liabilityAnalysisEntityFromDB.getApportionedAllocatedFaultSaveTime());
        liabilityAnalysisEntityFromLeela.setApportionedAllocatedFault(liabilityAnalysisEntityFromDB.getApportionedAllocatedFault());
        liabilityAnalysisEntityFromLeela.setEvidences(liabilityAnalysisEntityFromDB.getEvidences());

        participantsFromLeela.forEach(decisionLeela ->
                participantsFromDb.forEach(decisionDb -> {
                    if (decisionLeela.getParticipantSourceId().equals(decisionDb.getParticipantSourceId())) {
                        decisionLeela.setPhotoAttachments(decisionDb.getPhotoAttachments());
                    }
                })
        );

        if (claimParticipantsFromDb != null) {
            for (ParticipantEntity decisionDb : claimParticipantsFromDb) {
                boolean participantExistsInLeela = false;
                for (ParticipantEntity decisionLeela : claimParticipantsFromLeela) {
                    if (decisionLeela.getParticipantSourceId().equals(decisionDb.getParticipantSourceId())) {
                        participantExistsInLeela = true;
                    }
                }
                if (!participantExistsInLeela) {
                    claimParticipantsFromLeela.add(decisionDb);
                }
            }
        }
        return liabilityAnalysisEntityFromLeela;
    }

    public LiabilityAnalysisEntity buildLiabilityAnalysisEntity(ClaimData claimData, String claimNumber) {
        validateClaimForLoon(claimData, claimNumber);

        validateClaimAuthorization(claimData);

        validateResetClaim(claimData);

        List<ParticipantEntity> participants = createParticipants(claimData);

        List<LiabilitySubject> liabilitySubjects = createLiabilitySubjects(claimData, participants);

        return LiabilityAnalysisEntity
                .builder()
                .claimId(claimData.getClaim().getClaimId())
                .claimNumber(claimData.getClaim().getClaimNumber())
                .claimSourceId(claimData.getClaim().getClaimId())
                .lossDetailTypeCode(claimData.getClaim().getLossDetailTypeCode())
                .lossDetailType(claimData.getClaim().getLossDetailType())
                .lossState(claimData.getClaim().getLossState())
                .lossStreet(claimData.getClaim().getLossStreet())
                .lossCity(claimData.getClaim().getLossCity())
                .lossZip(claimData.getClaim().getLossZip())
                .lossCountyDescription(claimData.getClaim().getLossCountyDescription())
                .lossAddress(claimData.getClaim().getLossAddress())
                .mapAddress(addressHelper.createAddress(Address.builder().street(claimData.getClaim().getLossStreet())
                        .city(claimData.getClaim().getLossCity())
                        .state(claimData.getClaim().getLossState())
                        .zip(claimData.getClaim().getLossZip())
                        .county(claimData.getClaim().getLossCountyDescription())
                        .build()))
                .negligenceRuleFromClaimSource(claimData.getClaim().getNegligenceRule())
                .liabilitySubjects(liabilitySubjects)
                .participants(participants)
                .lossDate(dateTimeHelper.dateTimeToDateConverter(claimData.getClaim().getLossDate()))
                .lossTime(dateTimeHelper.dateTimeToTimeConverter(claimData.getClaim().getLossTime()))
                .lineOfBusinessCode(claimData.getClaim().getLineOfBusinessCode())
                .lineOfBusiness(AUTO_PERSONAL_CODE.equals(claimData.getClaim().getLineOfBusinessCode()) ? "Auto - Personal" : null)
                .claimOpenedDate(dateTimeHelper.getDate(claimData.getClaim().getClaimOpenedDate()))
                .resetClaims(claimData.getClaimReset() != null ? claimData.getClaimReset().getClaimResetList() : null)
                .build();
    }

    private void validateClaimForLoon(ClaimData claimData, String claimNumber) {
        if (claimData.getClaim() == null) {
            throw new InvalidClaimException(claimNumber);
        }
        if (containsCode(claimData.getClaim().getLossTypeCode())) {
            throw new InvalidClaimException(claimNumber);
        }
        if (!AUTO_PERSONAL_CODE.equals(claimData.getClaim().getLineOfBusinessCode())) {
            throw new InvalidClaimException(claimNumber);
        }
        if (!isValidEnum(ValidClaimStatuses.class, claimData.getClaim().getClaimStatus())) {
            throw new InvalidClaimException(claimNumber);
        }
    }

    private void validateClaimAuthorization(ClaimData claimData) {
        if (SENSITIVE.equalsIgnoreCase(claimData.getClaim().getClaimSensitivity())
                && !isPerformer(claimData.getPerformers())) {
            throw new UnauthorizedClaimException();
        }
    }

    private void validateResetClaim(ClaimData claimData) {
        if (claimData.getClaimReset() != null && claimData.getClaimReset().getClaimResetList() != null && !claimData.getClaimReset().getClaimResetList().isEmpty()) {
            claimData.getClaimReset().getClaimResetList().forEach(a -> {
                if (!a.getClaimNumber().equalsIgnoreCase(claimData.getClaim().getClaimNumber()) && a.getResetOnDate() == null) {
                    throw new ClaimResetException(a.getClaimNumber());
                }
            });
        }
    }

    private boolean isPerformer(List<Performer> performers) {
        if (null != performers && !performers.isEmpty() && null != userService.getUserName()) {
            for (Performer performer : performers) {
                if (null != performer.getOrg()) {
                    if (userService.getUserName().equalsIgnoreCase(performer.getOrg().getNtid())) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private List<LiabilitySubject> createLiabilitySubjects(ClaimData claimData, List<ParticipantEntity> participants) {
        List<LiabilitySubject> liabilitySubjects = new ArrayList<>();
        Set<String> addedIds = new HashSet<>();

        claimData.getAsset().forEach(asset -> {

            List<Participant> assetAllParticipants = asset.getParticipants().stream().map(assetParticipant ->
                    claimDataModelHelper.getMatchingParticipant(assetParticipant, claimData.getParticipants())).collect(Collectors.toList());

            asset.getParticipants().forEach(assetParticipant -> {
                Participant matchingParticipant = claimDataModelHelper.getMatchingParticipant(assetParticipant, claimData.getParticipants());

                if (matchingParticipant.isInsured()
                        || matchingParticipant.isClaimantAndOwner()
                        || matchingParticipant.isPedestrianBicyclist()) {
                    LiabilitySubject claimantDetail = liabilitySubjectConverter.convertLiabilitySubject(matchingParticipant, asset, assetAllParticipants, matchingParticipant.getRole(), participants);
                    addedIds.add(claimantDetail.getParticipantPartyId());
                    liabilitySubjects.add(claimantDetail);
                }
            });
        });

        claimData.getParticipants().forEach(p -> {
            if (p.isPedestrianBicyclist() && !addedIds.contains(p.getLegacyInvolvedId())) {
                liabilitySubjects.add(liabilitySubjectConverter.convertLiabilitySubject(p, null, new ArrayList<>(), p.getRole(), new ArrayList<>()));
            }
        });
        sort(liabilitySubjects);
        return liabilitySubjects;
    }

    private List<ParticipantEntity> createParticipants(ClaimData claimData) {
        List<ParticipantEntity> participants = new ArrayList<>();
        claimData.getParticipants().forEach(p -> {
            ParticipantEntity participant = ParticipantEntity.builder()
                    .participantPartyId(p.getLegacyInvolvedId())
                    .participantSourceId(p.getInsInvolvementId())
                    .firstName(p.getClient().getFirstName())
                    .lastName(p.getClient().getLastName())
                    .organizationName(p.getClient().getOrganizationName())
                    .role(p.getRole())
                    .isDriver(p.isDriver())
                    .build();
            participants.add(participant);
        });
        return participants;
    }

    private void createEvent(LiabilityAnalysisEntity liabilityAnalysisEntity) {
        if (liabilityAnalysisEntity.getEvents().isEmpty()
                && !liabilityAnalysisEntity.getLiabilitySubjects().isEmpty()
                && liabilityAnalysisEntity.getLiabilitySubjects().size() <= 2) {
            LiabilitySubject insured = liabilityAnalysisEntity.getLiabilitySubjects().get(0);
            Event event = Event.builder()
                    .id(Long.toString(dateTimeHelper.getCurrentDateTime().toInstant().toEpochMilli()))
                    .build();
            List<String> insuredPassengers = getPassengerPartyIds(liabilityAnalysisEntity.getLiabilitySubjects(), insured.getParticipantSourceId());

            if (liabilityAnalysisEntity.getLiabilitySubjects().size() == 2) {
                LiabilitySubject claimant = liabilityAnalysisEntity.getLiabilitySubjects().get(1);
                List<String> claimantPassengers = getPassengerPartyIds(liabilityAnalysisEntity.getLiabilitySubjects(), claimant.getParticipantSourceId());

                AffectedParty affectedClaimantParticipant = AffectedParty.builder()
                        .participantId(claimant.getParticipantPartyId())
                        .participantSourceId(claimant.getParticipantSourceId())
                        .assetId(claimant.getAsset().getVehicleItemId())
                        .passengerPartyIds(claimantPassengers)
                        .build();

                AffectedParty affectedInsuredParticipant = AffectedParty.builder()
                        .participantId(insured.getParticipantPartyId())
                        .participantSourceId(insured.getParticipantSourceId())
                        .assetId(insured.getAsset().getVehicleItemId())
                        .passengerPartyIds(insuredPassengers)
                        .build();

                InvolvedParty involvedParty1 = liabilitySubjectToInvolvedParty(
                        insured,
                        insuredPassengers,
                        singletonList(affectedClaimantParticipant)
                );

                InvolvedParty involvedParty2 = liabilitySubjectToInvolvedParty(
                        claimant,
                        getPassengerPartyIds(liabilityAnalysisEntity.getLiabilitySubjects(), claimant.getParticipantSourceId()),
                        singletonList(affectedInsuredParticipant));

                event.setInvolvedParties(asList(involvedParty1, involvedParty2));
            } else if (liabilityAnalysisEntity.getLiabilitySubjects().size() == 1) {
                InvolvedParty involvedParty = InvolvedParty.builder()
                        .participantId(insured.getParticipantPartyId())
                        .participantSourceId(insured.getParticipantSourceId())
                        .affectedParties(singletonList(AffectedParty.builder().build()))
                        .assetId(insured.getAsset().getVehicleItemId())
                        .passengerPartyIds(insuredPassengers)
                        .build();
                event.setInvolvedParties(singletonList(involvedParty));
            }
            liabilityAnalysisEntity.setEvents(singletonList(event));
        }
    }

    private List<String> getPassengerPartyIds(List<LiabilitySubject> liabilitySubjects, String sourceId) {
        List<String> passengerPartyIds = new ArrayList<>();
        List<ParticipantEntity> passengers = getPassengers(getLiabilitySubjectByParticipantSourceId(liabilitySubjects, sourceId));
        if (!passengers.isEmpty()) {
            passengerPartyIds.addAll(passengers.stream().map(ParticipantEntity::getParticipantPartyId).collect(toList()));
        }
        return passengerPartyIds;
    }

    private LiabilitySubject getLiabilitySubjectByParticipantSourceId(List<LiabilitySubject> liabilitySubjects, String id) {
        return liabilitySubjects.stream().filter(ls -> ls.getParticipantSourceId().equalsIgnoreCase(id)).findFirst().get();
    }

    private List<ParticipantEntity> getPassengers(LiabilitySubject ls) {
        return ls.getRelatedParticipants().stream().filter(p -> PASSENGER_CAPS.equalsIgnoreCase(p.getRole())).collect(toList());
    }

    private InvolvedParty liabilitySubjectToInvolvedParty(LiabilitySubject liabilitySubject, List<String> passengers, List<AffectedParty> affectedParties) {
        InvolvedParty involvedParty = InvolvedParty.builder()
                .participantId(liabilitySubject.getParticipantPartyId())
                .participantSourceId(liabilitySubject.getParticipantSourceId())
                .assetId(liabilitySubject.getAsset().getVehicleItemId())
                .passengerPartyIds(passengers)
                .affectedParties(affectedParties)
                .build();
        if (liabilitySubject.getAsset().getAssetTypeDescription().equals(PED_BIKE_CAPS)) {
            List<String> damages = singletonList("HAS_DAMAGES");
            involvedParty.setDamageSections(damages);
        }
        return involvedParty;
    }
}
