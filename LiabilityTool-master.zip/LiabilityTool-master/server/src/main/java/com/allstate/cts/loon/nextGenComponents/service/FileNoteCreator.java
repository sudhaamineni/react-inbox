package com.allstate.cts.loon.nextGenComponents.service;

import com.allstate.cts.loon.helpers.ClaimDataModelHelper;
import com.allstate.cts.loon.liabilityAnalysis.entity.LiabilityAnalysisEntity;
import com.allstate.cts.loon.liabilityAnalysis.entity.damageapportionment.CollectingParty;
import com.allstate.cts.loon.nextGenComponents.model.FileNote;
import com.allstate.cts.loon.nextGenComponents.model.FilenoteParticipant;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

import static com.allstate.cts.loon.constants.LoonConstants.EMPTY;
import static com.allstate.cts.loon.constants.LoonConstants.INSURED_CAPS;
import static java.util.Collections.singletonList;

@Service
public class FileNoteCreator {
    private ClaimDataModelHelper claimDataModelHelper;

    public FileNoteCreator(ClaimDataModelHelper claimDataModelHelper) {
        this.claimDataModelHelper = claimDataModelHelper;
    }

    public FileNote createSubmitSettlementFileNote(LiabilityAnalysisEntity liabilityAnalysisEntity) {
        String additionalNotes = EMPTY;
        List<FilenoteParticipant> participantList = new ArrayList<>();
        StringBuilder owingPartiesText = new StringBuilder();
        participantList.add(FilenoteParticipant
            .builder()
            .sInsInvlID(liabilityAnalysisEntity.getLiabilitySubjects().stream().filter(p -> INSURED_CAPS.equals(p.getRole())).findFirst().get().getParticipantSourceId())
            .build());

        if (liabilityAnalysisEntity.getApportionedAllocatedFault() != null
            && liabilityAnalysisEntity.getApportionedAllocatedFault().getOwingParties() != null) {
            liabilityAnalysisEntity.getApportionedAllocatedFault().getOwingParties().forEach(a -> {
                String toAppend = "<b>";
                toAppend += claimDataModelHelper.getParticipantNameByParticipantId(a.getParticipantId(), liabilityAnalysisEntity.getLiabilitySubjects());
                toAppend += " owes damages to: </b><br>";

                List<CollectingParty> collectingPartyList = a.getCollectingParties();

                for (int i = 0; i < collectingPartyList.size(); i++) {
                    String allocation = "";
                    CollectingParty current = collectingPartyList.get(i);
                    toAppend += claimDataModelHelper.getParticipantNameByParticipantId(current.getParticipantId(), liabilityAnalysisEntity.getLiabilitySubjects());
                    toAppend += " - ";
                    for (int j = 0; j < current.getDamages().size(); j++) {
                        toAppend += current.getDamages().get(j).getAllocation() + "% " + allocation + current.getDamages().get(j).getDamageLocation() + " ";
                    }
                    toAppend += "<br>";
                }

                owingPartiesText.append(toAppend);
            });
        }

        String description = null;
        if (liabilityAnalysisEntity.isNoFaultAllocationResponse()) {
            description = "Allstate has been unable to contact the other party/TPC to discuss liability.";
            additionalNotes = "<P><b>Allstate has been unable to contact the other party/TPC to discuss liability.</b></P>";
        } else if (liabilityAnalysisEntity.isNoFaultAllocationAgreement()) {
            description = "Allstate is not able to reach a liability agreement with the other party/TPC.";
            additionalNotes = "<P><b>Allstate is not able to reach a liability agreement with the other party/TPC.</b></P>";
        } else if (liabilityAnalysisEntity.getApportionedAllocatedFault() != null) {
            description = "Allstate has reached a final liability agreement with other party/TPC.";
            additionalNotes = "<P><b>Allstate has reached a final liability agreement with other party/TPC.</b></P>";
            additionalNotes += "<P><b>Damage apportionment based on the state negligence rules in " + liabilityAnalysisEntity.getLossState() + ": </b><br/></P>";
            additionalNotes += owingPartiesText;
        }
        return FileNote
            .builder()
            .ClaimNumber(liabilityAnalysisEntity.getClaimNumber())
            .ClaimID(liabilityAnalysisEntity.getClaimSourceId())
            .Categories(singletonList("LIA"))
            .Participants(participantList)
            .Description(description)
            .Comments("Comments")
            .ShortText("ShortText")
            .StandardText("StandardText")
            .AttachmentExists(false)
            .AdditionalNotes(additionalNotes)
            .build();
    }
}
