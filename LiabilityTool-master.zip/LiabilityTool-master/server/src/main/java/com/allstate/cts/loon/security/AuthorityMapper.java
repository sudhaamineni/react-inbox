package com.allstate.cts.loon.security;

import com.allstate.cts.loon.org.model.OrgRole;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static com.allstate.cts.loon.constants.SecurityConstants.*;

@Component
public class AuthorityMapper {
    public Set<SimpleGrantedAuthority> getAuthoritiesForLoonUserOrgRole(List<OrgRole> orgRoles) {
        Set<SimpleGrantedAuthority> authorities = new HashSet<>();
        if (orgRoles != null && !orgRoles.isEmpty()) {
            orgRoles.forEach(orgRole -> {
                if (orgRole != null && orgRole.getRoleDescription() != null) {
                    switch (orgRole.getRoleDescription()) {
                        case ORG_ROLE_LOON_USER:
                            authorities.add(new SimpleGrantedAuthority(ORG_ROLE_LOON_USER));
                            break;

                        case ORG_ROLE_LOON_READ_ONLY_USER:
                            authorities.add(new SimpleGrantedAuthority(ORG_ROLE_LOON_READ_ONLY_USER));
                            break;

                        default:
                            break;
                    }
                }
            });
        }
        return authorities;
    }
}