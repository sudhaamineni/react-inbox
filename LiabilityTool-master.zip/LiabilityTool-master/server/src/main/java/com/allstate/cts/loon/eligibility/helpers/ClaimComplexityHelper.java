package com.allstate.cts.loon.eligibility.helpers;

import com.allstate.cts.loon.claimData.model.ClaimData;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

import static com.allstate.cts.loon.constants.LoonConstants.*;

@Component
public class ClaimComplexityHelper {
    private  Map<String, Integer> detailLossTypesInsuredScoreNonComplexMap;

    ClaimComplexityHelper() {
        initializeNonComplexMap();
    }

    private void initializeNonComplexMap() {
        detailLossTypesInsuredScoreNonComplexMap = new HashMap<>();
        detailLossTypesInsuredScoreNonComplexMap.put(INSD_HIT_A_FIXED_OBJECT, 100);
        detailLossTypesInsuredScoreNonComplexMap.put(INSD_HIT_PARKED_PART, 100);
        detailLossTypesInsuredScoreNonComplexMap.put(PART_HIT_PARKED_INSD, 0);
        detailLossTypesInsuredScoreNonComplexMap.put(PART_REARENDED_INSD, 0);
        detailLossTypesInsuredScoreNonComplexMap.put(DROVE_INTO_STANDING_WATER, 100);
        detailLossTypesInsuredScoreNonComplexMap.put(DRIVER_ASSAULT_CAR_JACK, 0);
        detailLossTypesInsuredScoreNonComplexMap.put(INJURED_ENTERING_EXITING, 100);
        detailLossTypesInsuredScoreNonComplexMap.put(INJURED_LOAD_UNLOAD_ASSET, 100);
        detailLossTypesInsuredScoreNonComplexMap.put(INSD_REAR_ENDED_PART, 100);
    }

    public boolean isNonComplexClaim(ClaimData claimData) {
        return (claimData != null &&
                claimData.getClaim() != null &&
                claimData.getClaim().getLossDetailTypeCode() != null &&
                detailLossTypesInsuredScoreNonComplexMap.containsKey(claimData.getClaim().getLossDetailTypeCode().trim().toUpperCase()))
                && isInsuredRearEndedParticipantAndSuddenStop(claimData);
    }

    private boolean isInsuredRearEndedParticipantAndSuddenStop(ClaimData claimData) {
        return !claimData.getClaim().getLossDetailTypeCode().trim().equals(INSD_REAR_ENDED_PART)|| !("Y").equals(claimData.getKeyFactAnswers().getVehStopInd());
}

    public Integer getNonComplexInsuredScore(String detailedLossTypeCode) {
        return (detailLossTypesInsuredScoreNonComplexMap.get(detailedLossTypeCode));
    }

    public Integer getNonComplexClaimantScore(String detailedLossTypeCode) {
        if (detailLossTypesInsuredScoreNonComplexMap.get(detailedLossTypeCode) == null) {
            return null;
        }
        return (Integer.valueOf(100)).equals(detailLossTypesInsuredScoreNonComplexMap.get(detailedLossTypeCode)) ? 0 : 100;
    }
}
