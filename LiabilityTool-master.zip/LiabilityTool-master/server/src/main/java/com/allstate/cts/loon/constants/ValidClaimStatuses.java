package com.allstate.cts.loon.constants;

public enum ValidClaimStatuses {
    Open, Closed
}