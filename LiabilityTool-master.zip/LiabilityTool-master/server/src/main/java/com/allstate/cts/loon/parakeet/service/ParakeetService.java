package com.allstate.cts.loon.parakeet.service;

import com.allstate.cts.loon.exception.SystemErrorException;
import com.allstate.cts.loon.parakeet.model.RecordedObjectsResponse;
import com.allstate.cts.loon.resttemplate.LoonRestTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;

import java.util.ArrayList;

@Service
public class ParakeetService {
    private LoonRestTemplate parakeetRestTemplate;

    public ParakeetService(LoonRestTemplate parakeetRestTemplate) {
        this.parakeetRestTemplate = parakeetRestTemplate;
    }

    public RecordedObjectsResponse getRecordedObjects(String claimNumber) {
        try {
            return parakeetRestTemplate.getObject(RecordedObjectsResponse.class, claimNumber, claimNumber);
        } catch (HttpClientErrorException e) {
            return RecordedObjectsResponse.builder()
                    .claimnumber(claimNumber)
                    .metadata(new ArrayList<>())
                    .build();
        } catch (Exception ex) {
            throw new SystemErrorException();
        }
    }
}