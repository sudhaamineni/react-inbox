package com.allstate.cts.loon.aspect;

import com.allstate.cts.loon.exception.UnauthorizedClaimException;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import static com.allstate.cts.loon.constants.SecurityConstants.ORG_ROLE_LOON_USER;

@Aspect
@Component
public class ValidateLoonUserRoleAspect {
    @Before("@annotation(ValidateLoonUserRole)")
    public void validateLoonUser() {
        for (Object o : ((UserDetails) (SecurityContextHolder.getContext().getAuthentication().getPrincipal())).getAuthorities()) {
            if (ORG_ROLE_LOON_USER.equalsIgnoreCase(((SimpleGrantedAuthority) o).getAuthority())) {
                return;
            }
        }
        throw new UnauthorizedClaimException();
    }
}
