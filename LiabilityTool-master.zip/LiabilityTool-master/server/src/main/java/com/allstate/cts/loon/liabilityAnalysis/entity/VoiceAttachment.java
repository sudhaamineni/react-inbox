package com.allstate.cts.loon.liabilityAnalysis.entity;

import com.allstate.cts.loon.highlight.entity.HighlightEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VoiceAttachment {
    private String sourceVoiceId;
    private String sourceVoiceTitle;
    private String sourceVoiceUrl;
    private String createdDate;
    private String sourceTranscriptUrl;
    private String sourceNlpUrl;
    private String participantSourceId;
    private String participantDisplayName;

    //PCI
    private Date reportedPciDate;
    private List<String> pciCategories;

    @Builder.Default
    private List<HighlightEntity> highlightEntities = new ArrayList<>();
}
