package com.allstate.cts.loon.claimData.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

import static java.util.Objects.nonNull;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Asset {
    private Vehicle vehicle;

    @Builder.Default
    private List<AssetParticipant> participants = new ArrayList<>();

    private Damages damages;

    @Builder.Default
    private String itemId = "";

    @Builder.Default
    private String assetTypeDescription = "";
}