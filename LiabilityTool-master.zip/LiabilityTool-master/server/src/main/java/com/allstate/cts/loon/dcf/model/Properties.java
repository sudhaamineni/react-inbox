package com.allstate.cts.loon.dcf.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

import static java.util.Objects.nonNull;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Properties {
    @Builder.Default
    @JsonProperty(value = "Document")
    private Document document = Document.builder().build();

    @Builder.Default
    private String allstate_participant = "";

    private List<String> allstate_participantID;

    @Builder.Default
    private List<String> allstate_documentCategory = new ArrayList<>();

    public void setDocument(Document document) {
        this.document = nonNull(document) ? document : Document.builder().build();
    }

    public void setAllstate_participant(String allstate_participant) {
        this.allstate_participant = nonNull(allstate_participant) ? allstate_participant : "";
    }

    public void setAllstate_documentCategory(List<String> allstate_documentCategory) {
        this.allstate_documentCategory = nonNull(allstate_documentCategory) ? allstate_documentCategory : new ArrayList<>();
    }
}