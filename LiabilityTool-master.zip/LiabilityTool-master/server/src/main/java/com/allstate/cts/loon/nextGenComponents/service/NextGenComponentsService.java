package com.allstate.cts.loon.nextGenComponents.service;

import com.allstate.cts.loon.exception.SubmissionSystemErrorException;
import com.allstate.cts.loon.nextGenComponents.model.AddTaskRequest;
import com.allstate.cts.loon.nextGenComponents.model.AddTaskResponse;
import com.allstate.cts.loon.nextGenComponents.model.FileNote;
import com.allstate.cts.loon.nextGenComponents.model.FileNoteResponse;
import com.allstate.cts.loon.resttemplate.LoonRestTemplate;
import org.springframework.stereotype.Service;

@Service
public class NextGenComponentsService implements NextGenComponentsServiceInterface {
    private final LoonRestTemplate nextGenRestTemplate;

    public NextGenComponentsService(LoonRestTemplate nextGenRestTemplate) {
        this.nextGenRestTemplate = nextGenRestTemplate;
    }

    @Override
    public FileNoteResponse publishFileNote(String claimNumber, FileNote fileNote) {
        try {
            return nextGenRestTemplate.sendObject(fileNote, FileNoteResponse.class, claimNumber, "InsertFileNote");
        } catch (Exception ex) {
            throw new SubmissionSystemErrorException(ex);
        }
    }
}
