package com.allstate.cts.loon.messaging.listeners;

import com.allstate.cts.auditLog.annotation.AuditLoggedTibco;
import com.allstate.cts.auditLog.annotation.Identifier;
import com.allstate.cts.loon.eligibility.service.EligibilityService;
import com.allstate.cts.parakeet.sdk.NlpReadyNotification;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.stereotype.Component;

import javax.jms.JMSException;
import javax.jms.TextMessage;

import static com.allstate.cts.auditLog.utilities.IdentifierTypes.CLAIM_NUMBER;


@Component
@Slf4j
@Profile("!PRODUCTION")
public class NlpListener {
    private MessageConverter messageConverter;
    private EligibilityService eligibilityService;

    @Autowired
    public NlpListener(MessageConverter messageConverter, EligibilityService eligibilityService) {
        this.messageConverter = messageConverter;
        this.eligibilityService = eligibilityService;
    }

    @AuditLoggedTibco
    @JmsListener(id = "nlp", destination = "${messaging.parakeet_nlp_queue_name}")
    public void receiveMessage(@Identifier(identifierType = CLAIM_NUMBER, jsonPath = "claimNumber") final TextMessage jsonMessage) throws JMSException {
        NlpReadyNotification nlpReadyNotification = (NlpReadyNotification) messageConverter.fromMessage(jsonMessage);
        eligibilityService.processNlpReadyNotification(nlpReadyNotification);
    }
}