package com.allstate.cts.loon.claimData.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Claim {
    private String claimNumber;
    private String claimId;
    private String lineOfBusinessCode;
    private String lineOfBusiness;
    private String lossType;
    private String lossTypeCode;
    private String lossDetailTypeCode;
    private String lossDetailType;
    private String lossState;
    private String negligenceRule;
    private String claimStatus;
    private String lossDate;
    private String lossTime;
    private String lossStreet;
    private String lossAddress;
    private String lossCity;
    private String lossZip;
    private String lossCountyDescription;
    private String claimSensitivity;
    private String claimOpenedDate;
}