package com.allstate.cts.loon.eligibility.service;

import com.allstate.cts.loon.assignment.service.AssignmentService;
import com.allstate.cts.loon.claimData.model.ClaimData;
import com.allstate.cts.loon.claimData.service.ClaimDataRetrieverServiceInterface;
import com.allstate.cts.loon.eligibility.helpers.ClaimComplexityHelper;
import com.allstate.cts.loon.eligibility.model.FNOLClaimData;
import com.allstate.cts.loon.eligibility.repository.FnolMessageRepository;
import com.allstate.cts.loon.helpers.DateTimeHelper;
import com.allstate.cts.parakeet.sdk.NlpReadyNotification;
import org.springframework.stereotype.Service;

@Service
public class EligibilityService {
    private ClaimDataRetrieverServiceInterface claimDataRetrieverServiceInterface;
    private FnolMessageRepository fnolMessageRepository;
    private ClaimComplexityHelper claimComplexityHelper;
    private AssignmentService assignmentService;
    private DateTimeHelper dateTimeHelper;
    private NonComplexLiabilityAnalysisService nonComplexLiabilityAnalysisService;

    public EligibilityService(ClaimDataRetrieverServiceInterface claimDataRetrieverServiceInterface,
                              FnolMessageRepository fnolMessageRepository,
                              ClaimComplexityHelper claimComplexityHelper,
                              AssignmentService assignmentService,
                              NonComplexLiabilityAnalysisService nonComplexLiabilityAnalysisService,
                              DateTimeHelper dateTimeHelper) {
        this.claimDataRetrieverServiceInterface = claimDataRetrieverServiceInterface;
        this.fnolMessageRepository = fnolMessageRepository;
        this.claimComplexityHelper = claimComplexityHelper;
        this.assignmentService = assignmentService;
        this.nonComplexLiabilityAnalysisService = nonComplexLiabilityAnalysisService;
        this.dateTimeHelper = dateTimeHelper;
    }

    public void processClaim(FNOLClaimData fnolClaimData) {
        if (isClaimEligible(fnolClaimData)) {
            ClaimData claimData = claimDataRetrieverServiceInterface.getClaimData(fnolClaimData.getClaimNumber(), "claim,keyFactAnswers");
            if (doesClaimExists(claimData)) {
                if (claimComplexityHelper.isNonComplexClaim(claimData)) {
                    claimData = claimDataRetrieverServiceInterface.getClaimData(fnolClaimData.getClaimNumber(), "claim,asset,participant");
                    nonComplexLiabilityAnalysisService.processNonComplexAssignment(claimData);
                } else {
                    assignmentService.createAssignment(fnolClaimData.getClaimNumber());
                }
            } else {
                saveFnolClaimData(fnolClaimData);
            }
        } else {
            saveFnolClaimData(fnolClaimData);
        }
    }

    public void processNlpReadyNotification(NlpReadyNotification nlpReadyNotification) {
        System.out.println("Received NLP message: " + nlpReadyNotification.toString());
    }

    private boolean isClaimEligible(FNOLClaimData fnolClaimData) {
        String lineOfBusiness = fnolClaimData.getLineOfBusiness().replace(" ", "");
        return ("Auto-Personal").equalsIgnoreCase(lineOfBusiness);
    }

    private boolean doesClaimExists(ClaimData claimData) {
        return claimData != null && claimData.getClaim() != null;
    }

    private void saveFnolClaimData(FNOLClaimData fnolClaimData) {
        fnolClaimData.setCreatedDate(dateTimeHelper.getCurrentDateTime());
        fnolMessageRepository.save(fnolClaimData);
    }
}