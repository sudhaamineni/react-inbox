package com.allstate.cts.loon.exception;

public class InvalidCharacterException extends RuntimeException implements CustomException {
    private final String msgHeader;
    private final String msgDescription;

    public InvalidCharacterException(String claimNumber) {
        this.msgHeader = "Claim #" + claimNumber + " is invalid";
        this.msgDescription = "We were unable to find this claim number. Please check and try again.";
    }

    @Override
    public String getMessageHeader() {
        return this.msgHeader;
    }

    @Override
    public String getMessageDescription() {
        return this.msgDescription;
    }
}

