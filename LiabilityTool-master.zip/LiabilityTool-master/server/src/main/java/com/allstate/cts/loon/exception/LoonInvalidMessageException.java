package com.allstate.cts.loon.exception;

import org.springframework.http.HttpStatus;

public class LoonInvalidMessageException extends LoonEligibilityException {
    public LoonInvalidMessageException(String message, Throwable ex) {
        super(HttpStatus.INTERNAL_SERVER_ERROR, false, message, ex);
    }
}