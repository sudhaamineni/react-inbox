package com.allstate.cts.loon.liabilityAnalysis.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ContributingFactorEntity {
    private String id;
    private String category;
    private String reason;
    private String details;
    @Builder.Default
    private List<String> evidenceIds = new ArrayList<>();
}
