package com.allstate.cts.loon.liabilityAnalysis.model;

import com.allstate.cts.loon.liabilityAnalysis.entity.Event;
import com.allstate.cts.loon.liabilityAnalysis.entity.Evidence;
import com.allstate.cts.loon.liabilityAnalysis.entity.PhotoAttachment;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SavePhotoAttachmentRequest {

    @Builder.Default
    List<PhotoAttachment> photoAttachmentList = new ArrayList<>();

    @Builder.Default
    List<Evidence> evidenceList = new ArrayList<>();

    @Builder.Default
    List<Event> eventList = new ArrayList<>();
}
