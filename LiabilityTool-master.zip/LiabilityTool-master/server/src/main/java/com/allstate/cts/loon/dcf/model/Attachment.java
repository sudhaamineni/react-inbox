package com.allstate.cts.loon.dcf.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import static java.util.Objects.nonNull;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Attachment {

    @Builder.Default
    private String objectId = "";

    @Builder.Default
    private Properties properties = Properties.builder().build();

    public void setObjectId(String objectId) {
        this.objectId = nonNull(objectId) ? objectId : "";
    }

    public void setProperties(Properties properties) {
        this.properties = nonNull(properties) ? properties : Properties.builder().build();
    }
}
