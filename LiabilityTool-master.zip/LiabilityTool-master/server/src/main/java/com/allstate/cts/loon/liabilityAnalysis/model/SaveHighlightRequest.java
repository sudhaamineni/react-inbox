package com.allstate.cts.loon.liabilityAnalysis.model;


import com.allstate.cts.loon.highlight.entity.HighlightEntity;
import com.allstate.cts.loon.liabilityAnalysis.entity.Event;
import com.allstate.cts.loon.liabilityAnalysis.entity.Evidence;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SaveHighlightRequest {

    @Builder.Default
    List<HighlightEntity> highlightEntityList  = new ArrayList<>();

    @Builder.Default
    List<Evidence> evidenceList  = new ArrayList<>();

    @Builder.Default
    List<Event> eventList  = new ArrayList<>();
}
