package com.allstate.cts.loon.nextGenComponents.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AddTaskResponse {

    @JsonProperty("Exception")
    boolean exception;

    @JsonProperty("sTaskID")
    private String  sTaskID;

    @JsonProperty("<IsSuccessful>k__BackingField")
    boolean isSuccessful;
}
