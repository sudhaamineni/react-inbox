package com.allstate.cts.loon.helpers;

import io.spring.gradle.dependencymanagement.org.codehaus.plexus.util.StringUtils;
import org.joda.time.DateTime;
import org.springframework.stereotype.Component;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

@Component
public class DateTimeHelper {
    public Date getCurrentDateTime() {
        return new Date();
    }

    public String getCurrentDateTimePlus48Hours() {
        return new DateTime().plusHours(48).toString();
    }

    public String dateTimeToDateConverter(String dateInput) {
        DateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
        DateFormat outputFormat = new SimpleDateFormat("MM/dd/yyyy");

        try {
            Date date = inputFormat.parse(dateInput);
            return outputFormat.format(date);
        } catch (Exception ex) {
            return "";
        }
    }

    public Date getDate(String source, String pattern) {
        try {
            return new SimpleDateFormat(pattern).parse(source);
        } catch (ParseException ex) {
            return null;
        }
    }

    public Date getDate(String source) {
        return getDate(source, "yyyy-MM-dd HH:mm:ss.S");
    }

    public Date setDateToNextDay(Date date) {
        GregorianCalendar calendar = new GregorianCalendar();
        calendar.setTime(date);
        calendar.add(Calendar.DATE, 1);
        return calendar.getTime();
    }

    public String dateTimeToTimeConverter(String dateInput) {
        DateFormat inputFormat = new SimpleDateFormat("HH:mm:ss");
        DateFormat outputFormat = new SimpleDateFormat("hh:mm a");

        try {
            String formatted = outputFormat.format(inputFormat.parse(dateInput));
            formatted = StringUtils.replace(formatted, "AM", "am");
            formatted = StringUtils.replace(formatted, "PM", "pm");
            return formatted;
        } catch (Exception ex) {
            return "";
        }
    }

    public String formatTimeInGMT(Date submittedTime) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("EEE, MMM d yyyy \'at\' h:mma z");

            TimeZone gmtTime = TimeZone.getTimeZone("GMT");
            sdf.setTimeZone(gmtTime);

            String theTime = sdf.format(submittedTime);
            return theTime;
        } catch (Exception ex) {
            return "";
        }
    }

    public String formatTimeInCST(Date submittedTime) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("EEE, MMM d yyyy \'at\' h:mma z");

            TimeZone gmtTime = TimeZone.getTimeZone("CST");
            sdf.setTimeZone(gmtTime);

            String theTime = sdf.format(submittedTime);
            return theTime;
        } catch (Exception ex) {
            return "";
        }
    }
}
