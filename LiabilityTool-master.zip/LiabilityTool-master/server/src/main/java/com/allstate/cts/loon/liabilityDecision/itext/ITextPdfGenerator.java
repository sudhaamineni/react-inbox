package com.allstate.cts.loon.liabilityDecision.itext;

import com.allstate.cts.loon.exception.SubmissionSystemErrorException;
import com.allstate.cts.loon.liabilityDecision.model.SubmitLiabilityDecisionRequest;
import com.itextpdf.text.Document;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfWriter;
import org.apache.commons.io.IOUtils;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;

import static com.allstate.cts.loon.liabilityDecision.itext.ITextHelper.convertToPoints;
import static com.itextpdf.text.PageSize.A4;

@Component
public class ITextPdfGenerator {
    private ITextInitialFaultSummarySectionGenerator iTextInitialFaultSummarySectionGenerator;
    private ITextLocationSectionGenerator iTextLocationSectionGenerator;
    private ITextInitialFaultDetailsSectionGenerator iTextInitialFaultDetailsSectionGenerator;

    ITextPdfGenerator(ITextInitialFaultSummarySectionGenerator iTextInitialFaultSummarySectionGenerator,
                      ITextLocationSectionGenerator iTextLocationSectionGenerator,
                      ITextInitialFaultDetailsSectionGenerator iTextInitialFaultDetailsSectionGenerator) {
        this.iTextInitialFaultSummarySectionGenerator = iTextInitialFaultSummarySectionGenerator;
        this.iTextLocationSectionGenerator = iTextLocationSectionGenerator;
        this.iTextInitialFaultDetailsSectionGenerator = iTextInitialFaultDetailsSectionGenerator;
    }

    public byte[] createPdf(SubmitLiabilityDecisionRequest submitLiabilityDecisionRequest) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        Document document = null;
        try {
            document = new Document(new Rectangle(A4), convertToPoints(48), convertToPoints(48), convertToPoints(80), convertToPoints(48));

            PdfWriter.getInstance(document, baos).setPageEvent(new ITextPageEventHandler(submitLiabilityDecisionRequest.getLiabilityAnalysisEntity()));

            document.open();
            iTextInitialFaultSummarySectionGenerator.addInitialFaultSummary(submitLiabilityDecisionRequest.getLiabilityAnalysisEntity(), document);
            iTextLocationSectionGenerator.generateLocationSection(submitLiabilityDecisionRequest, document);
            iTextInitialFaultDetailsSectionGenerator.generateInitialFaultDetailsSection(submitLiabilityDecisionRequest.getLiabilityAnalysisEntity(), document);
            document.close();

            return baos.toByteArray();
        } catch (Exception e) {
            throw new SubmissionSystemErrorException(e);
        } finally {
            if (document != null && document.isOpen()) {
                document.close();
            }
            IOUtils.closeQuietly(baos);
        }
    }
}
