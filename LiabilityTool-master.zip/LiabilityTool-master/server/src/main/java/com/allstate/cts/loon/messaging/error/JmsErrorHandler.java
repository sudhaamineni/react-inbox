package com.allstate.cts.loon.messaging.error;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import org.springframework.util.ErrorHandler;

@Slf4j
@Component
public class JmsErrorHandler implements ErrorHandler {

//  private MessagingService messagingService;
//  private MessagingHelper messagingHelper;
//  private String deadLetterQueueName;
//
//  public JmsErrorHandler(@Lazy MessagingService messagingService, MessagingHelper messagingHelper, @Value("${messaging.pkt_dead_letter_queue_name}") String deadLetterQueueName) {
//    this.messagingService = messagingService;
//    this.messagingHelper = messagingHelper;
//    this.deadLetterQueueName = deadLetterQueueName;
//  }
//
  @Override
  public void handleError(Throwable t) {
//    ErrorMessage errorMessage = ErrorMessage.builder()
//      .originalThrowable(t)
//      .throwable(t)
//      .retryCount(0)
//      .originalCompletionNotification(null)
//      .lastRetryTime(messagingHelper.getCurrentTimeInMillis())
//      .build();
//    messagingService.sendMessageToQueue(errorMessage, deadLetterQueueName);
  }
}
