package com.allstate.cts.loon.dcf.service;

import com.allstate.cts.auditLog.utilities.UUIDWrapper;
import com.allstate.cts.loon.dcf.model.*;
import com.allstate.cts.loon.exception.SystemErrorException;
import com.allstate.cts.loon.resttemplate.LoonRestTemplate;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.JSONObject;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.text.SimpleDateFormat;
import java.util.*;

import static com.allstate.cts.loon.constants.LoonConstants.*;
import static java.lang.String.format;
import static java.util.Objects.isNull;
import static org.hibernate.validator.internal.util.CollectionHelper.newArrayList;

@Service
public class DigitalClaimFileService {
    private static final Map<String, String> voiceTranscriptIdMapping = new HashMap<>();

    private static final String IMAGE_JPEG = "image/jpeg";
    private static final String ATTACHMENT_URL = "/v3/retrieve?alfrescoId=%s&versionLabel=1.0";

    private final LoonRestTemplate dcfRestTemplate;
    private final LoonRestTemplate dcfStoreRestTemplate;
    private UUIDWrapper uuidWrapper;

    public DigitalClaimFileService(LoonRestTemplate dcfRestTemplate,
                                   LoonRestTemplate dcfStoreRestTemplate,
                                   UUIDWrapper uuidWrapper) {
        this.dcfRestTemplate = dcfRestTemplate;
        this.dcfStoreRestTemplate = dcfStoreRestTemplate;
        this.uuidWrapper = uuidWrapper;

        voiceTranscriptIdMapping.put("workspace://SpacesStore/6eae5b80-9e80-441c-82f1-45800cc37512", "workspace://SpacesStore/225a5c39-c46b-405c-96be-a9b19aea621c");
    }

    public List<ParticipantDocuments> getParticipantDocuments(String claimNumber) {
        RetrieveAttachmentResponse attachmentResponse = searchByClaimNumber(claimNumber);
        if (attachmentResponse != null) {
            return getObjectIdsList(attachmentResponse);
        } else {
            return new ArrayList<>();
        }
    }

    private RetrieveAttachmentResponse searchByClaimNumber(String claimNumber) {
        try {
            String dcfResponse = dcfRestTemplate.getObject(String.class, claimNumber, claimNumber);
            if (dcfResponse.equals("{\"search_results\":[\"NO RESULTS FOUND\"]}")) {
                return RetrieveAttachmentResponse.builder().search_results(new ArrayList<Attachment>()).build();
            } else {
                ObjectMapper mapper = new ObjectMapper();
                return mapper.readValue(dcfResponse, RetrieveAttachmentResponse.class);
            }
        } catch (Exception ex) {
            throw new SystemErrorException();
        }
    }

    private List<ParticipantDocuments> getObjectIdsList(RetrieveAttachmentResponse response) {
        if (isNull(response)) {
            return newArrayList();
        }

        List<ParticipantDocuments> participantDocuments = newArrayList();
        response.getSearch_results().forEach(attachment -> {
            if (attachment.getProperties().getDocument().getMimetype().equals(IMAGE_JPEG)
                    && attachment.getProperties().getAllstate_participantID() != null && attachment.getProperties().getAllstate_participantID().size() > 0) {
                participantDocuments.add(ParticipantDocuments.builder()
                        .fullName(attachment.getProperties().getAllstate_participant())
                        .participantSourceId(attachment.getProperties().getAllstate_participantID().get(0))
                        .photoUrlList(getPhotoDetail(attachment))
                        .build());
            }
        });

        return participantDocuments;
    }

    private List<PhotoDetail> getPhotoDetail(Attachment attachment) {
        List<PhotoDetail> newList = new ArrayList<>();
        newList.add(PhotoDetail
                .builder()
                .url(buildAttachmentURL(attachment.getObjectId()))
                .dcfId(attachment.getObjectId())
                .build());
        return newList;
    }

    private String buildAttachmentURL(String objectId) {
        return format(ATTACHMENT_URL,
                objectId
        );
    }

    public void storeSummary(String claimNumber, String participantId, byte[] summaryPdf) throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd-HHmmss");
        sdf.setTimeZone(TimeZone.getTimeZone("America/Chicago"));
        String fileName = "Initial-Fault-Analysis-Claim" + claimNumber + "-" + sdf.format(new Date()) + ".pdf";

        Map<String, String> headers = new HashMap<>();
        headers.put("LOON_DCF_PDF_DOC_TYPE_CODE", DCF_PDF_DOC_TYPE_CODE);
        headers.put("LOON_DCF_PDF_FILE_NAME", fileName);
        headers.put("LOON_DCF_PDF_PARTICIPANT_ID", participantId);

        MultiValueMap<String, Object> payload = new LinkedMultiValueMap<>();
        JSONObject additionalProps = new JSONObject();
        additionalProps.put("DocTypeCode", DCF_PDF_DOC_TYPE_CODE);
        payload.add("docTypeCode", DCF_PDF_DOC_TYPE_CODE);
        payload.add("referenceId", uuidWrapper.getRandomUUID());
        payload.add("claimNumber", claimNumber);
        payload.add("systemName", SYSTEM_NAME);
        payload.add("brandName", ALLSTATE_BRANDNAME);
        payload.add("participantId", participantId);
        payload.add("additionalProps", additionalProps.toString());
        ByteArrayResource contentsAsResource = new ByteArrayResource(summaryPdf) {
            @Override
            public String getFilename() {
                return fileName;
            }
        };
        payload.add("file", contentsAsResource);

        dcfStoreRestTemplate.sendObject(payload, StoreResponse.class, headers, claimNumber);
    }
}