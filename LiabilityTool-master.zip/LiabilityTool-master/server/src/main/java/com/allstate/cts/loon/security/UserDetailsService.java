package com.allstate.cts.loon.security;

import com.allstate.cts.loon.org.service.OrgDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.AuthenticationUserDetailsService;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

import static org.springframework.security.core.userdetails.User.withUsername;


@Service
public class UserDetailsService implements AuthenticationUserDetailsService<PreAuthenticatedAuthenticationToken> {
    private OrgDataService orgDataService;
    private AuthorityMapper authorityMapper;

    @Autowired
    public UserDetailsService(OrgDataService orgDataService, AuthorityMapper authorityMapper) {
        this.orgDataService = orgDataService;
        this.authorityMapper = authorityMapper;
    }

    @Override
    public UserDetails loadUserDetails(PreAuthenticatedAuthenticationToken token) {
        return withUsername((String) token.getPrincipal())
                .password("")
                .authorities(new ArrayList(authorityMapper.getAuthoritiesForLoonUserOrgRole(orgDataService.getOrgData((String) token.getPrincipal()).getSecurityRoleList())))
                .build();
    }
}