package com.allstate.cts.loon.configuration;

import com.github.mongobee.Mongobee;
import com.mongodb.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.config.AbstractMongoConfiguration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;

import java.util.List;
import java.util.stream.Collectors;

import static com.mongodb.MongoCredential.createCredential;
import static com.mongodb.MongoCredential.createPlainCredential;
import static com.mongodb.WriteConcern.MAJORITY;

@Configuration
public class MongoConfiguration extends AbstractMongoConfiguration {
    @Autowired
    private ServerConfiguration serverConfiguration;

    @Value("${spring.data.mongodb.replicaset:#{null}}")
    private String replicaSet;

    @Value("${spring.data.mongodb.database}")
    private String databaseName;

    @Value("${spring.data.mongodb.timeout.socket}")
    private int socketTimeout;

    @Value("${spring.data.mongodb.timeout.serverselect}")
    private int serverSelectTimeout;

    @Value("${spring.data.mongodb.timeout.connect}")
    private int connectTimeout;

    @Value("${spring.data.mongodb.username}")
    private String userName;

    @Value("${spring.data.mongodb.password}")
    private String password;

    @Override
    protected String getDatabaseName() {
        return this.databaseName;
    }

    @Override
    public MongoClient mongoClient() {
        return this.getMongoClient();
    }

    @Override
    @Bean
    public SimpleMongoDbFactory mongoDbFactory() {
        return new SimpleMongoDbFactory(getMongoClient(), getDatabaseName());
    }

    private MongoClient getMongoClient() {
        MongoCredential credential;
        if (this.replicaSet == null) {
            credential = createCredential(this.userName, getDatabaseName(), this.password.toCharArray());
        } else {
            credential = createPlainCredential(this.userName, "$external", this.password.toCharArray());
        }
        List<ServerAddress> serverAddressList = serverConfiguration.getServer().stream()
                .map(s -> new ServerAddress(s.getHost(), s.getPort())).collect(Collectors.toList());

        MongoClientOptions options = MongoClientOptions.builder()
                .socketTimeout(socketTimeout)
                .serverSelectionTimeout(serverSelectTimeout)
                .connectTimeout(connectTimeout)
                .requiredReplicaSetName(replicaSet)
                .writeConcern(MAJORITY)
                .build();
        return new MongoClient(serverAddressList, credential, options);
    }

    @Override
    @Bean
    public MongoTemplate mongoTemplate() {
        return new MongoTemplate(mongoDbFactory());
    }

    @Bean
    public Mongobee mongobee() {
        Mongobee runner = new Mongobee(getMongoClient());
        runner.setDbName(getDatabaseName());
        runner.setChangeLogsScanPackage("com.allstate.cts.loon.mongobee"); // the package to be scanned for changesets
        return runner;
    }
}
