package com.allstate.cts.loon.nextGenComponents.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FilenoteAttachment {
    private String sFileName;
    private String sFileExt;
    private String sContentID;
    private String sAtchDesc;
}
