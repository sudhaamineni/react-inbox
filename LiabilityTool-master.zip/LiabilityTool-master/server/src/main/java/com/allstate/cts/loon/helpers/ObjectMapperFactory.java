package com.allstate.cts.loon.helpers;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Component;

@Component
public class ObjectMapperFactory {
    public ObjectMapper getObjectMapper() {
        return new ObjectMapper();
    }
}
