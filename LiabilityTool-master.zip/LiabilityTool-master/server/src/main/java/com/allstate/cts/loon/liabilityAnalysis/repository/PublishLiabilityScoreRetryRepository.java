package com.allstate.cts.loon.liabilityAnalysis.repository;

import com.allstate.cts.loon.liabilityAnalysis.entity.PublishLiabilityScoreRetryEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PublishLiabilityScoreRetryRepository extends MongoRepository<PublishLiabilityScoreRetryEntity, String> {
}