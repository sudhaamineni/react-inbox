package com.allstate.cts.loon.griffin.service;

import com.allstate.cts.loon.griffin.model.*;
import com.allstate.cts.loon.liabilityAnalysis.entity.LiabilityAnalysisEntity;
import com.allstate.cts.loon.liabilityAnalysis.entity.damageapportionment.CollectingParty;
import com.allstate.cts.loon.liabilityAnalysis.entity.damageapportionment.DamageAllocation;
import com.allstate.cts.loon.liabilityAnalysis.entity.damageapportionment.DamageApportionment;
import com.allstate.cts.loon.liabilityAnalysis.entity.damageapportionment.OwingParty;
import com.allstate.cts.loon.resttemplate.LoonRestTemplate;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.allstate.cts.loon.constants.LoonConstants.EMPTY;
import static java.util.stream.Collectors.toSet;

@Service
public class GriffinService {
    private LoonRestTemplate griffinRestTemplate;

    public GriffinService(LoonRestTemplate griffinRestTemplate) {
        this.griffinRestTemplate = griffinRestTemplate;
    }

    public DamageApportionment submitToGriffin(LiabilityAnalysisEntity liabilityAnalysisEntity, boolean initialFault) throws Exception {
        if (!initialFault && (liabilityAnalysisEntity.isNoFaultAllocationAgreement() || liabilityAnalysisEntity.isNoFaultAllocationResponse())) {
            return null;
        }
        ApportionedDamagesRequest griffinRequest = getPayload(liabilityAnalysisEntity, initialFault);
        ApportionedDamagesResponse griffinResponse = griffinRestTemplate.sendObject(griffinRequest, ApportionedDamagesResponse.class, liabilityAnalysisEntity.getClaimNumber(), liabilityAnalysisEntity.getClaimNumber());
        return convertToDamageApportionment(griffinResponse);
    }

    private ApportionedDamagesRequest getPayload(LiabilityAnalysisEntity liabilityAnalysisEntity, boolean initialFault) throws ParseException {
        List<Event> griffinEvents = new ArrayList<>();
        liabilityAnalysisEntity.getEvents().forEach(e -> {
            List<InvolvedParty> involvedParties = new ArrayList<>();
            e.getInvolvedParties().forEach(ip -> {
                Set<String> expectedAffectedParties = e.getInvolvedParties().stream().map(p -> p.getParticipantId()).collect(toSet());
                // remove the involved party from its possible affected parties
                expectedAffectedParties.remove(ip.getParticipantId());

                List<AffectedParticipant> affectedParticipants = new ArrayList<>();
                // if involved party has actual affected parties for each affected party,
                // add an AffectedParticipant object to list of affectedParticipants
                ip.getAffectedParties().forEach(ap -> {
                    affectedParticipants.add(
                        AffectedParticipant.builder()
                            .participantId(ap.getParticipantId() != null ? ap.getParticipantId() : EMPTY)
                            .faultPercentage(initialFault ? ap.getInitialFaultPercent() : ap.getFaultAllocationPercent())
                            .build()
                    );
                    // remove from pool of possible affected parties
                    expectedAffectedParties.remove(ap.getParticipantId());
                });

                // for remaining possible affected parties, add them to list of actual affected parties with fault percentage null
                expectedAffectedParties.forEach(eap ->
                    affectedParticipants.add(
                        AffectedParticipant.builder()
                            .participantId(eap)
                            .faultPercentage(null)
                            .build()
                    )
                );
                involvedParties.add(
                    InvolvedParty.builder()
                        .participantId(ip.getParticipantId())
                        .pointOfImpact(ip.getDamageSections())
                        .affectedParticipants(affectedParticipants)
                        .build()
                );
            });
            griffinEvents.add(
                Event.builder()
                    .id(e.getId())
                    .relativeSeverity(getSeverity(e.getSeverity()))
                    .involvedParties(involvedParties)
                    .build()
            );
        });
        return ApportionedDamagesRequest.builder()
            .claimNumber(liabilityAnalysisEntity.getClaimNumber())
            .lossState(liabilityAnalysisEntity.getLossState())
            .lossDate(new SimpleDateFormat("MM/dd/yyyy").parse(liabilityAnalysisEntity.getLossDate()))
            .events(griffinEvents)
            .build();
    }

    private Double getSeverity(Integer severity) {
        if (severity == null) {
            return 1.0;
        }
        switch (severity) {
            case -1:
                return 1.0 / 3.0;
            case 1:
                return 3.0;
            default:
                return 1.0;
        }
    }

    private DamageApportionment convertToDamageApportionment(ApportionedDamagesResponse griffinResponse) {
        Map<String, OwingParty> owingParties = new LinkedHashMap<>();

        griffinResponse.getSummary().getParticipants().stream().filter(p -> !p.isBarredFromRecovery()).forEach(p ->
            p.getPointOfImpacts().forEach(poi -> {
                poi.getDamages().forEach(d -> {
                    if (!owingParties.containsKey(d.getMainParticipantId())) {
                        owingParties.put(d.getMainParticipantId(), OwingParty.builder().participantId(d.getMainParticipantId()).build());
                    }

                    List<CollectingParty> collectingParties = owingParties.get(d.getMainParticipantId()).getCollectingParties();

                    CollectingParty collectingParty = collectingParties.stream()
                        .filter(cp -> cp.getParticipantId().equals(p.getAffectedParticipantId()))
                        .findFirst()
                        .orElse(CollectingParty
                            .builder()
                            .participantId(p.getAffectedParticipantId())
                            .damages(new ArrayList<>())
                            .build());

                    collectingParty.getDamages().add(
                        DamageAllocation.builder()
                            .allocation((int) (d.getAllocation() + 0.5))
                            .damageLocation(poi.getLocation())
                            .build());

                    int cpIndex = collectingParties.indexOf(collectingParty);

                    if (cpIndex >= 0) {
                        owingParties.get(d.getMainParticipantId()).getCollectingParties().set(cpIndex, collectingParty);
                    } else {
                        owingParties.get(d.getMainParticipantId()).getCollectingParties().add(collectingParty);
                    }
                });
            })
        );
        return DamageApportionment.builder()
            .comparativeNegligenceRule(griffinResponse.getComparativeNegligenceRule())
            .owingParties(new ArrayList<>(owingParties.values()))
            .build();
    }
}
