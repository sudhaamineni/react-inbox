package com.allstate.cts.loon.reporting.service;

import com.allstate.cts.loon.helpers.DateTimeHelper;
import com.allstate.cts.loon.reporting.entity.ReportingLiabilityAnalysisEntity;
import com.allstate.cts.loon.reporting.model.ResubmitedClaims;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.SortOperation;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

import static org.springframework.data.domain.Sort.Direction.DESC;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;
import static org.springframework.data.mongodb.core.query.Criteria.where;

@Service
public class ReportingService {
    private MongoTemplate mongoTemplate;
    private DateTimeHelper dateTimeHelper;

    public ReportingService(MongoTemplate mongoTemplate, DateTimeHelper dateTimeHelper) {
        this.mongoTemplate = mongoTemplate;
        this.dateTimeHelper = dateTimeHelper;
    }

    public List<ResubmitedClaims> getResubmittedClaims(String beginDate, String endDate) {
        AggregationOperation matchOperation = match(
                where("liabilityAnalysisEntity.initialFaultSubmitTime")
                        .gte(dateTimeHelper.getDate(beginDate, "yyyyMMdd"))
                        .lte(dateTimeHelper.setDateToNextDay(dateTimeHelper.getDate(endDate, "yyyyMMdd")))
        );

        AggregationOperation firstGroup = group("$liabilityAnalysisEntity.claimNumber", "$liabilityAnalysisEntity.initialFaultSubmitTime");
        AggregationOperation secondGroup = group("_id.claimNumber").count().as("count");
        AggregationOperation secondMatchOperation = match(
                where("count").gt(1)
        );
        AggregationOperation firstProjection = project().and("$_id").as("claimNumber").and("$count").as("count");

        Aggregation expectedAggregation = newAggregation(
                matchOperation, firstGroup, secondGroup, secondMatchOperation, firstProjection);
        AggregationResults<ResubmitedClaims> result = mongoTemplate.aggregate(expectedAggregation, "LiabilityAnalysisHistory", ResubmitedClaims.class);

        return result.getMappedResults();
    }

    public List<ReportingLiabilityAnalysisEntity> getClaimsByInitialFaultSubmitted(String beginDate, String endDate) {
        AggregationOperation matchDateRangeOp = match(
                where("liabilityAnalysisEntity.initialFaultSubmitTime")
                        .gte(dateTimeHelper.getDate(beginDate, "yyyyMMdd"))
                        .lt(dateTimeHelper.setDateToNextDay(dateTimeHelper.getDate(endDate, "yyyyMMdd")))
        );

        AggregationOperation proj = project()
                .and("$_id").as("id")
                .and("$claimNumber").as("claimNumber")
                .and("$liabilityAnalysisEntity.createdByUserId").as("createdByUserId")
                .and("$liabilityAnalysisEntity.lastModifiedByUserId").as("lastModifiedByUserId")
                .and("$liabilityAnalysisEntity.lossState").as("lossState")
                .and("$liabilityAnalysisEntity.negligenceRuleFromClaimSource").as("comparativeNegligenceRule")
                .and("$liabilityAnalysisEntity.lossDetailType").as("lossDetailType")
                .and("$liabilityAnalysisEntity.liabilitySubjects").size().as("participantSize")
                .and("$liabilityAnalysisEntity.createdTime").as("createdTime")
                .and("$liabilityAnalysisEntity.initialFaultSubmitTime").as("initialFaultSubmitTime")
                .and("$liabilityAnalysisEntity.updatedTime").as("updatedTime");

        SortOperation sortOp = sort(new Sort(DESC, "$liabilityAnalysisEntity.initialFaultSubmitTime"));

        Aggregation expectedAggregation = newAggregation(matchDateRangeOp, sortOp, proj);
        List<ReportingLiabilityAnalysisEntity> initialReportingLiabilityAnalysisList = mongoTemplate.aggregate(expectedAggregation, "LiabilityAnalysisHistory", ReportingLiabilityAnalysisEntity.class).getMappedResults();

        Map<String, ReportingLiabilityAnalysisEntity> result = new HashMap<>();

        initialReportingLiabilityAnalysisList.stream().forEach(report -> {
            String key = report.getClaimNumber();

            if (!result.containsKey(key)) {
                result.put(key, report);
            } else {
                Date recordedInitialFaultSubmitTime = result.get(key).getInitialFaultSubmitTime();
                Date reportedInitialFaultSubmitTime = report.getInitialFaultSubmitTime();
                if (recordedInitialFaultSubmitTime.equals(reportedInitialFaultSubmitTime)) {
                    Date recordedGetUpdatedTime = result.get(key).getUpdatedTime();
                    Date reportedGetUpdatedTime = report.getUpdatedTime();
                    if (recordedGetUpdatedTime.after(reportedGetUpdatedTime)) {
                        result.put(key, report);
                    }
                }
            }
        });
        convertTimeAndCount(new ArrayList<>(result.values()));

        return new ArrayList<>(result.values());
    }


    public List<ReportingLiabilityAnalysisEntity> getClaimsByCreatedTime(String beginDate, String endDate) {
        AggregationOperation matchOp = match(
                where("createdTime")
                        .gte(dateTimeHelper.getDate(beginDate, "yyyyMMdd"))
                        .lt(dateTimeHelper.setDateToNextDay(dateTimeHelper.getDate(endDate, "yyyyMMdd")))
        );

        AggregationOperation proj = project()
                .and("$claimNumber").as("claimNumber")
                .and("$createdByUserId").as("createdByUserId")
                .and("$lastModifiedByUserId").as("lastModifiedByUserId")
                .and("$lossState").as("lossState")
                .and("negligenceRuleFromClaimSource").as("comparativeNegligenceRule")
                .and("$lossDetailType").as("lossDetailType")
                .and("$liabilitySubjects").size().as("participantSize")
                .and("$createdTime").as("createdTime")
                .and("$initialFaultSubmitTime").as("initialFaultSubmitTime")
                .and("$settlementSubmitTime").as("settlementSubmitTime");
        Aggregation aggregation = newAggregation(matchOp, proj);

        List<ReportingLiabilityAnalysisEntity> reportingLiabilityAnalysisEntities = mongoTemplate.aggregate(aggregation, "LiabilityAnalysis", ReportingLiabilityAnalysisEntity.class).getMappedResults();
        convertTimeAndCount(reportingLiabilityAnalysisEntities);
        return reportingLiabilityAnalysisEntities;
    }

    public List<ReportingLiabilityAnalysisEntity> getInitialFaultPendingClaims() {
        AggregationOperation matchOp = match(
                where("locked").is(false)
        );

        AggregationOperation proj = project()
                .and("$claimNumber").as("claimNumber")
                .and("$createdByUserId").as("createdByUserId")
                .and("$lastModifiedByUserId").as("lastModifiedByUserId")
                .and("$lossState").as("lossState")
                .and("negligenceRuleFromClaimSource").as("comparativeNegligenceRule")
                .and("$lossDetailType").as("lossDetailType");
        Aggregation aggregation = newAggregation(matchOp, proj);

        List<ReportingLiabilityAnalysisEntity> reportingLiabilityAnalysisEntities = mongoTemplate.aggregate(aggregation, "LiabilityAnalysis", ReportingLiabilityAnalysisEntity.class).getMappedResults();

        convertTimeAndCount(reportingLiabilityAnalysisEntities);

        return reportingLiabilityAnalysisEntities;
    }


    private void convertTimeAndCount(List<ReportingLiabilityAnalysisEntity> reportingLiabilityAnalysisEntities) {
        AtomicInteger atomicInteger = new AtomicInteger(1);

        reportingLiabilityAnalysisEntities.forEach((reportingLiabilityAnalysisEntity) -> {
            reportingLiabilityAnalysisEntity.setCount(atomicInteger.getAndIncrement());
            reportingLiabilityAnalysisEntity.setCreatedTimeInCSTStringFormat(dateTimeHelper.formatTimeInCST(reportingLiabilityAnalysisEntity.getCreatedTime()));
            reportingLiabilityAnalysisEntity.setInitialFaultSubmitTimeInCSTStringFormat(dateTimeHelper.formatTimeInCST(reportingLiabilityAnalysisEntity.getInitialFaultSubmitTime()));
            reportingLiabilityAnalysisEntity.setSettlementSubmitTimeInCSTStringFormat(dateTimeHelper.formatTimeInCST((reportingLiabilityAnalysisEntity.getSettlementSubmitTime())));
        });

    }
}
