package com.allstate.cts.loon.startup.service;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserService {
    public String getUserName() {
        return ((UserDetails) (SecurityContextHolder.getContext().getAuthentication().getPrincipal())).getUsername();
    }

    public List<String> getUserRoles() {
        List<String> roles = new ArrayList<>();
        ((UserDetails) (SecurityContextHolder.getContext().getAuthentication().getPrincipal()))
                .getAuthorities().forEach(a -> roles.add(a.getAuthority()));
        return roles;
    }
}