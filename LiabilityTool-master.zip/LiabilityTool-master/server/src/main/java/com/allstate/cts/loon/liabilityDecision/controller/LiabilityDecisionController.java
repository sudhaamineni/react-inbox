package com.allstate.cts.loon.liabilityDecision.controller;

import com.allstate.cts.auditLog.annotation.AuditLoggedHttp;
import com.allstate.cts.auditLog.annotation.Identifier;
import com.allstate.cts.loon.aspect.ValidateLoonUserRole;
import com.allstate.cts.loon.liabilityAnalysis.entity.LiabilityAnalysisEntity;
import com.allstate.cts.loon.liabilityAnalysis.service.LiabilityAnalysisSummaryPdfService;
import com.allstate.cts.loon.liabilityDecision.model.SubmitLiabilityDecisionRequest;
import com.allstate.cts.loon.liabilityDecision.service.LiabilityDecisionService;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import static com.allstate.cts.auditLog.utilities.IdentifierTypes.CLAIM_NUMBER;

@RestController
@RequestMapping("/api/v1/liabilitydecision")
public class LiabilityDecisionController {
    private LiabilityDecisionService liabilityDecisionService;
    private LiabilityAnalysisSummaryPdfService liabilityAnalysisSummaryPdfService;

    public LiabilityDecisionController(LiabilityDecisionService liabilityDecisionService, LiabilityAnalysisSummaryPdfService liabilityAnalysisSummaryPdfService) {
        this.liabilityDecisionService = liabilityDecisionService;
        this.liabilityAnalysisSummaryPdfService = liabilityAnalysisSummaryPdfService;
    }

    @PostMapping
    @AuditLoggedHttp
    @ValidateLoonUserRole
    public LiabilityAnalysisEntity submitInitialFault(@RequestBody @Valid @Identifier(jsonPath = "$.liabilityAnalysisEntity.claimNumber", identifierType = CLAIM_NUMBER) SubmitLiabilityDecisionRequest submitLiabilityDecisionRequest) {
        return liabilityDecisionService.submitInitialFault(submitLiabilityDecisionRequest);
    }

    @PostMapping("/{claimNumber}/damage-apportionment")
    @AuditLoggedHttp
    @ValidateLoonUserRole
    public LiabilityAnalysisEntity updateDamageApportionment(@PathVariable @Identifier(identifierType = CLAIM_NUMBER) String claimNumber, @RequestBody LiabilityAnalysisEntity lae) throws Exception {
        return liabilityDecisionService.updateDamageApportionment(claimNumber, lae.getApportionedAllocatedFaultSaveTime());
    }

    @PostMapping("/{claimNumber}/submit-settlement")
    @AuditLoggedHttp
    @ValidateLoonUserRole
    public void submitSettlement(@PathVariable @Identifier(identifierType = CLAIM_NUMBER) String claimNumber) throws Exception {
        liabilityDecisionService.submitSettlement(claimNumber);
    }

    @GetMapping("/{claimNumber}/summary-pdf")
    public byte[] getSummaryPdf(@PathVariable @Identifier(identifierType = CLAIM_NUMBER) String claimNumber) {
        return liabilityAnalysisSummaryPdfService.getSummaryPdf(claimNumber);
    }
}
