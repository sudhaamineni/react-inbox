package com.allstate.cts.loon.liabilityDecision.itext;

import com.allstate.cts.loon.exception.SubmissionSystemErrorException;
import com.allstate.cts.loon.helpers.ClaimDataModelHelper;
import com.allstate.cts.loon.liabilityAnalysis.entity.AffectedParty;
import com.allstate.cts.loon.liabilityAnalysis.entity.Event;
import com.allstate.cts.loon.liabilityAnalysis.entity.InvolvedParty;
import com.allstate.cts.loon.liabilityAnalysis.entity.LiabilityAnalysisEntity;
import com.allstate.cts.loon.liabilityAnalysis.entity.damageapportionment.OwingParty;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPTable;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.List;

import static com.allstate.cts.loon.constants.LoonConstants.*;
import static com.allstate.cts.loon.liabilityDecision.itext.ITextConstants.FontColors.*;
import static com.allstate.cts.loon.liabilityDecision.itext.ITextHelper.*;
import static com.itextpdf.text.Font.BOLD;
import static com.itextpdf.text.html.WebColors.getRGBColor;
import static java.util.stream.IntStream.range;

@Component
public class ITextInitialFaultSummarySectionGenerator {
    private ClaimDataModelHelper claimDataModelHelper;

    ITextInitialFaultSummarySectionGenerator(ClaimDataModelHelper claimDataModelHelper) {
        this.claimDataModelHelper = claimDataModelHelper;
    }

    void addInitialFaultSummary(LiabilityAnalysisEntity liabilityAnalysisEntity, Document document) throws DocumentException, IOException {
        PdfPTable table = getDefaultTable();

        table.addCell(getMainHeader());

        table.addCell(getHeader("Participants Involved"));
        table.addCell(getParticipants(liabilityAnalysisEntity));

        table.addCell(getFirstEvent(liabilityAnalysisEntity));
        if (liabilityAnalysisEntity.getEvents().size() > 1) {
            range(1, liabilityAnalysisEntity.getEvents().size()).forEach(index -> {
                try {
                    PdfPTable eventTable = getDefaultTable();
                    eventTable.addCell(getInvolvedParties(liabilityAnalysisEntity, liabilityAnalysisEntity.getEvents().get(index), index + 1));
                    eventTable.setKeepTogether(true);

                    table.addCell(eventTable);
                } catch (Exception e) {
                    throw new SubmissionSystemErrorException(e);
                }
            });
        }

        if (liabilityAnalysisEntity.getApportionedInitialFault().getOwingParties().size() > 0) {
            List<OwingParty> owingParties = liabilityAnalysisEntity.getApportionedInitialFault().getOwingParties();
            owingParties.sort((o1, o2) -> {
                String role = liabilityAnalysisEntity.getLiabilitySubjects().stream().filter(o -> o.getParticipantPartyId().equals(o1.getParticipantId())).findFirst().get().getRole();
                if ("INSURED".equals(role)) {
                    return -1;
                }
                return 1;
            });
            table.addCell(getFirstDamageApportionment(liabilityAnalysisEntity, owingParties));
            if (owingParties.size() > 1) {
                range(1, owingParties.size()).forEach(index -> {
                    try {
                        PdfPTable owingPartyTable = getDefaultTable();
                        owingPartyTable.addCell(getOwingParty(liabilityAnalysisEntity, owingParties.get(index)));
                        owingPartyTable.setKeepTogether(true);

                        table.addCell(owingPartyTable);
                    } catch (Exception e) {
                        throw new SubmissionSystemErrorException(e);
                    }
                });
            }
        }

        document.add(table);
    }

    private PdfPTable getMainHeader() throws DocumentException, IOException {
        PdfPTable table = getDefaultTable();
        table.addCell(new Phrase("Initial Fault Summary", getAllstateSansRegularFont(20, BOLD, GRAY_333333)));
        return table;
    }

    private PdfPTable getHeader(String text) throws DocumentException, IOException {
        PdfPTable table = getDefaultTable();
        table.addCell(new Phrase(text, getAllstateSansRegularFont(16, BOLD, GRAY_484848)));
        return table;
    }

    private PdfPTable getParticipants(LiabilityAnalysisEntity liabilityAnalysisEntity) throws IOException, DocumentException {
        Font normalGrayFont = getAllstateSansRegularFont(12, GRAY_484848);

        PdfPTable table = getDefaultTable();
        liabilityAnalysisEntity.getLiabilitySubjects().forEach(ls -> {
            try {
                String name = ls.getName();
                String asset = ls.getAsset().getAssetYearMakeModel();
                String role = ls.getRole();

                switch (ls.getRole()) {
                    case INSURED_CAPS:
                        table.addCell(getCell(new Phrase("Insured Owner: " + name + " - " + asset, normalGrayFont), 16, 4));
                        break;

                    case CLAIMANT_CAPS:
                        table.addCell(getCell(new Phrase("Claimant Owner: " + name + " - " + asset, normalGrayFont), 16, 4));
                        break;

                    case PED_BIKE_CAPS:
                        table.addCell(getCell(new Phrase("Claimant: " + name + " - " + role, normalGrayFont), 16, 4));
                        break;

                    default:
                        table.addCell(getCell(new Phrase(role + ": " + name + " - " + asset, normalGrayFont), 16, 4));
                        break;
                }
            } catch (Exception e) {
                throw new SubmissionSystemErrorException(e);
            }
        });
        return table;
    }

    private PdfPTable getFirstEvent(LiabilityAnalysisEntity liabilityAnalysisEntity) throws IOException, DocumentException {
        PdfPTable table = getDefaultTable();

        table.addCell(getHeader("Initial Fault"));
        table.addCell(getInvolvedParties(liabilityAnalysisEntity, liabilityAnalysisEntity.getEvents().get(0), 1));

        table.setKeepTogether(true);
        return table;
    }

    private PdfPTable getInvolvedParties(LiabilityAnalysisEntity liabilityAnalysisEntity, Event event, int index) throws IOException, DocumentException {
        Font normalGrayFont = getAllstateSansRegularFont(12, GRAY_484848);

        PdfPTable table = getDefaultTable();
        table.getDefaultCell().setBackgroundColor(getRGBColor(GRAY_F4F4F4));

        String eventName = "Event " + index + (event.getTitle() != null && !event.getTitle().isEmpty() ? " - " + event.getTitle() : "");
        PdfPTable eventNameTable = getDefaultTable();
        eventNameTable.addCell(getCell(new Phrase(eventName, normalGrayFont), 16, 8));
        table.addCell(eventNameTable);

        // If index > 1, include severity
        if (index > 1) {
            PdfPTable severityTable = getDefaultTable();
            severityTable.addCell(getCell(new Phrase("Severity: " + getSeverityLabel(event.getSeverity()), normalGrayFont), 16, 4));
            table.addCell(severityTable);
        }

        PdfPTable involvedPartiesTable = getDefaultTable(2);
        List<InvolvedParty> involvedParties = event.getInvolvedParties();
        for (InvolvedParty involvedParty : involvedParties) {
            String involvedPartyName = claimDataModelHelper.getParticipantNameByParticipantId(involvedParty.getParticipantId(), liabilityAnalysisEntity.getLiabilitySubjects());
            List<AffectedParty> affectedParties = involvedParty.getAffectedParties();
            for (AffectedParty affectedParty : affectedParties) {
                String affectedPartyName = affectedParty.getParticipantId() !=null ? claimDataModelHelper.getParticipantNameByParticipantId(affectedParty.getParticipantId(), liabilityAnalysisEntity.getLiabilitySubjects()) : "UNKNOWN";

                involvedPartiesTable.addCell(getCell(new Phrase(involvedPartyName + " to " + affectedPartyName, normalGrayFont), 32, 4));
                involvedPartiesTable.addCell(getCell(new Phrase(affectedParty.getInitialFaultPercent() + "%", normalGrayFont), 0, 4));
            }
        }
        table.addCell(involvedPartiesTable);

        return table;
    }

    private String getSeverityLabel(int severity) {
        String label;
        switch (severity) {
            case -1: {
                label = "Less than Event 1";
                break;
            }
            case 1: {
                label = "Less than Event 1";
                break;
            }
            default: {
                label = "Same as Event 1";
                break;
            }
        }
        return label;
    }

    private PdfPTable getFirstDamageApportionment(LiabilityAnalysisEntity liabilityAnalysisEntity, List<OwingParty> owingParties) throws IOException, DocumentException {
        PdfPTable table = getDefaultTable();

        table.addCell(getHeader("Damage Apportionment based on Initial Fault"));
        String compNegRule = "Based on the state negligence laws in the state of " + liabilityAnalysisEntity.getLossState() + ": " + liabilityAnalysisEntity.getApportionedInitialFault().getComparativeNegligenceRule();
        table.addCell(getCell(new Phrase(compNegRule, getAllstateSansRegularFont(12, GRAY_484848)), 6, 4));
        table.addCell(getOwingParty(liabilityAnalysisEntity, owingParties.get(0)));

        table.setKeepTogether(true);
        return table;
    }

    private PdfPTable getOwingParty(LiabilityAnalysisEntity liabilityAnalysisEntity, OwingParty owingParty) throws IOException, DocumentException {
        PdfPTable table = getDefaultTable(2);
        table.setWidths(new int[]{40, 60});

        String owingPartyName = claimDataModelHelper.getParticipantNameByParticipantId(owingParty.getParticipantId(), liabilityAnalysisEntity.getLiabilitySubjects());
        for (int cp = 0; cp < owingParty.getCollectingParties().size(); cp++) {
            if (cp == 0) {
                table.addCell(getCell(new Phrase(owingPartyName + " owes damages to:", getAllstateSansRegularFont(12, GRAY_484848)), 24, 4));
            } else {
                table.addCell(getEmptyCell());
            }

            String collectingPartyName = claimDataModelHelper.getParticipantNameByParticipantId(owingParty.getCollectingParties().get(cp).getParticipantId(), liabilityAnalysisEntity.getLiabilitySubjects());
            StringBuilder collectingPartyBuilder = new StringBuilder();
            collectingPartyBuilder.append(collectingPartyName).append(" - ");
            for (int i = 0; i < owingParty.getCollectingParties().get(cp).getDamages().size(); i++) {
                collectingPartyBuilder
                    .append(owingParty.getCollectingParties().get(cp).getDamages().get(i).getAllocation()).append("% ")
                    .append(capitalizeFirstLetters(owingParty.getCollectingParties().get(cp).getDamages().get(i).getDamageLocation()));
                if (i < owingParty.getCollectingParties().get(cp).getDamages().size() - 1) {
                    collectingPartyBuilder.append(", ");
                }
            }
            table.addCell(getCell(new Phrase(collectingPartyBuilder.toString(), getAllstateSansRegularFont(12, GRAY_484848)), 0, 4));
        }
        return table;
    }
}
