package com.allstate.cts.loon.resttemplate;

import com.allstate.cts.auditLog.annotation.AuditLoggedTemplate;
import lombok.*;
import org.apache.commons.lang.StringUtils;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.conn.HttpClientConnectionManager;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.Map;

import static java.util.Objects.isNull;
import static org.springframework.http.HttpMethod.GET;


@Getter
@ToString
public class LoonRestTemplate {
    public static final String FAILED = " failed.";

    // optional
    private int connectionTimeout;
    private int readTimeout;
    private int maxConnections;
    private int maxPerRouteConnections;
    private HttpHeaders httpHeaders;

    // required
    private String targetSystemUrl;
    private String targetSystemName;
    private String systemName;

    @AuditLoggedTemplate
    @Setter(value = AccessLevel.PROTECTED)   // Allow "setRestTemplate" (for Unit Tests)
    private RestTemplate restTemplate;

    // This constructor sets intelligent defaults as well as prevents outsiders from setting the configuredRestTemplate
    // (which is built and configured by the configuredRestTemplate() method below).
    @Builder
    private LoonRestTemplate(int connectionTimeout,
                             int readTimeout,
                             int maxConnections,
                             int maxPerRouteConnections,
                             HttpHeaders httpHeaders,
                             @NonNull String targetSystemUrl,
                             @NonNull String targetSystemName,
                             @NonNull String systemName
    ) {
        this.connectionTimeout = connectionTimeout <= 0 ? 5000 : connectionTimeout;
        this.readTimeout = readTimeout <= 0 ? 25000 : connectionTimeout;
        this.maxConnections = maxConnections <= 0 ? 200 : maxConnections;
        this.maxPerRouteConnections = maxPerRouteConnections <= 0 ? 20 : maxPerRouteConnections;
        this.httpHeaders = isNull(httpHeaders) ? new HttpHeaders() : httpHeaders;
        this.targetSystemUrl = targetSystemUrl;
        this.targetSystemName = targetSystemName;
        this.systemName = systemName;
        this.restTemplate = configuredRestTemplate();
    }


    public <T> T getObject(Class<T> objectType,
                           String identifier,
                           Object... uriVariables) throws Exception {

        HttpEntity<T> requestEntity = new HttpEntity<>(httpHeaders);

        ResponseEntity<T> responseEntity = get(
                targetSystemUrl,
                requestEntity,
                objectType,
                uriVariables
        );

        return responseEntity.getBody();
    }

    public <T, R> T sendObject(R payload,
                               Class<T> responseType,
                               String identifier,
                               Object... uriVariables) throws Exception {
        return sendObject(payload, responseType, null, identifier, uriVariables);
    }

    public <T, R> T sendObject(R payload,
                               Class<T> responseType,
                               Map<String, String> headers,
                               String identifier,
                               Object... uriVariables) throws Exception {
        HttpHeaders httpHeaders = this.httpHeaders;
        if (headers != null) {
            headers.forEach((k, v) -> httpHeaders.add(k, v));
        }
        HttpEntity<R> requestEntity = new HttpEntity<>(payload, httpHeaders);
        ResponseEntity<T> responseEntity = send(
                targetSystemUrl,
                requestEntity,
                responseType,
                uriVariables
        );
        return responseEntity.getBody();
    }

    private RestTemplate configuredRestTemplate() {
        RequestConfig requestConfig = createRequestConfig();
        HttpClientConnectionManager connectionManager = createHttpClientConnectionManager();
        CloseableHttpClient httpClient = createHttpClient(connectionManager, requestConfig);
        ClientHttpRequestFactory clientHttpRequestFactory = createClientHttpRequestFactory(httpClient);
        ClientHttpRequestFactory factory = new BufferingClientHttpRequestFactory(clientHttpRequestFactory);
        RestTemplate restTemplate = new RestTemplate(factory);

        return restTemplate;
    }

    private ClientHttpRequestFactory createClientHttpRequestFactory(CloseableHttpClient httpClient) {
        return new HttpComponentsClientHttpRequestFactory(httpClient);
    }

    private RequestConfig createRequestConfig() {
        return RequestConfig.custom()
                .setConnectTimeout(connectionTimeout)
                .setSocketTimeout(readTimeout)
                .build();
    }

    private HttpClientConnectionManager createHttpClientConnectionManager() {
        PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager();
        connectionManager.setMaxTotal(maxConnections);
        connectionManager.setDefaultMaxPerRoute(maxPerRouteConnections);
        return connectionManager;
    }

    private CloseableHttpClient createHttpClient(HttpClientConnectionManager httpClientConnectionManager, RequestConfig requestConfig) {
        return HttpClientBuilder
                .create()
                .setConnectionManager(httpClientConnectionManager)
                .setDefaultRequestConfig(requestConfig)
                .build();
    }

    private <T> ResponseEntity<T> get(String url,
                                      HttpEntity<?> requestEntity,
                                      Class<T> responseType,
                                      Object... uriVariables) throws Exception {
        String uri = buildUri(url, uriVariables);

        return restTemplate.exchange(new URI(uri), GET, requestEntity, responseType);

    }

    private <T> ResponseEntity<T> send(String url,
                                       Object payload,
                                       Class<T> responseType,
                                       Object... uriVariables) throws Exception {
        String uri = buildUri(url, uriVariables);

        return restTemplate.postForEntity(new URI(uri), payload, responseType);
    }

    private static String buildUri(String url, Object... pathVariables) {
        for (Object var : pathVariables) {
            url = StringUtils.replaceOnce(url, "{}", (String) var);
        }

        return url;
    }
}