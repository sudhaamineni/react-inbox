package com.allstate.cts.loon.exception;

public class SubmissionSystemErrorException extends RuntimeException implements CustomException {
    private final String msgHeader;
    private final String msgDescription;

    public SubmissionSystemErrorException(Exception e) {
        super("Claim analysis submission failed.", e);
        this.msgHeader = "Claim analysis submission failed.";
        this.msgDescription = e.getMessage();
    }

    @Override
    public String getMessageHeader() {
        return this.msgHeader;
    }

    @Override
    public String getMessageDescription() {
        return this.msgDescription;
    }
}