package com.allstate.cts.loon.helpers;

import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.net.URL;

@Component
public class FileUtilsWrapper {
    public void copyURLToFile(URL source, File destination) throws IOException {
        FileUtils.copyURLToFile(source,destination);
    }

    public void writeByteArrayToFile(File file, byte[] data) throws IOException {
        FileUtils.writeByteArrayToFile(file, data);
    }

    public byte[] readFileToByteArray(File file) throws IOException {
        return FileUtils.readFileToByteArray(file);
    }
}
