package com.allstate.cts.loon.exception;

public class ClaimOwnerNotFoundException extends RuntimeException implements CustomException {
    private final String msgHeader;
    private final String msgDescription;

    public ClaimOwnerNotFoundException(String claimNumber) {
        this.msgHeader ="No Claim Owner for Claim #" + claimNumber;
        this.msgDescription = "We were unable to find a claim owner. Please check and try again.";
    }

    @Override
    public String getMessageHeader() {
        return this.msgHeader;
    }

    @Override
    public String getMessageDescription() { return this.msgDescription; }
}
