package com.allstate.cts.loon.reporting.controller;

import com.allstate.cts.loon.reporting.entity.ReportingLiabilityAnalysisEntity;
import com.allstate.cts.loon.reporting.model.ResubmitedClaims;
import com.allstate.cts.loon.reporting.service.ReportingService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/rpt")
public class ReportingController {
    private ReportingService reportingService;

    public ReportingController(ReportingService reportingService) {
        this.reportingService = reportingService;
    }

    @GetMapping("/resubmitted/{beginDate}/{endDate}")
    public List<ResubmitedClaims> getResubmittedClaims(@PathVariable("beginDate") String beginDate,
                                                       @PathVariable("endDate") String endDate) {
        return reportingService.getResubmittedClaims(beginDate, endDate);
    }

    @GetMapping("/claims-by-created-time/{beginDate}/{endDate}")
    public List<ReportingLiabilityAnalysisEntity> getClaimsByCreatedTime(@PathVariable("beginDate") String beginDate,
                                                                         @PathVariable("endDate") String endDate) {
        return reportingService.getClaimsByCreatedTime(beginDate, endDate);
    }

    @GetMapping("/initial-fault-pending-claims")
    public List<ReportingLiabilityAnalysisEntity> getInitialFaultPendingClaims() {
        return reportingService.getInitialFaultPendingClaims();
    }

    @GetMapping("/claims-by-initial-fault-submitted-time/{beginDate}/{endDate}")
    public List<ReportingLiabilityAnalysisEntity> getClaimsByInitialFaultSubmitted(@PathVariable("beginDate") String beginDate,
                                                                         @PathVariable("endDate") String endDate) {
        List<ReportingLiabilityAnalysisEntity> reportingLiabilityAnalysisEntities = reportingService.getClaimsByInitialFaultSubmitted(beginDate, endDate);
        return reportingLiabilityAnalysisEntities;
    }
}
