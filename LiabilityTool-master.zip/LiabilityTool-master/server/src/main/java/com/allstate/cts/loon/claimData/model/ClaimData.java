package com.allstate.cts.loon.claimData.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimData {
    private Claim claim;

    @Builder.Default
    private List<Asset> asset = new ArrayList<>();

    @Builder.Default
    private List<Performer> performers = new ArrayList<>();

    @Builder.Default
    private List<Participant> participants = new ArrayList<>();

    @Builder.Default
    private KeyFactAnswers keyFactAnswers = new KeyFactAnswers();

    @Builder.Default
    private ClaimReset claimReset = new ClaimReset();
}