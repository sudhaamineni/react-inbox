package com.allstate.cts.loon.liabilityAnalysis.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Sketch {
    private String imageSource;
    private String garageSource;
    private boolean completed;
    private String notCompletedReason;
}
