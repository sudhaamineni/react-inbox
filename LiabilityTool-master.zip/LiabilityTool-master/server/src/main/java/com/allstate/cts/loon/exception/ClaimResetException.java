package com.allstate.cts.loon.exception;

public class ClaimResetException extends RuntimeException implements CustomException {
    private final String messageHeader;
    private final String messageDescription;
    private final String newClaimNumber;

    public ClaimResetException(String newClaimNumber) {
        this.messageHeader = "Claim reset error";
        this.messageDescription = "This claim has been reset.";
        this.newClaimNumber = newClaimNumber;
    }

    @Override
    public String getMessageHeader() {
        return this.messageHeader;
    }

    @Override
    public String getMessageDescription() {
        return this.messageDescription;
    }

    public String getNewClaimNumber() {
        return this.newClaimNumber;
    }
}