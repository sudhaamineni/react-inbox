package com.allstate.cts.loon.claimData.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Damages {
    private String damageId;

    @Builder.Default
    private List<String> rear = new ArrayList<>();

    @Builder.Default
    private List<String> other = new ArrayList<>();

    @Builder.Default
    private List<String> passengerSideExterior = new ArrayList<>();

    @Builder.Default
    private List<String> driverSideExterior = new ArrayList<>();

    @Builder.Default
    private List<String> mechanical = new ArrayList<>();

    @Builder.Default
    private List<String> front = new ArrayList<>();

    @Builder.Default
    private List<String> interior = new ArrayList<>();
}
