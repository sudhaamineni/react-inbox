package com.allstate.cts.loon.admin.controller;

import com.allstate.cts.loon.admin.service.AdminService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RestController
@RequestMapping("/api/v1/admin")
public class AdminController {

    private final AdminService adminService;
    public AdminController(AdminService adminService) {
        this.adminService = adminService;
    }


    @PostMapping
    public void insertAssignmentClaimList(@RequestBody List<String> claimNumberList,
                                          @RequestParam(required = false, defaultValue = "false") Boolean clearQueue,
                                          @RequestParam(required = false, defaultValue = "true") Boolean useKafka) {
        adminService.insertAssignmentClaimList(claimNumberList, clearQueue, useKafka);
    }
}