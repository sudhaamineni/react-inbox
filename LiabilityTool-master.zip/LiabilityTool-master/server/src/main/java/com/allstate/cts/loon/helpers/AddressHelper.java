package com.allstate.cts.loon.helpers;

import com.allstate.cts.loon.claimData.model.Address;
import org.springframework.stereotype.Component;

@Component
public class AddressHelper {
    public String createAddress(Address address) {

        Address outputAddress = new Address();
        outputAddress.setStreet((address.getStreet() == null || address.getStreet().isEmpty()) ? "" : address.getStreet());
        outputAddress.setCity((address.getCity() == null || address.getCity().isEmpty()) ? "" : ", " + address.getCity());
        outputAddress.setState((address.getState() == null || address.getState().isEmpty()) ? "" : ", " + address.getState());
        outputAddress.setZip((address.getZip() == null || address.getZip().isEmpty()) ? "" : ", " + address.getZip());

        if (address.getStreet() == null && address.getCity() != null) {
            outputAddress.setCity(address.getCity());
        }

        if (address.getStreet() == null && address.getCity() == null && address.getState() == null && address.getZip() != null) {
            outputAddress.setZip(address.getZip());
        }

        if (address.getStreet() == null && address.getCity() == null && address.getState() != null) {
            outputAddress.setState(address.getState());
        }

        return getAddressString(address, outputAddress);

    }

    private String getAddressString(Address address, Address outputAddress) {
        String outputCounty;
        if (address.getStreet() == null && address.getCity() == null && address.getZip() == null && address.getCounty() != null) {
            outputCounty = address.getCounty() + " County";
            return outputCounty + (outputAddress.getState().isEmpty() ? "" : ", ") + outputAddress.getState();
//            return outputCounty + (outputState.isEmpty() ? "" : ", ") + outputState;
        } else {
            return outputAddress.getStreet() + outputAddress.getCity() + outputAddress.getState() + outputAddress.getZip();
        }
    }
}
