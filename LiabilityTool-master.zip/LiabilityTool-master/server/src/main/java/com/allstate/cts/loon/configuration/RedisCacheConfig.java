package com.allstate.cts.loon.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.interceptor.CacheErrorHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisPassword;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisClientConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;

import java.time.Duration;

@Configuration
@EnableCaching
@Profile("!devci")
public class RedisCacheConfig extends CachingConfigurerSupport {
    @Value("${spring.profiles.active}")
    private String activeProfile;

    @Bean
    public JedisConnectionFactory redisConnectionFactory(@Value("${redis.hostName}") String hostName,
                                                         @Value("${redis.hostPort}") int hostPort,
                                                         @Value("${redis.hostPassword}") String hostPassword) {
        RedisStandaloneConfiguration redisStandaloneConfiguration = new RedisStandaloneConfiguration();
        redisStandaloneConfiguration.setHostName(hostName);
        redisStandaloneConfiguration.setPort(hostPort);
        if (!"local".equals(this.activeProfile) && !"localci".equals(this.activeProfile)) {
            redisStandaloneConfiguration.setPassword(RedisPassword.of(hostPassword));
        }
        return new JedisConnectionFactory(redisStandaloneConfiguration, JedisClientConfiguration.builder().build());
    }

    @Bean
    public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory cf) {
        RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(cf);
        return redisTemplate;
    }

    @Bean
    public CacheManager cacheManager(JedisConnectionFactory jedisConnectionFactory, @Value("${redis.durationInMinutes}") int durationInMinutes) {
        RedisCacheConfiguration redisCacheConfiguration = RedisCacheConfiguration.defaultCacheConfig();
        RedisCacheConfiguration redisCacheConfigurationWithTtl = redisCacheConfiguration.entryTtl(Duration.ofMinutes(durationInMinutes));
        return RedisCacheManager.builder(jedisConnectionFactory).cacheDefaults(redisCacheConfigurationWithTtl).build();
    }

    @Bean
    @Override
    public CacheErrorHandler errorHandler() {
        return new CacheErrorHandler() {
            @Override
            public void handleCacheGetError(RuntimeException e, Cache cache, Object key) {
                System.err.println("Got error trying to get key = " + key);
                e.printStackTrace();
            }

            @Override
            public void handleCachePutError(RuntimeException e, Cache cache, Object key, Object value) {
                System.err.println("Got error trying to put key = " + key);
                e.printStackTrace();
            }

            @Override
            public void handleCacheEvictError(RuntimeException e, Cache cache, Object key) {
                System.err.println("Got error trying to evict key = " + key);
                e.printStackTrace();
            }

            @Override
            public void handleCacheClearError(RuntimeException e, Cache cache) {
                System.err.println("Got error trying to clear cache");
                e.printStackTrace();
            }
        };
    }
}
