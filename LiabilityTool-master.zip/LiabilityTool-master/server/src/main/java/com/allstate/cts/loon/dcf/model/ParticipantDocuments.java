package com.allstate.cts.loon.dcf.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ParticipantDocuments {
    private String fullName;
    private String participantSourceId;

    @Builder.Default
    private List<PhotoDetail> photoUrlList = new ArrayList<>();
}
