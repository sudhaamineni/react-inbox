package com.allstate.cts.loon.nextGenComponents.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FileNote {

    private String ClaimID;
    private List<String> Categories;
    private String SubCategory;
    private String SubCategory2;
    private boolean MarkInErrorReason; //false
    private boolean MarkInErrInd;
    private String StandardText;
    private String AdditionalNotes;
    private String FNTextID;
    private String ShortText;
    private String Description;
    private String Comments;
    private boolean SignificantInd; //false
    private boolean DraftInd; //false
    private boolean UpdateFileNoteWithNullPart; //false
    private boolean SystemGeneratedInd;
    private String FileNoteFinal; //String
    private String FinalOn;
    private String Created;
    private String LastUpdate;
    private boolean AttachmentExists;
    private boolean UpdateFinal;
    private boolean FromFNWebService;
    private boolean FromSnapshot;
    private List<FilenoteParticipant> Participants;
    private boolean FailedFCPPymnt;
    private boolean LetterApprovalRequested;
    private boolean LetterRejected;
    private boolean SkipParticipantValidation;
    private boolean DocCollectionPackage;
    private boolean AlreadyInEDMS;
    private boolean FollowUp;
    private boolean Reviewed;
    private boolean DocViewer;
    private boolean AttachInsertNotUpdate;
    private boolean MessageToCustomer;
    private boolean NotifyToViewMessage;
    private boolean SendToECS;
    private String LineId;
    private String ClaimNumber;
    private FilenoteAttachment FNAttachment;
}
