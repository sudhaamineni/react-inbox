package com.allstate.cts.loon.liabilityAnalysis.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AffectedParty {
    private String participantId;
    private String participantSourceId;
    private String assetId;
    private List<String> passengerPartyIds;
    private Integer initialFaultPercent;
    private Integer beginNegotiatingRange;
    private Integer endNegotiatingRange;
    private Integer submittedInitialFaultPercent;
    private Integer faultAllocationPercent;
}
