package com.allstate.cts.loon.startup.model;

import com.allstate.cts.loon.configuration.FeatureSwitches;
import com.allstate.cts.loon.liabilityAnalysis.entity.LiabilityAnalysisEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ClientInit {
    private String userId;
    private List<String> userRoles;
    private LiabilityAnalysisEntity assignedClaimData;
    private FeatureSwitches featureSwitches;
}