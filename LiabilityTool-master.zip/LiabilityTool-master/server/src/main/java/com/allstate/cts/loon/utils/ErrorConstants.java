package com.allstate.cts.loon.utils;

import lombok.experimental.UtilityClass;

@UtilityClass
public class ErrorConstants {
    public static final String KAFKA_CONSUMER_CONFIG_INTERNAL_ERROR =
            "KafkaConsumerConfig - encountered internal error";
    public static final String LOON_ELIGIBILITY_FNOL_CONSUMER_MESSAGE_RECEIVED =
            "Loon FNOL Consumer - message received";
    public static final String LOON_ELIGIBILITY_FNOL_CONSUMER_INTERNAL_ERROR =
            "Loon FNOL Consumer: onReceiving - encountered internal error";
}