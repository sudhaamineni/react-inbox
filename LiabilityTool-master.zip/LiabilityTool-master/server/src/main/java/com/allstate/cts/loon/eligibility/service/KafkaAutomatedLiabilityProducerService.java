package com.allstate.cts.loon.eligibility.service;

import com.allstate.cts.loon.configuration.KafkaProperties;
import com.allstate.cts.loon.eligibility.model.FNOLContext;
import com.allstate.cts.loon.eligibility.model.KafkaFNOLClaimData;
import com.compozed.appfabric.logging.AppFabricLogger;
import com.compozed.appfabric.logging.annotations.AppFabricLog;
import org.springframework.kafka.KafkaException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import static com.allstate.cts.loon.constants.LoonConstants.LOON_SERVER_EXCEPTION;
import static com.allstate.cts.loon.constants.LoonConstants.LOON_SERVER_INFO;
import static com.compozed.appfabric.logging.LoggingEventType.APPLICATION;
import static com.compozed.appfabric.logging.LoggingEventType.SYSTEM;
import static com.compozed.appfabric.logging.LoggingResultType.FAILURE;
import static com.compozed.appfabric.logging.LoggingResultType.SUCCESS;

@Service
public class KafkaAutomatedLiabilityProducerService {

    private KafkaTemplate kafkaTemplate;
    private KafkaProperties kafkaProperties;

    @AppFabricLog
    private AppFabricLogger logger;

    public KafkaAutomatedLiabilityProducerService(KafkaTemplate kafkaTemplate,
                                                  KafkaProperties kafkaProperties) {
        this.kafkaTemplate = kafkaTemplate;
        this.kafkaProperties = kafkaProperties;
    }

    public void publishFNOLToKafka(FNOLContext fnolContext) {
        ListenableFuture<SendResult<String, KafkaFNOLClaimData>> future = kafkaTemplate.send(kafkaProperties.getFnolTopic(), "CorelationGUID", fnolContext);
        future.addCallback(new ListenableFutureCallback<SendResult<String, KafkaFNOLClaimData>>() {

            @Override
            public void onSuccess(SendResult<String, KafkaFNOLClaimData> result) {

                logger.info(
                        LOON_SERVER_INFO, APPLICATION, "KafkaAutomatedLiabilityProducerService",
                        "publishFNOLToKafka",
                        SUCCESS, "Send Result: " + result.getProducerRecord());
            }

            @Override
            public void onFailure(Throwable ex) {

                logger.error(LOON_SERVER_EXCEPTION, ex, SYSTEM,
                        "KafkaAutomatedLiabilityProducerService",
                        "publishFNOLToKafka", FAILURE, ex.getMessage()
                );
                throw new KafkaException(ex.getMessage());
            }
        });
    }
}
