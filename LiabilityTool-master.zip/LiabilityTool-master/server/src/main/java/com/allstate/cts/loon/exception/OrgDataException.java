package com.allstate.cts.loon.exception;

public class OrgDataException extends RuntimeException implements CustomException {
    private final String msgHeader;
    private final String msgDescription;

    public OrgDataException(String ntId) {
        this.msgHeader = "No Results for ntId " + ntId;
        this.msgDescription = "We were unable to find user information. Please check and try again.";
    }

    @Override
    public String getMessageHeader() {
        return this.msgHeader;
    }

    @Override
    public String getMessageDescription() {
        return this.msgDescription;
    }
}