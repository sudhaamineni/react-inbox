package com.allstate.cts.loon.helpers;

import org.springframework.stereotype.Component;

import java.util.regex.Pattern;

@Component
public class Validator {
    public boolean isStringSafeForLeela(String inputString) {
        if (inputString != null) {
            Pattern p = Pattern.compile("[^0-9]");
            return !p.matcher(inputString).find();
        }

        return true;
    }

    public String padClaimNumber(String claimNumber) {
        try {
            claimNumber = String.format("%012d", Integer.parseInt(claimNumber));
        } catch (Exception e) {
            // Do nothing adding this comment to fix sonarqube bug
        }
        return claimNumber;
    }
}