package com.allstate.cts.loon.security;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.GenericFilterBean;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static com.allstate.cts.loon.constants.SecurityConstants.LOON_API_KEY_HEADER;
import static org.springframework.util.StringUtils.isEmpty;

@Component
public class ApiKeyValidatorFilter extends GenericFilterBean {
    String loonClientApiKey;

    public ApiKeyValidatorFilter(@Value("${liabilityAnalysis.clientApiKey}") String loonClientKey) {
        this.loonClientApiKey = loonClientKey;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        if(isEmpty(loonClientApiKey)) {
            throw new ServletException("Missing loon client api key.");
        }

        if (!isUserAuthenticated()) {
            chain.doFilter(request, response);
            return;
        }

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        String apiKey = httpRequest.getHeader(LOON_API_KEY_HEADER);

        if (!loonClientApiKey.equals(apiKey)) {
            ((HttpServletResponse) response).sendError(HttpServletResponse.SC_FORBIDDEN, "API Key is not valid.");
        } else {
            chain.doFilter(request, response);
        }
    }

    private boolean isUserAuthenticated() {
        boolean isAuthenticated = false;

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication != null && authentication.isAuthenticated()) {
            isAuthenticated = true;
        }

        return isAuthenticated;
    }
}
