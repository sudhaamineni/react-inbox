package com.allstate.cts.loon.exception;

public class TaskException extends RuntimeException implements CustomException {
    private final String msgHeader;
    private final String msgDescription;

    public TaskException(String claimNumber) {
        this.msgHeader ="Error creating task for Claim #" + claimNumber;
        this.msgDescription = "We were unable to create a task. Please try again.";
    }

    @Override
    public String getMessageHeader() {
        return this.msgHeader;
    }

    @Override
    public String getMessageDescription() { return this.msgDescription; }
}