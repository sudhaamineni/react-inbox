package com.allstate.cts.loon.liabilityDecision.itext;

import com.allstate.cts.loon.exception.SubmissionSystemErrorException;
import com.allstate.cts.loon.helpers.DateTimeHelper;
import com.allstate.cts.loon.liabilityAnalysis.entity.LiabilityAnalysisEntity;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import org.apache.commons.io.IOUtils;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;

import static com.allstate.cts.loon.liabilityDecision.itext.ITextConstants.FontColors.GRAY_6B6B6B;
import static com.allstate.cts.loon.liabilityDecision.itext.ITextConstants.FontColors.GREEN_005F6E;
import static com.allstate.cts.loon.liabilityDecision.itext.ITextHelper.*;
import static com.itextpdf.text.Element.*;
import static com.itextpdf.text.PageSize.A4;
import static com.itextpdf.text.Rectangle.BOTTOM;
import static com.itextpdf.text.Rectangle.TOP;
import static com.itextpdf.text.html.WebColors.getRGBColor;

public class ITextPageEventHandler extends PdfPageEventHelper {
    private PdfTemplate pageCountTemplate;
    private Image pageCountImage;
    private String claimNumber;
    private LiabilityAnalysisEntity liabilityAnalysisEntity;
    private DateTimeHelper dateTimeHelper;


    ITextPageEventHandler(LiabilityAnalysisEntity liabilityAnalysisEntity) {
        this.dateTimeHelper = new DateTimeHelper();
        this.liabilityAnalysisEntity = liabilityAnalysisEntity;
        this.claimNumber = liabilityAnalysisEntity.getClaimNumber();
    }

    @Override
    public void onOpenDocument(PdfWriter writer, Document document) {
        try {
            pageCountTemplate = writer.getDirectContent().createTemplate(convertToPoints(24), convertToPoints(15));
            pageCountImage = Image.getInstance(pageCountTemplate);
        } catch (DocumentException e) {
            throw new SubmissionSystemErrorException(e);
        }
    }

    public void onCloseDocument(PdfWriter writer, Document document) {
        try {
            Phrase phrase = new Phrase(String.valueOf(writer.getPageNumber()), getAllstateSansRegularFont(12, GRAY_6B6B6B));
            ColumnText.showTextAligned(pageCountTemplate, ALIGN_LEFT, phrase, 2, 2, 0);
        } catch (DocumentException | IOException e) {
            throw new SubmissionSystemErrorException(e);
        }
    }

    public void onEndPage(PdfWriter writer, Document document) {
        try {
            createHeader(writer);
            createFooter(writer, document);
        } catch (DocumentException | IOException e) {
            throw new SubmissionSystemErrorException(e);
        }
    }

    private void createHeader(PdfWriter writer) throws DocumentException, IOException {
        PdfPTable table = getDefaultTable(6);
        table.setTotalWidth(A4.getWidth());
        table.setWidths(new int[]{8, 10, 19, 18, 18, 27});

        table.addCell(getLoonLogoImage());
        table.addCell(getLoonLogoText());
        table.addCell(getClaimNumber());
        table.addCell(getCurrentPageNumber(writer, BOTTOM));
        table.addCell(getTotalPageNumber(BOTTOM));
        table.addCell(getSubmittedText());

        table.writeSelectedRows(0, -1, 0, A4.getHeight() - convertToPoints(5), writer.getDirectContent());
    }

    private void createFooter(PdfWriter writer, Document document) throws DocumentException, IOException {
        PdfPTable tableFooter = getDefaultTable(6);
        tableFooter.setTotalWidth(A4.getWidth());
        tableFooter.setWidths(new int[]{8, 10, 19, 18, 18, 27});

        tableFooter.addCell(getEmptyCell(TOP));
        tableFooter.addCell(getEmptyCell(TOP));
        tableFooter.addCell(getEmptyCell(TOP));
        tableFooter.addCell(getCurrentPageNumber(writer, TOP));
        tableFooter.addCell(getTotalPageNumber(TOP));
        tableFooter.addCell(getEmptyCell(TOP));

        tableFooter.writeSelectedRows(0, -1, 0, document.bottom(), writer.getDirectContent());
    }

    private PdfPCell getLoonLogoImage() throws DocumentException, IOException {
        Image image = Image.getInstance(IOUtils.toByteArray(new ClassPathResource("images/loon-logo.png").getInputStream()));
        image.scaleToFit(convertToPoints(48), convertToPoints(24));
        PdfPCell cell = new PdfPCell(image);
        cell.setVerticalAlignment(ALIGN_MIDDLE);
        cell.setFixedHeight(convertToPoints(56));
        cell.setPaddingLeft(convertToPoints(16));
        cell.setUseVariableBorders(true);
        cell.setBorderColorBottom(getRGBColor(GRAY_6B6B6B));
        cell.setBorder(BOTTOM);
        return cell;
    }

    private PdfPCell getLoonLogoText() throws DocumentException, IOException {
        Phrase phrase = new Phrase("LOON", getAllstateSansRegularFont(18, GREEN_005F6E));
        PdfPCell cell = new PdfPCell(phrase);
        cell.setPaddingLeft(convertToPoints(16));
        cell.setBorderColorBottom(getRGBColor(GRAY_6B6B6B));
        cell.setVerticalAlignment(ALIGN_MIDDLE);
        cell.setUseAscender(true);
        cell.setUseVariableBorders(true);
        cell.setBorder(BOTTOM);
        return cell;
    }

    private PdfPCell getCurrentPageNumber(PdfWriter writer, int border) throws DocumentException, IOException {
        Phrase phrase = new Phrase(String.format("Page %d of", writer.getPageNumber()), getAllstateSansRegularFont(12, GRAY_6B6B6B));
        PdfPCell cell = new PdfPCell(phrase);
        cell.setHorizontalAlignment(ALIGN_RIGHT);
        if (border == TOP) {
            cell.setBorderColorTop(getRGBColor(GRAY_6B6B6B));
        } else {
            cell.setBorderColorBottom(getRGBColor(GRAY_6B6B6B));
        }
        cell.setFixedHeight(convertToPoints(40));
        cell.setVerticalAlignment(ALIGN_MIDDLE);
        cell.setUseAscender(true);
        cell.setUseVariableBorders(true);
        cell.setBorder(border);
        return cell;
    }

    private PdfPCell getTotalPageNumber(int border) {
        PdfPCell cell = new PdfPCell(pageCountImage);
        if (border == TOP) {
            cell.setBorderColorTop(getRGBColor(GRAY_6B6B6B));
        } else {
            cell.setBorderColorBottom(getRGBColor(GRAY_6B6B6B));
        }
        cell.setVerticalAlignment(ALIGN_MIDDLE);
        cell.setUseVariableBorders(true);
        cell.setBorder(border);
        return cell;
    }

    private PdfPCell getClaimNumber() throws DocumentException, IOException {
        Phrase phrase = new Phrase("Claim #" + claimNumber, getAllstateSansRegularFont(12, GRAY_6B6B6B));
        PdfPCell cell = new PdfPCell(phrase);
        cell.setBorderColorBottom(getRGBColor(GRAY_6B6B6B));
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(ALIGN_MIDDLE);
        cell.setPaddingRight(convertToPoints(16));
        cell.setUseAscender(true);
        cell.setUseVariableBorders(true);
        cell.setBorder(BOTTOM);
        return cell;
    }

    private PdfPCell getSubmittedText() throws IOException, DocumentException {
        Phrase phrase = new Phrase("Initial Fault Last Submitted\n" + dateTimeHelper.formatTimeInCST(liabilityAnalysisEntity.getInitialFaultSubmitTime()), getAllstateSansRegularFont(12, GRAY_6B6B6B));
        PdfPCell cell = new PdfPCell(phrase);
        cell.setBorderColorBottom(getRGBColor(GRAY_6B6B6B));
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(ALIGN_MIDDLE);
        cell.setPaddingRight(convertToPoints(16));
        cell.setUseAscender(true);
        cell.setUseVariableBorders(true);
        cell.setBorder(BOTTOM);
        return cell;
    }
}
