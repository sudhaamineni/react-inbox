package com.allstate.cts.loon.helpers;

import com.allstate.cts.loon.claimData.model.Damages;
import com.allstate.cts.loon.liabilityAnalysis.entity.DamagesEntity;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

import static org.springframework.util.CollectionUtils.isEmpty;

@Component
public class DamageConverter {
    public List<DamagesEntity> convertDamages(Damages damages) {
        List<DamagesEntity> damagesEntities = new ArrayList<>();


        if (damages != null) {
            if (!isEmpty(damages.getRear())) {
                DamagesEntity rearDamagesEntity = new DamagesEntity();
                rearDamagesEntity.setDamageArea("REAR");
                rearDamagesEntity.setDamageParts(damages.getRear());
                damagesEntities.add(rearDamagesEntity);
            }
            if (!isEmpty(damages.getFront())) {
                DamagesEntity frontDamagesEntity = new DamagesEntity();
                frontDamagesEntity.setDamageArea("FRONT");
                frontDamagesEntity.setDamageParts(damages.getFront());
                damagesEntities.add(frontDamagesEntity);
            }
            if (!isEmpty(damages.getOther())) {
                DamagesEntity otherDamagesEntity = new DamagesEntity();
                otherDamagesEntity.setDamageArea("OTHER");
                otherDamagesEntity.setDamageParts(damages.getOther());
                damagesEntities.add(otherDamagesEntity);
            }
            if (!isEmpty(damages.getPassengerSideExterior())) {
                DamagesEntity passengerSideExteriorDamagesEntity = new DamagesEntity();
                passengerSideExteriorDamagesEntity.setDamageArea("PASSENGER SIDE EXTERIOR");
                passengerSideExteriorDamagesEntity.setDamageParts(damages.getPassengerSideExterior());
                damagesEntities.add(passengerSideExteriorDamagesEntity);
            }
            if (!isEmpty(damages.getDriverSideExterior())) {
                DamagesEntity driverSideExteriorDamagesEntity = new DamagesEntity();
                driverSideExteriorDamagesEntity.setDamageArea("DRIVER SIDE EXTERIOR");
                driverSideExteriorDamagesEntity.setDamageParts(damages.getDriverSideExterior());
                damagesEntities.add(driverSideExteriorDamagesEntity);
            }
            if (!isEmpty(damages.getMechanical())) {
                DamagesEntity mechanicalDamagesEntity = new DamagesEntity();
                mechanicalDamagesEntity.setDamageArea("MECHANICAL");
                mechanicalDamagesEntity.setDamageParts(damages.getMechanical());
                damagesEntities.add(mechanicalDamagesEntity);
            }
            if (!isEmpty(damages.getInterior())) {
                DamagesEntity interiorDamagesEntity = new DamagesEntity();
                interiorDamagesEntity.setDamageArea("INTERIOR");
                interiorDamagesEntity.setDamageParts(damages.getInterior());
                damagesEntities.add(interiorDamagesEntity);
            }
        }
        return  damagesEntities;
    }
}
