package com.allstate.cts.loon;

import com.allstate.cts.loon.configuration.PostConstructConfigurer;
import com.compozed.appfabric.logging.EnableLogging;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.amqp.RabbitAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.retry.annotation.EnableRetry;

import javax.annotation.PostConstruct;

import static java.lang.System.getenv;
import static java.lang.System.setProperty;
import static java.util.Objects.nonNull;

@SpringBootApplication(exclude = RabbitAutoConfiguration.class)
@ComponentScan(basePackages = {"com.allstate.cts"})
@EnableRetry
@EnableJms
@EnableLogging
public class LiabilityToolApplication {
    private static final String ACTIVE_PROFILE = "spring.profiles.active";
    private static final String ENV = "env";
    private final PostConstructConfigurer postConstructConfigurer;

    public LiabilityToolApplication(PostConstructConfigurer postConstructConfigurer) {
        this.postConstructConfigurer = postConstructConfigurer;
    }

    public static void main(String[] args) {
//        if (nonNull(getenv(ENV)))
//            setProperty(ACTIVE_PROFILE, getenv(ENV));

        SpringApplication.run(LiabilityToolApplication.class, args);
    }

    @PostConstruct
    public void runPostConstructConfiguration() {
        postConstructConfigurer.configure();
    }
}
