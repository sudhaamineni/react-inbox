package com.allstate.cts.loon.nextGenComponents.service;

import com.allstate.cts.loon.nextGenComponents.model.AddTaskRequest;
import com.allstate.cts.loon.nextGenComponents.model.AddTaskResponse;
import com.allstate.cts.loon.nextGenComponents.model.FileNote;
import com.allstate.cts.loon.nextGenComponents.model.FileNoteResponse;

public interface NextGenComponentsServiceInterface {

    FileNoteResponse publishFileNote(String claimNumber, FileNote fileNote);
}
