package com.allstate.cts.loon.exception;

public class SystemErrorException extends RuntimeException implements CustomException {
    private final String msgHeader;
    private final String msgDescription;
    public SystemErrorException() {
        this.msgHeader = "Our systems are currently unavailable";
        this.msgDescription = "Our systems are currently unable to process your search. Please try again later.";
    }

    @Override
    public String getMessageHeader() {
        return this.msgHeader;
    }

    @Override
    public String getMessageDescription() { return this.msgDescription; }
}
