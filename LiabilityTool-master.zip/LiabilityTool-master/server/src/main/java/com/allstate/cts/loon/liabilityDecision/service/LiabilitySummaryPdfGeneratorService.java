package com.allstate.cts.loon.liabilityDecision.service;

import com.allstate.cts.loon.liabilityDecision.itext.ITextPdfGenerator;
import com.allstate.cts.loon.liabilityDecision.model.SubmitLiabilityDecisionRequest;
import org.springframework.stereotype.Service;

@Service
public class LiabilitySummaryPdfGeneratorService {
    private ITextPdfGenerator iTextPdfGenerator;

    public LiabilitySummaryPdfGeneratorService(ITextPdfGenerator iTextPdfGenerator) {
        this.iTextPdfGenerator = iTextPdfGenerator;
    }

    public byte[] generateSummaryPdf(SubmitLiabilityDecisionRequest submitLiabilityDecisionRequest) {
        return iTextPdfGenerator.createPdf(submitLiabilityDecisionRequest);
    }
}