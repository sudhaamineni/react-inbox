package com.allstate.cts.loon.configuration;

import com.allstate.cts.loon.resttemplate.LoonRestTemplate;
import com.allstate.cts.loon.utils.SecurityUtility;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.http.MediaType.MULTIPART_FORM_DATA;

@Configuration
public class LoonRestTemplateConfig {
    public static final String LIABILITY_TOOL = "Liability Tool";
    public static final String CLIENT_KEY = "CLIENT_KEY";

    private String leelaClaimUrl;
    private String leelaClientKey;
    private String orgDataUrl;
    private String orgDataClientKey;
    private String ravenUrl;
    private String ravenUsername;
    private String ravenPassword;
    private String dcfUrl;
    private String dcfContentUrl;
    private String dcfStoreUrl;
    private String dcfClientKey;
    private String nextGenUrl;
    private String nextGenUserId;
    private String parakeetUrl;
    private String parakeetApiKey;
    private String liabilityAnalysisSystemId;
    private String griffinUrl;
    private SecurityUtility securityUtility;

    public LoonRestTemplateConfig(
        @Value("${leela.claimUrl}") String leelaClaimUrl,
        @Value("${leela.clientKey}") String leelaClientKey,
        @Value("${shadow.orgData.url}") String orgDataUrl,
        @Value("${shadow.orgData.clientKey}") String orgDataClientKey,
        @Value("${raven.url}") String ravenUrl,
        @Value("${raven.username}") String ravenUsername,
        @Value("${raven.password}") String ravenPassword,
        @Value("${dcf.url}") String dcfUrl,
        @Value("${dcf.contentUrl}") String dcfContentUrl,
        @Value("${dcf.storeUrl}") String dcfStoreUrl,
        @Value("${dcf.clientKey}") String dcfClientKey,
        @Value("${nextGen.url}") String nextGenUrl,
        @Value("${nextGen.userId}") String nextGenUserId,
        @Value("${parakeet.url}") String parakeetUrl,
        @Value("${parakeet.api.key}") String parakeetApiKey,
        @Value("${liabilityanalysis.systemId}") String liabilityAnalysisSystemId,
        @Value("${griffin.url}") String griffinUrl,
        SecurityUtility securityUtility) {
        this.leelaClaimUrl = leelaClaimUrl;
        this.leelaClientKey = leelaClientKey;
        this.orgDataUrl = orgDataUrl;
        this.orgDataClientKey = orgDataClientKey;
        this.ravenUrl = ravenUrl;
        this.ravenUsername = ravenUsername;
        this.ravenPassword = ravenPassword;
        this.dcfUrl = dcfUrl;
        this.dcfContentUrl = dcfContentUrl;
        this.dcfStoreUrl = dcfStoreUrl;
        this.dcfClientKey = dcfClientKey;
        this.nextGenUrl = nextGenUrl;
        this.nextGenUserId = nextGenUserId;
        this.parakeetUrl = parakeetUrl;
        this.parakeetApiKey = parakeetApiKey;
        this.liabilityAnalysisSystemId = liabilityAnalysisSystemId;
        this.griffinUrl = griffinUrl;
        this.securityUtility = securityUtility;
    }

    @Bean(name = "leelaClaimRestTemplate")
    public LoonRestTemplate leelaClaimRestTemplate() {
        return LoonRestTemplate.builder()
            .httpHeaders(buildLeelaHeaders())
            .systemName(LIABILITY_TOOL)
            .targetSystemName("Leela")
            .targetSystemUrl(leelaClaimUrl)
            .build();
    }

    @Bean(name = "orgDataRestTemplate")
    public LoonRestTemplate orgDataRestTemplate() {
        return LoonRestTemplate.builder()
            .httpHeaders(buildOrgDataHeaders())
            .systemName(LIABILITY_TOOL)
            .targetSystemName("Shadow")
            .targetSystemUrl(orgDataUrl)
            .build();
    }

    @Bean(name = "ravenRestTemplate")
    public LoonRestTemplate ravenRestTemplate() {
        return LoonRestTemplate.builder()
            .httpHeaders(buildRavenHeaders())
            .systemName(LIABILITY_TOOL)
            .targetSystemName("Raven")
            .targetSystemUrl(ravenUrl)
            .build();
    }

    @Bean(name = "dcfRestTemplate")
    public LoonRestTemplate dcfRestTemplate() {
        return LoonRestTemplate.builder()
            .httpHeaders(buildDcfHeaders(APPLICATION_JSON))
            .systemName(LIABILITY_TOOL)
            .targetSystemName("DCF")
            .targetSystemUrl(dcfUrl)
            .build();
    }

    @Bean(name = "dcfContentRestTemplate")
    public LoonRestTemplate dcfContentRestTemplate() {
        return LoonRestTemplate.builder()
            .httpHeaders(buildDcfHeaders(APPLICATION_JSON))
            .systemName(LIABILITY_TOOL)
            .targetSystemName("DCF Content")
            .targetSystemUrl(dcfContentUrl)
            .build();
    }

    @Bean(name = "dcfStoreRestTemplate")
    public LoonRestTemplate dcfStoreRestTemplate() {
        return LoonRestTemplate.builder()
            .httpHeaders(buildDcfHeaders(MULTIPART_FORM_DATA))
            .systemName(LIABILITY_TOOL)
            .targetSystemName("DCF Store")
            .targetSystemUrl(dcfStoreUrl)
            .build();
    }

    @Bean(name = "nextGenRestTemplate")
    public LoonRestTemplate nextGenRestTemplate() {
        return LoonRestTemplate.builder()
            .httpHeaders(buildNextGenHeaders())
            .systemName(LIABILITY_TOOL)
            .targetSystemName("NextGen")
            .targetSystemUrl(nextGenUrl)
            .build();
    }

    @Bean(name = "parakeetRestTemplate")
    public LoonRestTemplate parakeetRestTemplate() {
        return LoonRestTemplate.builder()
            .httpHeaders(buildParakeetHeaders())
            .systemName(LIABILITY_TOOL)
            .targetSystemName("Parakeet")
            .targetSystemUrl(parakeetUrl)
            .build();
    }

    @Bean(name = "griffinRestTemplate")
    public LoonRestTemplate griffinRestTemplate() {
        return LoonRestTemplate.builder()
            .httpHeaders(buildGriffinHeaders())
            .systemName(LIABILITY_TOOL)
            .targetSystemName("Griffin")
            .targetSystemUrl(griffinUrl)
            .build();
    }

    private HttpHeaders buildLeelaHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(APPLICATION_JSON);
        headers.add(CLIENT_KEY, leelaClientKey);
        return headers;
    }

    private HttpHeaders buildOrgDataHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(APPLICATION_JSON);
        headers.add(CLIENT_KEY, orgDataClientKey);
        return headers;
    }

    private HttpHeaders buildRavenHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(APPLICATION_JSON);
        headers.add(
            "Authorization",
            securityUtility.encodeCredentials(ravenUsername, ravenPassword));
        return headers;
    }

    private HttpHeaders buildDcfHeaders(MediaType mediaType) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(mediaType);
        headers.add(CLIENT_KEY, dcfClientKey);
        headers.add("SYSTEM_ID", liabilityAnalysisSystemId);
        return headers;
    }

    private HttpHeaders buildNextGenHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(APPLICATION_JSON);
        headers.add("user", nextGenUserId);
        return headers;
    }

    private HttpHeaders buildParakeetHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(APPLICATION_JSON);
        headers.add("api-key", parakeetApiKey);
        return headers;
    }

    private HttpHeaders buildGriffinHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(APPLICATION_JSON);
        return headers;
    }
}