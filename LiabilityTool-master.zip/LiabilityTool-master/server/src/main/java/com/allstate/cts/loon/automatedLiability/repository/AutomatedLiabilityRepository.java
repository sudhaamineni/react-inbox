package com.allstate.cts.loon.automatedLiability.repository;

import com.allstate.cts.loon.automatedLiability.entity.AutomatedLiabilityEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface AutomatedLiabilityRepository extends MongoRepository<AutomatedLiabilityEntity, String> {
    AutomatedLiabilityEntity findByClaimNumber(String claimNumber);

    Optional<AutomatedLiabilityEntity> findById(String id);
}