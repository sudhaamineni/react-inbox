package com.allstate.cts.loon.automatedLiability.service;

import com.allstate.cts.loon.automatedLiability.entity.AutomatedLiabilityEntity;
import com.allstate.cts.loon.automatedLiability.repository.AutomatedLiabilityRepository;
import org.springframework.stereotype.Service;

@Service
public class AutomatedLiabilityService {
    private AutomatedLiabilityRepository automatedLiabilityRepository;

    public AutomatedLiabilityService(AutomatedLiabilityRepository automatedLiabilityRepository) {
        this.automatedLiabilityRepository = automatedLiabilityRepository;
    }

    public void processAutomatedLiability(AutomatedLiabilityEntity automatedLiabilityEntity) {
        automatedLiabilityRepository.save(automatedLiabilityEntity);
    }
}
