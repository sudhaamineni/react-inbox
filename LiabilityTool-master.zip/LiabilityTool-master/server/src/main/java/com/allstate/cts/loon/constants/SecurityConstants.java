package com.allstate.cts.loon.constants;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class SecurityConstants {
    public static final String ISAM_USER_HEADER = "IV-USER";
    public static final String ISAM_GROUPS_HEADER = "IV-GROUPS";
    public static final String AD_NON_PROD_GENERAL_ACCESS_GROUP = "LOON-NONPROD";
    public static final String AD_PROD_GENERAL_ACCESS_GROUP = "LOON-PROD";
    public static final String LOON_API_KEY_HEADER = "API-KEY";
    public static final String ORG_ROLE_LOON_USER_CODE = "1907";
    public static final String ORG_ROLE_LOON_USER = "LOON User";
    public static final String ORG_ROLE_LOON_READ_ONLY_USER = "LOON Read Only User";
    public static final String ORG_ROLE_LOON_READ_ONLY_USER_CODE = "1908";
}