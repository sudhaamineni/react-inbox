package com.allstate.cts.loon.nextGenComponents.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FilenoteParticipant {

    private String sInsInvlID;
    private String sInvlRoleID;
    private String sNameID;
    private String sFullName;
    private String tPartRoleTree;

}