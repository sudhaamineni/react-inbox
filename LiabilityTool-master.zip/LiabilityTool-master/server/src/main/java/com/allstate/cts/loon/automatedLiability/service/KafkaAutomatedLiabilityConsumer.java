package com.allstate.cts.loon.automatedLiability.service;

import com.allstate.cts.loon.automatedLiability.entity.AutomatedLiabilityEntity;
import com.allstate.cts.loon.exception.LoonInvalidMessageException;
import com.allstate.cts.loon.helpers.DateTimeHelper;
import com.allstate.cts.loon.helpers.ObjectMapperFactory;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;

@Service
public class KafkaAutomatedLiabilityConsumer {
    private DateTimeHelper dateTimeHelper;
    private AutomatedLiabilityService automatedLiabilityService;
    private ObjectMapperFactory objectMapperFactory;

    public KafkaAutomatedLiabilityConsumer(DateTimeHelper dateTimeHelper,
                                           AutomatedLiabilityService automatedLiabilityService,
                                           ObjectMapperFactory objectMapperFactory) {
        this.dateTimeHelper = dateTimeHelper;
        this.automatedLiabilityService = automatedLiabilityService;
        this.objectMapperFactory = objectMapperFactory;
    }

    public void onReceiving(byte[] entry, Acknowledgment ack) {
        String entryString = new String(entry, StandardCharsets.UTF_8);

        try {
            AutomatedLiabilityEntity automatedLiabilityEntity = getAutomatedLiabilityFromMessage(entryString);
            automatedLiabilityService.processAutomatedLiability(automatedLiabilityEntity);
            ack.acknowledge();

        } catch (LoonInvalidMessageException ex) {
            ack.acknowledge();
            return;
        } catch (Exception ex) {
            return;
        }
    }

    protected AutomatedLiabilityEntity getAutomatedLiabilityFromMessage(String entryString) throws Exception {
        AutomatedLiabilityEntity automatedLiabilityEntity;
        JsonParser jsonParser = null;
        try {
            ObjectMapper objectMapper = objectMapperFactory.getObjectMapper();
            JsonFactory jsonFactory = objectMapper.getFactory();
            jsonParser = jsonFactory.createParser(entryString);
            automatedLiabilityEntity = jsonParser.readValueAs(AutomatedLiabilityEntity.class);
        } catch (Exception exception) {
            throw new LoonInvalidMessageException("Deserialization of kafka message into Automated Liability failed", exception);
        } finally {
            if (jsonParser != null)
                jsonParser.close();
        }
        automatedLiabilityEntity.setCreatedDate(dateTimeHelper.getCurrentDateTime());

        return automatedLiabilityEntity;
    }
}