package com.allstate.cts.loon.automatedLiability.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LiabilityScore {
    private String id;
    private Double score0;
    private Double score100;
    private String gretzkyVersion;
    private Double scoreGreaterThan0LessThan100;
}