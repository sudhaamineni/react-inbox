package com.allstate.cts.loon.exception;

public class ClaimInsuredNotFoundException extends RuntimeException implements CustomException {
    private final String msgHeader;
    private final String msgDescription;

    public ClaimInsuredNotFoundException(String claimNumber) {
        this.msgHeader ="No Insured for Claim #" + claimNumber;
        this.msgDescription = "We were unable to find an insured participant on the claim.";
    }

    @Override
    public String getMessageHeader() {
        return this.msgHeader;
    }

    @Override
    public String getMessageDescription() { return this.msgDescription; }
}
