package com.allstate.cts.loon.liabilityDecision.itext;

import com.allstate.cts.loon.exception.SubmissionSystemErrorException;
import com.allstate.cts.loon.helpers.ClaimDataModelHelper;
import com.allstate.cts.loon.liabilityAnalysis.entity.*;
import com.allstate.cts.loon.resttemplate.LoonRestTemplate;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

import static com.allstate.cts.loon.liabilityDecision.itext.ITextConstants.FontColors.GRAY_333333;
import static com.allstate.cts.loon.liabilityDecision.itext.ITextConstants.FontColors.GRAY_484848;
import static com.allstate.cts.loon.liabilityDecision.itext.ITextHelper.*;
import static com.itextpdf.text.Font.BOLD;
import static com.itextpdf.text.Rectangle.NO_BORDER;
import static java.util.Arrays.asList;
import static java.util.Objects.isNull;
import static java.util.stream.IntStream.range;

@Component
public class ITextInitialFaultDetailsSectionGenerator {
    private ClaimDataModelHelper claimDataModelHelper;
    private LoonRestTemplate dcfContentRestTemplate;

    private static Map<String, String> contributingFactorReasons = new HashMap<>();
    private static Map<String, String> contributingFactorDetails = new HashMap<>();
    private static Map<Integer, String> numberWords = new HashMap<>();
    private static Map<String, String> categoriesAndLabels = new HashMap<>();
    private static final String OTHER = "Other";

    static {
        contributingFactorReasons.put("participant-has-right-of-way", "Has Right of Way");
        contributingFactorReasons.put("participant-did-not-have-right-of-way", "Didn't Have Right of Way");
        contributingFactorReasons.put("failed-to-obey-traffic-control", "Failed to Obey Traffic Control");
        contributingFactorReasons.put("failed-to-adhere-to-lane-of-travel", "Failed to Adhere to Lane of Travel");
        contributingFactorReasons.put("improper-maneuver", "Improper Maneuver");
        contributingFactorReasons.put("failed-to-signal", "Failed to Signal");
        contributingFactorReasons.put("unsafe-speed-for-circumstances", "Unsafe speed for circumstances");
        contributingFactorReasons.put("driver-compromised", "Driver Compromised");
        contributingFactorReasons.put("mechanical-failure", "Mechanical Failure");
        contributingFactorReasons.put("additional-factors-other", OTHER);
        contributingFactorReasons.put("proper-lookout", "Proper Lookout");
        contributingFactorReasons.put("improper-lookout", "Improper Lookout");
        contributingFactorReasons.put("late-recognition", "Late Recognition");
        contributingFactorReasons.put("timely-recognition", "Timely Recognition");
        contributingFactorReasons.put("timely-recognition-other", OTHER);
        contributingFactorReasons.put("took-evasive-action", "Took Evasive Action");
        contributingFactorReasons.put("did-not-take-evasive-action", "Didn't Take Evasive Action");
        contributingFactorReasons.put("evasive-action-other", OTHER);

        contributingFactorDetails.put("failure-to-obey-appropriate-signage", "Failure to obey appropriate signage");
        contributingFactorDetails.put("failure-to-obey-traffic-guard-officer", "Failure to obey traffic guard/officer");
        contributingFactorDetails.put("saw-obstruction-in-roadway", "Saw obstruction in roadway");
        contributingFactorDetails.put("saw-other-party", "Saw other party");
        contributingFactorDetails.put("recognized-danger-on-roadway", "Recognized danger on roadway");
        contributingFactorDetails.put("didnt-see-obstruction-in-roadway", "Didn't see obstruction in roadway ");
        contributingFactorDetails.put("didnt-see-other-party", "Didn't see other party ");
        contributingFactorDetails.put("didnt-recognize-danger-on-roadway", "Didn't recognize danger on roadway ");
        contributingFactorDetails.put("improper-lane-change", "Improper lane change");
        contributingFactorDetails.put("sudden-stop", "Sudden stop");
        contributingFactorDetails.put("participant-following-too-closely", "Participant following too closely");
        contributingFactorDetails.put("for-weather-condition", "For weather condition");
        contributingFactorDetails.put("for-driving-conditions", "For driving conditions");
        contributingFactorDetails.put("driving-too-slow", "Driving too slow");
        contributingFactorDetails.put("driving-too-fast", "Driving too fast");
        contributingFactorDetails.put("proper-evasive-action-taken", "Proper evasive action taken");
        contributingFactorDetails.put("improper-evasive-action-taken", "Improper evasive action taken");
        contributingFactorDetails.put("created-greater-risk", "Created greater risk");
        contributingFactorDetails.put("timely", "Timely");
        contributingFactorDetails.put("late", "Late");
        contributingFactorDetails.put("tired-distracted", "Tired / Distracted");
        contributingFactorDetails.put("under-influence", "Under influence");
        contributingFactorDetails.put("medical-emergency", "Medical Emergency");
        contributingFactorDetails.put("road-rage", "Road Rage");
        contributingFactorDetails.put("failed-to-maintain-vehicle", "Failed to maintain Vehicle");
        contributingFactorDetails.put("recent-repair", "Recent Repair");

        categoriesAndLabels.put("loss-address", "Loss Address");
        categoriesAndLabels.put("road-attributes", "Road Attributes");
        categoriesAndLabels.put("condition-of-roadway", "Condition of Roadway");
        categoriesAndLabels.put("weather", "Weather");
        categoriesAndLabels.put("traffic-control-measures", "Traffic Control Measures");
        categoriesAndLabels.put("amount-of-traffic", "Amount of Traffic");
        categoriesAndLabels.put("time-of-day", "Time of Day");
        categoriesAndLabels.put("direction-of-travel", "Direction of Travel");
        categoriesAndLabels.put("participant-speed", "Participant Speed");
        categoriesAndLabels.put("point-of-impact", "Point of Impact");
        categoriesAndLabels.put("damages", "Damages");
        categoriesAndLabels.put("driver-actions", "Driver Actions");
        categoriesAndLabels.put("injuries", "Injuries");
        categoriesAndLabels.put("other", "Other");

        numberWords.put(1, "ONE");
        numberWords.put(2, "TWO");
        numberWords.put(3, "THREE");
        numberWords.put(4, "FOUR");
        numberWords.put(5, "FIVE");
    }

    ITextInitialFaultDetailsSectionGenerator(ClaimDataModelHelper claimDataModelHelper, LoonRestTemplate dcfContentRestTemplate) {
        this.claimDataModelHelper = claimDataModelHelper;
        this.dcfContentRestTemplate = dcfContentRestTemplate;
    }

    void generateInitialFaultDetailsSection(LiabilityAnalysisEntity liabilityAnalysisEntity, Document document) throws DocumentException, IOException {
        PdfPTable table = getDefaultTable();

        range(0, liabilityAnalysisEntity.getEvents().size()).forEach(index -> {
            try {
                PdfPTable eventTable = getDefaultTable();
                if (index == 0) {
                    eventTable.addCell(new Phrase("Initial Fault Details", getAllstateSansRegularFont(20, BOLD, GRAY_333333)));
                }
                eventTable.addCell(getEventName(index, liabilityAnalysisEntity.getEvents().get(index)));
                eventTable.addCell(getParticipantsInvolved(liabilityAnalysisEntity.getEvents().get(index), liabilityAnalysisEntity.getLiabilitySubjects()));
                eventTable.setKeepTogether(true);
                table.addCell(eventTable);

                liabilityAnalysisEntity.getEvents().get(index).getInvolvedParties().forEach(ip -> {
                    try {
                        table.addCell(getInvolvedPartyTable(ip, liabilityAnalysisEntity));
                    } catch (Exception e) {
                        throw new SubmissionSystemErrorException(e);
                    }
                });

                table.addCell(new Phrase(String.format("END OF EVENT %s", numberWords.get(index + 1)), getAllstateSansRegularFont(16, BOLD, GRAY_484848)));
            } catch (Exception e) {
                throw new SubmissionSystemErrorException(e);
            }
        });

        document.add(table);
    }

    private PdfPTable getEventName(int index, Event event) throws IOException, DocumentException {
        PdfPTable table = getDefaultTable();
        String eventName = "Event " + (index + 1) + (event.getTitle() != null && !event.getTitle().isEmpty() ? " - " + event.getTitle() : "");
        table.addCell(new Phrase(eventName, getAllstateSansRegularFont(16, BOLD, GRAY_484848)));
        return table;
    }

    private PdfPTable getParticipantsInvolved(Event event, List<LiabilitySubject> liabilitySubjects) throws IOException, DocumentException {
        PdfPTable table = getDefaultTable(2);

        table.addCell(getCell(new Phrase("Participants Involved", getAllstateSansRegularFont(16, GRAY_484848)), 16, 8));
        table.addCell(getCell(new Phrase("Damages", getAllstateSansRegularFont(16, GRAY_484848)), 16, 8));

        event.getInvolvedParties().forEach(ip -> {
            try {
                String participantRole = claimDataModelHelper.isInsuredByPartyId(ip.getParticipantId(), liabilitySubjects) ? "Insured Owner: " : "Claimant Owner: ";
                String participantName = claimDataModelHelper.getParticipantNameByParticipantId(ip.getParticipantId(), liabilitySubjects);

                table.addCell(getCell(new Phrase(participantRole + participantName, getAllstateSansRegularFont(12, GRAY_484848)), 32, 8));
                table.addCell(getCell(new Phrase(getDamageSections(ip), getAllstateSansRegularFont(12, GRAY_484848)), 32, 8));
            } catch (Exception e) {
                throw new SubmissionSystemErrorException(e);
            }
        });

        return table;
    }

    private String getDamageSections(InvolvedParty involvedParty) {
        StringBuilder sb = new StringBuilder();
        involvedParty.getDamageSections().forEach(d -> sb.append(d.toUpperCase()).append(", "));
        return sb.toString().trim().substring(0, sb.toString().trim().length() - 1);
    }

    private PdfPTable getInvolvedPartyTable(InvolvedParty involvedParty, LiabilityAnalysisEntity liabilityAnalysisEntity) throws IOException, DocumentException {
        PdfPTable table = getDefaultTable();

        table.addCell(getAffectedParties(involvedParty, liabilityAnalysisEntity));
        table.addCell(getContributingFactors(involvedParty));

        if (liabilityAnalysisEntity.getEvidences() != null && !liabilityAnalysisEntity.getEvidences().isEmpty()) {
            Object[] categoryNameArray = categoriesAndLabels.keySet().toArray();
            String[] categoryNameStringArray = Arrays.copyOf(categoryNameArray, categoryNameArray.length, String[].class);
            List<String> categoryNamesStringList = asList(categoryNameStringArray);
            categoryNamesStringList.sort(String::compareTo);

            for (ContributingFactorEntity cf : involvedParty.getContributingFactors()) {
                boolean addHeader = true;
                List<Evidence> eventEvidence = liabilityAnalysisEntity.getEvidences().stream()
                    .filter(evidence -> cf.getEvidenceIds().contains(evidence.getId()))
                    .collect(Collectors.toList());
                for (String c : categoryNamesStringList) {
                    List<Evidence> categoryEvidence = eventEvidence.stream()
                        .filter(evidence -> evidence.getCategory().equals(c))
                        .collect(Collectors.toList());
                    if (categoryEvidence.size() > 0) {
                        PdfPTable evidenceTable = getDefaultTable();
                        evidenceTable.setKeepTogether(true);
                        if (addHeader) {
                            evidenceTable.addCell(getCell(new Phrase("Evidence:", getAllstateSansRegularFont(14, GRAY_484848)), 16, 8));
                            addHeader = false;
                        }
                        Phrase categorySectionHeader = new Phrase(String.format("%s (%d)", categoriesAndLabels.get(c), categoryEvidence.size()), getAllstateSansRegularFont(12, GRAY_484848));
                        evidenceTable.addCell(getCell(categorySectionHeader, 16, 8));
                        evidenceTable.addCell(getPhotoEvidences(liabilityAnalysisEntity, categoryEvidence));
                        evidenceTable.addCell(getHighlightEvidences(categoryEvidence));

                        table.addCell(evidenceTable);
                    }
                }
            }
        }
        return table;
    }

    private PdfPTable getAffectedParties(InvolvedParty involvedParty, LiabilityAnalysisEntity liabilityAnalysisEntity) throws DocumentException, IOException {
        PdfPTable table = getDefaultTable();
        table.setKeepTogether(true);

        List<LiabilitySubject> liabilitySubjects = liabilityAnalysisEntity.getLiabilitySubjects();
        String participantRole = claimDataModelHelper.isInsuredByPartyId(involvedParty.getParticipantId(), liabilitySubjects) ? "Insured Owner: " : "Claimant Owner: ";
        String participantName = claimDataModelHelper.getParticipantNameByParticipantId(involvedParty.getParticipantId(), liabilitySubjects);

        Phrase participantNamePhrase = new Phrase(participantRole + participantName, getAllstateSansRegularFont(16, GRAY_484848));
        table.addCell(getCell(participantNamePhrase, 16, 8));

        if (!involvedParty.getAffectedParties().isEmpty() && !isNull(involvedParty.getAffectedParties().get(0).getParticipantId())) {
            Phrase initialFaultPhrase = new Phrase("Initial Fault:", getAllstateSansRegularFont(14, GRAY_484848));
            table.addCell(getCell(initialFaultPhrase, 16, 8));

            involvedParty.getAffectedParties().forEach(affectedParty -> {
                try {
                    String affectedParticipantName = claimDataModelHelper.getParticipantNameByParticipantId(affectedParty.getParticipantId(), liabilitySubjects);

                    PdfPTable scoreTable = getDefaultTable();

                    Phrase participantsInvolvedPhrase = new Phrase(participantName + " to " + affectedParticipantName + ": " + affectedParty.getInitialFaultPercent() + "%", getAllstateSansRegularFont(12, GRAY_484848));
                    scoreTable.addCell(getCell(participantsInvolvedPhrase, 32, 8));

                    table.addCell(scoreTable);
                } catch (Exception e) {
                    throw new SubmissionSystemErrorException(e);
                }
            });
        }
        return table;
    }

    private PdfPTable getContributingFactors(InvolvedParty involvedParty) throws IOException, DocumentException {
        PdfPTable cfTable = getDefaultTable();
        cfTable.setKeepTogether(true);

        cfTable.addCell(getCell(new Phrase("Contributing Factors:", getAllstateSansRegularFont(14, GRAY_484848)), 16, 8));

        range(0, involvedParty.getContributingFactors().size()).forEach(index -> {
            try {
                ContributingFactorEntity contributingFactor = involvedParty.getContributingFactors().get(index);
                String contributingFactorText = (index + 1) + ". " + contributingFactor.getCategory()
                    + " - " + (contributingFactorReasons.get(contributingFactor.getReason()) != null ? contributingFactorReasons.get(contributingFactor.getReason()) : contributingFactor.getReason());
                if (contributingFactor.getDetails() != null) {
                    if (contributingFactorDetails.get(contributingFactor.getDetails()) == null) {
                        contributingFactorText += " - " + contributingFactor.getDetails();
                    } else {
                        contributingFactorText += " - " + contributingFactorDetails.get(contributingFactor.getDetails());
                    }
                }
                Phrase cfTextPhrase = new Phrase(contributingFactorText, getAllstateSansRegularFont(12, GRAY_484848));
                cfTable.addCell(getCell(cfTextPhrase, 16, 8));
            } catch (Exception e) {
                throw new SubmissionSystemErrorException(e);
            }
        });

        return cfTable;
    }

    private PdfPTable getPhotoEvidences(LiabilityAnalysisEntity liabilityAnalysisEntity, List<Evidence> categoryEvidence) {
        List<Evidence> photoEvidence = categoryEvidence.stream()
            .filter(evidence -> evidence.getType().equals("photo"))
            .collect(Collectors.toList());

        PdfPTable imageTable = getDefaultTable();
        int imageColumns = 3;
        int imageWidth = 141;
        int spacing = 15;
        int tableWidth = (imageWidth * imageColumns) + (spacing * (imageColumns - 1));

        imageTable.resetColumnCount(imageColumns);
        imageTable.setTotalWidth(convertToPoints(tableWidth));
        imageTable.setPaddingTop(10f);

        for (Evidence photo : photoEvidence) {
            String dcfId = photo.getSourceId();
            String claimNumber = liabilityAnalysisEntity.getClaimNumber();

            try {
                byte[] result = dcfContentRestTemplate.getObject(byte[].class, claimNumber, dcfId);
                Image image = Image.getInstance(result);
                image.setRotationDegrees(photo.getRotation());

                PdfPCell photoCell = new PdfPCell(image, true);
                photoCell.setBorder(NO_BORDER);
                photoCell.setPaddingBottom(10f);
                photoCell.setPaddingRight(convertToPoints(spacing));
                photoCell.setFixedHeight(convertToPoints(141));
                photoCell.setHorizontalAlignment(Element.ALIGN_CENTER);

                imageTable.addCell(photoCell);

            } catch (Exception e) {
                throw new SubmissionSystemErrorException(e);
            }
        }

        int extraCells = photoEvidence.size() % imageColumns;
        for (int i = 0; i < extraCells; i++) {
            imageTable.addCell(getEmptyCell());
        }
        return imageTable;
    }

    private PdfPTable getHighlightEvidences(List<Evidence> categoryEvidence) {
        PdfPTable table = getDefaultTable();
        table.setKeepTogether(true);

        List<Evidence> transcriptEvidence = categoryEvidence.stream()
            .filter(evidence -> evidence.getType().equals("highlight"))
            .sorted(Comparator.comparing(Evidence::getSourceVoiceId))
            .collect(Collectors.toList());
        try {
            String currentVoiceAttachment = "0";
            Iterator<Evidence> iter = transcriptEvidence.iterator();
            while (iter.hasNext()) {
                Evidence evidence = iter.next();
                if (!evidence.getSourceVoiceId().equals(currentVoiceAttachment)) {
                    currentVoiceAttachment = evidence.getSourceVoiceId();
                    Phrase voiceAttachmentTitle = new Phrase(String.format("%s from %s", evidence.getCallType(), evidence.getParticipantDisplayName()), getAllstateSansRegularFont(12, GRAY_484848));
                    table.addCell(getCell(voiceAttachmentTitle, 32, 8));
                }

                Phrase evidencePhrase = new Phrase();
                evidence.getHighlightTexts().forEach(e -> {
                    try {
                        evidencePhrase.add(new Chunk(("representative".equals(e.getSpeaker()) ? "rep" : e.getSpeaker()) + " ", getAllstateSansRegularFont(12, BOLD, GRAY_484848)).setLineHeight(convertToPoints(16)));
                        evidencePhrase.add(new Chunk(e.getText() + " ", getAllstateSansRegularFont(12, GRAY_484848)).setLineHeight(convertToPoints(16)));
                    } catch (Exception ex) {
                        throw new SubmissionSystemErrorException(ex);
                    }
                });
                table.addCell(getCell(evidencePhrase, 48, 8));
            }
        } catch (DocumentException | IOException e) {
            throw new SubmissionSystemErrorException(e);
        }
        return table;
    }
}
