package com.allstate.cts.loon.nextGenComponents.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FileNoteResponse {

    private String FileNoteID;
    private String[] FNAttachID;
    private String FNTextID;
}
