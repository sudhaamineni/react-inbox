package com.allstate.cts.loon.eligibility.repository;

import com.allstate.cts.loon.eligibility.model.FNOLClaimData;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FnolMessageRepository extends MongoRepository<FNOLClaimData, String> {
    FNOLClaimData findByClaimNumber(String claimNumber);
}