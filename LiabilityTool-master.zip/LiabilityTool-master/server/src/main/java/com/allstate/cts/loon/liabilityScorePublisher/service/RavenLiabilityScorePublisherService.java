package com.allstate.cts.loon.liabilityScorePublisher.service;

import com.allstate.cts.loon.liabilityAnalysis.entity.LiabilityAnalysisEntity;
import com.allstate.cts.loon.liabilityScorePublisher.model.RavenLiabilityScorePublisherRequest;
import com.allstate.cts.loon.liabilityScorePublisher.model.RavenLiabilityScorePublisherResponse;
import com.allstate.cts.loon.resttemplate.LoonRestTemplate;
import org.springframework.stereotype.Service;

@Service
public class RavenLiabilityScorePublisherService {
    private LoonToRavenMapper loonToRavenMapper;
    private LoonRestTemplate ravenRestTemplate;

    public RavenLiabilityScorePublisherService(LoonToRavenMapper loonToRavenMapper,
                                               LoonRestTemplate ravenRestTemplate) {
        this.loonToRavenMapper = loonToRavenMapper;
        this.ravenRestTemplate = ravenRestTemplate;
    }

    public RavenLiabilityScorePublisherResponse publishLiabilityScore(LiabilityAnalysisEntity liabilityAnalysisEntity, boolean isFaultAllocation) throws Exception {
        if(isFaultAllocation && (liabilityAnalysisEntity.isNoFaultAllocationAgreement() || liabilityAnalysisEntity.isNoFaultAllocationResponse())){
            return null;
        }
        RavenLiabilityScorePublisherRequest ravenRequest = loonToRavenMapper.map(liabilityAnalysisEntity, isFaultAllocation);
        return ravenRestTemplate.sendObject(ravenRequest, RavenLiabilityScorePublisherResponse.class, liabilityAnalysisEntity.getClaimNumber());
    }
}