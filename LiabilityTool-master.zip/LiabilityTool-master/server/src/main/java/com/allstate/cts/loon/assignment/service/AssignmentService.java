package com.allstate.cts.loon.assignment.service;

import com.allstate.cts.loon.exception.NoAssignmentAvailableException;
import com.allstate.cts.loon.helpers.DateTimeHelper;
import com.allstate.cts.loon.liabilityAnalysis.entity.LiabilityAnalysisEntity;
import com.allstate.cts.loon.liabilityAnalysis.repository.LiabilityAnalysisRepository;
import com.allstate.cts.loon.liabilityAnalysis.service.LiabilityAnalysisService;
import com.allstate.cts.loon.startup.service.UserService;
import com.compozed.appfabric.logging.AppFabricLogger;
import com.compozed.appfabric.logging.annotations.AppFabricLog;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.util.Optional;

import static com.allstate.cts.loon.constants.LoonConstants.*;
import static com.compozed.appfabric.logging.LoggingEventType.APPLICATION;
import static com.compozed.appfabric.logging.LoggingResultType.FAILURE;
import static java.util.Objects.nonNull;
import static org.springframework.data.domain.Sort.Direction.ASC;
import static org.springframework.data.mongodb.core.query.Criteria.where;

@Service
public class AssignmentService {
    private final LiabilityAnalysisService liabilityAnalysisService;
    private final LiabilityAnalysisRepository liabilityAnalysisRepository;
    private final MongoTemplate mongoTemplate;
    private final UserService userService;
    private final DateTimeHelper dateTimeHelper;

    @AppFabricLog
    private AppFabricLogger logger;

    public AssignmentService(LiabilityAnalysisService liabilityAnalysisService,
                             LiabilityAnalysisRepository liabilityAnalysisRepository,
                             MongoTemplate mongoTemplate,
                             UserService userService,
                             DateTimeHelper dateTimeHelper) {
        this.liabilityAnalysisService = liabilityAnalysisService;
        this.liabilityAnalysisRepository = liabilityAnalysisRepository;
        this.mongoTemplate = mongoTemplate;
        this.userService = userService;
        this.dateTimeHelper = dateTimeHelper;
    }

    public LiabilityAnalysisEntity getNextAssignment() {
        Query query = new Query()
                .with(new Sort(ASC, "claimOpenedDate"))
                .addCriteria(where("status")
                        .is(READY_FOR_ASSIGNMENT));

        LiabilityAnalysisEntity assignment = mongoTemplate.findOne(query, LiabilityAnalysisEntity.class);
        if (nonNull(assignment)) {
            assignment.setStatus(ASSIGNED);
            assignment.setAssignedUser(userService.getUserName());
            assignment.setAssignedTime(dateTimeHelper.getCurrentDateTime());

            return liabilityAnalysisService.save(assignment);
        }
        throw new NoAssignmentAvailableException();
    }

    private LiabilityAnalysisEntity getAssignmentByStatus(String status) {
        Optional<LiabilityAnalysisEntity> assignment = liabilityAnalysisRepository.findByAssignedUserAndStatus(userService.getUserName(), status);
        if (assignment.isPresent()) {
            return assignment.get();
        }
        return null;
    }

    public LiabilityAnalysisEntity getAssignmentByAssignedUser() {
        Optional<LiabilityAnalysisEntity> assignment = liabilityAnalysisRepository.findByAssignedUser(userService.getUserName());
        if (assignment.isPresent()) {
            return assignment.get();
        }
        return null;
    }

    public void updateAssignmentStatus(String fromStatus, String toStatus) {
        LiabilityAnalysisEntity assignment = getAssignmentByStatus(fromStatus);
        if (nonNull(assignment)) {
            assignment.setStatus(toStatus);
            if (READY_FOR_ASSIGNMENT.equals(toStatus)) {
                assignment.setAssignedUser(null);
                assignment.setAssignedTime(null);
            }
            liabilityAnalysisService.save(assignment);
        }
    }

    public void createAssignment(String claimNumber) {
        Optional<LiabilityAnalysisEntity> existing = liabilityAnalysisRepository.findByClaimNumber(claimNumber);

        if (!existing.isPresent()) {
            LiabilityAnalysisEntity liabilityAnalysisEntity = LiabilityAnalysisEntity.builder()
                    .claimNumber(claimNumber)
                    .status(READY_FOR_ASSIGNMENT)
                    .isComplex(true)
                    .createdTime(dateTimeHelper.getCurrentDateTime())
                    .build();
            liabilityAnalysisRepository.save(liabilityAnalysisEntity);
        }

        existing.ifPresent(e -> {
            if (!READY_FOR_ASSIGNMENT.equals(e.getStatus())) {
                e.setStatus(READY_FOR_ASSIGNMENT);
                e.setIsComplex(true);
                e.setCreatedTime(dateTimeHelper.getCurrentDateTime());
                liabilityAnalysisRepository.save(e);
            } else {
                logger.warn(LOON_SERVER_WARNING, APPLICATION, "AssignmentService.createAssignment", "Assignment already exists.",
                        FAILURE, "Request to create assignment for claim number " + claimNumber + " ignored: Assignment already exists."
                );
            }
        });
    }
}