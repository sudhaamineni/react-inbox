package com.allstate.cts.loon.liabilityDecision.itext;

class ITextConstants {
    class FontColors {
        private FontColors() {
            throw new IllegalStateException("Constants class");
        }

        static final String GRAY_484848 = "#484848";
        static final String GRAY_333333 = "#333333";
        static final String GRAY_6B6B6B = "#6b6b6b";
        static final String GRAY_F4F4F4 = "#f4f4f4";
        static final String GREEN_005F6E = "#005f6e";
    }
}
