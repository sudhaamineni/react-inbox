package com.allstate.cts.loon.highlight.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HighlightText {
    private int chunkIndex;
    private int beginIndex;
    private int endIndex;
    private String text;
    private String speaker;
}