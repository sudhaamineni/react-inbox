package com.allstate.cts.loon.exception;

public class ClaimDataRetrieverException extends RuntimeException implements CustomException {
    private final String msgHeader;
    private final String msgDescription;

    public ClaimDataRetrieverException(String claimNumber, Exception ex) {
        super(ex);
        this.msgHeader = "Error encountered retrieving claim #" + claimNumber;
        this.msgDescription = "We were unable to retrieve claim data for this claim number. Please check and try again.";
    }

    @Override
    public String getMessageHeader() {
        return this.msgHeader;
    }

    @Override
    public String getMessageDescription() {
        return this.msgDescription;
    }
}
