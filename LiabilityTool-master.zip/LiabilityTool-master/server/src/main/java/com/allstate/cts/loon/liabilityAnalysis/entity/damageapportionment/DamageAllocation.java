package com.allstate.cts.loon.liabilityAnalysis.entity.damageapportionment;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DamageAllocation {
    private int allocation;
    private String damageLocation;
}
