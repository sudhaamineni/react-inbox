package com.allstate.cts.loon.configuration;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Component
@ConfigurationProperties(prefix = "feature-switches")
public class FeatureSwitches {
    private boolean saveSummaryDocOnSubmit;
    private boolean openSummaryDocOnSuccess;
    private boolean enableAdmin;
    private boolean sendLiabilityScoreOnSubmit;
    private boolean renderSketchTab;
    private boolean sendLiabilityScoreOnFinalize;
    private boolean enableSettleTab;
    private boolean validateContributingFactorEvidence;
    private boolean submitSettlementFileNote;
}
