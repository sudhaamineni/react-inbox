package com.allstate.cts.loon.configuration;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Component
@ConfigurationProperties(prefix = "kafka")
public class KafkaProperties {

    private String bootstrap;
    private String group;
    private String fnolTopic;
    private String automatedLiabilityTopic;
}