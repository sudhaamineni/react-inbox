package com.allstate.cts.loon.liabilityAnalysis.repository;

import com.allstate.cts.loon.liabilityAnalysis.entity.LiabilityAnalysisHistoryEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface LiabilityAnalysisHistoryRepository extends MongoRepository<LiabilityAnalysisHistoryEntity, String> {
    LiabilityAnalysisHistoryEntity findByClaimNumber(String claimNumber);
    Optional<LiabilityAnalysisHistoryEntity> findById(String id);
}