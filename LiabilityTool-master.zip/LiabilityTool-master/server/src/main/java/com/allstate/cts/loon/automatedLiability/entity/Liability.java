package com.allstate.cts.loon.automatedLiability.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Liability {
    private String mainParticipant;
    private String affectedParticipant;
    private LiabilityScore liabilityScore;
    private String seagullVersion;
}
