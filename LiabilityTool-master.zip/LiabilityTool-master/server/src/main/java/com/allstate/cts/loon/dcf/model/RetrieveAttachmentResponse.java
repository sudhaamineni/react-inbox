package com.allstate.cts.loon.dcf.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

import static java.util.Objects.nonNull;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RetrieveAttachmentResponse {

    @Builder.Default
    private List<Attachment> search_results = new ArrayList<>();

    public void setResults(List<Attachment> results) {
        this.search_results = nonNull(results) ? results : new ArrayList<>();
    }
}