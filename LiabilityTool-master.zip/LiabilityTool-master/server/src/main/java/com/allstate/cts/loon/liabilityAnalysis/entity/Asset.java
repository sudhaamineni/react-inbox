package com.allstate.cts.loon.liabilityAnalysis.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Asset {
    @Builder.Default
    private String vehicleYear = "";

    @Builder.Default
    private String vehicleMake = "";

    @Builder.Default
    private String vehicleModel = "";

    @Builder.Default
    private String vehicleItemId = "";

    @Builder.Default
    private String assetTypeDescription = "";

    @Builder.Default
    private List<DamagesEntity> damages = new ArrayList<>();

    public String getAssetYearMakeModel() {
        return vehicleYear == null ? "UNKNOWN ASSET"
                : (vehicleYear.trim() + " "
                + (vehicleMake == null ? "" : vehicleMake.trim()) + " "
                + (vehicleModel == null ? "" : vehicleModel.trim())).trim();
    }
}
