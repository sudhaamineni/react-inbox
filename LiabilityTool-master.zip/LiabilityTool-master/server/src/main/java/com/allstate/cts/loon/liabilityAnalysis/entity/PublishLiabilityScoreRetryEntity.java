package com.allstate.cts.loon.liabilityAnalysis.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "PublishLiabilityScoreRetry")
public class PublishLiabilityScoreRetryEntity {

    @Id
    private String id;
    private String claimNumber;
    private int numberOfRetries;
    private boolean successfullyRetried;
    private LiabilityAnalysisEntity liabilityAnalysisEntity;
    private Date createdTime;
    private Date updatedTime;
}
