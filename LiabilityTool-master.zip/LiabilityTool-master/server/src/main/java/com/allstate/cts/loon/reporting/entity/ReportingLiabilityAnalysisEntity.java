package com.allstate.cts.loon.reporting.entity;

import com.allstate.cts.loon.liabilityAnalysis.entity.damageapportionment.DamageApportionment;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "LiabilityAnalysis")
public class ReportingLiabilityAnalysisEntity {
    private int count;
    private String claimNumber;
    private String lossDetailType;
    private String lossState;
    private String comparativeNegligenceRule;
    private Integer participantSize;
    private Integer fnolToSubmittedMins;
    private Integer searchToSubmittedMins;
    private String createdByUserId;
    private String lastModifiedByUserId;
    private Date createdTime;
    private String createdTimeInCSTStringFormat;
    private Date initialFaultSubmitTime;
    private String initialFaultSubmitTimeInCSTStringFormat;
    private Date settlementSubmitTime;
    private Date updatedTime;
    private String settlementSubmitTimeInCSTStringFormat;
}
