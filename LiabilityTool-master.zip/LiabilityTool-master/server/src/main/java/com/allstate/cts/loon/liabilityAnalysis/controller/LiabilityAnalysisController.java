package com.allstate.cts.loon.liabilityAnalysis.controller;

import com.allstate.cts.auditLog.annotation.AuditLoggedHttp;
import com.allstate.cts.auditLog.annotation.Identifier;
import com.allstate.cts.loon.aspect.ValidateLoonUserRole;
import com.allstate.cts.loon.highlight.entity.HighlightEntity;
import com.allstate.cts.loon.liabilityAnalysis.entity.*;
import com.allstate.cts.loon.liabilityAnalysis.model.SaveHighlightRequest;
import com.allstate.cts.loon.liabilityAnalysis.model.SavePhotoAttachmentRequest;
import com.allstate.cts.loon.liabilityAnalysis.service.LiabilityAnalysisService;
import com.allstate.cts.loon.liabilityAnalysis.service.RetrieveLiabilityAnalysisAttachmentService;
import com.allstate.cts.loon.liabilityAnalysis.service.RetrieveLiabilityAnalysisDataService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;

import static com.allstate.cts.auditLog.utilities.IdentifierTypes.CLAIM_NUMBER;

@Controller
@RestController
@RequestMapping("/api/v1/liabilityanalysis")
public class LiabilityAnalysisController {
    private RetrieveLiabilityAnalysisAttachmentService retrieveLiabilityAnalysisAttachmentService;
    private RetrieveLiabilityAnalysisDataService retrieveLiabilityAnalysisDataService;
    private LiabilityAnalysisService liabilityAnalysisService;

    public LiabilityAnalysisController(
            RetrieveLiabilityAnalysisDataService retrieveLiabilityAnalysisDataService,
            RetrieveLiabilityAnalysisAttachmentService retrieveLiabilityAnalysisAttachmentService,
            LiabilityAnalysisService liabilityAnalysisService) {
        this.retrieveLiabilityAnalysisDataService = retrieveLiabilityAnalysisDataService;
        this.retrieveLiabilityAnalysisAttachmentService = retrieveLiabilityAnalysisAttachmentService;
        this.liabilityAnalysisService = liabilityAnalysisService;
    }

    @GetMapping("/{claimNumber}")
    @AuditLoggedHttp
    public LiabilityAnalysisEntity getLiabilityAnalysisData(@PathVariable("claimNumber") @Identifier(identifierType = CLAIM_NUMBER) String claimNumber) {
        return retrieveLiabilityAnalysisDataService.getLiabilityAnalysisData(claimNumber);
    }

    @GetMapping("/photoattachments/{claimNumber}")
    @AuditLoggedHttp
    public List<LiabilitySubject> getPhotoAttachments(@PathVariable("claimNumber") @Identifier(identifierType = CLAIM_NUMBER) String claimNumber) {
        return retrieveLiabilityAnalysisAttachmentService.getPhotoAttachments(claimNumber);
    }

    @GetMapping("/voiceattachments/{claimNumber}")
    @AuditLoggedHttp
    public List<VoiceAttachment> getVoiceAttachments(@PathVariable("claimNumber") @Identifier(identifierType = CLAIM_NUMBER) String claimNumber) {
        return retrieveLiabilityAnalysisAttachmentService.getVoiceAttachments(claimNumber);
    }

    @PostMapping("/voiceattachments/{claimNumber}")
    @ValidateLoonUserRole
    public void saveVoiceAttachments(@PathVariable("claimNumber") @Identifier(identifierType = CLAIM_NUMBER) String claimNumber, @RequestBody LinkedHashMap linkedHashMap) {
        List<VoiceAttachment> voiceAttachments = (List<VoiceAttachment>) linkedHashMap.get("voiceAttachments");
        List<Evidence> evidences = (List<Evidence>) linkedHashMap.get("evidences");
        liabilityAnalysisService.saveVoiceAttachments(claimNumber, voiceAttachments, evidences);
    }

    @PostMapping("/{claimNumber}/sketch")
    @ValidateLoonUserRole
    public void saveSketch(@PathVariable("claimNumber") @Identifier(identifierType = CLAIM_NUMBER) String claimNumber, @RequestBody Sketch sketch) {
        liabilityAnalysisService.saveSketch(claimNumber, sketch);
    }

    @PostMapping("/event/create/{claimNumber}")
    @ValidateLoonUserRole
    public void createEvent(@PathVariable("claimNumber") @Identifier(identifierType = CLAIM_NUMBER) String claimNumber, @RequestBody Event event) {
        liabilityAnalysisService.createEvent(claimNumber, event);
    }

    @PostMapping("/event/update/{claimNumber}")
    @ValidateLoonUserRole
    public void updateEvent(@PathVariable("claimNumber") @Identifier(identifierType = CLAIM_NUMBER) String claimNumber, @RequestBody Event event) {
        liabilityAnalysisService.updateEvent(claimNumber, event);
    }

    @PostMapping("/event/remove/{claimNumber}")
    @ValidateLoonUserRole
    public void removeEvent(@PathVariable("claimNumber") @Identifier(identifierType = CLAIM_NUMBER) String claimNumber, @RequestBody Event event) {
        liabilityAnalysisService.removeEvent(claimNumber, event);
    }

    @PostMapping("/losslocation/{claimNumber}")
    @ValidateLoonUserRole
    public void saveLossLocation(@PathVariable("claimNumber") @Identifier(identifierType = CLAIM_NUMBER) String claimNumber, @RequestBody LinkedHashMap location) {
        Double latitude = (Double) location.get("latitude");
        Double longitude = (Double) location.get("longitude");
        String updatedLossLocation = (String) location.get("updatedLossLocation");

        liabilityAnalysisService.saveLossLocation(claimNumber, latitude, longitude, updatedLossLocation);
    }

    @PostMapping("/save-no-fault-ind/{claimNumber}")
    @ValidateLoonUserRole
    public void saveFaultAllocationIndicators(@PathVariable("claimNumber") @Identifier(identifierType = CLAIM_NUMBER) String claimNumber, @RequestBody LinkedHashMap fields) {
        boolean noAgreement = (boolean) fields.get("noFaultAllocationAgreement");
        boolean noResponse = (boolean) fields.get("noFaultAllocationResponse");
        liabilityAnalysisService.saveFaultAllocationIndicators(claimNumber, noAgreement, noResponse);
    }

    @PostMapping("/claim-unlock/{claimNumber}")
    @ValidateLoonUserRole
    public void saveClaimUnlock(@PathVariable("claimNumber") @Identifier(identifierType = CLAIM_NUMBER) String claimNumber, @RequestBody LinkedHashMap fields) {
        String unlockReason = (String) fields.get("unlockReason");
        String unlockDescription = (String) fields.get("unlockDescription");
        liabilityAnalysisService.saveClaimUnlock(claimNumber, unlockReason, unlockDescription);
    }

    @PostMapping("/{claimNumber}/{voiceId}/highlight")
    @ValidateLoonUserRole
    public void saveHighlights(@PathVariable("claimNumber") @Identifier(identifierType = CLAIM_NUMBER) String claimNumber, @PathVariable("voiceId") String voiceId, @RequestBody LinkedHashMap<String, Object> fields) {
        SaveHighlightRequest saveHighlightRequest = SaveHighlightRequest
                .builder()
                .highlightEntityList((List<HighlightEntity>) fields.get("highlightEntities"))
                .evidenceList((List<Evidence>) fields.get("evidences"))
                .eventList((List<Event>) fields.get("events"))
                .build();

        liabilityAnalysisService.saveHighlights(claimNumber, voiceId,saveHighlightRequest);
    }

    @PostMapping("/{claimNumber}/evidence")
    @ValidateLoonUserRole
    public void saveEvidence(@PathVariable("claimNumber") @Identifier(identifierType = CLAIM_NUMBER) String claimNumber, @RequestBody Evidence evidence) {
        liabilityAnalysisService.saveEvidence(claimNumber, evidence);
    }

    @PostMapping("/{claimNumber}/{participantSourceId}/photo")
    @ValidateLoonUserRole
    public void savePhotoAttachments(@PathVariable("claimNumber") @Identifier(identifierType = CLAIM_NUMBER) String claimNumber, @PathVariable("participantSourceId") String participantSourceId, @RequestBody LinkedHashMap<String, Object> fields) {
        SavePhotoAttachmentRequest savePhotoAttachmentRequest = SavePhotoAttachmentRequest.builder()
                .photoAttachmentList((List<PhotoAttachment>) fields.get("photoAttachments"))
                .evidenceList((List<Evidence>) fields.get("evidences"))
                .eventList((List<Event>) fields.get("events"))
                .build();
        liabilityAnalysisService.savePhotoAttachments(claimNumber, participantSourceId, savePhotoAttachmentRequest);
    }

    @PostMapping("/{claimNumber}/saveReportedPci")
    @ValidateLoonUserRole
    public void saveReportedPci(@PathVariable("claimNumber") @Identifier(identifierType = CLAIM_NUMBER) String claimNumber,
                                @RequestBody LinkedHashMap fields) throws MessagingException {
        Long reportedPciDate = (Long) fields.get("reportedPciDate");
        String sourceVoiceId = (String) fields.get("sourceVoiceId");
        String transcriptId = (String) fields.get("transcriptId");
        List<String> pciCategories = (List<String>) fields.get("pciCategories");

        liabilityAnalysisService.saveReportedPci(claimNumber, new Date(Long.valueOf(reportedPciDate)), sourceVoiceId, transcriptId, pciCategories);
    }
}
