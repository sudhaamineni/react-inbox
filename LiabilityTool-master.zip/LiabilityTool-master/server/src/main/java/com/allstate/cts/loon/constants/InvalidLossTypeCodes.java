package com.allstate.cts.loon.constants;

public enum InvalidLossTypeCodes {
    GLASS_AND_TOWING("03"),
    GLASS_ONLY("11"),
    TOWING_ONLY("12");

    private String code;

    InvalidLossTypeCodes(String code) {
        this.code = code;
    }

    public static boolean containsCode(String code) {
        for (InvalidLossTypeCodes val : InvalidLossTypeCodes.values()) {
            if (val.code.equals(code)) {
                return true;
            }
        }
        return false;
    }

    public static InvalidLossTypeCodes getEnumFromCode(String code) {
        for (InvalidLossTypeCodes val : InvalidLossTypeCodes.values()) {
            if (code.equals(val.code)) {
                return val;
            }
        }
        return null;
    }
}