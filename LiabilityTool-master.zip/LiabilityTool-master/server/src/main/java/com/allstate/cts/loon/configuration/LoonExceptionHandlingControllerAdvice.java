package com.allstate.cts.loon.configuration;

import com.allstate.cts.auditLog.annotation.AuditLoggedAdvice;
import com.allstate.cts.loon.exception.*;
import com.compozed.appfabric.logging.AppFabricLogger;
import com.compozed.appfabric.logging.annotations.AppFabricLog;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import static com.allstate.cts.loon.constants.LoonConstants.LOON_SERVER_EXCEPTION;
import static com.compozed.appfabric.logging.LoggingEventType.SYSTEM;
import static com.compozed.appfabric.logging.LoggingEventType.VALIDATION;
import static com.compozed.appfabric.logging.LoggingResultType.FAILURE;

@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
public class LoonExceptionHandlingControllerAdvice {
    @AppFabricLog
    private AppFabricLogger logger;

    @AuditLoggedAdvice
    @ExceptionHandler({
            InvalidCharacterException.class,
            InvalidUnlockReasonDescriptionException.class,
            InvalidClaimException.class,
            UnauthorizedClaimException.class})
    public ResponseEntity<ApiError> handleCustomExceptions(CustomException ex) {
        logger.error(LOON_SERVER_EXCEPTION, VALIDATION, ex.getClass().getSimpleName(), ex.getMessageHeader(), FAILURE, ex.getMessageDescription());
        ApiError error = new ApiError(ex.getMessageHeader(), ex.getMessageDescription());
        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }

    @AuditLoggedAdvice
    @ExceptionHandler({
            ClaimResetException.class
    })
    public ResponseEntity<ApiError> handleResetClaimException(ClaimResetException ex) {
        logger.error(LOON_SERVER_EXCEPTION, VALIDATION, ex.getClass().getSimpleName(), ex.getMessageHeader(), FAILURE, ex.getMessageDescription());
        ApiError claimResetApiError = new ApiError(ex.getMessageHeader(), ex.getMessageDescription(), ex.getNewClaimNumber());
        return new ResponseEntity<>(claimResetApiError, HttpStatus.BAD_REQUEST);
    }

    @AuditLoggedAdvice
    @ExceptionHandler({SubmissionSystemErrorException.class})
    public ResponseEntity<ApiError> handleNotAcceptableExceptions(CustomException ex) {
        logger.error(LOON_SERVER_EXCEPTION, SYSTEM, ex.getClass().getSimpleName(), ex.getMessageHeader(), FAILURE, ex.getMessageDescription());
        ApiError error = new ApiError(ex.getMessageHeader(), ex.getMessageDescription());
        return new ResponseEntity<>(error, HttpStatus.NOT_ACCEPTABLE);
    }

    @AuditLoggedAdvice
    @ExceptionHandler({SystemErrorException.class})
    public ResponseEntity<ApiError> handleServiceUnavailableExceptions(CustomException ex) {
        logger.error(LOON_SERVER_EXCEPTION, SYSTEM, ex.getClass().getSimpleName(), ex.getMessageHeader(), FAILURE, ex.getMessageDescription());
        ApiError error = new ApiError(ex.getMessageHeader(), ex.getMessageDescription());
        return new ResponseEntity<>(error, HttpStatus.SERVICE_UNAVAILABLE);
    }

    @AuditLoggedAdvice
    @ExceptionHandler({
            NoAssignmentAvailableException.class,
            ClaimNotFoundException.class})
    public ResponseEntity<ApiError> handleNotFoundCustomExceptions(CustomException ex) {
        logger.error(LOON_SERVER_EXCEPTION, VALIDATION, ex.getClass().getSimpleName(), ex.getMessageHeader(), FAILURE, ex.getMessageDescription());
        ApiError error = new ApiError(ex.getMessageHeader(), ex.getMessageDescription());
        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }

    @AuditLoggedAdvice
    @ExceptionHandler({Exception.class})
    public ResponseEntity<ApiError> handleEverythingElse(Exception ex) {
        logger.error(LOON_SERVER_EXCEPTION, ex, SYSTEM, ex.getClass().getSimpleName(), "LoonExceptionHandlingControllerAdvice", FAILURE, ex.getMessage());
        ApiError error = new ApiError("Our systems are currently unavailable", "Our systems are currently unable to process your search. Please try again later.");
        return new ResponseEntity<>(error, HttpStatus.SERVICE_UNAVAILABLE);
    }
}