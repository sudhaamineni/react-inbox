package com.allstate.cts.loon.exception;

import org.springframework.http.HttpStatus;

public class LoonEligibilityException extends Exception {
    protected final HttpStatus status;
    protected final boolean retriable;
    protected final String message;

    public LoonEligibilityException(HttpStatus status, boolean retriable, String message, Throwable cause) {
        super(cause);
        this.status = status;
        this.retriable = retriable;
        this.message = message;
    }

    @Override
    public String getMessage() {
        String messagePrefix = this.message == null ? "" : this.message;
        String throwableMessage = super.getCause() == null ? "" : super.getCause().getMessage();
        String separator = "".equals(messagePrefix) || "".equals(throwableMessage) ? ""  : " - ";
        return messagePrefix + separator + throwableMessage;
    }
}