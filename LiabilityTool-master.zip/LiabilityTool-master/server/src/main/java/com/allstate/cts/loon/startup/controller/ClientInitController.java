package com.allstate.cts.loon.startup.controller;

import com.allstate.cts.loon.assignment.service.AssignmentService;
import com.allstate.cts.loon.configuration.FeatureSwitches;
import com.allstate.cts.loon.startup.model.ClientInit;
import com.allstate.cts.loon.startup.service.UserService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/api/v1/init")
public class ClientInitController {
    private final UserService userService;
    private final AssignmentService assignmentService;
    private final FeatureSwitches featureSwitches;

    public ClientInitController(UserService userService, AssignmentService assignmentService, FeatureSwitches featureSwitches) {
        this.userService = userService;
        this.assignmentService = assignmentService;
        this.featureSwitches = featureSwitches;
    }

    @GetMapping
    public ClientInit onWebAppLoad() {
        return ClientInit.builder()
                .userId(userService.getUserName())
                .userRoles(userService.getUserRoles())
                .assignedClaimData(assignmentService.getAssignmentByAssignedUser())
                .featureSwitches(featureSwitches)
                .build();
    }
}