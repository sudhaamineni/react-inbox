package com.allstate.cts.loon.liabilityAnalysis.repository;

import com.allstate.cts.loon.liabilityAnalysis.entity.LiabilityAnalysisSummaryPdf;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface LiabilityAnalysisSummaryPdfRepository extends MongoRepository<LiabilityAnalysisSummaryPdf, String> {
    Optional<LiabilityAnalysisSummaryPdf> findByClaimNumber(String claimNumber);
}
