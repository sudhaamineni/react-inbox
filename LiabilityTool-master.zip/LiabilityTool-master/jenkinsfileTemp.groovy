def MAJOR_BUILD_NUMBER = '1'
def APPLICATION_SERVER = "loon-server"
def APPLICATION_CLIENT = "loon-client"
def BUILD_NUMBER = env.BUILD_NUMBER
def FULL_BUILD_VERSION = "${MAJOR_BUILD_NUMBER}.0.${BUILD_NUMBER}"
def JAR_FILE_NAME = "loon-server-temp-${FULL_BUILD_VERSION}.jar"
def CLIENT_ZIP_FILE_NAME = "loon-client-temp-${FULL_BUILD_VERSION}.zip"
def SERVICE_NOW_GROUP = 'XP_CTS_CHG'
def ORGANIZATION = 'CTS-Loon'
def DOCKER_IMAGE_URI = '/compozed/labs/ci-base-node-eight:1.1'
def ARTIFACTORY_SERVER_URL = "https://artifactory.allstate.com/artifactory/CTS-Compozed/CTS-Loon/loon-server-temp/${FULL_BUILD_VERSION}/${JAR_FILE_NAME}"
def ARTIFACTORY_CLIENT_URL = "https://artifactory.allstate.com/artifactory/CTS-Compozed/CTS-Loon/loon-client-temp/${FULL_BUILD_VERSION}/${CLIENT_ZIP_FILE_NAME}"
def serviceHelper

withEnv(["PIPELINE=temp",]) {
    node {
        stage('clean') {
            step([$class: 'WsCleanup'])
        }
        env.SOURCE_BUILD_NUMBER = env.BUILD_NUMBER
        checkout scm
        serviceHelper = load './jenkinsServicesHelper.groovy'
    }

    node {
        docker.image(env.DOCKER_REGISTRY + DOCKER_IMAGE_URI).inside('--privileged') {
            withCredentials([
                    [
                            $class          : 'UsernamePasswordMultiBinding',
                            credentialsId   : 'CTS-Loon-System-ID',
                            passwordVariable: 'ARTIFACTORY_PASSWORD',
                            usernameVariable: 'ARTIFACTORY_USERNAME'
                    ],
                    [
                            $class          : 'UsernamePasswordMultiBinding',
                            credentialsId   : 'CTS-Loon-System-ID',
                            passwordVariable: 'CF_PASSWORD',
                            usernameVariable: 'CF_USERNAME'
                    ]
            ]) {
                stage('test/distribute') {
                    parallel(
                            Client: {
                                withEnv(['HOME=.']) {
                                    sh '''
                                        cd client
                                        npm cache --force clean
                                        npm ci
                                    '''
                                }

                                sh './gradlew client:clientTest'
                                sh 'cd client; NODE_ENV=dev ./node_modules/.bin/webpack --config webpack.config.js'
                                sh 'export GRADLE_USER_HOME=~/.gradle; ./gradlew client:publish'
                            },
                            Server: {
                                sh 'git rev-parse HEAD > git-commit'
                                sh 'export GRADLE_USER_HOME=~/.gradle; ./gradlew server:clean server:build -x test'
                                sh 'export GRADLE_USER_HOME=~/.gradle; ./gradlew -Penv=devci server:test iT'
                                sh 'export GRADLE_USER_HOME=~/.gradle; ./gradlew server:publishLoonPublicationToArtifactoryRepository -x server:test'
                            }
                    )
                }

                stage('code-quality-check') {
                    parallel(
                            'SERVER-TEST-REPORT': {
                                sh "./gradlew -Penv=devci jacocoTestReport server:test"
                                sh './gradlew server:sonarqube -x test'
                            },
                            'WEB-TEST-REPORT': {
                                sh './gradlew client:sonarqube -x test'
                            }
                    )
                }
            }
        }
    }

    checkpoint "after test/distribute and code-quality-check"

    node {
        docker.image(env.DOCKER_REGISTRY + DOCKER_IMAGE_URI).inside('--privileged') {
            withCredentials([
                    [
                            $class          : 'UsernamePasswordMultiBinding',
                            credentialsId   : 'CTS-Loon-System-ID',
                            passwordVariable: 'ARTIFACTORY_PASSWORD',
                            usernameVariable: 'ARTIFACTORY_USERNAME'
                    ],
                    [
                            $class          : 'UsernamePasswordMultiBinding',
                            credentialsId   : 'CTS-Loon-System-ID',
                            passwordVariable: 'CF_PASSWORD',
                            usernameVariable: 'CF_USERNAME'
                    ],
                    [
                            $class          : 'UsernamePasswordMultiBinding',
                            credentialsId   : 'RAVEN_PT_ACCESS',
                            passwordVariable: 'RAVEN_PASSWORD',
                            usernameVariable: 'RAVEN_USERNAME'
                    ],
                    [
                            $class       : 'StringBinding',
                            credentialsId: 'LEELA_STAGING_KEY',
                            variable     : 'LEELA_STAGING_KEY'
                    ],
                    [
                            $class       : 'StringBinding',
                            credentialsId: 'LOON_CLIENT_API_KEY_DEV',
                            variable     : 'LOON_CLIENT_API_KEY_DEV'
                    ],
                    [
                            $class       : 'StringBinding',
                            credentialsId: 'LOONELIGIBILITY_ENCRYPTION_KEY',
                            variable     : 'LOONELIGIBILITY_ENCRYPTION_KEY'
                    ],
                    [
                            $class          : 'UsernamePasswordMultiBinding',
                            credentialsId   : 'CTS_Loon_DEV_MONGODB_ID',
                            passwordVariable: 'CTS_Loon_DEV_MONGODB_PASSWORD',
                            usernameVariable: 'CTS_Loon_DEV_MONGODB_USERNAME'
                    ],
                    [
                            $class          : 'UsernamePasswordMultiBinding',
                            credentialsId   : 'CTS-Loon-DEV-AuditLog',
                            passwordVariable: 'CTS_Loon_DEV_AuditLog_PASSWORD',
                            usernameVariable: 'CTS_Loon_DEV_AuditLog_USERNAME'
                    ],
                    [
                            $class       : 'StringBinding',
                            credentialsId: 'DCF_CLIENT_KEY_DEVELOPMENT',
                            variable     : 'DCF_CLIENT_KEY_DEVELOPMENT'
                    ],
                    [
                            $class       : 'StringBinding',
                            credentialsId: 'PARAKEET_API_KEY_DEVELOPMENT',
                            variable     : 'PARAKEET_API_KEY_DEVELOPMENT'
                    ],
                    [
                            $class       : 'StringBinding',
                            credentialsId: 'ORGDATA_CLIENT_KEY',
                            variable     : 'ORGDATA_CLIENT_KEY'
                    ],
                    [
                            $class       : 'StringBinding',
                            credentialsId: 'SKETCH_CLIENT_KEY_TEST',
                            variable     : 'SKETCH_CLIENT_KEY_TEST'
                    ]
            ]) {
                stage('Deploy Dev') {
                    parallel(
                            Client: {
                                step([$class          : 'ConveyorJenkinsPlugin',
                                      applicationName : "${APPLICATION_CLIENT}-dev-temp",
                                      artifactURL     : ARTIFACTORY_CLIENT_URL,
                                      environment     : 'ro11',
                                      manifest        : """
                                      applications:
                                      - name: ${APPLICATION_CLIENT}
                                        disk_quota: 512M
                                        instances: 1
                                        memory: 64M
                                        space: DEV
                                        buildpacks:
                                        - staticfile_buildpack
                                        routes:
                                        - route: loon-dev-temp.auth-platform-sandbox.allstate.com
                                        services:
                                        - autoscaler
                                        env:
                                            LOON_BACKEND_URL: https://loon-server-dev-temp.apps.nonprod-mpn.ro11.allstate.com
                                            LOONCLIENTAPIKEY: '${LOON_CLIENT_API_KEY_DEV}'
                                            LIABILITYANALYSIS_SYSTEMID: 2974
                                            DCF_CLIENTKEY: '${DCF_CLIENT_KEY_DEVELOPMENT}'
                                            DCF_URL: https://cts-duncan-staging-pt.platform-test.allstate.com
                                            PARAKEET_URL: https://ingkko-staging.apps.nonprod-mpn.ro11.allstate.com
                                            PARAKEET_API_KEY: '${PARAKEET_API_KEY_DEVELOPMENT}'
                                            SKETCH_URL: https://sketch-frontend-staging.platform-test.allstate.com
                                            SKETCH_CLIENT_KEY: '${SKETCH_CLIENT_KEY_TEST}'
                                            RADPRO_URL: https://rad-pro-server-uat.platform-test.allstate.com
                             """,
                                      organization    : ORGANIZATION,
                                      password        : "${CF_PASSWORD}",
                                      serviceNowGroup : SERVICE_NOW_GROUP,
                                      serviceNowUserID: 'CTS-Loon-System-ID',
                                      space           : 'DEV',
                                      username        : "${CF_USERNAME}",
                                      barometerId     : "0418000015FW"
                                ])
                            },
                            Server: {
                                step([$class          : 'ConveyorJenkinsPlugin',
                                      applicationName : "${APPLICATION_SERVER}-dev-temp",
                                      artifactURL     : ARTIFACTORY_SERVER_URL,
                                      environment     : 'ro11',
                                      manifest        : """
                                      applications:
                                      - name: ${APPLICATION_SERVER}
                                        instances: 1
                                        memory: 1024M
                                        disk_quota: 512M
                                        host: ${APPLICATION_SERVER}
                                        org: ${ORGANIZATION}
                                        space: DEV
                                        timeout: 180
                                        buildpacks:
                                        - java_buildpack_offline
                                        services:
                                        - autoscaler
                                        - redisCache
                                        env:
                                            LIABILITYANALYSIS_CLIENTAPIKEY: '${LOON_CLIENT_API_KEY_DEV}'
                                            LOONELIGIBILITY_ENCRYPTION_KEY: '${LOONELIGIBILITY_ENCRYPTION_KEY}'
                                            LOONELIGIBILITY_ENCRYPTION_KEYTAB-FILE: feeder_enc_DEV.keytab
                                            EXTERNALRESOURCES_USESTUBS: false
                                            LEELA_CLAIMURL: 'https://leela-nextgen-service-staging-pt.platform-test.allstate.com/api/v1/claim/{}?claimParams={}'
                                            LEELA_CLIENTKEY: '${LEELA_STAGING_KEY}'
                                            SHADOW_ORGDATA_URL: 'https://cts-org-data-retriever-staging-pt.platform-test.allstate.com/api/v1/nextgen/org/{}'
                                            SHADOW_ORGDATA_CLIENTKEY: '${ORGDATA_CLIENT_KEY}'
                                            NEXTGEN_USERID: SYSLOON
                                            NEXTGEN_URL: https://hngcomponents-ws.allstate.com/AllstateCTSNGComponents-WS/api/{}
                                            RAVEN_URL: 'https://hravenapi-ws.allstate.com/RavenAPI-ws/api/Liability'
                                            RAVEN_USERNAME: '${RAVEN_USERNAME}'
                                            RAVEN_PASSWORD: '${RAVEN_PASSWORD}'
                                            DCF_URL: https://cts-duncan-staging-pt.platform-test.allstate.com/v3/search?claimNumber={}&brandName=ALL&mimeType=image/jpeg
                                            DCF_CONTENTURL: https://cts-duncan-staging-pt.platform-test.allstate.com/v3/retrieve?alfrescoId={}&versionLabel=1.0
                                            DCF_STOREURL: https://cts-duncan-staging-pt.platform-test.allstate.com/v3/store
                                            DCF_CLIENTKEY: '${DCF_CLIENT_KEY_DEVELOPMENT}'
                                            PARAKEET_URL: https://ingkko-staging.apps.nonprod-mpn.ro11.allstate.com/recordedobjects/{}
                                            PARAKEET_NLP_URL: /recordedobjects/summary/transcripts/
                                            PARAKEET_API_KEY: '${PARAKEET_API_KEY_DEVELOPMENT}'
                                            GRIFFIN_URL: https://griffin-uat.apps.nonprod-mpn.ro11.allstate.com/api/v1/claims/{}/appropriate-damages
                                            SPRING_PROFILES_ACTIVE: DEV
                                            SPRING_DATA_MONGODB_USERNAME: '${CTS_Loon_DEV_MONGODB_USERNAME}'
                                            SPRING_DATA_MONGODB_PASSWORD: '${CTS_Loon_DEV_MONGODB_PASSWORD}'
                                            SPRING_DATA_MONGODB_DATABASE: "A9DEV"
                                            SPRING_DATA_MONGODB_WRITECONCERN: "2"
                                            SPRING_DATA_MONGODB_TIMEOUT_SOCKET: "5000"
                                            SPRING_DATA_MONGODB_TIMEOUT_SERVERSELECT: "15000"
                                            SPRING_DATA_MONGODB_TIMEOUT_CONNECT: "5000"
                                            SPRING_DATA_MONGODB_SERVER[0]_HOST: "lxv5557.allstate.com"
                                            SPRING_DATA_MONGODB_SERVER[0]_PORT: "27010"
                                            SPRING_DATA_MONGODB_SERVER[1]_HOST: "lxv5558.allstate.com"
                                            SPRING_DATA_MONGODB_SERVER[1]_PORT: "27010"
                                            SPRING_DATA_MONGODB_SERVER[2]_HOST: "lxv5560.allstate.com"
                                            SPRING_DATA_MONGODB_SERVER[2]_PORT: "27010"
                                            SPRING_DATA_MONGODB_SERVER[3]_HOST: "lxv5561.allstate.com"
                                            SPRING_DATA_MONGODB_SERVER[3]_PORT: "27010"
                                            SPRING_DATA_MONGODB_REPLICASET: "MPODS-DEV-001"
                                            SPRING_KAFKA_BOOTSTRAP-SERVERS: 'lxe0961.allstate.com:9092, lxe0962.allstate.com:9092, lxe0963.allstate.com:9092, lxe0964.allstate.com:9092, lxe0965.allstate.com:9092'
                                            SPRING_KAFKA_TEMPLATE_DEFAULT-TOPIC: 'rtalab.allstate.claims.feeder.fnol_context_received'
                                            KAFKA_BOOTSTRAP: 'lxe0961.allstate.com:9092, lxe0962.allstate.com:9092, lxe0963.allstate.com:9092, lxe0964.allstate.com:9092, lxe0965.allstate.com:9092'
                                            KAFKA_GROUP: 'loonDev'
                                            KAFKA_FNOLTOPIC: 'rtalab.allstate.claims.feeder.fnol_context_received'
                                            KAFKA_AUTOMATEDLIABILITYTOPIC: 'rtalab.allstate.claims.feeder.sgl_response_received'
                                            FEATURE-SWITCHES_SAVESUMMARYDOCONSUBMIT: 'FALSE'
                                            FEATURE-SWITCHES_OPENSUMMARYDOCONSUCCESS: 'TRUE'
                                            FEATURE-SWITCHES_ENABLEADMIN: 'TRUE'
                                            FEATURE-SWITCHES_SENDLIABILITYSCOREONSUBMIT: 'FALSE'
                                            FEATURE-SWITCHES_RENDERSKETCHTAB: 'TRUE'
                                            FEATURE-SWITCHES_ENABLESETTLETAB: 'TRUE'
                                            FEATURE-SWITCHES_VALIDATECONTRIBUTINGFACTOREVIDENCE: 'TRUE'
                                            JBP_CONFIG_CONTAINER_CERTIFICATE_TRUST_STORE: '{enabled: true}'
                                            AUDITLOG_USERNAME: '${CTS_Loon_DEV_AuditLog_USERNAME}'
                                            AUDITLOG_PASSWORD: '${CTS_Loon_DEV_AuditLog_PASSWORD}'
                                            AUDITLOG_URL: 'https://cts-auditlog-v2-staging.platform-test.allstate.com/api/'
                                            AUDITLOG_BIRDWATCH-URL: 'https://cts-auditlogui-v2-staging.platform-test.allstate.com'
                                            LOGGING_APPLICATION_NAME: LiabilityTool
                                            HYSTRIX_COMMAND_CALLAUDITLOGSERVICE_ENABLEHYSTRIX: false
                                            HYSTRIX_COMMAND_CALLAUDITLOGSERVICE_EXECUTION_ISOLATION_THREAD_TIMEOUTINMILLISECONDS: 1000
                                            HYSTRIX_COMMAND_CALLAUDITLOGSERVICE_CIRCUITBREAKER_REQUESTVOLUMETHRESHOLD: 100
                                            HYSTRIX_COMMAND_CALLAUDITLOGSERVICE_CIRCUITBREAKER_ERRORTHRESHOLDPERCENTAGE: 20
                                            HYSTRIX_COMMAND_CALLAUDITLOGSERVICE_CIRCUITBREAKER_SLEEPWINDOWINMILLISECONDS: 300000
                                            HYSTRIX_COMMAND_THREADPOOL_DEFAULT_METRICS_ROLLINGSTATS_TIMEINMILLISECONDS: 300000
                                            KERBEROS_CONFIG: kafka-kerberos/krb5.conf
                                            KERBEROS_AUTH: kafka-kerberos/rtalab_feeder_nonprod.jaas
                                            MESSAGING_PARAKEET_NLP_QUEUE_NAME: ALS.IT.CTS.PKT.PARAKEET_OUTBOUND.V1_0
                                            MESSAGING_RECEIVE_TIMEOUT: 100000
                                            MESSAGING_CONNECTION_CACHE_SIZE: 10
                                            MESSAGING_CONSUMERS_MAX_CONCURRENT: 20
                                            MESSAGING_CONSUMERS_IDLE_CONCURRENT: 1
                                            MESSAGING_TIBCO_JNDI_INITIAL_CONTEXT_FACTORY: com.tibco.tibjms.naming.TibjmsInitialContextFactory
                                            MESSAGING_TIBCO_JNDI_URL: tibjmsnaming://tibjndi-it.allstate.com:22220
                                            MESSAGING_TIBCO_JNDI_PRINCIPAL: claimsappsavc-ext
                                            MESSAGING_TIBCO_JNDI_CREDENTIALS: claims28408
                                            MESSAGING_TIBCO_JNDI_QUEUE_CONNECTION_FACTORY_NAME: ALS.IT.CLAIMS.AVC.QCF.MS
                                            MESSAGING_TIBCO_EMS_USERNAME: claimsappsavc-ext
                                            MESSAGING_TIBCO_EMS_PASSWORD: claims28408
                                            MESSAGING_TIBCO_EMS_CONNECTION_TIMEOUT: 30000
                                            MESSAGING_TIBCO_EMS_CONNECTION_ATTEMPTS: 6
                                            MESSAGING_TIBCO_EMS_RECONNECTION_TIMEOUT: 90000
                                            MESSAGING_TIBCO_EMS_RECONNECTION_ATTEMPTS: 6
                                            EMAIL_SMTPHOST: mail.allstate.com
                                            EMAIL_SMTPPORT: 25
                                            EMAIL_TO: ypatf@allstate.com; rpaac@allstate.com
                                            EMAIL_FROM: loon@allstate.com
                                        """,
                                      organization    : ORGANIZATION,
                                      password        : "${CF_PASSWORD}",
                                      serviceNowGroup : SERVICE_NOW_GROUP,
                                      serviceNowUserID: 'CTS-Loon-System-ID',
                                      space           : 'DEV',
                                      username        : "${CF_USERNAME}",
                                      barometerId     : "0418000015FW"
                                ])
                            }
                    )
                }
            }
        }
    }

    checkpoint "Before deployment to uat"
    stage('confirm uat deploy')
    timeout(time: 20, unit: 'MINUTES') {
        input 'Deploy to UAT?'
    }

    node {
        docker.image(env.DOCKER_REGISTRY + DOCKER_IMAGE_URI).inside('--privileged') {
            withCredentials([
                    [
                            $class          : 'UsernamePasswordMultiBinding',
                            credentialsId   : 'CTS-Loon-System-ID',
                            passwordVariable: 'ARTIFACTORY_PASSWORD',
                            usernameVariable: 'ARTIFACTORY_USERNAME'
                    ],
                    [
                            $class          : 'UsernamePasswordMultiBinding',
                            credentialsId   : 'CTS-Loon-System-ID',
                            passwordVariable: 'CF_PASSWORD',
                            usernameVariable: 'CF_USERNAME'
                    ],
                    [
                            $class          : 'UsernamePasswordMultiBinding',
                            credentialsId   : 'RAVEN_PT_ACCESS',
                            passwordVariable: 'RAVEN_PASSWORD',
                            usernameVariable: 'RAVEN_USERNAME'
                    ],
                    [
                            $class       : 'StringBinding',
                            credentialsId: 'LEELA_STAGING_KEY',
                            variable     : 'LEELA_STAGING_KEY'
                    ],
                    [
                            $class       : 'StringBinding',
                            credentialsId: 'LOON_CLIENT_API_KEY_DEV',
                            variable     : 'LOON_CLIENT_API_KEY_DEV'
                    ],
                    [
                            $class       : 'StringBinding',
                            credentialsId: 'LOONELIGIBILITY_ENCRYPTION_KEY',
                            variable     : 'LOONELIGIBILITY_ENCRYPTION_KEY'
                    ],
                    [
                            $class          : 'UsernamePasswordMultiBinding',
                            credentialsId   : 'CTS_Loon_UAT_MONGODB_ID',
                            passwordVariable: 'CTS_Loon_UAT_MONGODB_PASSWORD',
                            usernameVariable: 'CTS_Loon_UAT_MONGODB_USERNAME'
                    ],
                    [
                            $class          : 'UsernamePasswordMultiBinding',
                            credentialsId   : 'CTS-Loon-UAT-AuditLog',
                            passwordVariable: 'CTS_Loon_UAT_AuditLog_PASSWORD',
                            usernameVariable: 'CTS_Loon_UAT_AuditLog_USERNAME'
                    ],
                    [
                            $class       : 'StringBinding',
                            credentialsId: 'DCF_CLIENT_KEY_DEVELOPMENT',
                            variable     : 'DCF_CLIENT_KEY_DEVELOPMENT'
                    ],
                    [
                            $class       : 'StringBinding',
                            credentialsId: 'PARAKEET_API_KEY_DEVELOPMENT',
                            variable     : 'PARAKEET_API_KEY_DEVELOPMENT'
                    ],
                    [
                            $class       : 'StringBinding',
                            credentialsId: 'ORGDATA_CLIENT_KEY',
                            variable     : 'ORGDATA_CLIENT_KEY'
                    ],
                    [
                            $class       : 'StringBinding',
                            credentialsId: 'SKETCH_CLIENT_KEY_TEST',
                            variable     : 'SKETCH_CLIENT_KEY_TEST'
                    ]

            ]) {
                stage('Shutdown DEV') {
                    serviceHelper.stopServices('ro11', 'DEV', "${CF_USERNAME}", "${CF_PASSWORD}", ["${APPLICATION_CLIENT}-dev-temp"], ORGANIZATION)
                    serviceHelper.stopServices('ro11', 'DEV', "${CF_USERNAME}", "${CF_PASSWORD}", ["${APPLICATION_SERVER}-dev-temp"], ORGANIZATION)
                }
            }
        }
    }
}