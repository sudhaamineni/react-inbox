def APPLICATION_SERVER = "loon-server"
def APPLICATION_CLIENT = "loon-client"
def ORGANIZATION = 'CTS-Loon'
def DOCKER_IMAGE_URI = '/compozed/labs/ci-base-node-eight:1.1'
def serviceHelper

node {
    stage('Cleanup WS') {
        step([$class: 'WsCleanup'])
    }
    checkout scm
    serviceHelper = load './jenkinsServicesHelper.groovy'
}

node {
    stage('Stop Services') {
        docker.image(env.DOCKER_REGISTRY + DOCKER_IMAGE_URI).inside('--privileged') {
            withCredentials([
                    [
                            $class          : 'UsernamePasswordMultiBinding',
                            credentialsId   : 'CTS-Loon-System-ID',
                            passwordVariable: 'CF_PASSWORD',
                            usernameVariable: 'CF_USERNAME'
                    ]
            ]) {
                //serviceHelper.stopServices('ro10', 'INT', "${CF_USERNAME}", "${CF_PASSWORD}", ["${APPLICATION_CLIENT}-int"], ORGANIZATION)
                serviceHelper.stopServices('ro11', 'INT', "${CF_USERNAME}", "${CF_PASSWORD}", ["${APPLICATION_CLIENT}-int"], ORGANIZATION)
                //serviceHelper.stopServices('ro10', 'INT', "${CF_USERNAME}", "${CF_PASSWORD}", ["${APPLICATION_SERVER}-int"], ORGANIZATION)
                serviceHelper.stopServices('ro11', 'INT', "${CF_USERNAME}", "${CF_PASSWORD}", ["${APPLICATION_SERVER}-int"], ORGANIZATION)

                serviceHelper.stopServices('ro11', 'DEV', "${CF_USERNAME}", "${CF_PASSWORD}", ["${APPLICATION_CLIENT}-dev"], ORGANIZATION)
                serviceHelper.stopServices('ro11', 'DEV', "${CF_USERNAME}", "${CF_PASSWORD}", ["${APPLICATION_SERVER}-dev"], ORGANIZATION)

                serviceHelper.stopServices('ro11', 'UAT', "${CF_USERNAME}", "${CF_PASSWORD}", ["${APPLICATION_CLIENT}-uat"], ORGANIZATION)
                serviceHelper.stopServices('ro11', 'UAT', "${CF_USERNAME}", "${CF_PASSWORD}", ["${APPLICATION_SERVER}-uat"], ORGANIZATION)

                serviceHelper.stopServices('ro11', 'STAGING', "${CF_USERNAME}", "${CF_PASSWORD}", ["${APPLICATION_CLIENT}-staging"], ORGANIZATION)
                serviceHelper.stopServices('ro11', 'STAGING', "${CF_USERNAME}", "${CF_PASSWORD}", ["${APPLICATION_SERVER}-staging"], ORGANIZATION)
            }
        }
    }
}
