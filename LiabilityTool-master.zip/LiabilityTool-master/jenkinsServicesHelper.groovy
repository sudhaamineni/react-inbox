def stopServices(server, space, userName, password, appNames, orgName) {
    env.server = server
    env.space = space
    env.userName = userName
    env.password = password
    env.orgName = orgName
//    sh 'cf login -a api.cf.nonprod-mpn.$server.allstate.com -u ${userName} -p ${password} -o $orgName -s ${space} --skip-ssl-validation'
    sh 'cf api https://api.cf.nonprod-mpn.$server.allstate.com --skip-ssl-validation'
    sh 'cf auth ${userName} ${password}'
    sh 'cf target -o $orgName -s ${space}'

    for(String appName : appNames) {
        env.appName = appName
        sh 'cf stop ${appName}'
    }
}

def startServices(server, space, userName, password, appNames, orgName) {
    env.server = server
    env.space = space
    env.userName = userName
    env.password = password
    env.orgName = orgName
//    sh 'cf login -a api.cf.nonprod-mpn.$server.allstate.com -u ${userName} -p ${password} -o $orgName -s ${space} --skip-ssl-validation'
    sh 'cf api https://api.cf.nonprod-mpn.$server.allstate.com --skip-ssl-validation'
    sh 'cf auth ${userName} ${password}'
    sh 'cf target -o $orgName -s ${space}'

    for(String appName : appNames) {
        env.appName = appName
        sh 'cf start ${appName}'
    }
}

return this